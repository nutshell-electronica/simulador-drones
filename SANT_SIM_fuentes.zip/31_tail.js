/* ===== MODELO: tail-sitter VTOL (ArduPilot Plane · Q_TAILSIT_ENABLE) =====
   Cuatro fases: VTOL (despegue/aterrizaje sobre la cola, control tipo multirrotor), transición a vuelo adelante,
   vuelo adelante (ala fija: reutiliza stepFixed) y transición a VTOL.
   tsAng = ángulo del eje del morro respecto a la vertical (0 = estacionario, 90° = vuelo horizontal). */
(function(){
var D_ = (typeof SD!=='undefined'?SD:require('./20_data.js'));
var deg = D_.deg, clamp = D_.clamp, G = D_.G;
var F = SM.Flight.prototype;

SM.fwNow = function(f){ return f.ac.kind==='fixed' || (f.ac.kind==='tailsitter' && f.tsMode==='fw'); };
SM.tsDefaults = {angle:45, ratFw:50, ratVt:50, angVt:0, minAlt:15, input:0};

F.tsInit = function(){ this.tsMode='vtol'; this.tsAng=0; this.tsReq='vtol'; this.tsFw=false; this.tsMsg=''; this.tsT=0; this.tsAuto=false; };

F.toggleVtol = function(){
  if(this.ac.kind!=='tailsitter') return;
  if(this.status!=='flying'){ this.tsMsg='Despega primero: la transición sólo se hace en vuelo.'; this.tsMsgT=this.t; return; }
  if(this.tsMode==='toFw'||this.tsMode==='toVt') return;
  this.tsReq=(this.tsMode==='vtol')?'fw':'vtol'; this.tsAuto=false;
};

function ctsA(fr,k,al){          /* CL y CD hasta ±180°: lineal + pérdida, mezcla con placa plana */
  var aS=fr.aMax*deg, CLm=fr.CL0+fr.CLa*aS, a=Math.abs(al), CLl=clamp(fr.CL0+fr.CLa*al,-CLm,CLm);
  var t=clamp((a-aS)/(12*deg),0,1), wgt=t*t*(3-2*t), sn=Math.sin(al);
  var CLf=1.15*Math.sin(2*al), CDf=0.06+1.25*sn*sn, CDl=fr.CD0+k*CLl*CLl;
  return {CL:(1-wgt)*CLl+wgt*CLf, CD:(1-wgt)*CDl+wgt*CDf};
}

F.stepTail = function(dt,c,rho){
  var ap=this.st.ap||{}, D=SM.tsDefaults, flying=this.status==='flying', agl=this.agl();
  if(this.tsMode==='fw'){
    if(this.landNow && this.tsReq!=='vtol'){ this.tsReq='vtol'; this.tsAuto=true; }
    if(this.rth && this.hdist()<(ap.tsRtlDist||90) && this.tsReq!=='vtol'){ this.tsReq='vtol'; this.tsAuto=true; this.rthPhase='cruise'; }
  } else if(this.tsMode==='vtol' && (this.landNow||this.rth) && this.tsReq==='fw'){ this.tsReq='vtol'; }
  if(this.tsMode==='vtol'){
    if(this.tsReq==='fw' && flying){
      var minAlt=ap.tsMinAlt||D.minAlt;
      if(agl<minAlt){ this.tsReq='vtol'; this.tsMsg='Altura insuficiente para la transición ('+agl.toFixed(0)+' m < '+minAlt+' m).'; this.tsMsgT=this.t; }
      else { this.tsMode='toFw'; this.tsT=0; this.tsAng=Math.max(0,this.pitch); this.tsMsg='Transición a vuelo adelante…'; this.tsMsgT=this.t; return this.stepTrans(dt,rho); }
    }
    var c2=c; if((ap.tsInput!==undefined?ap.tsInput:D.input)===1) c2={pitch:c.pitch,roll:c.yaw,yaw:c.roll,thr:c.thr,thrAbs:c.thrAbs};
    this.stepRotor(dt,c2,rho); this.tsFw=false; this.tsAng=Math.max(0,this.pitch);
    return;
  }
  if(this.tsMode==='toFw'||this.tsMode==='toVt') return this.stepTrans(dt,rho);
  /* vuelo adelante */
  if(this.tsReq==='vtol' && flying && !this.stalledAbort){
    var e=this.alpha+this.gamma;
    this.tsMode='toVt'; this.tsT=0; this.tsAng=clamp(Math.PI/2-e,0,Math.PI/2); this.tsFw=false; this.pitch=this.tsAng; this.tsMsg='Transición a VTOL…'; this.tsMsgT=this.t;
    return this.stepTrans(dt,rho);
  }
  this.tsFw=true; this.stepFixed(dt,c,rho);
};

F.stepTrans = function(dt,rho){
  var ac=this.ac, fr=ac.frame, w=this.world, p=this.pos, v=this.vel, m=ac.mass, W=ac.W, ap=this.st.ap||{}, D=SM.tsDefaults, nm=ac.nMotors;
  var toFw=this.tsMode==='toFw', wd=this.wcur;
  var angFw=(ap.tsAngle||D.angle)*deg, angVt=((ap.tsAngVt||0)||(ap.tsAngle||D.angle))*deg;
  var rate=(toFw?(ap.tsRatFw||D.ratFw):(ap.tsRatVt||D.ratVt))*deg;
  this.tsT+=dt;
  var ang=this.tsAng;
  if(toFw) ang=Math.min(angFw,ang+rate*dt); else ang=Math.max(angVt-0.02,ang-rate*dt);
  this.tsAng=ang;
  var sy=Math.sin(this.yaw), cy=Math.cos(this.yaw), fx=sy, fz=-cy, rx=cy, rz=sy;
  var vf=v.x*fx+v.z*fz-(wd.x*fx+wd.z*fz), vr=v.x*rx+v.z*rz-(wd.x*rx+wd.z*rz), vy=v.y-wd.y;
  var Vr=Math.max(0.1,Math.hypot(vf,vy)), uf=vf/Vr, uy=vy/Vr;
  var gam=Math.atan2(vy,vf), e=Math.PI/2-ang, al=e-gam; while(al>Math.PI) al-=2*Math.PI; while(al<-Math.PI) al+=2*Math.PI;
  var S=fr.S, AR=fr.b*fr.b/S, k=1/(Math.PI*fr.e*AR), q=0.5*rho*Vr*Vr, co=ctsA(fr,k,al);
  var L=q*S*co.CL, Dg=q*S*co.CD+0.5*rho*Vr*Vr*ac.accCd;
  var lf=-uy*L, ly=uf*L, df=-uf*Dg, dy=-uy*Dg;
  var nf=Math.sin(ang), ny=Math.cos(ang);
  var Tm1=SM.maxThrust(ac,this.V,rho), Tmax=(this.dod>1.08||this.chuteOpen)?0:Tm1*nm;
  var need=m*(G+clamp(2.5*(0-v.y),-4,4))-(ly+dy);
  var Tc=clamp(need/Math.max(ny,0.35),toFw?1.2*W:0.25*W,Tmax);
  this.sat=need/Math.max(ny,0.35)>Tmax*0.98;
  this.Tcur+=(Tc-this.Tcur)*Math.min(1,dt/0.06); var Tt=this.Tcur;
  var ax=(Tt*nf+lf+df)/m, ay=(Tt*ny+ly+dy)/m-G, ar=-1.5*vr;
  v.x+=(ax*fx+ar*rx)*dt; v.z+=(ax*fz+ar*rz)*dt; v.y+=ay*dt;
  p.x+=v.x*dt; p.y+=v.y*dt; p.z+=v.z*dt;
  this.pitch=ang; this.roll=0; this.tsFw=false;
  this.accel={x:ax*fx,y:ay+G,z:ax*fz}; this.gload=Math.hypot(ax,ay+G)/G;
  this.alpha=al; this.gamma=gam; this.Va=Vr; this.CL=co.CL; this.LoD=L/Math.max(Dg,0.01);
  /* potencia: todos los motores VTOL activos durante la transición */
  var n1=SM.rotorPower(ac,Tt/nm,rho), tl=1-0.18*Math.min(1,Vr/12);
  this.P=(Tmax>0?n1.P*tl*nm:0)/(ac.effM*ac.effE)+ac.accW+ac.avW; this.rpm=n1.n*60; this.nmax=SM.maxN(ac,this.V);
  this.thrPct=Tmax>0?Math.min(100,100*n1.n/this.nmax):0; this.Tmax=Tmax; this.TWR=Tmax/W;
  /* fin de la transición */
  var CLmax=fr.CL0+fr.CLa*fr.aMax*deg, Vs=Math.sqrt(2*W/(rho*S*CLmax)); this.Vs=Vs;
  if(toFw && ang>=angFw-1e-3 && (Vr>=0.9*Vs || this.tsT>7)){
    var Tm0=ac.ct*rho*Math.pow(SM.maxN(ac,this.V),2)*Math.pow(ac.D,4);
    this.tsMode='fw'; this.tsFw=true; this.chi=this.yaw; this.Va=Vr; this.gamma=gam; this.alpha=clamp(al,-10*deg,fr.aMax*deg*1.6);
    this.thr=clamp(Math.sqrt(Math.max(0,Tt/(Math.max(1,ac.nFw)*Math.max(Tm0,1e-3)))),0.3,1); this.roll=0;
    this.tsMsg='Vuelo adelante (FBWA)'; this.tsMsgT=this.t; this.tsReq='fw'; this.tsAuto=false;
  } else if(!toFw && ang<=angVt+1e-3){
    this.tsMode='vtol'; this.tsFw=false; this.tsReq='vtol'; this.pitch=ang; this.roll=0; this.iF=this.iR=0; this.iZ=0; this.yawRate=0;
    this.tsMsg='Modo VTOL'; this.tsMsgT=this.t;
    if(this.landNow||this.rth) this.tsAuto=false;
  }
  /* suelo */
  var gh=w.floorH(p.x,p.y,p.z)+0.02;
  if(p.y<=gh){ p.y=gh; this.crash('Impacto contra el suelo durante la transición ('+(toFw?'a vuelo adelante':'a VTOL')+'): faltó altura o empuje.'); }
};
})();
if(typeof module!=='undefined') module.exports=SM;
