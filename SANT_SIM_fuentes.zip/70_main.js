/* ===== PRINCIPAL: arranque, entradas, bucle ===== */
(function(){
var $=function(id){return document.getElementById(id);};
var clamp=SD.clamp, deg=SD.deg, ST=SIM.ST, H=SIM.hud;
var F=null, world=null, wxLive=null, sig='', paused=false, speed=1, speeds=[1,2,0.5,0.25], si=0, hangarOpen=true, showInsp=false, stepOnce=false;
var cams=['vlos','fpv','chase','top'], camNames={vlos:'A la vista (VLOS)',fpv:'FPV',chase:'Seguimiento',top:'Cenital'};
SIM.camMode='vlos'; var zoomV=1, landShown=false, hudHidden=false;
var cmd={pitch:0,roll:0,yaw:0,thr:0}, keys={}, acc=0, HZ=1/120;
var lastHud=0, lastNoise=0;

/* ---------- inicio / reinicio ---------- */
function stFromUI(){
  var r=ST.rf;
  return {seed:(Math.random()*1e6)|0, ctrlLink:SD.byId(SD.CTRL_LINKS,r.cl), ctrlPw:r.cp, ctrlAnt:SD.byId(SD.GANT,r.ca), vidLink:SD.byId(SD.VID_LINKS,r.vl), vidPw:r.vp, vidAnt:SD.byId(SD.GANT,r.va),
          tod:ST.tod, fsLink:r.fl, fsBatt:r.fb, rthAlt:r.alt, jam:ST.jam, rfNoise:ST.rfNoise, ap:commAp()};
}
function commAp(){ var cm=ST.cfg.comm?SD.byId(SD.COMM,ST.cfg.comm):null, e=SIM.apEff(); if(!cm||!cm.ap) return e; return Object.assign({},cm.ap,e||{}); }
function applyLive(){
  if(!F) return;
  var s=stFromUI(); s.seed=F.st.seed; F.st=s;
  wxLive=Object.assign({},ST.wx); F.wx=wxLive; F.wind.wx=wxLive; world.elev=SIM.elev();
  timeSetup(); R3D.setWeather(wxLive,ST.tod,world.sun);
}
function timeSetup(){ world.timeMs0=SIM.flightMs(); SIM.syncTod(); world.sun=SIM.sunAt(world.timeMs0); }
function sigNow(){ return JSON.stringify({c:ST.cfg,s:ST.scn,b:ST.birds,k:ST.kites,p:ST.people,q:ST.comp}); }
function newFlight(){
  var V=SIM.validate(); if(V.errors.length) return false;
  world=SW.make(ST.scn); world.elev=SIM.elev();
  wxLive=Object.assign({},ST.wx);
  SW.addActors(world,{birds:ST.birds,kites:ST.kites,people:ST.people,seed:(Math.random()*1e6)|0},wxLive);
  timeSetup();
  F=new SM.Flight(V.ac,world,wxLive,stFromUI());
  R3D.loadWorld(world); R3D.buildDrone(V.ac); R3D.setWeather(wxLive,ST.tod,world.sun);
  H.setRaster(SIM.mapRaster(world,512,world.mapExt||SW.EXT)); H.setZoom(world.mapZoom||(world.mapExt?45:1000));
  sig=sigNow();
  var cam=SIM.camMode; if(cam==='fpv' && !hasCam()) cam='vlos'; setCam(cam);
  keysPanel(); compInit(); resetCommon(); return true;
}
function resetCommon(){
  compReset();
  H.logClear(); R3D.clearTrail(); cmd={pitch:0,roll:0,yaw:0,thr:0}; acc=0; landShown=false; hideMsg(); paused=false; syncPause();
  if(F){ var h=F.world.home; R3D.update(F,0,ropts()); }
}
/* ---------- modo competición ---------- */
var COMP={rings:[],st:null,seed:0,best:0};
function compOn(){ return COMP.rings.length>0&&COMP.st; }
function compKey(){ return 'santsim_comp_'+ST.scn+'_'+COMP.rings.length+(F&&F.ac.kind==='fixed'?'_f':'_m'); }
function compBest(){ try{ return +localStorage.getItem(compKey())||0; }catch(e){ return 0; } }
function fmtT(t){ var m=Math.floor(t/60), s=t-m*60; return (m<10?'0':'')+m+':'+(s<10?'0':'')+s.toFixed(1); }
function compInit(){
  COMP.rings=[]; COMP.st=null; R3D.setRings([]);
  if(!(ST.comp&&ST.comp.on)){ $('compHud').style.display='none'; return; }
  COMP.seed=(Math.random()*1e9)|0;
  COMP.rings=SW.compGen(world,{n:ST.comp.n,fixed:F.ac.kind==='fixed',seed:COMP.seed});
  R3D.setRings(COMP.rings);
}
function compReset(){
  if(!COMP.rings.length) return;
  COMP.st=SW.compNew(); COMP.best=compBest(); R3D.updateRings(0,false,0); compHud();
}
function compTick(dt){
  var s=COMP.st; if(!s) return;
  if(F.status==='crashed'){ if(!s.failed&&!s.done){ s.failed=true; s.running=false; } return; }
  var fl=F.status==='flying'||(F.status==='rolling'&&F.hspeed()>1);
  var r=SW.compStep(s,COMP.rings,F.pos,dt,fl);
  if(r>0){ AUD.event(r===2?'ringend':'ring'); ringFx(r===2,COMP.st.idx-1); } else if(r<0){ AUD.event('miss'); ringFx(false,-1,true); }
  if(r===2) compFinish();
}
function ringFx(fin,idx,bad){
  var f=$('ringFlash'), p=$('ringPop'); if(!f) return;
  f.className=''; p.className=''; void f.offsetWidth;
  f.className=(bad?'bad':(fin?'fin':'ok'))+' go'; p.className=(bad?'bad':(fin?'fin':'ok'))+' go';
  p.textContent=bad?'POR FUERA':(fin?'¡COMPLETADO!':'ARO '+(idx+1)+' / '+COMP.rings.length);
  if(!bad&&idx>=0) R3D.ringFlash(idx,performance.now(),fin);
}
function compFinish(){
  var s=COMP.st, n=COMP.rings.length, prev=COMP.best, rec=!prev||s.t<prev-1e-6;
  if(rec){ try{ localStorage.setItem(compKey(),String(s.t)); }catch(e){} COMP.best=s.t; }
  var sp=''; s.splits.forEach(function(t,i){ sp+=(i?' · ':'')+(i+1)+': '+fmtT(t); });
  showMsg('ok','RECORRIDO COMPLETADO','<b>'+n+(n===1?' aro':' aros')+' en '+fmtT(s.t)+'</b>'+(rec?' <b style="color:var(--green)">· ¡Nuevo récord!</b>':'')+'<br>Nivel '+SW.compLevel(n)+(prev&&!rec?' · Mejor tiempo '+fmtT(prev):'')+(s.miss?' · Aros fallados por fuera: '+s.miss:'')+'<br><small>Parciales — '+sp+'</small>','Seguir volando');
}
function compHud(){
  var el=$('compHud'); if(!compOn()||hangarOpen){ el.style.display='none'; return; }
  var s=COMP.st, R=COMP.rings, n=R.length, h='';
  el.style.display='block'; el.className='panel'+(s.done?' fin':(s.failed?' bad':''));
  var dots=''; for(var i=0;i<n;i++) dots+='<i class="'+(i<s.idx?'ok':(i===s.idx&&!s.done?'nx':''))+'"></i>';
  var nx='';
  if(s.done) nx='<b style="color:var(--green)">¡Completado!</b>';
  else if(s.failed) nx='<b style="color:var(--red)">Siniestro · '+s.idx+' de '+n+' aros</b>';
  else { var g=R[s.idx], dx=g.x-F.pos.x, dy=g.y-F.pos.y, dz=g.z-F.pos.z; nx='Aro '+(s.idx+1)+': <b>'+Math.round(Math.hypot(dx,dy,dz))+' m</b> · '+(dy>=0?'▲ +':'▼ ')+Math.round(dy)+' m'+((SIM.camMode!=='vlos')?'':'')+(s.t-s.missT<2.5&&s.miss?' · <span style="color:var(--red)">¡por fuera!</span>':''); }
  el.innerHTML='<div class="ct">Modo competición · '+SW.compLevel(n)+'</div><div class="cr"><div class="cn">'+s.idx+'<small> / '+n+'</small></div><div class="tm">'+fmtT(s.t)+'</div></div><div class="dots">'+dots+'</div><div class="nxt">'+nx+'</div>'+(COMP.best?'<div class="bst">Mejor: '+fmtT(COMP.best)+'</div>':'');
}
SIM.compDrawMap=function(g,k){
  if(!compOn()) return; var s=COMP.st;
  COMP.rings.forEach(function(r,i){
    var tx=-r.nz*r.r, tz=r.nx*r.r, passed=i<s.idx||s.done, nxt=!s.done&&i===s.idx;
    g.strokeStyle=passed?'#1b9a52':(nxt?'#e6a800':'#e0661a'); g.lineWidth=(nxt?4:3)/k; g.lineCap='round';
    g.beginPath(); g.moveTo(r.x-tx,r.z-tz); g.lineTo(r.x+tx,r.z+tz); g.stroke();
    g.fillStyle='#14283a'; g.font='bold '+(10/k)+'px sans-serif'; g.fillText(String(i+1),r.x+4/k,r.z-4/k); });
  g.lineCap='butt';
};
function compMark(g,W,Hh){
  if(!compOn()||COMP.st.done||COMP.st.failed) return;
  var R=COMP.rings[COMP.st.idx], pr=R3D.project(new THREE.Vector3(R.x,R.y,R.z));
  var dist=Math.hypot(R.x-F.pos.x,R.y-F.pos.y,R.z-F.pos.z), inFront=pr.z<1, m=34;
  var on=inFront&&pr.x>m&&pr.x<W-m&&pr.y>m&&pr.y<Hh-m;
  g.lineWidth=2; g.strokeStyle='#a67c00'; g.fillStyle='#ffd23f'; g.font='bold 12px monospace';
  if(on){ if(dist>25){ g.beginPath(); g.arc(pr.x,pr.y,16,0,6.3); g.stroke(); } g.fillStyle='#14283a'; g.fillText((COMP.st.idx+1)+' · '+Math.round(dist)+' m',pr.x+20,pr.y-14); }
  else { var cx=W/2, cy=Hh/2, vx=pr.x-cx, vy=pr.y-cy; if(!inFront){ vx=-vx; vy=-vy; } var L=Math.hypot(vx,vy)||1; vx/=L; vy/=L;
    var ex=Math.max(-1e9,Math.min(1e9,0)), t=Math.min((W/2-m)/Math.abs(vx||1e-6),(Hh/2-m)/Math.abs(vy||1e-6)), px=cx+vx*t, py=cy+vy*t;
    g.save(); g.translate(px,py); g.rotate(Math.atan2(vy,vx)); g.beginPath(); g.moveTo(14,0); g.lineTo(-10,-11); g.lineTo(-10,11); g.closePath(); g.fill(); g.stroke(); g.restore();
    g.fillStyle='#14283a'; g.fillText(Math.round(dist)+' m',px-18-vx*8,py+4-vy*14); }
}
function resetFlight(){ if(!F) return; applyLive(); F.reset(); resetCommon(); }
function hasCam(){ return F && (F.ac.has('camfpv')||F.ac.has('camhd')||F.ac.has('camir')); }
(function(){ var H=SIM.PAD.hooks; function ok(){ return F&&!hangarOpen; }
  H.cam=function(){ if(ok()) nextCam(); }; H.pause=function(){ if(ok()) togglePause(); }; H.reset=function(){ if(ok()) resetFlight(); };
  H.mode=function(){ if(ok()) F.toggleMode(); }; H.chute=function(){ if(ok()) F.deployChute(); }; H.fail=function(){ if(ok()) F.toggleFail(); };
  H.rth=function(on){ if(!ok()) return; if(on){ if(!F.rth&&(F.status==='flying'||F.status==='rolling')) F.startRTH('Emisora'); } else if(F.rth) F.cancelRTH(); };
  H.land=function(on){ if(!ok()) return; if(on){ if(!F.landNow) F.toggleLand(); } else if(F.landNow&&F.landUser) F.toggleLand(); };
})();
function setCam(m){ SIM.camMode=m; R3D.setCamMode(m); $('osd').style.display=(m==='fpv')?'block':'none'; if(m!=='fpv'){ $('noise').style.opacity=0; $('vidlost').style.display='none'; } R3D.setUptilt(F&&F.ac.frame.id==='quad-5'?32:12); }
function nextCam(){ var i=cams.indexOf(SIM.camMode), n=i; do{ n=(n+1)%cams.length; }while(cams[n]==='fpv'&&!hasCam()); setCam(cams[n]); }
function ropts(){ return {trail:ST.trail, zoom:zoomV, gimbal:F&&F.ac.has('camhd')&&!F.ac.has('camfpv'), windX:F?F.wcur.x:0, windZ:F?F.wcur.z:0, topH:90}; }

function openHangar(){ hangarOpen=true; AUD.hush(); $('hangar').style.display='flex'; paused=true; syncPause(); SIM.validate(); $('bFly').textContent=(F&&sig===sigNow())?'Aplicar y continuar ▶':'Volar ▶'; }
function closeHangar(){ hangarOpen=false; $('hangar').style.display='none'; }
function flyPressed(){
  var same=F&&sig===sigNow();
  if(same){ applyLive(); closeHangar(); paused=false; syncPause(); }
  else if(newFlight()){ closeHangar(); }
  SIM.save();
}
function syncPause(){ $('bPause').textContent=paused?'Reanudar':'Pausa'; $('inspector').style.display=(paused&&showInsp&&!hangarOpen)?'block':'none'; if(paused) renderInspector(); }
function togglePause(){ if(hangarOpen||!F) return; paused=!paused; if(paused) showInsp=true; syncPause(); }
function hideMsg(){ $('msg').style.display='none'; }
function showMsg(cls,title,html,btn){ var m=$('msg'); m.className=cls; m.style.display='block'; m.querySelector('h2').textContent=title; m.querySelector('p').innerHTML=html; $('msgBtn').textContent=btn||'Reiniciar vuelo'; }

/* ---------- entradas ---------- */
var CODES={KeyW:1,KeyA:1,KeyS:1,KeyD:1,ArrowUp:1,ArrowDown:1,ArrowLeft:1,ArrowRight:1,Space:1};
window.addEventListener('keydown',function(e){
  if(e.target&&/INPUT|SELECT|TEXTAREA/.test(e.target.tagName)&&e.code!=='Escape'&&e.code!=='F1') { if(e.code==='Space') e.preventDefault(); return; }
  if(CODES[e.code]) e.preventDefault();
  if(e.code==='F1'){ e.preventDefault(); toggleHelp(); return; }
  if(e.code==='Escape'){ if($('help').style.display==='block'){ toggleHelp(); return; } if(hangarOpen){ if(F){ closeHangar(); paused=false; syncPause(); } } else openHangar(); return; }
  AUD.init();
  if(hangarOpen||!F) return;
  keys[e.code]=true;
  if(e.repeat) return;
  switch(e.code){
    case 'Space': case 'KeyP': togglePause(); break;
    case 'KeyN': if(paused){ stepOnce=true; } break;
    case 'KeyR': resetFlight(); break;
    case 'KeyC': nextCam(); break;
    case 'Digit1': setCam('vlos'); break; case 'Digit2': if(hasCam()) setCam('fpv'); break; case 'Digit3': setCam('chase'); break; case 'Digit4': setCam('top'); break;
    case 'KeyM': H.zoomMap(0); break;
    case 'Equal': case 'NumpadAdd': H.zoomMap(-1); break; case 'Minus': case 'NumpadSubtract': H.zoomMap(1); break;
    case 'KeyB': F.toggleLand(); break;
    case 'KeyH': if(F.rth) F.cancelRTH(); else if(F.status==='flying'||F.status==='rolling') F.startRTH('Manual'); break;
    case 'KeyQ': F.toggleMode(); break;
    case 'KeyF': F.toggleFail(); break;
    case 'KeyX': F.deployChute(); break;
    case 'KeyT': si=(si+1)%speeds.length; speed=speeds[si]; break;
    case 'KeyI': showInsp=!showInsp; syncPause(); break;
    case 'KeyU': hudHidden=!hudHidden; $('stage').classList.toggle('hide-hud',hudHidden); break;
    case 'KeyG': ST.trail=!ST.trail; break;
    case 'KeyL': H.lidarToggle(); break;
    case 'KeyK': AUD.toggle(); syncSnd(); break;
    case 'KeyZ': zoomV=zoomV>=4?1:zoomV*2; break;
  }
});
window.addEventListener('keyup',function(e){ keys[e.code]=false; });
window.addEventListener('blur',function(){ keys={}; });
$('map').addEventListener('wheel',function(e){ e.preventDefault(); H.zoomMap(e.deltaY>0?1:-1); },{passive:false});
$('map').addEventListener('click',function(){ H.zoomMap(0); });
$('bHangar').onclick=function(){ hangarOpen?(F&&(closeHangar(),paused=false,syncPause())):openHangar(); };
function syncSnd(){ $('bSnd').textContent=AUD.isMuted()?'Sonido: no':'Sonido: sí'; }
$('bSnd').onclick=function(){ AUD.init(); AUD.toggle(); syncSnd(); }; syncSnd();
$('bPause').onclick=togglePause; $('bReset').onclick=function(){ if(!hangarOpen) resetFlight(); }; $('bCam').onclick=function(){ if(!hangarOpen&&F) nextCam(); };
$('bFly').onclick=function(){ AUD.init(); flyPressed(); }; $('msgBtn').onclick=function(){ if(F&&(F.status==='crashed')) resetFlight(); else hideMsg(); };
$('bPrev').onclick=function(){ var m=SW.LIST.filter(function(x){return x.id===ST.scn;})[0]; ST.wxId=m.wx; ST.wx=Object.assign({},SD.WX[m.wx]); ST.elevOv=null; ST.jam=false; ST.rfNoise=0; SIM.initHangar(); SIM.validate(); };
$('bHelp').onclick=function(){ toggleHelp(); };
window.addEventListener('resize',function(){ R3D.resize(); });

SIM.hangarOpen=function(){ return hangarOpen; };
var analog={yaw:0,thr:0,roll:0,pitch:0};
function targetCmd(){
  var t={pitch:(keys.ArrowUp?1:0)-(keys.ArrowDown?1:0), roll:(keys.ArrowRight?1:0)-(keys.ArrowLeft?1:0), yaw:(keys.KeyD?1:0)-(keys.KeyA?1:0), thr:(keys.KeyW?1:0)-(keys.KeyS?1:0)};
  for(var k in analog) if(analog[k]!==0) t[k]=analog[k];
  var P=SIM.PAD&&SIM.PAD.out; t._p={};
  if(P&&P.on){ ['pitch','roll','yaw','thr'].forEach(function(k){ if(t[k]===0){ t[k]=P[k]; t._p[k]=1; } }); t._abs=(t._p.thr?P.thrAbs:undefined); }
  return t;
}
function slew(dt){
  var t=targetCmd(); ['pitch','roll','yaw','thr'].forEach(function(k){ if(t._p[k]){ cmd[k]=t[k]; return; } var r=(t[k]===0)?7:3.2; var d=t[k]-cmd[k]; var m=r*dt; cmd[k]+=Math.abs(d)<m?d:Math.sign(d)*m; });
  cmd.thrAbs=t._abs;
}

/* ---------- inspector (datos congelados) ---------- */
function rows(d,f,w,wx){
  var ac=f.ac, c=d.c, v=d.v, p=f.pos, vv=f.vel, T=function(x,n){return (+x).toFixed(n);};
  var R=[['sec','Estado y movimiento'],
   ['Tiempo de vuelo',T(f.t,1)+' s'],['Estado',f.status+(f.rth?' · RTH':'')],
   ['Posición x / z',T(p.x,1)+' / '+T(p.z,1)+' m'],['Altura AGL / y',T(d.agl,2)+' / '+T(p.y,2)+' m'],
   ['Vel. x / z',T(vv.x,2)+' / '+T(vv.z,2)+' m/s'],['Vel. vertical',T(vv.y,2)+' m/s'],
   ['Vel. suelo',T(d.gs,2)+' m/s ('+T(d.gs*3.6,1)+' km/h)'],['Vel. aire',T(d.as,2)+' m/s'],
   ['Cabeceo / alabeo',T(-f.pitch/deg,1)+' / '+T(f.roll/deg,1)+' °'],['Rumbo',T(d.heading,1)+' °'],
   ['Factor de carga',T(f.gload,2)+' g'],['Modo de vuelo',ac.kind==='fixed'?'Estabilizado':(f.gpsActive?'GPS (retención)':'ATTI')],
   ['sec','Propulsión y energía'],
   ['Empuje actual',T(f.Tcur,2)+' N'],['Empuje máx.',T(f.Tmax||0,2)+' N'],
   ['Empuje / peso',T(d.twr,2)],['Gas motores',T(d.thr,1)+' %'],
   ['Velocidad de giro',T(f.rpm,0)+' rpm'],['Potencia eléctrica',T(f.P,1)+' W'],
   ['Corriente total',T(f.I,2)+' A'],['Corriente / ESC',T(d.iEsc,1)+' A de '+ac.cfg.esc+' A'],
   ['Tensión batería',T(f.V,2)+' V'],['Tensión por celda',T(d.cellV,3)+' V'],
   ['Capacidad usada',T(f.ahUsed*1000,0)+' mAh'],['Descarga (DoD)',T(f.dod*100,1)+' %'],
   ['Autonomía restante',(d.remMin>=99?'—':T(d.remMin,1)+' min')],['Peso / masa',T(ac.W,2)+' N / '+T(ac.mass*1000,0)+' g']];
  if(ac.kind==='fixed') R.push(['sec','Aerodinámica (ala fija)'],['Áng. de ataque',T(f.alpha/deg,1)+' °'],['Áng. de trayectoria',T(f.gamma/deg,1)+' °'],['Coef. sustentación CL',T(f.CL,2)],['Finura L/D',T(f.LoD,1)],['Vel. pérdida Vs',T(f.Vs||0,1)+' m/s'],['Estado de ala',f.stalled?'EN PÉRDIDA':'normal'],['Vne',ac.frame.vne+' m/s']);
  R.push(['sec','Atmósfera y viento'],
   ['Viento medio',T(d.windMean,2)+' m/s'],['Ráfaga',T(d.gust,2)+' m/s'],
   ['Viento total en dron',T(d.windSp,2)+' m/s'],['Componente vertical',T(f.wcur.y,2)+' m/s'],
   ['Procedencia',T(d.windFrom,0)+' °'],['Beaufort (medio)',d.beauf],
   ['Densidad del aire',T(d.rho,4)+' kg/m³'],['Presión',T(f.atm.p,1)+' hPa'],
   ['Temperatura',T(d.temp,1)+' °C'],['Altitud de densidad',T(d.densAlt,0)+' m'],
   ['Visibilidad',T(wx.vis,1)+' km'],['Lluvia',T(wx.rain,0)+' mm/h']);
  if(f.lidar&&f.lidar.any){ R.push(['sec','Sensores de distancia (láser)']); var nm={f:'Delante',b:'Detrás',l:'Izquierda',r:'Derecha',u:'Techo',d:'Suelo'}; Object.keys(f.lidar.rf).forEach(function(k){ var r=f.lidar.rf[k]; R.push(['Telémetro '+nm[k], r.d===null?'fuera de alcance (>'+r.max.toFixed(0)+' m)':T(r.d,3)+' m · '+r.label]); }); if(f.lidar.scan) R.push(['LiDAR 360°: mín.',(f.lidar.min>=99?'—':T(f.lidar.min,2)+' m')],['Puntos en el mapa',f.mapPts.length/2]); }
  R.push(['sec','Radioenlace de mando · balance de potencia'],
   ['Distancia 3D',T(c.d,0)+' m'],['Elevación desde tierra',T(c.elev,1)+' °'],
   ['Potencia TX',T(c.pt,1)+' dBm'],['Ganancia antena dron',T(c.gt,1)+' dBi'],
   ['Ganancia ant. tierra (patrón)',T(c.gr,1)+' dBi'],['Pérdida espacio libre',T(c.fs,1)+' dB'],
   ['Pérdida por obstáculos',T(c.obst,1)+' dB'],['Atenuación por lluvia',T(c.rain,2)+' dB'],
   ['Pérdidas de cable',T(c.cable,1)+' dB'],['Ruido de RF extra',T(c.noise,1)+' dB'],
   ['Potencia recibida',T(c.prx,1)+' dBm'],['Sensibilidad efectiva',T(c.sens,1)+' dBm'],
   ['Margen de enlace',T(c.margin,1)+' dB'],['Alcance en espacio libre',T(c.free/1000,2)+' km'],
   ['Despejo 1.ª zona Fresnel',c.clear>=0.6?'libre ('+T(c.clear,2)+'×F1)':(c.clear>0?'parcial ('+T(c.clear,2)+'×F1)':'OBSTRUIDA')],['Radio F1 en el punto medio',T(0.5*Math.sqrt(300/SD.byId(SD.CTRL_LINKS,ST.rf.cl).f*c.d),1)+' m'],
   ['sec','Radioenlace de vídeo'],
   ['Frecuencia',T(f.st.vidLink.f,0)+' MHz'],['Pérdida espacio libre',T(v.fs,1)+' dB'],['Pérdida obstáculos',T(v.obst,1)+' dB'],['Potencia recibida',T(v.prx,1)+' dBm'],['Margen de enlace',T(v.margin,1)+' dB'],
   ['sec','GNSS y límites normativos'],
   ['Satélites visibles',d.sats],['HDOP',d.sats?T(d.hdop,2):'—'],
   ['Error de posición est.',d.sats?T((ac.has('rtk')?0.03:1.5)*d.hdop,2)+' m':'sin fix'],['Límite VLOS',T(d.vlos,0)+' m'],
   ['Dist. a obstáculo',T(f.sens.obsDist,1)+' m'],['Obstáculo',f.sens.obsLabel||'—']);
  return R;
}
function renderInspector(){
  if(!F||!paused) return;
  var d=H.data(F,world,wxLive), R=rows(d,F,world,wxLive), cells={};
  var html='<div class="ph"><span>Datos del instante · t = '+F.t.toFixed(2)+' s</span><span><button class="btn" id="iCsv" style="padding:1px 8px">CSV</button> <button class="btn" id="iStep" style="padding:1px 8px">Paso +0,1 s (N)</button></span></div><table>';
  var pend=null;
  R.forEach(function(r){
    if(r[0]==='sec'){ if(pend){ html+='<tr><td>'+pend[0]+'</td><td>'+pend[1]+'</td><td></td><td></td></tr>'; pend=null; } html+='<tr class="sec"><td colspan="4">'+r[1]+'</td></tr>'; }
    else if(pend){ html+='<tr><td>'+pend[0]+'</td><td>'+pend[1]+'</td><td>'+r[0]+'</td><td>'+r[1]+'</td></tr>'; pend=null; } else pend=r;
  });
  if(pend) html+='<tr><td>'+pend[0]+'</td><td>'+pend[1]+'</td><td></td><td></td></tr>';
  var el=$('inspector'); el.innerHTML=html+'</table>';
  var cs=el.querySelector('#iCsv'); if(cs) cs.onclick=function(){ var b=new Blob([H.csv()],{type:'text/csv;charset=utf-8'}), a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='vuelo_santsim.csv'; document.body.appendChild(a); a.click(); setTimeout(function(){document.body.removeChild(a);},100); };
  var sp=el.querySelector('#iStep'); if(sp) sp.onclick=function(){ stepOnce=true; };
  /* resaltado de valores críticos en la tabla */
  var warn={'Margen de enlace':d.c.margin<6?'c':(d.c.margin<12?'w':''),'Satélites visibles':d.sats<6?'c':(d.sats<9?'w':''),'Empuje / peso':d.twr<1.3?'c':'','Descarga (DoD)':d.batt<15?'c':(d.batt<30?'w':'')};
  el.querySelectorAll('tr:not(.sec)').forEach(function(tr){ var t=tr.children; for(var i=0;i<4;i+=2){ var k=t[i]&&t[i].textContent; if(k&&warn[k]) t[i+1].className=warn[k]; } });
}

/* ---------- ayuda ---------- */
function toggleHelp(){
  var h=$('help'); if(h.style.display==='block'){ h.style.display='none'; return; }
  h.querySelector('.in').innerHTML='<h2>AYUDA · CONTROLES</h2><p>Controles simplificados con el teclado. En multirrotores y helicópteros los mandos son de <b>velocidad</b> (modo GPS): al soltarlos el dron frena y mantiene la posición y la altura. Sin GNSS o con <kbd>Q</kbd> pasa a <b>ATTI</b>: los mandos inclinan el dron y el viento lo arrastra.</p>'
  +'<h4>Pilotaje</h4><table><tr><td><kbd>W</kbd> / <kbd>S</kbd></td><td>Multirrotor: subir / bajar. Ala fija: más / menos gas (el gas se mantiene).</td></tr><tr><td><kbd>A</kbd> / <kbd>D</kbd></td><td>Girar a izquierda / derecha (guiñada). En ala fija: timón de dirección.</td></tr><tr><td><kbd>↑</kbd> <kbd>↓</kbd></td><td>Multirrotor: avanzar / retroceder. Ala fija: morro abajo / morro arriba.</td></tr><tr><td><kbd>←</kbd> <kbd>→</kbd></td><td>Desplazamiento lateral. Ala fija: alabeo (inclinar para virar).</td></tr></table>'
  +'<h4>Simulación</h4><table><tr><td><kbd>Espacio</kbd> / <kbd>P</kbd></td><td>Pausa: congela todo y muestra los datos del instante (CSV, paso a paso con <kbd>N</kbd>).</td></tr><tr><td><kbd>R</kbd></td><td>Reiniciar el vuelo (mismas condiciones).</td></tr><tr><td><kbd>Esc</kbd></td><td>Hangar: cambiar dron, meteorología, escenario y radio.</td></tr><tr><td><kbd>T</kbd></td><td>Velocidad de simulación 1× / 2× / ½× / ¼×.</td></tr><tr><td><kbd>C</kbd> o <kbd>1</kbd>–<kbd>4</kbd></td><td>Cámara: a la vista · FPV · seguimiento · cenital. <kbd>Z</kbd> zoom en vista a la vista.</td></tr><tr><td><kbd>M</kbd> <kbd>+</kbd> <kbd>−</kbd></td><td>Zoom del mapa (también con la rueda).</td></tr><tr><td><kbd>I</kbd> <kbd>U</kbd> <kbd>G</kbd> <kbd>L</kbd></td><td>Inspector · ocultar paneles · estela · panel de distancias LiDAR.</td></tr><tr><td><kbd>K</kbd></td><td>Sonido sí / no (motores, viento, lluvia, impactos y avisos; sintetizado, se silencia en pausa).</td></tr></table>'
  +'<h4>Emisora real (USB, cable o dongle)</h4><p>Conecta la emisora en modo «USB Joystick (HID)», abre la pestaña <b>Emisora real</b> del hangar y mueve un stick: se detecta sola. Elige un perfil (AETR, TAER o mando de consola), pulsa «Detectar» para asignar ejes e interruptores y «Calibrar» si hace falta. Chrome o Edge recomendados.</p>'
  +'<h4>Modo competición</h4><p>Activa «Modo competición» en la pestaña <b>Escenario</b> y elige de 1 a 20 aros. Pasa por ellos en orden: el siguiente brilla en amarillo, los superados se ponen verdes y las flechas te indican hacia dónde está. El cronómetro empieza al despegar y se para en el último aro. Se guarda tu mejor tiempo por escenario y número de aros. <kbd>R</kbd> repite el mismo recorrido; un vuelo nuevo genera otro.</p>'
  +'<h4>Sistemas de a bordo</h4><table><tr><td><kbd>H</kbd></td><td>Regreso a casa (RTH) on/off. Requiere GNSS.</td></tr><tr><td><kbd>B</kbd></td><td>Aterrizaje suave asistido en el punto donde estés (también fuera de pista). Mover el acelerador lo cancela.</td></tr><tr><td><kbd>Q</kbd></td><td>Alternar GPS ↔ ATTI (multirrotores).</td></tr><tr><td><kbd>F</kbd></td><td>Provocar un fallo de motor (observa la redundancia de 3, 4, 6 y 8 rotores).</td></tr><tr><td><kbd>X</kbd></td><td>Paracaídas (si está instalado): corta motores y frena la caída.</td></tr></table>'
  +'<h4>Cómo leer los avisos</h4><p>Valores y alertas en <b style="color:#c27a00">ámbar</b> son avisos; en <b style="color:#c0272d">rojo parpadeante</b> son críticos. El mapa muestra la zona VLOS (ámbar) y el alcance teórico del enlace en espacio libre (magenta): la diferencia con la realidad es la pérdida por obstáculos, lluvia, ruido y patrón de antena.</p>'
  +'<p style="margin-top:12px"><button class="btn pri" onclick="document.getElementById(\'help\').style.display=\'none\'">Cerrar</button></p>';
  h.style.display='block';
}

/* ---------- vídeo FPV ---------- */
function videoFx(d,now){
  if(SIM.camMode!=='fpv'){ return; }
  var vm=d.v.margin, analog=F.st.vidLink.analog, a=0, lost=vm<0;
  if(analog) a=vm>=14?0:Math.pow(clamp((14-vm)/14,0,1),1.3)*0.85; else a=vm>=5?0:(vm>=0?0.25:1);
  if(lost) a=1;
  $('noise').style.opacity=a; $('vidlost').style.display=lost?'block':'none';
  var cv=$('noise'); if(a>0 && now-lastNoise>60 && !paused){ lastNoise=now; var g=cv.getContext('2d'), im=g.createImageData(cv.width,cv.height), dd=im.data; for(var i=0;i<dd.length;i+=4){ var v=(Math.random()*255)|0; dd[i]=dd[i+1]=dd[i+2]=v; dd[i+3]=255; } g.putImageData(im,0,0); if(analog&&!lost){ g.fillStyle='rgba(0,0,0,.5)'; g.fillRect(0,(Math.random()*cv.height)|0,cv.width,2); } }
  var m=d.v; $('osd').innerHTML='V '+d.V.toFixed(1)+'  A '+d.I.toFixed(0)+'  ·  ALT '+d.agl.toFixed(0)+' m  ·  '+(d.gs*3.6).toFixed(0)+' km/h  ·  ↑'+d.vz.toFixed(1)+'<br>'+'RSSI '+d.c.prx.toFixed(0)+' dBm  ·  SAT '+d.sats+'  ·  '+F.mode+(F.rth?' RTH':'')+'  ·  '+Math.round(d.dist)+' m';
}
function markOverlay(d){
  var cv=$('mark'), c=cv.parentNode, W=c.clientWidth, Hh=c.clientHeight; if(cv.width!==W||cv.height!==Hh){ cv.width=W; cv.height=Hh; }
  var g=cv.getContext('2d'); g.clearRect(0,0,W,Hh);
  if(hangarOpen||!F) return;
  var pr=R3D.project(R3D.dronePos());
  if(SIM.camMode==='vlos'&&pr.z<1){
    var dist=Math.max(1,Math.hypot(F.pos.x-world.home.x,F.pos.y-(world.homeY+1.75),F.pos.z-world.home.z));
    var ang=F.ac.frame.dim/dist, px=ang/(R3D.camera().fov*deg)*Hh;
    var vis=Math.max(0,1-dist/Math.max(60,Math.min(wxLive.vis*1000, d.vlos*1.4)));
    if(px<26){ g.strokeStyle='#b0245d'; g.lineWidth=1.5; g.beginPath(); g.arc(pr.x,pr.y,16,0,6.3); g.stroke(); g.fillStyle='#b0245d'; g.font='11px monospace'; g.fillText(dist.toFixed(0)+' m · '+(F.agl()).toFixed(0)+' m alt',pr.x+20,pr.y+4); g.fillText('tamaño aparente '+(ang*1000).toFixed(2)+' mrad',pr.x+20,pr.y+18); }
  }
  compMark(g,W,Hh);
  /* marcador de casa */
  var hv=new THREE.Vector3(world.home.x,world.homeY+3,world.home.z), hp=R3D.project(hv);
  if(SIM.camMode!=='vlos'&&hp.z<1&&hp.x>0&&hp.x<W&&hp.y>0&&hp.y<Hh){ g.strokeStyle='#d99500'; g.fillStyle='#f5c842'; g.lineWidth=1.5; g.beginPath(); g.moveTo(hp.x,hp.y); g.lineTo(hp.x-6,hp.y-12); g.lineTo(hp.x+6,hp.y-12); g.closePath(); g.fill(); g.stroke(); g.fillStyle='#14283a'; g.font='bold 10px sans-serif'; g.fillText('CASA',hp.x-12,hp.y-16); }
}

/* ---------- panel de teclas y chips ---------- */
function keysPanel(){ var _t=$('tbChute'); if(_t) _t.style.display=(F&&F.ac.has('chute'))?'':'none';
  var fx=F&&F.ac.kind==='fixed';
  $('keys').innerHTML=(fx?'<div><b>W / S</b>gas + / −</div><div><b>↑ ↓</b>morro abajo / arriba</div><div><b>← →</b>alabeo (virar)</div><div><b>A / D</b>timón</div>':'<div><b>W / S</b>subir / bajar</div><div><b>A / D</b>girar</div><div><b>↑ ↓ ← →</b>desplazar</div>')
   +'<div><b>Espacio</b>pausa · <kbd>N</kbd> paso</div><div><b>C</b>cámara · <kbd>H</kbd> RTH · <kbd>R</kbd> reiniciar</div><div><b>Esc</b>hangar · <kbd>F1</kbd> ayuda</div>';
}
$('chips').addEventListener('click',function(e){ var b=e.target.closest&&e.target.closest('button[data-cam]'); if(b&&!b.disabled&&F&&!hangarOpen) setCam(b.dataset.cam); });
function chips(d){
  var s=[]; var st={ground:'En tierra',landed:'En tierra',flying:'En vuelo',rolling:'Rodando',crashed:'Siniestrado'}[F.status];
  s.push('<span class="chip">'+(F.ac.cm?F.ac.cm.name:F.ac.type.name.split(' (')[0])+'</span>');
  s.push('<span class="chip cams">Cám: '+cams.map(function(m,i){ var off=(m==='fpv'&&!hasCam()); return '<button type="button" data-cam="'+m+'"'+(m===SIM.camMode?' class="on"':'')+(off?' disabled title="Este dron no lleva cámara (añádela en el hangar)"':' title="Tecla '+(i+1)+'"')+'>'+({vlos:'Vista',fpv:'FPV',chase:'Seguim.',top:'Cenital'})[m]+'</button>'; }).join('')+'</span>');
  if(F.ac.kind!=='fixed') s.push('<span class="chip">Modo: <b>'+(F.rth?'RTH':(F.gpsActive?(F.holdSrc==='FLUJO'?'FLUJO ÓPTICO':'GPS'):'ATTI'))+'</b></span>');
  s.push('<span class="chip"><b>'+st+'</b></span>');
  if(SIM.PAD.out.on) s.push('<span class="chip">Emisora <b>activa</b></span>');
  if(speed!==1) s.push('<span class="chip">Sim <b>×'+speed+'</b></span>');
  if(paused) s.push('<span class="chip p"><b>⏸ PAUSA</b> · t='+F.t.toFixed(1)+' s</span>');
  var c=$('chips'), h=s.join(''); if(c._h!==h){ c.innerHTML=h; c._h=h; }
}

/* ---------- bucle principal ---------- */
var glareEl=$('glare'), _gv=null, _gp=null; SIM.glare=0;
function glareTick(){
  var g=0, X=50, Y=50;
  if(world&&world.sun&&world.sun.el>0&&!world.indoor&&!hangarOpen&&F){
    var cam=R3D.camera(), si=R3D.sunInfo(); if(!_gv){ _gv=new THREE.Vector3(); _gp=new THREE.Vector3(); }
    cam.getWorldDirection(_gv); var cosA=_gv.dot(si.dir), ang=Math.acos(clamp(cosA,-1,1));
    var sm=clamp((55*deg-ang)/(43*deg),0,1); g=sm*sm*(3-2*sm);
    g*=clamp(1.15-si.el/75,0.5,1);
    var oc=clamp(wxLive.rain/10+(wxLive.vis<6?0.5:0),0,1); g*=1-0.65*oc;
    if(g>0.01){
      var cp=cam.position, occ=false;
      for(var s=40;s<=2600;s*=2){ if(world.terrainH(cp.x+si.dir.x*s,cp.z+si.dir.z*s)>cp.y+si.dir.y*s){ occ=true; break; } }
      if(occ) g*=0.12;
      _gp.copy(cp).addScaledVector(si.dir,1000).project(cam); X=clamp((_gp.x*0.5+0.5)*100,-60,160); Y=clamp((-_gp.y*0.5+0.5)*100,-60,160);
    }
  }
  SIM.glare=g;
  if(g>0.01){ glareEl.style.opacity=Math.pow(g,0.85).toFixed(3); glareEl.style.background='radial-gradient(circle at '+X.toFixed(1)+'% '+Y.toFixed(1)+'%, rgba(255,253,240,.97) 0%, rgba(255,244,205,.72) 7%, rgba(255,236,185,.40) 22%, rgba(255,236,195,.20) 50%, rgba(255,240,210,.12) 100%)'; }
  else if(glareEl.style.opacity!=='0') glareEl.style.opacity='0';
}
var _vh=0;
function viewHeading(){ var cam=R3D.camera(); if(!_gv) return {hd:0,top:true}; if(SIM.camMode==='top') return {hd:0,top:true}; cam.getWorldDirection(_gv); if(Math.hypot(_gv.x,_gv.z)>0.04) _vh=((Math.atan2(_gv.x,-_gv.z)/deg)%360+360)%360; return {hd:_vh,top:false}; }
var last=0;
function frame(ts){
  requestAnimationFrame(frame);
  var dtR=Math.min(0.05,(ts-last)/1000||0.016); last=ts;
  if(!F||hangarOpen){ AUD.hush(); return; }
  var simDt=0;
  if(!paused){
    acc+=dtR*speed; var n=0;
    while(acc>=HZ&&n<14){ slew(HZ); world.update(F.t); F.step(HZ,cmd); compTick(HZ); acc-=HZ; n++; simDt+=HZ; }
    if(n>=14) acc=0;
  } else if(stepOnce){
    for(var i=0;i<12;i++){ slew(HZ); world.update(F.t); F.step(HZ,cmd); compTick(HZ); } stepOnce=false; simDt=0; renderInspector();
  }
  R3D.update(F,paused?0:dtR*speed,ropts());
  if(COMP.st) R3D.updateRings(COMP.st.idx,COMP.st.done,ts);
  glareTick();
  { var hp0=F.world.home, ddx=F.pos.x-hp0.x, ddy=F.pos.y-(F.world.homeY+1.7), ddz=F.pos.z-hp0.z; AUD.update(F,{paused:paused,cam:SIM.camMode,dist:Math.sqrt(ddx*ddx+ddy*ddy+ddz*ddz),rain:wxLive?wxLive.rain:0}); }
  if(ts-lastHud>80){
    lastHud=ts; compHud();
    var d=H.data(F,world,wxLive);
    if(!paused||!F._hudDone){ H.updateCells(d,F); H.renderAlerts(H.alerts(d,F,world,wxLive)); H.compliance(d,F,world,wxLive); H.drawMap(F,world,d,wxLive); chips(d); } H.drawLidar(F,world); { var vh=viewHeading(); H.drawCompass(F,d,vh.hd,vh.top); }
    if(!paused) H.logTick(F,d); H.drawChart(); videoFx(d,ts); markOverlay(d);
    F._hudDone=paused;
    if(F.status==='crashed' && $('msg').style.display==='none') showMsg('crash','SINIESTRO',F.crashMsg+(compOn()?'<br><b>Competición: '+COMP.st.idx+' de '+COMP.rings.length+' aros</b>':'')+'<br><small>Pausa y revisa los datos del instante, o reinicia el vuelo.</small>','Reiniciar vuelo');
    if((F.status==='landed'||F.status==='rolling'&&F.hspeed()<0.5) && F.flightT>6 && !landShown && F.landMsg){ landShown=true;
      showMsg('ok','ATERRIZAJE','<b>'+F.landMsg+'</b><br>Tiempo de vuelo '+F.flightT.toFixed(0)+' s · distancia '+F.dist.toFixed(0)+' m · altura máx. '+F.maxAlt.toFixed(0)+' m · alejamiento máx. '+F.maxDist.toFixed(0)+' m · vel. máx. '+(F.maxSpd*3.6).toFixed(0)+' km/h · consumo '+(F.ahUsed*1000).toFixed(0)+' mAh ('+(F.dod*100).toFixed(0)+' %)','Continuar'); }
    if(F.status==='flying') landShown=false;
  }
}

/* ---------- controles táctiles ---------- */
var touchOn=false;
function key(code){ window.dispatchEvent(new KeyboardEvent('keydown',{code:code})); window.dispatchEvent(new KeyboardEvent('keyup',{code:code})); }
function setTouch(on){
  touchOn=on; document.documentElement.classList.toggle('touch',on); $('bTouch').textContent=on?'Táctil: sí':'Táctil: no';
  try{ localStorage.setItem('santsim_touch',on?'1':'0'); }catch(e){}
  if(!on){ analog.yaw=analog.thr=analog.roll=analog.pitch=0; } setTimeout(function(){ R3D.resize(); },30);
}
function stick(el,ax,ay){
  var knob=el.querySelector('i'), id=null, R=44;
  function upd(e){ var r=el.getBoundingClientRect(), x=e.clientX-(r.left+r.width/2), y=e.clientY-(r.top+r.height/2), L=Math.hypot(x,y); if(L>R){ x*=R/L; y*=R/L; }
    knob.style.transform='translate('+x+'px,'+y+'px)';
    var nx=x/R, ny=-y/R, dz=0.1; nx=Math.abs(nx)<dz?0:nx; ny=Math.abs(ny)<dz?0:ny; analog[ax]=nx; analog[ay]=ny; }
  function end(){ id=null; knob.style.transform=''; analog[ax]=0; analog[ay]=0; el.classList.remove('act'); }
  el.addEventListener('pointerdown',function(e){ AUD.init(); if(id!==null) return; id=e.pointerId; el.setPointerCapture(id); el.classList.add('act'); e.preventDefault(); upd(e); });
  el.addEventListener('pointermove',function(e){ if(e.pointerId===id){ e.preventDefault(); upd(e); } });
  el.addEventListener('pointerup',function(e){ if(e.pointerId===id) end(); });
  el.addEventListener('pointercancel',function(e){ if(e.pointerId===id) end(); });
}
stick($('stL'),'yaw','thr'); stick($('stR'),'roll','pitch');
[['tbLand','KeyB'],['tbCam','KeyC'],['tbRth','KeyH'],['tbMode','KeyQ'],['tbLid','KeyL'],['tbChute','KeyX'],['tbFail','KeyF'],['tbZoom','KeyZ'],['tbIns','KeyI'],['tbHud','KeyU']].forEach(function(b){
  $(b[0]).addEventListener('click',function(){ AUD.init(); if(!hangarOpen&&F) key(b[1]); }); });
$('bTouch').onclick=function(){ setTouch(!touchOn); };
(function(){ var on=false, saved=null; try{ saved=localStorage.getItem('santsim_touch'); }catch(e){}
  if(saved==='1'||(saved===null&&window.matchMedia&&matchMedia('(pointer:coarse)').matches)) on=true;
  if(/[?&]touch=1/.test(location.search)) on=true; setTouch(on); })();
var booted=false;
SIM.boot=function(){
  if(booted) return; booted=true;
  R3D.init($('gl')); H.build(); H.initChart(); SIM.initHangar(); keysPanel();
  /* escena de portada: se carga el escenario elegido para que el hangar tenga fondo */
  world=SW.make(ST.scn); R3D.loadWorld(world); world.timeMs0=SIM.flightMs(); SIM.syncTod(); world.sun=SIM.sunAt(world.timeMs0); R3D.setWeather(Object.assign({},ST.wx),ST.tod,world.sun);
  $('bFly').textContent='Volar ▶';
  requestAnimationFrame(frame);
  window.SIMDBG={get F(){return F;},get world(){return world;},cmd:cmd,keys:keys,start:function(){flyPressed();},ST:ST,get COMP(){return COMP;},hud:H,setCam:setCam,pause:togglePause};
};
$('tabs').addEventListener('click',function(){});
document.addEventListener('DOMContentLoaded',function(){ SIM.boot(); });
if(document.readyState!=='loading') SIM.boot();
})();
