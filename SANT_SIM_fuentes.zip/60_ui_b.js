/* ===== INTERFAZ (B): HUD, alertas, normativa, mapa, registro ===== */
(function(){
var $=function(id){return document.getElementById(id);};
var clamp=SD.clamp, deg=SD.deg, ST=SIM.ST;
var H=SIM.hud={};

/* ---------- valores derivados ---------- */
H.vlosLimit=function(f,wx){ return Math.max(60,Math.min(500,f.ac.frame.dim/0.001,wx.vis*1000*0.9)); };
H.data=function(f,w,wx){
  var ac=f.ac, p=f.pos, d={};
  d.agl=f.agl(); d.amsl=SIM.elev()+p.y; d.dist=f.hdist(); d.heading=((f.yaw/deg)%360+360)%360;
  d.bearing=((f.bearingHome()/deg)%360+360)%360;
  d.gs=f.hspeed(); d.vz=f.vel.y;
  var wc=f.wcur; d.as=SM.fwNow(f)?f.Va:Math.hypot(f.vel.x-wc.x,f.vel.y-wc.y,f.vel.z-wc.z);
  d.batt=Math.max(0,(1-f.dod)*100); d.V=f.V; d.cellV=f.V/ac.cfg.cells; d.I=f.I; d.P=f.P;
  var capEff=ac.battAh*SM.capFactor(wx.temp);
  d.remMin=f.P>8?Math.max(0,((1-f.dod-0.15)*capEff*f.V/f.P)*60):99;
  d.thr=f.thrPct; d.rpm=f.rpm; d.twr=f.TWR||0; d.Tcur=f.Tcur;
  d.windSp=wc.speed+Math.abs(wc.y)*0.5; d.windMean=wc.mean; d.gust=wc.gust; d.windFrom=((Math.atan2(-wc.x,wc.z)/deg)+360)%360; d.windFrom=(((Math.atan2(wc.x,-wc.z)/deg)+180)%360+360)%360;
  d.rho=f.atm.rho; d.temp=f.atm.T; d.densAlt=SM.densAlt(f.atm.rho)+SIM.elev()*0; d.vis=wx.vis;
  var s=f.sens; d.c=s.ctrl; d.v=s.vid; d.sats=s.gnss.sats; d.hdop=s.gnss.hdop;
  d.vlos=H.vlosLimit(f,wx);
  d.beauf=SM.beaufort(wc.mean);
  var wl=f.world, gp=(f.sens.gnss.sats>=4&&!wl.noGnss);
  var la=ST.lat-p.z/111320; d.lat=gp?la:null; d.lon=gp?ST.lon+p.x/(111320*Math.cos(la*deg)):null;
  d.clockMs=(wl.timeMs0||Date.now())+f.t*1000; d.sun=SM.sunPos(d.clockMs,ST.lat,ST.lon);
  d.iEsc=ac.nMotors?(f.I-ac.accW/Math.max(f.V,1)-ac.avW/Math.max(f.V,1))/ac.nMotors:0;
  return d;
};
function sev(v,warn,crit,lowBad){ if(lowBad){ if(v<crit)return 'c'; if(v<warn)return 'w'; return ''; } if(v>crit)return 'c'; if(v>warn)return 'w'; return ''; }
function f1(v,n){return (+v).toFixed(n);}
function rssiSev(m){ return m<6?'c':(m<12?'w':''); }
/* Definición de celdas: [grupo, etiqueta, función(d,f)=> [texto, unidad, sev]] */
var CELLS=[
 ['Vuelo','Altura (AGL)',function(d){return [f1(d.agl,1),'m',d.agl>120?'c':(d.agl>105?'w':'')];}],
 ['Vuelo','Altitud (AMSL)',function(d){return [f1(d.amsl,0),'m',''];}],
 ['Vuelo','Distancia a casa',function(d){return [f1(d.dist,0),'m',d.dist>d.vlos?'c':(d.dist>d.vlos*0.8?'w':'')];}],
 ['Vuelo','Rumbo / a casa',function(d){return [f1(d.heading,0)+'/'+f1(d.bearing,0),'°',''];}],
 ['Vuelo','Vel. suelo',function(d){return [f1(d.gs*3.6,0),'km/h',''];}],
 ['Vuelo','Vel. aire',function(d,f){var s=''; if(SM.fwNow(f)&&f.status==='flying'){ s=f.Va<f.Vs*1.15?'c':(f.Va<f.Vs*1.35?'w':(f.Va>f.ac.frame.vne*0.85?'w':'')); } return [f1(d.as*3.6,0),'km/h',s];}],
 ['Vuelo','Vel. vertical',function(d){return [f1(d.vz,1),'m/s',d.vz<-6?'c':(d.vz<-4?'w':'')];}],
 ['Vuelo','Actitud',function(d,f){return [f1(-f.pitch/deg,0)+'/'+f1(f.roll/deg,0),'°',''];}],
 ['Posición y Sol','Latitud',function(d){return [d.lat===null?'—':f1(Math.abs(d.lat),5),d.lat===null?'':'° '+(d.lat>=0?'N':'S'),d.lat===null?'w':''];}],
 ['Posición y Sol','Longitud',function(d){return [d.lon===null?'—':f1(Math.abs(d.lon),5),d.lon===null?'':'° '+(d.lon>=0?'E':'O'),d.lon===null?'w':''];}],
 ['Posición y Sol','Hora local',function(d){var t=new Date(d.clockMs),p=function(n){return (n<10?'0':'')+n;}; return [p(t.getHours())+':'+p(t.getMinutes())+':'+p(t.getSeconds()),'',''];}],
 ['Posición y Sol','Sol (acimut/elev.)',function(d){var e=d.sun.el; return [e<0?'bajo horiz.':f1(d.sun.az,0)+'/'+f1(e,0),e<0?'':'°',SIM.glare>0.8?'c':(SIM.glare>0.4?'w':'')];}],
 ['Energía','Batería',function(d){return [f1(d.batt,0),'%',sev(d.batt,30,15,true)];}],
 ['Energía','Tensión',function(d,f){return [f1(d.V,1),'V',sev(d.cellV,3.5,3.3,true)];}],
 ['Energía','Tensión celda',function(d){return [f1(d.cellV,2),'V',sev(d.cellV,3.5,3.3,true)];}],
 ['Energía','Corriente',function(d,f){return [f1(d.I,1),'A',d.I>f.ac.battCmax?'c':(d.I>f.ac.battCmax*0.8?'w':'')];}],
 ['Energía','Potencia',function(d){return [f1(d.P,0),'W',''];}],
 ['Energía','Autonomía',function(d){return [d.remMin>=99?'—':f1(d.remMin,1),'min',sev(d.remMin,4,2,true)];}],
 ['Energía','Gas motores',function(d,f){return [f1(d.thr,0),'%',(f.sat&&!SM.fwNow(f))?'c':(d.thr>90?'w':'')];}],
 ['Energía','Empuje / peso',function(d,f){ if(SM.fwNow(f)) return [f1(f.LoD,1),'L/D','']; return [f1(d.twr,2),'×',d.twr<1.3?'c':(d.twr<1.8?'w':'')];}],
 ['Atmósfera','Viento (en dron)',function(d,f){var mx=f.ac.frame.maxWind; return [f1(d.windSp,1),'m/s',d.windSp>mx?'c':(d.windSp>mx*0.75?'w':'')];}],
 ['Atmósfera','Procede de',function(d){return [f1(d.windFrom,0),'° · B'+d.beauf,''];}],
 ['Atmósfera','Ráfaga',function(d){return [f1(d.gust,1),'m/s',d.gust>6?'w':''];}],
 ['Atmósfera','Densidad aire',function(d){return [f1(d.rho,3),'kg/m³',d.rho<1.0?'w':''];}],
 ['Atmósfera','Temperatura',function(d){return [f1(d.temp,1),'°C',d.temp<5?'w':(d.temp>35?'w':'')];}],
 ['Atmósfera','Alt. densidad',function(d){return [f1(d.densAlt,0),'m',d.densAlt>2500?'w':''];}],
 ['Radio y GNSS','Control RSSI',function(d){return [f1(d.c.prx,0),'dBm',rssiSev(d.c.margin)];}],
 ['Radio y GNSS','Margen control',function(d){return [f1(d.c.margin,1),'dB',rssiSev(d.c.margin)];}],
 ['Radio y GNSS','Vídeo RSSI',function(d){return [f1(d.v.prx,0),'dBm',rssiSev(d.v.margin)];}],
 ['Radio y GNSS','Margen vídeo',function(d){return [f1(d.v.margin,1),'dB',rssiSev(d.v.margin)];}],
 ['Radio y GNSS','Satélites',function(d){return [d.sats,'',sev(d.sats,9,6,true)];}],
 ['Radio y GNSS','HDOP',function(d){return [d.sats?f1(d.hdop,1):'—','',d.hdop>3?'w':''];}]
];
var cellEls=[];
H.build=function(){
  var left=$('left'); left.innerHTML=''; cellEls=[];
  var cs=document.createElement('div'); cs.className='grp'; cs.innerHTML='<div class="ph"><span>Brújula</span><span id="cmpTxt"></span></div><canvas id="compass" width="436" height="76" style="display:block;width:100%;height:auto"></canvas>'; left.appendChild(cs);
  var groups=[]; CELLS.forEach(function(c){ if(groups.indexOf(c[0])<0) groups.push(c[0]); });
  groups.forEach(function(g){
    var s=document.createElement('div'); s.className='grp'; s.innerHTML='<div class="ph"><span>'+g+'</span></div><div class="cells"></div>'; left.appendChild(s);
    var box=s.querySelector('.cells');
    CELLS.forEach(function(c){ if(c[0]!==g) return; var el=document.createElement('div'); el.className='cell'; el.innerHTML='<label>'+c[1]+'</label><div class="v"></div>'; box.appendChild(el); cellEls.push({el:el,fn:c[2],v:el.querySelector('.v')}); });
  });
};
H.updateCells=function(d,f){
  cellEls.forEach(function(c){ var r=c.fn(d,f); c.v.innerHTML=r[0]+(r[1]?'<small>'+r[1]+'</small>':''); var cl='cell'+(r[2]?' '+r[2]:''); if(c.el.className!==cl) c.el.className=cl; });
};

/* ---------- brújula (rumbo de la vista, dron, casa y Sol) ---------- */
H.drawCompass=function(f,d,viewHd,top){
  var cv=$('compass'); if(!cv) return; var g=cv.getContext('2d'), W=cv.width, Hh=cv.height, span=130, k=W/span;
  g.fillStyle='#f4f7fa'; g.fillRect(0,0,W,Hh);
  var c=top?0:viewHd;
  function X(az){ var a=((az-c+540)%360)-180; return W/2+a*k; }
  var card={0:'N',45:'NE',90:'E',135:'SE',180:'S',225:'SO',270:'O',315:'NO'};
  g.strokeStyle='#8fa1b2'; g.fillStyle='#14283a'; g.textAlign='center';
  for(var az=0;az<360;az+=5){ var x=X(az); if(x<-10||x>W+10) continue; var big=az%45===0, mid=az%15===0;
    g.lineWidth=big?2:1; g.beginPath(); g.moveTo(x,Hh-30); g.lineTo(x,Hh-30-(big?16:(mid?11:6))); g.stroke();
    if(big){ g.font='bold 20px sans-serif'; g.fillStyle=az===0?'#b0245d':'#14283a'; g.fillText(card[az],x,Hh-50); }
    else if(mid){ g.font='11px monospace'; g.fillStyle='#51657a'; g.fillText(az,x,Hh-47); } }
  /* marcas */
  function mark(az,fn){ var a=((az-c+540)%360)-180, x=W/2+a*k; if(Math.abs(a)>span/2){ x=a>0?W-10:10; fn(x,true); } else fn(x,false); }
  mark(d.sun.az,function(x,edge){ if(d.sun.el<-1) return; g.fillStyle='#f5b800'; g.strokeStyle='#8a5a00'; g.lineWidth=1.5; g.beginPath(); g.arc(x,Hh-14,edge?5:8,0,6.3); g.fill(); g.stroke(); if(!edge){ g.strokeStyle='#f5b800'; for(var i=0;i<8;i++){ var a=i*Math.PI/4; g.beginPath(); g.moveTo(x+Math.cos(a)*10,Hh-14+Math.sin(a)*10); g.lineTo(x+Math.cos(a)*13,Hh-14+Math.sin(a)*13); g.stroke(); } } });
  mark(d.heading,function(x,edge){ g.fillStyle='#0b6aa8'; g.beginPath(); g.moveTo(x,Hh-3); g.lineTo(x-7,Hh-17); g.lineTo(x+7,Hh-17); g.closePath(); g.fill(); });
  mark(d.bearing,function(x,edge){ g.fillStyle='#14283a'; g.fillRect(x-5,Hh-14,10,10); g.fillStyle='#f5c842'; g.font='bold 9px sans-serif'; g.fillText('H',x,Hh-6); });
  /* centro de la vista */
  g.fillStyle='#b0245d'; g.beginPath(); g.moveTo(W/2,Hh-34); g.lineTo(W/2-6,Hh-26); g.lineTo(W/2+6,Hh-26); g.closePath(); g.fill();
  g.strokeStyle='#b0245d'; g.lineWidth=1; g.beginPath(); g.moveTo(W/2,2); g.lineTo(W/2,Hh-34); g.stroke();
  var t=$('cmpTxt'); if(t) t.textContent=top?'norte arriba':'vista '+f1(((c%360)+360)%360,0)+'° '+SIM.compass(((c%360)+360)%360);
};

/* ---------- alertas ---------- */
H.alerts=function(d,f,w,wx){
  var A=[], ac=f.ac, fl=(f.status==='flying'||f.status==='rolling');
  function a(l,t){A.push({l:l,t:t});}
  if(f.fail) a('c',ac.kind==='heli'?'FALLO DE MOTOR · AUTORROTACIÓN':'FALLO DE MOTOR');
  if(d.batt<15) a('c','BATERÍA CRÍTICA · '+f1(d.batt,0)+' %'); else if(d.batt<30) a('w','BATERÍA BAJA · '+f1(d.batt,0)+' %');
  if(d.cellV<3.3 && fl) a('c','TENSIÓN DE CELDA BAJA · '+f1(d.cellV,2)+' V');
  if(d.c.margin<0) a('c','ENLACE PERDIDO'+(f.fsActive?' · FAILSAFE':'')); else if(d.c.margin<6) a('c','RECEPCIÓN MUY DÉBIL · '+f1(d.c.prx,0)+' dBm'); else if(d.c.margin<12) a('w','RECEPCIÓN DÉBIL · margen '+f1(d.c.margin,0)+' dB');
  if(SIM.camMode==='fpv'){ if(d.v.margin<0) a('c','SIN SEÑAL DE VÍDEO'); else if(d.v.margin<8) a('w','VÍDEO DEGRADADO · '+f1(d.v.margin,0)+' dB'); }
  if(d.sats<6){ if(f.holdSrc==='FLUJO') a('i','SIN GNSS · retención por flujo óptico'); else a('w',(d.sats===0?'SIN GNSS':'GNSS DEGRADADO ('+d.sats+' sat.)')+' · modo ATTI'); } else if(f.mode==='ATTI' && ac.kind==='multi') a('i','MODO ATTI · sin retención de posición');
  var mx=ac.frame.maxWind; if(d.windSp>mx) a('c','VIENTO '+f1(d.windSp,0)+' m/s > MÁX. '+mx+' m/s'); else if(d.windSp>mx*0.75) a('w','VIENTO FUERTE · '+f1(d.windSp,0)+' m/s');
  if(!SM.fwNow(f) && f.sat && fl) a('w','EMPUJE AL LÍMITE · sin reserva');
  if(SM.fwNow(f) && f.status==='flying'){ if(f.stalled) a('c','PÉRDIDA (STALL) · baja el morro y da gas'); else if(f.Va<f.Vs*1.15) a('w','VELOCIDAD PRÓXIMA A PÉRDIDA'); if(f.Va>ac.frame.vne*0.85) a('w','VELOCIDAD CERCA DEL VNE'); }
  var o=f.sens.obsDist; if(fl){ if(o<2.5) a('c','OBSTÁCULO a '+f1(o,1)+' m · '+f.sens.obsLabel); else if(o<7) a('w','OBSTÁCULO a '+f1(o,0)+' m · '+f.sens.obsLabel); }
  if(f.obsBrake) a('i','FRENADO AUTOMÁTICO (sensores)');
  if(fl){
    if(d.agl>120) a('c','ALTURA '+f1(d.agl,0)+' m > 120 m · límite UE');
    if(d.dist>d.vlos) a('w','FUERA DE LÍNEA DE VISTA · >'+f1(d.vlos,0)+' m');
    if(SIM.camMode==='fpv' && !ST.rf.obs) a('c','FPV SIN OBSERVADOR · infracción');
    if(w.zoneAt(f.pos.x,f.pos.z,'restricted')) a('c','ZONA UAS RESTRINGIDA');
    if(w.zoneAt(f.pos.x,f.pos.z,'crowd')) a('c','SOBREVUELO DE REUNIÓN DE PERSONAS');
    if(ac.mass>=4){ var zd=w.zoneDist(f.pos.x,f.pos.z,'urban'); if(zd.zone&&zd.d<150) a('w','A3: <150 m de zona urbana'); }
    if(ST.tod==='noche' && !ac.has('strobe')) a('w','VUELO NOCTURNO SIN LUZ VERDE');
    if(w.dynamic.length){ var t=w.dynamic[0], dd=Math.sqrt(Math.pow(f.pos.x-t.x,2)+Math.pow(f.pos.y-t.y,2)+Math.pow(f.pos.z-t.z,2)); if(dd<500) a('c','TRÁFICO TRIPULADO a '+f1(dd,0)+' m · CEDA EL PASO'); else if(dd<900) a('w','TRÁFICO TRIPULADO a '+f1(dd,0)+' m'); }
    if(wx.temp<=2 && (wx.rain>0||wx.vis<2)) a('w','RIESGO DE ENGELAMIENTO');
    if(d.densAlt>2500) a('w','ALTITUD DE DENSIDAD ALTA · '+f1(d.densAlt,0)+' m');
    if(wx.vis*1000<d.vlos) a('w','VISIBILIDAD REDUCIDA · '+f1(wx.vis,1)+' km');
    if(ac.nMotors && d.iEsc>ac.cfg.esc) a('c','CORRIENTE > ESC ('+f1(d.iEsc,0)+' A)');
  }
  if(f.lidar&&f.lidar.any&&fl&&f.lidar.min<1.2) a('w','DISTANCIA < 1,2 m ('+f1(f.lidar.min,2)+' m)');
  if(fl){
    var ai=w.actorInfo&&w.actorInfo(f.pos.x,f.pos.y,f.pos.z);
    if(ai){
      if(ai.air<10) a('c','COLISIÓN INMINENTE · '+ai.airLabel+' a '+f1(ai.air,0)+' m'); else if(ai.air<30) a('w','OBSTÁCULO AÉREO · '+ai.airLabel+' a '+f1(ai.air,0)+' m');
      if(ai.overPerson) a('c','SOBREVUELO DE PERSONAS'); else if(ai.overCrowd) a('c','SOBREVUELO DE UNA AGLOMERACIÓN'); else if(ai.crowdEdge<50) a('w','AGLOMERACIÓN DE PERSONAS a '+f1(Math.max(0,ai.crowdEdge),0)+' m · mantén ≥ 50 m'); else if(ai.pers<15) a('w','PERSONAS a '+f1(ai.pers,0)+' m · mantén la distancia');
    }
    if(SIM.glare>0.8) a('c','SOL DE FRENTE · deslumbramiento: pierdes de vista el dron'); else if(SIM.glare>0.4) a('w','SOL DE FRENTE · visibilidad reducida');
    if(f.fenceMsg) a('c','GEOVALLA · '+f.fenceMsg);
    if(f.apWarn) a('w',f.apWarn);
  }
  if(f.landNow&&fl&&!f.rth) a('i','ATERRIZANDO · descenso controlado');
  else if(fl&&!SM.fwNow(f)&&d.agl<6&&d.vz<-3.2) a('w','DESCENSO RÁPIDO · '+f1(-d.vz,1)+' m/s · reduce antes de tocar');
  if(fl&&d.agl<4&&!SM.fwNow(f)){ var sl=w.slope(f.pos.x,f.pos.z), sd=Math.atan(Math.hypot(sl.x,sl.z))/deg; if(sd>10) a(sd>16?'c':'w','TERRENO INCLINADO '+f1(sd,0)+'° · riesgo de vuelco al posarse'); }
  if(f.rth) a('i','REGRESO A CASA · '+(f.rthPhase||'')+' ('+(f.rthReason||'')+')');
  if(f.chute>0||f.chuteOpen) a('i',f.chuteOpen?'PARACAÍDAS ABIERTO':'ABRIENDO PARACAÍDAS…');
  return A;
};
/* ---------- explicación de avisos (clic en una alerta) ---------- */
H.ALX=[
 ["^FALLO DE MOTOR","Un motor (o su ESC) ha dejado de dar empuje. Con 6 u 8 rotores el resto puede compensarlo; con 4 o menos se pierde el control de guiñada y el dron puede caer. Un helicóptero entra en autorrotación.","Aterriza cuanto antes en el sitio más seguro (tecla B) lejos de personas y revisa en el hangar motores y ESC."],
 ["^BATER[ÍI]A (CR[ÍI]TICA|BAJA)","La carga restante es baja. Con poca carga la tensión cae al dar gas y el empuje disminuye, justo cuando más lo necesitas.","Vuelve a casa (tecla H) y aterriza ya. No esperes al corte por tensión: puede ser brusco."],
 ["^TENSI[ÓO]N DE CELDA BAJA","Una celda está por debajo de 3,3 V: la batería está casi agotada y se daña si sigues descargándola.","Aterriza inmediatamente."],
 ["^ENLACE PERDIDO","La señal de la emisora no llega al dron (margen de enlace negativo). Si el failsafe está activo, el dron ejecuta la acción programada (RTH, aterrizar…).","Acércate, gana altura o quita obstáculos entre antena y dron. Mira el margen de enlace en el panel de comunicaciones."],
 ["^RECEPCI[ÓO]N (MUY )?D[ÉE]BIL","Queda poco margen sobre la sensibilidad del receptor. Un obstáculo, lluvia o girar el dron puede cortar el enlace.","Acércate al dron, busca línea de vista y evita volar tras edificios o árboles."],
 ["^(SIN SE[ÑN]AL DE V[ÍI]DEO|V[ÍI]DEO DEGRADADO)","El enlace de vídeo FPV es débil o se ha perdido; vuelas a ciegas o con imagen ruidosa.","Acércate, sube o pasa a vuelo a la vista. Con vídeo perdido no sigas en FPV."],
 ["(GNSS|ATTI)","El GPS no tiene suficientes satélites o estás en ATTI: el dron no mantiene la posición y deriva con el viento.","Corrige tú con los mandos, aléjate de edificios altos y cañones urbanos y espera a recuperar satélites antes de volar lejos."],
 ["^VIENTO","El viento supera (o se acerca a) el máximo que soporta este dron. Los motores gastan más y el control se degrada.","Baja de altura (hay menos viento), vuelve a favor de viento con margen de batería y aterriza si empeora."],
 ["^EMPUJE AL L[ÍI]MITE","Los motores están al máximo y no queda reserva para corregir. Causas típicas: sobrepeso, batería baja, viento fuerte o altitud de densidad alta.","Reduce el gas, desciende y aterriza. En el hangar baja carga útil o elige motores/hélices con más empuje."],
 ["^(P[ÉE]RDIDA \\(STALL\\)|VELOCIDAD PR[ÓO]XIMA A P[ÉE]RDIDA)","El ala está cerca de perder la sustentación (ángulo de ataque excesivo o poca velocidad).","Baja el morro, nivela las alas y da gas. No tires de la palanca."],
 ["^VELOCIDAD CERCA DEL VNE","Estás cerca de la velocidad máxima estructural: riesgo de flameo o rotura.","Reduce gas y suaviza los mandos."],
 ["^OBST[ÁA]CULO a","Hay un obstáculo muy cerca en la dirección del movimiento.","Frena y sube o rodéalo con margen. Si el frenado automático está activo, puede detenerte solo."],
 ["^FRENADO AUTOM","Los sensores han frenado el dron para evitar un choque.","Suelta el mando y elige otra trayectoria."],
 ["^ALTURA","Superas los 120 m sobre el terreno, límite de la normativa europea para la categoría abierta.","Desciende por debajo de 120 m."],
 ["^FUERA DE L[ÍI]NEA DE VISTA","El dron está más lejos de lo que puedes ver a simple vista (VLOS). Es una infracción en categoría abierta sin observador.","Acércate hasta recuperar la línea de vista."],
 ["^FPV SIN OBSERVADOR","Volar en FPV exige un observador que vigile el dron a simple vista.","Activa «observador» en las opciones de radio/normativa o pasa a vuelo a la vista."],
 ["^(ZONA UAS RESTRINGIDA)","Estás dentro de una zona geográfica UAS (por ejemplo cerca de un aeropuerto) donde no se puede volar sin autorización.","Sal de la zona de inmediato."],
 ["^(SOBREVUELO|AGLOMERACI[ÓO]N|PERSONAS a)","Estás sobre o muy cerca de personas. En categoría abierta no se sobrevuelan reuniones de gente y hay que mantener distancia.","Aléjate y vuela por zonas despobladas."],
 ["^TR[ÁA]FICO TRIPULADO","Hay una aeronave tripulada cerca. Siempre tiene prioridad.","Ceda el paso: desciende o aléjate de su trayectoria."],
 ["^RIESGO DE ENGELAMIENTO","Con temperatura cercana a 0 °C y humedad el hielo se forma en hélices y reduce el empuje.","Aterriza o sal de la zona de humedad."],
 ["^ALTITUD DE DENSIDAD","El aire es poco denso (altitud, calor): las hélices dan menos empuje.","Reduce peso y no exijas ascensos fuertes."],
 ["^VISIBILIDAD REDUCIDA","La visibilidad es menor que tu alcance VLOS: pierdes el dron de vista antes.","Vuela más cerca o aterriza."],
 ["^CORRIENTE > ESC","Un motor pide más corriente de la que aguanta su ESC: se puede quemar.","Reduce el gas y cambia el ESC por uno de más amperios en el hangar."],
 ["^DISTANCIA < 1","El LiDAR detecta algo a menos de 1,2 m.","Aléjate del objeto."],
 ["^(COLISI[ÓO]N INMINENTE|OBST[ÁA]CULO A[ÉE]REO)","Hay otro objeto volando (ave, avión, dron) en rumbo de colisión.","Cambia de rumbo o altura de inmediato."],
 ["^SOL DE FRENTE","Con el sol de cara no distingues la orientación del dron.","Cambia de posición para tener el sol de lado o a la espalda."],
 ["^GEOVALLA","Has llegado al límite de la geovalla configurada y se aplica su acción (RTH o aterrizar).","Vuelve al interior del área permitida."],
 ["^VELOCIDAD \\d+","La velocidad está por debajo del mínimo ARSPD_FBW_MIN configurado.","Da gas o baja el morro para ganar velocidad."],
 ["^DESCENSO R[ÁA]PIDO","Desciendes muy rápido cerca del suelo: tocarás con dureza y puedes romper el tren.","Sube el gas ya para frenar antes de tocar."],
 ["^TERRENO INCLINADO","El suelo tiene pendiente: al posarte el dron puede volcar.","Busca un punto llano para aterrizar."],
 ["^VUELO NOCTURNO SIN LUZ","De noche hace falta luz verde intermitente para ser visible.","Instala la luz (strobe) en el hangar o aterriza."],
 ["^A3:","Con más de 4 kg debes estar a más de 150 m de zonas urbanas en subcategoría A3.","Aléjate de la zona urbana."],
 ["^(ATERRIZANDO|REGRESO A CASA|PARACA[ÍI]DAS|ABRIENDO PARACA)","Es un aviso informativo: el dron está ejecutando un procedimiento automático.","Puedes tomar el mando moviendo el acelerador (cancela el aterrizaje asistido) o pulsar H para cancelar el regreso."]
].map(function(r){ return {re:new RegExp(r[0],'i'),what:r[1],todo:r[2]}; });
H.alertClick=function(txt,lv){
  var x=null; for(var i=0;i<H.ALX.length;i++){ if(H.ALX[i].re.test(txt)){ x=H.ALX[i]; break; } }
  var dlg=$('alDlg'); dlg._wasPaused=H.ctl.isPaused(); if(!dlg._wasPaused) H.ctl.setPaused(true);
  dlg.className=lv; dlg.querySelector('h2').textContent=txt;
  dlg.querySelector('.alw').innerHTML=x?('<b>Qué ocurre</b><br>'+x.what+'<br><br><b>Qué hacer</b><br>'+x.todo):'Aviso del sistema de a bordo.';
  dlg.style.display='block';
};
H.alertClose=function(resume){ var dlg=$('alDlg'); dlg.style.display='none'; if(resume!==false && !dlg._wasPaused && !H.ctl.hangarOpen()) H.ctl.setPaused(false); };
H.renderAlerts=function(A){
  var c=$('alerts'), order={c:0,w:1,i:2}; A.sort(function(x,y){return order[x.l]-order[y.l];});
  var html=A.slice(0,6).map(function(x){return '<div class="al '+x.l+'" data-l="'+x.l+'" title="Pulsa para ver qué ocurre y qué hacer">'+x.t+' <span class="alq">ⓘ</span></div>';}).join('');
  if(c._h!==html){ c.innerHTML=html; c._h=html; }
  if(!c._bound){ c._bound=true; c.addEventListener('pointerdown',function(e){ var el=e.target.closest&&e.target.closest('.al'); if(!el) return; e.preventDefault(); var t=I18N.es(el).replace(/\s*ⓘ\s*$/,''); H.alertClick(t,el.getAttribute('data-l')); }); }
};

/* ---------- normativa ---------- */
H.compliance=function(d,f,w,wx){
  var ac=f.ac, L=[], I=SM.validate(ac.cfg).info;
  function add(c,t){ L.push('<div class="'+c+'"><i>'+(c==='ok'?'✔':(c==='wn'?'!':'✘'))+'</i><span>'+t+'</span></div>'); }
  add(d.agl>120?'bd':'ok','Altura máx. 120 m sobre el terreno · ahora '+f1(d.agl,0)+' m');
  var fpv=SIM.camMode==='fpv';
  add(d.dist>d.vlos?'wn':'ok','Línea de vista (VLOS) · '+f1(d.dist,0)+' / '+f1(d.vlos,0)+' m');
  if(fpv) add(ST.rf.obs?'ok':'bd','FPV: '+(ST.rf.obs?'con observador':'requiere observador'));
  var rz=w.zones.some(function(z){return z.type==='restricted';});
  if(rz) add(w.zoneAt(f.pos.x,f.pos.z,'restricted')?'bd':'ok','Zona geográfica UAS (aeropuerto 2 km)');
  var cz=w.zones.some(function(z){return z.type==='crowd';});
  if(cz) add(w.zoneAt(f.pos.x,f.pos.z,'crowd')?'bd':'ok','No sobrevolar reuniones de personas');
  var uz=w.zones.some(function(z){return z.type==='urban';});
  if(ac.mass>=4 && uz){ var zd=w.zoneDist(f.pos.x,f.pos.z,'urban'); add(zd.d<150?'wn':'ok','A3: ≥150 m de zona urbana · '+f1(Math.max(0,zd.d),0)+' m'); }
  else add('ok','Categoría: '+I.cat.split(' · ')[0]+' ('+f1(ac.mass*1000,0)+' g)');
  if(ST.tod==='noche') add(ac.has('strobe')?'ok':'bd','Vuelo nocturno: luz verde intermitente');
  add(I.needReg?'wn':'ok',I.needReg?'Operador: registro obligatorio':'Operador: sin registro (<250 g sin cámara)');
  if(ac.mass>=0.25) add(ac.has('rid')?'ok':'wn','Identificación remota '+(ac.has('rid')?'instalada':'no instalada'));
  if(w.dynamic.length){ var t=w.dynamic[0], dd=Math.sqrt(Math.pow(f.pos.x-t.x,2)+Math.pow(f.pos.y-t.y,2)+Math.pow(f.pos.z-t.z,2)); add(dd<500?'bd':'ok','Ceder el paso a aeronaves tripuladas · '+f1(dd,0)+' m'); }
  if(w.actors&&w.actors.people.length&&w.actorInfo){ var ai=w.actorInfo(f.pos.x,f.pos.y,f.pos.z); add(ai.overPerson||ai.overCrowd?'bd':((ai.crowdEdge<50||ai.pers<15)?'wn':'ok'),'Personas: sin sobrevuelo · aglomeración a '+(ai.crowdEdge>=99?'>99':f1(Math.max(0,ai.crowdEdge),0))+' m (≥ 50 m)'); }
  if(SIM.glare>0.4) add('wn','Sol de frente: riesgo de perder el contacto visual');
  var cl=SD.byId(SD.CTRL_LINKS,ST.rf.cl), vl=SD.byId(SD.VID_LINKS,ST.rf.vl);
  add(ST.rf.cp>cl.lim?'bd':'ok','Potencia mando '+ST.rf.cp+' mW'+(ST.rf.cp>cl.lim?' > '+cl.lim+' mW':''));
  if(ac.has('camfpv')||ac.has('camhd')) add(ST.rf.vp>vl.lim?'bd':'ok','Potencia vídeo '+ST.rf.vp+' mW'+(ST.rf.vp>vl.lim?' > '+vl.lim+' mW':''));
  var h=L.join(''); var c=$('comp'); if(c._h!==h){ c.innerHTML=h; c._h=h; }
};

/* ---------- registro (gráfica) ---------- */
var LOGK=[['alt','Altura AGL (m)',function(d){return d.agl;},[[120,'#c0272d','120 m']]],
 ['gs','Vel. suelo (km/h)',function(d){return d.gs*3.6;}],
 ['vz','Vel. vertical (m/s)',function(d){return d.vz;}],
 ['batt','Batería (%)',function(d){return d.batt;},[[30,'#c27a00','30'],[15,'#c0272d','15']]],
 ['V','Tensión (V)',function(d){return d.V;}],
 ['I','Corriente (A)',function(d){return d.I;}],
 ['P','Potencia (W)',function(d){return d.P;}],
 ['mc','Margen control (dB)',function(d){return d.c.margin;},[[0,'#c0272d','0'],[12,'#c27a00','12']]],
 ['rc','RSSI control (dBm)',function(d){return d.c.prx;}],
 ['mv','Margen vídeo (dB)',function(d){return d.v.margin;},[[0,'#c0272d','0']]],
 ['wind','Viento en dron (m/s)',function(d){return d.windSp;}],
 ['sats','Satélites',function(d){return d.sats;}],
 ['thr','Gas motores (%)',function(d,f){return d.thr;}],
 ['dist','Distancia a casa (m)',function(d){return d.dist;}],
 ['lf','Telémetro frontal (m)',function(d,f){return rfv(f,'f');},[[1.5,'#c0272d','1,5']]],
 ['lb','Telémetro trasero (m)',function(d,f){return rfv(f,'b');}],
 ['ll','Telémetro izquierdo (m)',function(d,f){return rfv(f,'l');}],
 ['lr','Telémetro derecho (m)',function(d,f){return rfv(f,'r');}],
 ['lu','Telémetro techo (m)',function(d,f){return rfv(f,'u');}],
 ['ld','Telémetro suelo (m)',function(d,f){return rfv(f,'d');}],
 ['lm','Distancia mínima LiDAR (m)',function(d,f){return f.lidar&&f.lidar.any?Math.min(f.lidar.min,40):0;},[[1.5,'#c0272d','1,5']]]];
function rfv(f,k){ var r=f.lidar&&f.lidar.rf[k]; return r?(r.d===null?r.max:r.d):0; }
H.LOGK=LOGK; H.log=[]; H.logT=0;
H.logTick=function(f,d){ if(f.t<H.logT) return; H.logT=f.t+0.2; var s={t:f.t}; LOGK.forEach(function(k){ s[k[0]]=k[2](d,f); }); s.x=f.pos.x; s.y=f.pos.y; s.z=f.pos.z; H.log.push(s); if(H.log.length>1500) H.log.shift(); };
H.logClear=function(){ H.log=[]; H.logT=0; };
var chSel, hoverX=-1;
H.initChart=function(){
  chSel=$('chsel'); LOGK.forEach(function(k,i){ var o=document.createElement('option'); o.value=i; o.textContent=k[1]; chSel.appendChild(o); });
  var cv=$('chart'); cv.onmousemove=function(e){ var r=cv.getBoundingClientRect(); hoverX=(e.clientX-r.left)*cv.width/r.width; if(SIM.redrawChart) SIM.redrawChart(); }; cv.onmouseleave=function(){ hoverX=-1; if(SIM.redrawChart) SIM.redrawChart(); };
  chSel.onchange=function(){ H.drawChart(); };
  SIM.redrawChart=H.drawChart;
};
H.drawChart=function(){
  var cv=$('chart'), g=cv.getContext('2d'), W=cv.width, Hh=cv.height, k=LOGK[+chSel.value||0], key=k[0], L=H.log;
  g.clearRect(0,0,W,Hh); g.fillStyle='#fbfcfd'; g.fillRect(0,0,W,Hh);
  var pad={l:40,r:8,t:8,b:16};
  var N=Math.min(L.length,600), data=L.slice(L.length-N); if(N<2){ g.fillStyle='#51657a'; g.font='11px sans-serif'; g.fillText('Sin datos todavía',pad.l,Hh/2); return; }
  var mn=1e9,mx=-1e9; data.forEach(function(s){ if(s[key]<mn)mn=s[key]; if(s[key]>mx)mx=s[key]; });
  (k[3]||[]).forEach(function(t){ if(t[0]<mn&&t[0]>mn-(mx-mn+1)) mn=Math.min(mn,t[0]); if(t[0]>mx&&t[0]<mx+(mx-mn+1)) mx=Math.max(mx,t[0]); });
  if(mx-mn<1e-6){ mx=mn+1; } var m=(mx-mn)*0.1; mn-=m; mx+=m;
  var X=function(i){return pad.l+(W-pad.l-pad.r)*i/(N-1);}, Y=function(v){return pad.t+(Hh-pad.t-pad.b)*(1-(v-mn)/(mx-mn));};
  g.strokeStyle='#dfe7ee'; g.lineWidth=1; g.fillStyle='#51657a'; g.font='10px monospace';
  for(var i=0;i<=4;i++){ var v=mn+(mx-mn)*i/4, y=Y(v); g.beginPath(); g.moveTo(pad.l,y); g.lineTo(W-pad.r,y); g.stroke(); g.fillText(Math.abs(v)>=100?v.toFixed(0):v.toFixed(1),2,y+3); }
  (k[3]||[]).forEach(function(t){ var y=Y(t[0]); if(y<pad.t||y>Hh-pad.b) return; g.strokeStyle=t[1]; g.setLineDash([4,3]); g.beginPath(); g.moveTo(pad.l,y); g.lineTo(W-pad.r,y); g.stroke(); g.setLineDash([]); });
  g.strokeStyle='#0b6aa8'; g.lineWidth=1.6; g.beginPath(); data.forEach(function(s,i){ var x=X(i),y=Y(s[key]); if(i)g.lineTo(x,y); else g.moveTo(x,y); }); g.stroke();
  var t0=data[0].t, t1=data[N-1].t; g.fillStyle='#51657a'; g.fillText((t1-t0).toFixed(0)+' s',W-pad.r-34,Hh-3); g.fillText('t = '+t1.toFixed(1)+' s',pad.l,Hh-3);
  var last=data[N-1][key]; g.fillStyle='#14283a'; g.font='bold 11px monospace'; g.fillText(last.toFixed(1),W-pad.r-44,pad.t+10);
  if(hoverX>=pad.l&&hoverX<=W-pad.r){ var idx=Math.round((hoverX-pad.l)/(W-pad.l-pad.r)*(N-1)), s=data[clamp(idx,0,N-1)]; g.strokeStyle='#b0245d'; g.lineWidth=1; g.beginPath(); g.moveTo(X(idx),pad.t); g.lineTo(X(idx),Hh-pad.b); g.stroke(); g.fillStyle='#b0245d'; g.font='bold 11px monospace'; g.fillText('t='+s.t.toFixed(1)+'  '+s[key].toFixed(2),Math.min(X(idx)+4,W-110),pad.t+22); }
};
H.csv=function(){
  var keys=['t'].concat(LOGK.map(function(k){return k[0];}),['x','y','z']);
  var out=[keys.join(';')];
  H.log.forEach(function(s){ out.push(keys.map(function(k){return String(+s[k].toFixed(3)).replace('.',',');}).join(';')); });
  return '﻿'+out.join('\n');
};

/* ---------- mapa ---------- */
var ZOOMS=[30,60,120,250,500,1000,2000,3000], zi=5;
H.setZoom=function(half){ zi=0; for(var i=0;i<ZOOMS.length;i++) if(ZOOMS[i]<=half) zi=i; };
H.mapRaster=null;
H.setRaster=function(r){H.mapRaster=r;};
H.zoomMap=function(dir){ zi=clamp(zi+(dir||1),0,ZOOMS.length-1); if(dir===0) zi=(zi+1)%ZOOMS.length; };
H.drawMap=function(f,w,d,wx){
  var cv=$('map'), g=cv.getContext('2d'), S=cv.width, half=ZOOMS[zi], k=S/2/half, ext=H.mapRaster.ext;
  g.fillStyle='#dfe7ee'; g.fillRect(0,0,S,S); g.save(); g.translate(S/2,S/2); g.scale(k,k); g.translate(-f.pos.x,-f.pos.z);
  g.imageSmoothingEnabled=true; g.drawImage(H.mapRaster.canvas,-ext,-ext,2*ext,2*ext);
  g.lineWidth=1.5/k;
  /* obstáculos cercanos en vectorial */
  if(half<=1000){ w.obstacles.forEach(function(o){ if(o.label==='el techo') return; if(Math.abs(o.x-f.pos.x)>half*1.2||Math.abs(o.z-f.pos.z)>half*1.2) return;
    if(o.kind==='tree'){ if(half>500) return; g.fillStyle='rgba(30,100,50,.7)'; g.beginPath(); g.arc(o.x,o.z,Math.max(o.dx,1.5/k),0,6.3); g.fill(); }
    else if(o.kind==='box'){ g.fillStyle='#8b94a0'; g.strokeStyle='#4a525c'; g.fillRect(o.x-o.dx/2,o.z-o.dz/2,o.dx,o.dz); g.strokeRect(o.x-o.dx/2,o.z-o.dz/2,o.dx,o.dz); }
    else { g.fillStyle='#c0392b'; g.beginPath(); g.arc(o.x,o.z,Math.max(o.dx*1.2,2/k),0,6.3); g.fill(); } }); }
  /* zonas */
  w.zones.forEach(function(z){ g.strokeStyle='#d9342b'; g.fillStyle='rgba(217,52,43,.10)'; g.setLineDash([8/k,5/k]); g.beginPath(); g.arc(z.x,z.z,z.r,0,6.3); g.fill(); g.stroke(); g.setLineDash([]); });
  /* alcance libre de control y VLOS */
  var hm=w.home; g.setLineDash([6/k,5/k]);
  g.strokeStyle='#b0245d'; g.beginPath(); g.arc(hm.x,hm.z,Math.min(d.c.free,20000),0,6.3); g.stroke();
  g.strokeStyle='#c27a00'; g.beginPath(); g.arc(hm.x,hm.z,d.vlos,0,6.3); g.stroke(); g.setLineDash([]);
  /* estela */
  if(ST.trail && H.log.length>1){ g.strokeStyle='#e2552d'; g.lineWidth=2/k; g.beginPath(); H.log.forEach(function(s,i){ if(i%2) return; if(i===0)g.moveTo(s.x,s.z); else g.lineTo(s.x,s.z); }); g.lineTo(f.pos.x,f.pos.z); g.stroke(); }
  if(SIM.compDrawMap) SIM.compDrawMap(g,k);
  /* casa */
  g.fillStyle='#f5c842'; g.strokeStyle='#14283a'; g.lineWidth=2/k; g.beginPath(); g.arc(hm.x,hm.z,5/k,0,6.3); g.fill(); g.stroke();
  /* aves, cometas y personas */
  if(w.actors){ var Ac=w.actors;
    Ac.crowds.forEach(function(c){ g.fillStyle='rgba(217,52,43,.18)'; g.strokeStyle='#d9342b'; g.lineWidth=1.2/k; g.beginPath(); g.arc(c.x,c.z,c.r+5,0,6.3); g.fill(); g.stroke(); });
    g.fillStyle='#2b3a4a'; Ac.people.forEach(function(p){ if(Math.abs(p.x-f.pos.x)>half*1.2||Math.abs(p.z-f.pos.z)>half*1.2) return; g.beginPath(); g.arc(p.x,p.z,Math.max(1.1,1.6/k),0,6.3); g.fill(); });
    g.fillStyle='#ffffff'; g.strokeStyle='#51657a'; g.lineWidth=1/k; Ac.birds.forEach(function(b){ g.beginPath(); g.arc(b.x,b.z,Math.max(1.2,2.2/k),0,6.3); g.fill(); g.stroke(); });
    Ac.kites.forEach(function(q){ g.strokeStyle='rgba(60,60,60,.6)'; g.beginPath(); g.moveTo(q.ax,q.az); g.lineTo(q.x,q.z); g.stroke(); g.fillStyle='#e2552d'; g.save(); g.translate(q.x,q.z); g.rotate(Math.PI/4); var r2=Math.max(1.5,3/k); g.fillRect(-r2,-r2,2*r2,2*r2); g.restore(); });
  }
  /* tráfico */
  if(w.dynamic.length){ var t=w.dynamic[0]; g.fillStyle='#d9342b'; g.beginPath(); g.arc(t.x,t.z,6/k,0,6.3); g.fill(); }
  g.restore();
  /* dron */
  g.save(); g.translate(S/2,S/2); g.rotate(f.yaw); g.fillStyle='#0b6aa8'; g.strokeStyle='#fff'; g.lineWidth=1.5; g.beginPath(); g.moveTo(0,-9); g.lineTo(6,7); g.lineTo(0,4); g.lineTo(-6,7); g.closePath(); g.fill(); g.stroke(); g.restore();
  /* viento y norte */
  g.save(); g.translate(S-26,28); g.fillStyle='rgba(251,252,253,.85)'; g.beginPath(); g.arc(0,0,20,0,6.3); g.fill(); g.strokeStyle='#14283a'; g.lineWidth=1; g.stroke();
  g.rotate((d.windFrom+180)*deg); g.strokeStyle='#0b6aa8'; g.fillStyle='#0b6aa8'; g.lineWidth=2; g.beginPath(); g.moveTo(0,10); g.lineTo(0,-12); g.stroke(); g.beginPath(); g.moveTo(0,-15); g.lineTo(-4,-8); g.lineTo(4,-8); g.fill(); g.restore();
  g.fillStyle='#14283a'; g.font='bold 10px sans-serif'; g.fillText('N↑',S-36,S>0?58:0); g.font='10px monospace'; g.fillText(f1(d.windSp,0)+' m/s',S-52,70);
  /* Sol sobre el borde del mapa */
  if(d.sun.el>0){ var sa=d.sun.az*deg, sx=S/2+Math.sin(sa)*(S/2-12), sy=S/2-Math.cos(sa)*(S/2-12); g.fillStyle='#f5b800'; g.strokeStyle='#8a5a00'; g.lineWidth=1.2; g.beginPath(); g.arc(sx,sy,6,0,6.3); g.fill(); g.stroke(); }
  /* escala */
  var sc=half>=1000?500:(half>=250?100:(half>=100?50:10)); g.fillStyle='#14283a'; g.fillRect(8,S-14,sc*k,3); g.font='10px monospace'; g.fillText(sc+' m',8,S-18);
  $('mapinfo').textContent='±'+(half>=1000?half/1000+' km':half+' m');
};
})();

/* ---------- panel LiDAR / telémetros ---------- */
(function(){
var $=function(id){return document.getElementById(id);}, H=SIM.hud, deg=SD.deg;
var mode='s', mapR=35, visible=true;
H.lidarToggle=function(){ visible=!visible; };
H.lidarOn=function(f){ return visible && f && f.lidar && f.lidar.any; };
document.addEventListener('click',function(e){ var b=e.target.closest&&e.target.closest('#lidar .tg'); if(!b) return; mode=b.dataset.m; document.querySelectorAll('#lidar .tg').forEach(function(x){x.classList.toggle('on',x===b);}); });
$('lcv').addEventListener('wheel',function(e){ if(mode!=='m') return; e.preventDefault(); mapR=Math.max(10,Math.min(120,mapR*(e.deltaY>0?1.2:0.83))); },{passive:false});
function col(d){ return d<1.5?'#c0272d':(d<3?'#c27a00':(d<6?'#1c8a5a':'#0b6aa8')); }
H.drawLidar=function(f,w){
  var show=H.lidarOn(f), el=$('lidar'); el.style.display=show?'block':'none'; if(!show) return;
  var L=f.lidar, cv=$('lcv'), g=cv.getContext('2d'), S=cv.width, c=S/2;
  g.fillStyle='#f4f7fa'; g.fillRect(0,0,S,S);
  var R=L.scan?L.max:12, k=(c-16)/R, step=R>15?5:2;
  if(mode==='s'){
    g.strokeStyle='#d3dde6'; g.lineWidth=1; g.fillStyle='#7b8ea0'; g.font='9px monospace';
    for(var r=step;r<=R;r+=step){ g.beginPath(); g.arc(c,c,r*k,0,6.3); g.stroke(); g.fillText(r+' m',c+3,c-r*k+10); }
    g.beginPath(); g.moveTo(c,6); g.lineTo(c,S-6); g.moveTo(6,c); g.lineTo(S-6,c); g.stroke();
    if(L.scan){ L.scan.forEach(function(p){ if(p.d===null) return; var x=c+Math.sin(p.a)*p.d*k, y=c-Math.cos(p.a)*p.d*k; g.fillStyle=col(p.d); g.fillRect(x-1.5,y-1.5,3,3); }); }
    var dirs={f:[0,-1],b:[0,1],l:[-1,0],r:[1,0]};
    Object.keys(dirs).forEach(function(q){ var r=L.rf[q]; if(!r) return; var dd=r.d===null?r.max:r.d, ex=c+dirs[q][0]*dd*k, ey=c+dirs[q][1]*dd*k;
      g.strokeStyle=r.d===null?'#9fb2c2':col(r.d); g.lineWidth=2; if(r.d===null) g.setLineDash([4,4]); g.beginPath(); g.moveTo(c,c); g.lineTo(ex,ey); g.stroke(); g.setLineDash([]);
      g.fillStyle=r.d===null?'#9fb2c2':col(r.d); g.beginPath(); g.arc(ex,ey,4,0,6.3); g.fill();
      g.fillStyle='#14283a'; g.font='bold 11px monospace'; var t=r.d===null?'>'+r.max.toFixed(0):r.d.toFixed(2); g.fillText(t,ex+(dirs[q][0]>0?-34:(dirs[q][0]<0?6:6)),ey+(dirs[q][1]>0?-8:(dirs[q][1]<0?14:-6))); });
    g.fillStyle='#0b6aa8'; g.beginPath(); g.moveTo(c,c-9); g.lineTo(c+6,c+7); g.lineTo(c,c+3); g.lineTo(c-6,c+7); g.closePath(); g.fill();
    g.fillStyle='#51657a'; g.font='10px sans-serif'; g.fillText('Delante ↑ · vista desde arriba (el plano gira con el dron)',6,S-18);
    g.fillText('cabeceo '+(-f.pitch/deg).toFixed(0)+'° · alabeo '+(f.roll/deg).toFixed(0)+'° → los haces se inclinan',6,S-6);
  } else {
    var kk=(c-10)/mapR, px=f.pos.x, pz=f.pos.z;
    g.strokeStyle='#e1e8ef'; g.lineWidth=1; var gs=mapR>50?10:5; g.fillStyle='#7b8ea0'; g.font='9px monospace';
    for(var gx=Math.ceil((px-mapR)/gs)*gs;gx<px+mapR;gx+=gs){ var X=c+(gx-px)*kk; g.beginPath(); g.moveTo(X,0); g.lineTo(X,S); g.stroke(); }
    for(var gz=Math.ceil((pz-mapR)/gs)*gs;gz<pz+mapR;gz+=gs){ var Y=c+(gz-pz)*kk; g.beginPath(); g.moveTo(0,Y); g.lineTo(S,Y); g.stroke(); }
    g.fillStyle='#1d3a52'; var pts=f.mapPts; for(var i=0;i<pts.length;i+=2){ var x=c+(pts[i]-px)*kk, y=c+(pts[i+1]-pz)*kk; if(x<0||y<0||x>S||y>S) continue; g.fillRect(x-1,y-1,2,2); }
    if(L.scan){ var cs=Math.cos(f.yaw), sn=Math.sin(f.yaw); L.scan.forEach(function(p){ if(p.d===null) return; g.fillStyle='#d9342b'; var a=p.a+f.yaw; g.fillRect(c+Math.sin(a)*p.d*kk-1.5,c-Math.cos(a)*p.d*kk-1.5,3,3); }); }
    var hx=c+(w.home.x-px)*kk, hy=c+(w.home.z-pz)*kk; g.fillStyle='#f5c842'; g.strokeStyle='#14283a'; g.beginPath(); g.arc(hx,hy,4,0,6.3); g.fill(); g.stroke();
    g.save(); g.translate(c,c); g.rotate(f.yaw); g.fillStyle='#0b6aa8'; g.beginPath(); g.moveTo(0,-9); g.lineTo(6,7); g.lineTo(0,4); g.lineTo(-6,7); g.closePath(); g.fill(); g.restore();
    g.fillStyle='#51657a'; g.font='10px sans-serif'; g.fillText(L.scan?'Mapa acumulado por el LiDAR (norte arriba) · rueda: zoom ±'+mapR.toFixed(0)+' m':'Sin LiDAR 360°: el mapa se construye con el escáner',6,S-6);
  }
  var names=[['f','Delante'],['b','Detrás'],['l','Izq.'],['r','Dcha.'],['u','Techo'],['d','Suelo']], h='';
  names.forEach(function(n){ var r=L.rf[n[0]]; if(!r) return; var v=r.d===null?'<span class="n">&gt;'+r.max.toFixed(0)+' m</span>':r.d.toFixed(2)+' m', cl=r.d===null?'':(r.d<1.5?'c':(r.d<3?'w':'')); h+='<div class="'+cl+'"><label>'+n[1]+'</label>'+v+'</div>'; });
  if(L.scan){ h+='<div class="'+(L.min<1.5?'c':(L.min<3?'w':''))+'"><label>Mín. LiDAR</label>'+(L.min>=99?'—':L.min.toFixed(2)+' m')+'</div><div><label>Puntos mapa</label>'+(f.mapPts.length/2)+'</div>'; }
  if($('lrf')._h!==h){ $('lrf').innerHTML=h; $('lrf')._h=h; }
};
})();
