/* ===== GRÁFICOS: niveles de calidad, texturas procedurales, materiales y geometrías auxiliares ===== */
var GFX = {};
(function(){
var clamp=SD.clamp;
/* ---------- niveles de calidad ---------- */
var LV={
  low:  {id:'low',  name:'Bajo',  px:0.8, pxMax:1,   shadow:0,    shR:0,  env:0, clouds:0, tex:0, seg:0, geo:0, facade:0, aniso:1,  phys:0},
  med:  {id:'med',  name:'Medio', px:1,   pxMax:1,   shadow:1024, shR:32, env:1, clouds:3, tex:1, seg:0, geo:1, facade:1, aniso:4,  phys:0},
  high: {id:'high', name:'Alto',  px:1,   pxMax:1.5, shadow:2048, shR:45, env:1, clouds:4, tex:1, seg:1, geo:2, facade:1, aniso:8,  phys:1},
  ultra:{id:'ultra',name:'Ultra', px:1,   pxMax:2,   shadow:4096, shR:60, env:1, clouds:5, tex:1, seg:2, geo:3, facade:1, aniso:16, phys:1}
};
GFX.LV=LV; GFX.ORDER=['low','med','high','ultra']; GFX.MODES=['auto','low','med','high','ultra'];
function ls(k,v){ try{ if(v===undefined) return localStorage.getItem(k); localStorage.setItem(k,v); }catch(e){} return null; }
var urlM=null; try{ var um=/[?&]gfx=(auto|low|med|high|ultra)/.exec(location.search); if(um) urlM=um[1]; }catch(e){}
GFX.mode=urlM||ls('santsim_gfx')||'auto'; if(GFX.MODES.indexOf(GFX.mode)<0) GFX.mode='auto';
var autoLv=ls('santsim_gfx_auto'); if(GFX.ORDER.indexOf(autoLv)<0) autoLv='high';
GFX.level=GFX.mode==='auto'?autoLv:GFX.mode; GFX.q=LV[GFX.level];
GFX.setMode=function(m){ GFX.mode=m; ls('santsim_gfx',m); if(m==='auto'){ autoLv='high'; ls('santsim_gfx_auto','high'); } GFX.level=(m==='auto'?autoLv:m); GFX.q=LV[GFX.level]; GFX.fpsReset(); };
GFX.label=function(){ return GFX.mode==='auto'?'Auto ('+GFX.q.name+')':GFX.q.name; };
GFX.pixelRatio=function(){ var d=window.devicePixelRatio||1; return Math.max(0.5,Math.min(d,GFX.q.pxMax)*GFX.q.px); };
/* medidor de fotogramas y bajada automática de nivel */
var fT=0,fN=0,fps=60,slow=0;
GFX.fpsReset=function(){ fT=0; fN=0; slow=0; };
GFX.fps=function(){ return fps; };
GFX.tick=function(dtReal){   /* devuelve true si hay que bajar un nivel (modo automático) */
  if(!(dtReal>0)||dtReal>3){ fT=0; fN=0; return false; }   /* pausas largas (pestaña oculta, hangar): no cuentan */
  fT+=dtReal; fN++; if(fT<1) return false;
  fps=fN/fT; fT=0; fN=0;
  if(GFX.mode!=='auto') return false;
  if(fps<27) slow++; else slow=0;
  if(slow>=3){ slow=0; var i=GFX.ORDER.indexOf(GFX.level); if(i>0){ autoLv=GFX.ORDER[i-1]; ls('santsim_gfx_auto',autoLv); GFX.level=autoLv; GFX.q=LV[autoLv]; return true; } }
  return false;
};
GFX.uTime={value:0}; GFX.uNight={value:0};

/* ---------- ruido y texturas procedurales (teselables) ---------- */
function hash(i,j,s){ var n=Math.sin(i*127.1+j*311.7+s*74.7)*43758.5453; return n-Math.floor(n); }
function vnoise(x,y,per,s){ var xi=Math.floor(x), yi=Math.floor(y), xf=x-xi, yf=y-yi, u=xf*xf*(3-2*xf), v=yf*yf*(3-2*yf);
  var x0=((xi%per)+per)%per, x1=(x0+1)%per, y0=((yi%per)+per)%per, y1=(y0+1)%per;
  var a=hash(x0,y0,s), b=hash(x1,y0,s), c=hash(x0,y1,s), d=hash(x1,y1,s); return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v; }
function fbm(u,v,per,oct,s){ var f=0,a=0.5,p=per,t=0; for(var o=0;o<oct;o++){ f+=a*vnoise(u*p,v*p,p,s+o*7); t+=a; a*=0.5; p*=2; } return f/t; }
GFX.fbm=fbm;
var TC={};
function field(N,fn){ var h=new Float32Array(N*N); for(var j=0;j<N;j++) for(var i=0;i<N;i++) h[j*N+i]=fn(i/N,j/N); return h; }
function texFrom(N,fill,srgb,q){ var c=document.createElement('canvas'); c.width=c.height=N; var g=c.getContext('2d'), im=g.createImageData(N,N); fill(im.data); g.putImageData(im,0,0);
  var t=new THREE.CanvasTexture(c); t.wrapS=t.wrapT=THREE.RepeatWrapping; t.anisotropy=(q||GFX.q).aniso; if(srgb) t.colorSpace=THREE.SRGBColorSpace; return t; }
function grayTex(N,h,lo,hi){ return texFrom(N,function(d){ for(var i=0;i<N*N;i++){ var v=Math.round(255*clamp(lo+(hi-lo)*h[i],0,1)); d[i*4]=d[i*4+1]=d[i*4+2]=v; d[i*4+3]=255; } },true); }
function normalTex(N,h,str){ return texFrom(N,function(d){ for(var j=0;j<N;j++) for(var i=0;i<N;i++){ var l=h[j*N+((i+N-1)%N)], r=h[j*N+((i+1)%N)], u=h[((j+N-1)%N)*N+i], dn=h[((j+1)%N)*N+i];
    var nx=(l-r)*str, ny=(u-dn)*str, nz=1, k=1/Math.hypot(nx,ny,nz), o=(j*N+i)*4; d[o]=Math.round((nx*k*0.5+0.5)*255); d[o+1]=Math.round((ny*k*0.5+0.5)*255); d[o+2]=Math.round((nz*k*0.5+0.5)*255); d[o+3]=255; } },false); }
/* pareja color+normal para el suelo, según el tipo */
GFX.ground=function(kind){
  var key='g_'+kind+GFX.level; if(TC[key]) return TC[key];
  var N=GFX.q.geo>=2?512:256, h;
  if(kind==='urban') h=field(N,function(u,v){ return 0.55*fbm(u,v,6,3,11)+0.45*fbm(u,v,64,2,23); });
  else if(kind==='rock') h=field(N,function(u,v){ var a=fbm(u,v,5,5,31); return 0.55*a+0.25*Math.abs(a-0.5)*2+0.2*fbm(u,v,48,2,5); });
  else if(kind==='sand') h=field(N,function(u,v){ return 0.6*fbm(u,v,4,3,41)+0.4*(0.5+0.5*Math.sin((u*14+fbm(u,v,6,2,9)*2.2)*6.2832)); });
  else h=field(N,function(u,v){ return 0.5*fbm(u,v,5,4,3)+0.5*fbm(u,v,96,2,17); });
  var lo=kind==='urban'?0.8:(kind==='rock'?0.62:0.7);
  return (TC[key]={map:grayTex(N,h,lo,1.0),nrm:normalTex(N,h,kind==='urban'?1.6:(kind==='rock'?3.5:3))});
};
GFX.waterNormal=function(){ var key='wn'+GFX.level; if(TC[key]) return TC[key]; var N=256, h=field(N,function(u,v){ return 0.6*fbm(u,v,6,4,71)+0.4*fbm(u+0.37,v+0.11,13,3,83); }); return (TC[key]=normalTex(N,h,5)); };
GFX.lavaTex=function(){ var key='lava'; if(TC[key]) return TC[key]; var N=256, h=field(N,function(u,v){ var a=fbm(u,v,5,5,91); return Math.abs(a-0.5)*2; });
  return (TC[key]=texFrom(N,function(d){ for(var i=0;i<N*N;i++){ var k=clamp(1-h[i]*2.3,0,1), o=i*4; d[o]=Math.round(255*(0.16+0.84*k)); d[o+1]=Math.round(255*(0.03+0.62*k*k)); d[o+2]=Math.round(255*0.06*k*k*k); d[o+3]=255; } },true)); };
GFX.carbonTex=function(){ var key='carbon'; if(TC[key]) return TC[key]; var N=128;
  return (TC[key]=texFrom(N,function(d){ for(var j=0;j<N;j++) for(var i=0;i<N;i++){ var c=8, bx=Math.floor(i/c), by=Math.floor(j/c), t=((bx+by)%4+4)%4, hz=t<2, fx=(i%c)/c, fy=(j%c)/c;
    var v=hz?0.16+0.10*Math.sin(fy*3.1416):0.11+0.07*Math.sin(fx*3.1416), o=(j*N+i)*4, g=Math.round(255*v); d[o]=g; d[o+1]=g; d[o+2]=Math.round(g*1.06); d[o+3]=255; } },true)); };
GFX.blurTex=function(tip){ var key='blur'+tip; if(TC[key]) return TC[key]; var c=document.createElement('canvas'); c.width=c.height=128; var g=c.getContext('2d'), gr=g.createRadialGradient(64,64,4,64,64,64);
  gr.addColorStop(0,'rgba(30,34,40,0.55)'); gr.addColorStop(0.2,'rgba(30,34,40,0.30)'); gr.addColorStop(0.72,'rgba(30,34,40,0.42)'); gr.addColorStop(0.86,tip); gr.addColorStop(0.97,tip); gr.addColorStop(1,'rgba(30,34,40,0)');
  g.fillStyle=gr; g.fillRect(0,0,128,128); var t=new THREE.CanvasTexture(c); t.colorSpace=THREE.SRGBColorSpace; return (TC[key]=t); };
GFX.glowTex=function(){ var key='glow'; if(TC[key]) return TC[key]; var c=document.createElement('canvas'); c.width=c.height=64; var g=c.getContext('2d'), gr=g.createRadialGradient(32,32,0,32,32,32);
  gr.addColorStop(0,'rgba(255,255,255,1)'); gr.addColorStop(0.25,'rgba(255,255,255,0.55)'); gr.addColorStop(1,'rgba(255,255,255,0)'); g.fillStyle=gr; g.fillRect(0,0,64,64); var t=new THREE.CanvasTexture(c); t.colorSpace=THREE.SRGBColorSpace; return (TC[key]=t); };
GFX.flushTex=function(){ for(var k in TC){ var t=TC[k]; if(t.map){ t.map.dispose(); t.nrm.dispose(); } else t.dispose(); } TC={}; };

/* ---------- parches de sombreador ---------- */
/* coordenadas de textura a partir de la posición (mundo u objeto), para no depender de las UV de cada malla */
GFX.posUV=function(m,scale,obj,anim){
  m.onBeforeCompile=function(sh){ sh.uniforms.uT=GFX.uTime;
    sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nuniform float uT;').replace('#include <project_vertex>','#include <project_vertex>\n vec4 wU=vec4(transformed,1.0);\n'+(obj?'':'#ifdef USE_INSTANCING\n wU=instanceMatrix*wU;\n#endif\n wU=modelMatrix*wU;\n')+' vec2 uvW=wU.xz*'+scale.toFixed(5)+(anim?'+uT*vec2('+anim+')':'')+';\n#ifdef USE_MAP\n vMapUv=uvW;\n#endif\n#ifdef USE_NORMALMAP\n vNormalMapUv=uvW;\n#endif\n#ifdef USE_EMISSIVEMAP\n vEmissiveMapUv=uvW;\n#endif\n');
    if(m.userData.multi) sh.fragmentShader=sh.fragmentShader.replace('#include <map_fragment>',THREE.ShaderChunk.map_fragment.replace('texture2D( map, vMapUv )','( texture2D( map, vMapUv )*0.5 + texture2D( map, vMapUv*0.173+vec2(0.31,0.17) )*0.5 )'));
    if(anim&&m.userData.dual) sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nuniform float uT;').replace('#include <normal_fragment_maps>',THREE.ShaderChunk.normal_fragment_maps.replace('texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0','( texture2D( normalMap, vNormalMapUv ).xyz + texture2D( normalMap, vNormalMapUv*1.7 - uT*vec2(0.031,0.017) ).xyz ) - 1.0'));
  };
  m.customProgramCacheKey=function(){ return 'puv'+scale+(obj?'o':'w')+(anim||'')+(m.userData.dual?'d':'')+(m.userData.multi?'m':''); }; return m;
};
/* fachadas procedurales: 1 = ventanas (se iluminan de noche), 2 = sillería / bloques */
GFX.facade=function(m,mode){
  m.onBeforeCompile=function(sh){ sh.uniforms.uNight=GFX.uNight;
    sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vWp; varying vec3 vWn;').replace('#include <project_vertex>','#include <project_vertex>\n vec4 wpF=vec4(transformed,1.0); vec3 nF=objectNormal;\n#ifdef USE_INSTANCING\n wpF=instanceMatrix*wpF; nF=mat3(instanceMatrix)*nF;\n#endif\n wpF=modelMatrix*wpF; vWp=wpF.xyz; vWn=normalize(mat3(modelMatrix)*nF);\n');
    var fs=sh.fragmentShader.replace('#include <common>','#include <common>\nuniform float uNight; varying vec3 vWp; varying vec3 vWn; float gWin=0.0; float gLit=0.0;');
    var body=mode===1?
      ' { float wallF=step(abs(vWn.y),0.5); vec2 fuv=vec2(dot(vWp.xz,vec2(-vWn.z,vWn.x)),vWp.y); vec2 cl=fuv/vec2(3.4,3.1); vec2 ci=floor(cl), cf=fract(cl);\n'+
      '  float fw=max(fwidth(cl.x),fwidth(cl.y)); float fade=1.0-smoothstep(0.25,0.9,fw);\n'+
      '  float win=smoothstep(0.16,0.2,cf.x)*(1.0-smoothstep(0.8,0.84,cf.x))*smoothstep(0.26,0.3,cf.y)*(1.0-smoothstep(0.84,0.88,cf.y))*wallF;\n'+
      '  float rnd=fract(sin(dot(ci,vec2(12.9898,78.233)))*43758.5453);\n'+
      '  vec3 glass=mix(vec3(0.035,0.055,0.075),vec3(0.11,0.16,0.21),rnd*0.7);\n'+
      '  vec3 wall=diffuseColor.rgb*(0.94+0.06*step(0.5,fract(ci.y*0.5)));\n'+
      '  vec3 near=mix(wall,glass,win); vec3 far=mix(diffuseColor.rgb,glass,0.36*wallF);\n'+
      '  diffuseColor.rgb=mix(far,near,fade);\n'+
      '  diffuseColor.rgb=mix(diffuseColor.rgb,vec3(0.2,0.2,0.21),step(0.5,vWn.y)*0.75);\n'+
      '  gWin=mix(0.36*wallF,win,fade); gLit=mix(0.3,step(0.7,rnd),fade); }\n':
      ' { float wallF=step(abs(vWn.y),0.5); vec2 fuv=vec2(dot(vWp.xz,vec2(-vWn.z,vWn.x)),vWp.y); vec2 b=fuv/vec2(1.6,0.8); b.x+=0.5*floor(b.y); vec2 bf=fract(b), bi=floor(b);\n'+
      '  float fw=max(fwidth(b.x),fwidth(b.y)); float fade=(1.0-smoothstep(0.2,0.7,fw))*wallF;\n'+
      '  float mort=1.0-smoothstep(0.02,0.06,min(min(bf.x,1.0-bf.x),min(bf.y,1.0-bf.y)));\n'+
      '  float rnd=fract(sin(dot(bi,vec2(12.9898,78.233)))*43758.5453);\n'+
      '  diffuseColor.rgb*=mix(1.0,(0.86+0.26*rnd)*(1.0-0.45*mort),fade); }\n';
    fs=fs.replace('#include <color_fragment>','#include <color_fragment>\n'+body);
    if(mode===1) fs=fs.replace('#include <roughnessmap_fragment>','#include <roughnessmap_fragment>\n roughnessFactor=mix(roughnessFactor,0.07,gWin);').replace('#include <emissivemap_fragment>','#include <emissivemap_fragment>\n totalEmissiveRadiance+=vec3(1.0,0.74,0.38)*gWin*gLit*uNight*1.25;');
    sh.fragmentShader=fs;
  };
  m.extensions={derivatives:true};
  m.customProgramCacheKey=function(){ return 'fac'+mode; }; return m;
};

/* ---------- geometría ---------- */
var _m4=new THREE.Matrix4(), _q=new THREE.Quaternion(), _e=new THREE.Euler(), _p=new THREE.Vector3(), _s=new THREE.Vector3(), _up=new THREE.Vector3(0,1,0), _d=new THREE.Vector3();
/* superficie por secciones: rings = lista de anillos (cada uno, lista de [x,y,z]) con el mismo número de puntos */
GFX.loft=function(rings,capA,capB){
  var n=rings[0].length, P=[], IX=[];
  rings.forEach(function(r){ r.forEach(function(p){ P.push(p[0],p[1],p[2]); }); });
  for(var i=0;i<rings.length-1;i++) for(var j=0;j<n;j++){ var a=i*n+j, b=i*n+(j+1)%n, c=(i+1)*n+j, d=(i+1)*n+(j+1)%n; IX.push(a,c,b,b,c,d); }
  function cap(ri,flip){ var r=rings[ri], cx=0,cy=0,cz=0; r.forEach(function(p){ cx+=p[0]; cy+=p[1]; cz+=p[2]; }); var o=P.length/3, b0=o+1; P.push(cx/n,cy/n,cz/n);
    r.forEach(function(p){ P.push(p[0],p[1],p[2]); }); for(var j=0;j<n;j++){ var a=b0+j, b=b0+(j+1)%n; if(flip) IX.push(o,b,a); else IX.push(o,a,b); } }
  if(capA) cap(0,false); if(capB) cap(rings.length-1,true);
  var g=new THREE.BufferGeometry(); g.setAttribute('position',new THREE.Float32BufferAttribute(P,3)); g.setIndex(IX); g.computeVertexNormals(); return g;
};
/* perfil alar NACA de 4 cifras: devuelve puntos [xc, yt] recorriendo extradós (BS→BA) e intradós (BA→BS) */
GFX.airfoil=function(t,m,p,n){ n=n||9; t=t||0.12; m=m||0; p=p||0.4; var up=[], lo=[];
  for(var i=0;i<=n;i++){ var be=i/n*Math.PI, x=0.5*(1-Math.cos(be)), yt=5*t*(0.2969*Math.sqrt(x)-0.126*x-0.3516*x*x+0.2843*x*x*x-0.1036*x*x*x*x), yc=m?(x<p?m/(p*p)*(2*p*x-x*x):m/((1-p)*(1-p))*((1-2*p)+2*p*x-x*x)):0;
    up.push([x,yc+yt]); lo.push([x,yc-yt]); }
  var r=[]; for(var i=n;i>=0;i--) r.push(up[i]); for(var i=1;i<n;i++) r.push(lo[i]); return r; };
/* ala: estaciones {s: envergadura, c: cuerda, le: posición del borde de ataque en z, y: altura, tw: torsión (rad), t: espesor relativo}. Eje de envergadura x, morro hacia -z */
GFX.wing=function(st,af){ var rings=st.map(function(q){ var pr=af||GFX.airfoil(q.t||0.12,q.m||0.02,0.4), cs=Math.cos(q.tw||0), sn=Math.sin(q.tw||0);
    return pr.map(function(a){ var zc=(a[0]-0.25)*q.c, yc=a[1]*q.c; return [q.s, (q.y||0)+yc*cs-zc*sn, q.le+0.25*q.c+zc*cs+yc*sn]; }); });
  return GFX.loft(rings,true,true); };
/* aleta vertical: igual que el ala pero con la envergadura en y */
GFX.fin=function(st){ var g=GFX.wing(st.map(function(q){ return {s:q.s,c:q.c,le:q.le,t:q.t||0.1,m:0.0001}; })); g.rotateZ(Math.PI/2); return g; };
/* fuselaje: estaciones {z, rx, ry, y, e (exponente de superelipse)} */
GFX.fuse=function(st,n){ n=n||14; var rings=st.map(function(q){ var r=[], e=q.e||2; for(var j=0;j<n;j++){ var a=-j/n*2*Math.PI, c=Math.cos(a), s=Math.sin(a);
      var x=Math.sign(c)*Math.pow(Math.abs(c),2/e)*q.rx, y=Math.sign(s)*Math.pow(Math.abs(s),2/e)*q.ry; r.push([x,(q.y||0)+y,q.z]); } return r; });
  return GFX.loft(rings,true,true); };
/* tubo entre dos puntos */
GFX.tube=function(a,b,r0,r1,seg){ _d.set(b[0]-a[0],b[1]-a[1],b[2]-a[2]); var len=_d.length()||1e-6; var g=new THREE.CylinderGeometry(r1===undefined?r0:r1,r0,len,seg||8);
  _q.setFromUnitVectors(_up,_d.normalize()); _m4.compose(_p.set((a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2),_q,_s.set(1,1,1)); g.applyMatrix4(_m4); return g; };
/* caja entre dos puntos (brazo plano): ancho w, grosor h */
GFX.beam=function(a,b,w0,w1,h){ _d.set(b[0]-a[0],b[1]-a[1],b[2]-a[2]); var len=_d.length()||1e-6; var g=new THREE.BoxGeometry(1,h,len); var pa=g.attributes.position;
  for(var i=0;i<pa.count;i++){ var z=pa.getZ(i); pa.setX(i,pa.getX(i)*(z<0?w0:w1)); } g.computeVertexNormals();
  _q.setFromUnitVectors(_p.set(0,0,1),_d.normalize()); _m4.compose(_p.set((a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2),_q,_s.set(1,1,1)); g.applyMatrix4(_m4); return g; };
GFX.rbox=function(w,h,d,r){ r=Math.min(r,w/2-1e-4,d/2-1e-4,h/2-1e-4); var bv0=Math.min(r*0.6,h*0.3); w-=2*bv0; d-=2*bv0; r=Math.max(1e-4,r-bv0); var s=new THREE.Shape(), x=w/2-r, z=d/2-r;
  s.moveTo(-x,-d/2); s.lineTo(x,-d/2); s.absarc(x,-z,r,-Math.PI/2,0,false); s.lineTo(w/2,z); s.absarc(x,z,r,0,Math.PI/2,false); s.lineTo(-x,d/2); s.absarc(-x,z,r,Math.PI/2,Math.PI,false); s.lineTo(-w/2,-z); s.absarc(-x,-z,r,Math.PI,Math.PI*1.5,false);
  var bv=Math.min(r*0.6,h*0.3), g=new THREE.ExtrudeGeometry(s,{depth:h-2*bv,bevelEnabled:true,bevelThickness:bv,bevelSize:bv,bevelSegments:2,curveSegments:5}); g.rotateX(-Math.PI/2); g.translate(0,-h/2+bv,0); return g; };
/* hélice: R radio, nb palas, eje y (gira en el plano xz) */
GFX.prop=function(R,nb,cmax,pitch){ var st=[], N=7; cmax=cmax||R*0.2; pitch=pitch||0.5;
  for(var i=0;i<=N;i++){ var r=0.1+0.9*i/N, c=cmax*(0.45+1.9*r*(1-r)*(1-0.35*r))*(i===N?0.45:1), tw=Math.atan(pitch*0.5/Math.max(r,0.15))*0.9; st.push({s:r*R,c:c,le:-c*0.5,tw:tw,t:0.1,m:0.03}); }
  var one=GFX.wing(st), list=[]; for(var k=0;k<nb;k++){ var g=one.clone(); g.rotateY(k*2*Math.PI/nb); list.push(g); }
  var hub=new THREE.CylinderGeometry(R*0.1,R*0.11,R*0.09,10); list.push(hub); return GFX.merge(list); };
/* fusiona geometrías (sólo posición y normal) */
GFX.merge=function(list){ var P=[],Nn=[],IX=[],o=0;
  list.forEach(function(g){ var pa=g.attributes.position, na=g.attributes.normal, ix=g.index; if(!na){ g.computeVertexNormals(); na=g.attributes.normal; }
    for(var i=0;i<pa.count;i++){ P.push(pa.getX(i),pa.getY(i),pa.getZ(i)); Nn.push(na.getX(i),na.getY(i),na.getZ(i)); }
    if(ix){ for(var i=0;i<ix.count;i++) IX.push(o+ix.getX(i)); } else { for(var i=0;i<pa.count;i++) IX.push(o+i); } o+=pa.count; g.dispose(); });
  var m=new THREE.BufferGeometry(); m.setAttribute('position',new THREE.Float32BufferAttribute(P,3)); m.setAttribute('normal',new THREE.Float32BufferAttribute(Nn,3)); m.setIndex(IX); return m; };
/* constructor por lotes: agrupa piezas por material para reducir llamadas de dibujo */
function Batch(){ this.p={}; }
Batch.prototype.add=function(mk,g,x,y,z,rx,ry,rz,sx,sy,sz){ if(x!==undefined){ _e.set(rx||0,ry||0,rz||0); _q.setFromEuler(_e); _m4.compose(_p.set(x||0,y||0,z||0),_q,_s.set(sx===undefined?1:sx,sy===undefined?(sx===undefined?1:sx):sy,sz===undefined?(sx===undefined?1:sx):sz)); g.applyMatrix4(_m4); }
  (this.p[mk]||(this.p[mk]=[])).push(g); return this; };
Batch.prototype.build=function(grp,mats){ for(var k in this.p){ var m=new THREE.Mesh(GFX.merge(this.p[k]),mats[k]); m.castShadow=true; m.receiveShadow=true; grp.add(m); } this.p={}; };
GFX.Batch=Batch;

/* ---------- materiales del dron ---------- */
GFX.droneMats=function(){
  var q=GFX.q, env=q.env?1:0.0;
  function std(c,r,mt,o){ var m=new THREE.MeshStandardMaterial(Object.assign({color:c,roughness:r,metalness:mt||0,envMapIntensity:1},o||{})); return m; }
  function phys(c,r,mt,cc,o){ if(!q.phys) return std(c,r,mt,o); return new THREE.MeshPhysicalMaterial(Object.assign({color:c,roughness:r,metalness:mt||0,clearcoat:cc,clearcoatRoughness:0.12},o||{})); }
  var carbon=phys(0xffffff,0.42,0.1,0.7,{map:q.tex?GFX.carbonTex():null,color:q.tex?0xffffff:0x23262b}); if(q.tex){ GFX.posUV(carbon,60,true); }
  return {
    carbon:carbon,
    dark:std(0x23272d,0.55,0.05), darkGloss:phys(0x16191d,0.25,0.1,0.8), grey:std(0x60666e,0.5,0.1), lgrey:std(0xc9cdd1,0.42,0.05), white:phys(0xf2f2ee,0.35,0,0.5),
    orange:phys(0xe2552d,0.38,0.05,0.6), teal:phys(0x1f8a8a,0.3,0.1,0.8), yellow:std(0xf1c232,0.5,0), red:std(0xc2382e,0.45,0),
    alu:std(0xb8bcc2,0.32,0.9), aluDark:std(0x34383e,0.38,0.85), aluOrange:std(0xe0662e,0.34,0.85), steel:std(0xd8dadc,0.25,1),
    glass:phys(0x05070a,0.06,0.2,1), canopy:phys(0x2b4a66,0.08,0.3,1,{transparent:true,opacity:0.82}), rubber:std(0x121416,0.9,0),
    foam:std(0xf1f1ec,0.85,0), foamDark:std(0x1c1e21,0.85,0), foamOrange:std(0xe2552d,0.8,0), foamYellow:std(0xf2c81e,0.8,0), pcb:std(0x1f5a36,0.6,0.1), gold:std(0xd9b24a,0.35,0.9)
  };
};
})();
