/* ---------- i18n ES/EN: traduce DOM, atributos y texto de canvas en tiempo de ejecución ---------- */
var I18N=(function(){
  var KEY='santsim_lang', lang='es', EN=Object.create(null), EX=(typeof I18N_EXACT!=='undefined')?I18N_EXACT:{}, RE=null, cache=new Map(), CMAX=6000,
      orig=new WeakMap(), aorig=new WeakMap(), obs=null, subs=[], ATTRS=['title','placeholder','alt','aria-label'];
  var LET='A-Za-zÀ-ÿ';
  function esc(s){ return s.replace(/[.*+?^${}()|[\]\\\/]/g,'\\$&'); }
  function build(){
    var D=(typeof I18N_DICT!=='undefined')?I18N_DICT:[], keys=[];
    D.forEach(function(p){ EN[p[0]]=p[1]; keys.push(p[0]); });
    keys.sort(function(a,b){ return b.length-a.length; });
    var alts=keys.map(function(k){
      return (/^[A-Za-zÀ-ÿ]/.test(k)?'(?<!['+LET+'])':'')+esc(k)+(/[A-Za-zÀ-ÿ]$/.test(k)?'(?!['+LET+'])':'');
    });
    RE=new RegExp(alts.join('|'),'g');
  }
  function tr(s){
    if(lang!=='en'||typeof s!=='string'||s.length<1) return s;
    var c=cache.get(s); if(c!==undefined) return c;
    var tt=s.trim(), ex=EX[tt];
    if(ex!==undefined){ var r0=s.replace(tt,ex); cache.set(s,r0); return r0; }
    var r=/[A-Za-zÀ-ÿ]/.test(s)?s.replace(/(\d) de (\d)/g,'$1 of $2').replace(RE,function(m){ var v=EN[m]; return v===undefined?m:v; }):s;
    if(cache.size>CMAX) cache.clear();
    cache.set(s,r); return r;
  }
  function trText(n){
    var cur=n.nodeValue, r=orig.get(n);
    if(r&&cur===r.en) return;
    var en=tr(cur);
    if(en!==cur){ orig.set(n,{es:cur,en:en}); n.nodeValue=en; } else if(r) orig.delete(n);
  }
  function trAttrs(e){
    var rec=aorig.get(e);
    for(var i=0;i<ATTRS.length;i++){
      var a=ATTRS[i]; if(!e.hasAttribute(a)) continue;
      var cur=e.getAttribute(a), r=rec&&rec[a];
      if(r&&cur===r.en) continue;
      var en=tr(cur);
      if(en!==cur){ if(!rec){ rec={}; aorig.set(e,rec); } rec[a]={es:cur,en:en}; e.setAttribute(a,en); }
      else if(r) delete rec[a];
    }
  }
  function walk(root){
    if(!root) return;
    if(root.nodeType===3){ trText(root); return; }
    if(root.nodeType!==1) return;
    var tg=root.nodeName;
    if(tg==='SCRIPT'||tg==='STYLE'||tg==='CANVAS') return;
    trAttrs(root);
    var tw=document.createTreeWalker(root,5,{acceptNode:function(n){ if(n.nodeType===1){ var t=n.nodeName; if(t==='SCRIPT'||t==='STYLE') return 2; } return 1; }}), n;
    while((n=tw.nextNode())){ if(n.nodeType===3) trText(n); else trAttrs(n); }
  }
  function restore(){
    var tw=document.createTreeWalker(document.documentElement,5), n;
    while((n=tw.nextNode())){
      if(n.nodeType===3){ var r=orig.get(n); if(r){ if(n.nodeValue===r.en) n.nodeValue=r.es; orig.delete(n); } }
      else { var rec=aorig.get(n); if(rec){ for(var a in rec){ if(n.getAttribute(a)===rec[a].en) n.setAttribute(a,rec[a].es); } aorig.delete(n); } }
    }
  }
  function startObs(){
    if(obs||typeof MutationObserver==='undefined') return;
    obs=new MutationObserver(function(list){
      for(var i=0;i<list.length;i++){
        var m=list[i];
        if(m.type==='childList'){ for(var j=0;j<m.addedNodes.length;j++) walk(m.addedNodes[j]); }
        else if(m.type==='characterData') trText(m.target);
        else if(m.type==='attributes') trAttrs(m.target);
      }
    });
    obs.observe(document.documentElement,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:ATTRS});
  }
  function stopObs(){ if(obs){ obs.disconnect(); obs=null; } }
  function paintSwitch(){
    var el=document.getElementById('lang'); if(!el) return;
    var bs=el.querySelectorAll('button');
    for(var i=0;i<bs.length;i++){ var on=bs[i].getAttribute('data-l')===lang; bs[i].classList.toggle('on',on); bs[i].setAttribute('aria-pressed',on?'true':'false'); }
  }
  function set(l,noSave){
    if(l!=='es'&&l!=='en') return;
    if(l===lang){ paintSwitch(); return; }
    lang=l; cache.clear();
    if(!noSave){ try{ localStorage.setItem(KEY,l); }catch(e){} }
    document.documentElement.setAttribute('lang',l);
    if(l==='en'){ walk(document.head&&document.head.querySelector('title')); walk(document.body); startObs(); }
    else { stopObs(); restore(); }
    paintSwitch();
    for(var i=0;i<subs.length;i++){ try{ subs[i](l); }catch(e){} }
  }
  /* texto original en español de un nodo (para lógica que lee el DOM) */
  function es(node){
    if(!node) return '';
    if(node.nodeType===3){ var r=orig.get(node); return r&&node.nodeValue===r.en?r.es:node.nodeValue; }
    var out='', tw=document.createTreeWalker(node,4), n;
    while((n=tw.nextNode())) out+=es(n);
    return out;
  }
  /* canvas 2D: traduce lo que se dibuja con fillText/strokeText/measureText */
  (function(){
    if(typeof CanvasRenderingContext2D==='undefined') return;
    var P=CanvasRenderingContext2D.prototype;
    ['fillText','strokeText'].forEach(function(m){ var o=P[m]; P[m]=function(t,x,y,w){ return lang==='en'?o.call(this,tr(String(t)),x,y,w):o.call(this,t,x,y,w); }; });
    var mt=P.measureText; P.measureText=function(t){ return mt.call(this,lang==='en'?tr(String(t)):t); };
  })();
  build();
  var st=null; try{ st=localStorage.getItem(KEY); }catch(e){}
  var want=st||((navigator.language||'es').slice(0,2).toLowerCase()==='es'?'es':'en');
  var el=document.getElementById('lang');
  if(el) el.addEventListener('click',function(ev){ var b=ev.target.closest&&ev.target.closest('button[data-l]'); if(b) set(b.getAttribute('data-l')); });
  if(want==='en'){ lang='en'; document.documentElement.setAttribute('lang','en'); startObs(); walk(document.head&&document.head.querySelector('title')); walk(document.body); }
  paintSwitch();
  return { tr:tr, set:set, es:es, get lang(){ return lang; }, onChange:function(f){ subs.push(f); } };
})();
