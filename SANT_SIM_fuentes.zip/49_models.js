/* ===== MODELOS 3D DE LAS AERONAVES (materiales físicos, geometría por secciones) ===== */
(function(){
var clamp=SD.clamp, PI=Math.PI;
var propCache={};
function propGeo(R,nb,axis){ var k=R.toFixed(4)+'_'+nb; if(!propCache[k]) propCache[k]=GFX.prop(R,nb); var g=propCache[k].clone(); if(axis==='z') g.rotateX(PI/2); else if(axis==='x') g.rotateZ(PI/2); return g; }
GFX.flushModels=function(){ for(var k in propCache) propCache[k].dispose(); propCache={}; };
/* hélice con disco de desenfoque; axis: 'y' (por defecto), 'z' o 'x' */
function mkProp(D,nb,front,axis,cons){
  var R=D/2, g=new THREE.Group(), col=cons?0x50555c:(front?0xe2552d:0x2b3036);
  var bm=new THREE.MeshStandardMaterial({color:col,roughness:0.45,metalness:0,transparent:true});
  var bl=new THREE.Mesh(propGeo(R,nb,axis),bm); bl.castShadow=true; g.add(bl);
  var dk=new THREE.Mesh(new THREE.CircleGeometry(R,GFX.q.geo?32:18),new THREE.MeshBasicMaterial({map:GFX.blurTex(front?'rgba(226,85,45,0.6)':'rgba(30,34,40,0.5)'),transparent:true,opacity:0,depthWrite:false,side:THREE.DoubleSide}));
  if(axis==='z'){ } else if(axis==='x') dk.rotation.y=PI/2; else dk.rotation.x=-PI/2;
  dk.visible=false; g.add(dk);
  return {g:g,bl:bl,dk:dk,k:0};
}
/* motor sin escobillas vertical (eje y) apoyado en (x,y,z) */
function motorY(B,x,y,z,rm,front,cons){
  var hm=rm*1.25;
  B.add('aluDark',new THREE.CylinderGeometry(rm*0.92,rm,hm*0.3,14),x,y+hm*0.15,z);
  B.add(cons?'dark':'aluDark',new THREE.CylinderGeometry(rm,rm,hm*0.5,16),x,y+hm*0.58,z);
  B.add(cons?'grey':(front?'aluOrange':'alu'),new THREE.CylinderGeometry(rm*0.5,rm,hm*0.18,16),x,y+hm*0.92,z);
  B.add('steel',new THREE.CylinderGeometry(rm*0.13,rm*0.13,hm*0.5,8),x,y+hm*1.2,z);
  B.add(cons?'grey':(front?'aluOrange':'alu'),new THREE.ConeGeometry(rm*0.26,hm*0.3,10),x,y+hm*1.5,z);
  return y+hm*1.16;
}
/* góndola con motor de eje z (morro hacia -z) */
function nacelleZ(B,x,y,z,rn,len,mk,front){
  B.add(mk,GFX.fuse([{z:-len*0.1,rx:rn*0.9,ry:rn*0.9},{z:len*0.1,rx:rn,ry:rn},{z:len*0.6,rx:rn*0.85,ry:rn*0.85},{z:len,rx:rn*0.3,ry:rn*0.3}],12),x,y,z);
  B.add('aluDark',new THREE.CylinderGeometry(rn*0.8,rn*0.8,rn*0.9,12),x,y,z-len*0.1-rn*0.45,PI/2,0,0);
  B.add(front?'aluOrange':'alu',new THREE.ConeGeometry(rn*0.5,rn*1.3,12),x,y,z-len*0.1-rn*1.7,-PI/2,0,0);
  return z-len*0.1-rn*1.1;
}
function armAngles(n){ var r=[]; for(var i=0;i<n;i++){ var a=i*2*PI/n+(n===4?PI/4:PI/n); if(n===3) a=i*2*PI/3+PI; r.push(a); } return r; }
function led(B,x,y,z,r,front){ B.add(front?'ledG':'ledR',new THREE.SphereGeometry(r,8,6),x,y,z); }

/* ---------- multirrotores genéricos ---------- */
function multiGeneric(ac,B,O){
  var d=ac.frame.dim, n=ac.rotors, R=d/2, D=ac.D, ang=armAngles(n), rm=clamp(D*0.105,0.006,0.05), small=d<0.3, pro=(d>=0.56||n>=6);
  var nb=D<0.16?3:2, gear, propY;
  ang.forEach(function(a,i){ O.mot.push({x:Math.sin(a)*R,z:-Math.cos(a)*R,front:Math.cos(a)>0.3,dir:(i%2?1:-1)}); });
  if(small){
    var whoop=d<0.2; gear=Math.max(d*0.07,O.minGear);
    B.add('carbon',GFX.rbox(d*0.2,d*0.018,d*0.56,d*0.04),0,0,0);
    B.add('carbon',GFX.rbox(d*0.17,d*0.014,d*0.5,d*0.035),0,d*0.13,0);
    [[-1,-1],[1,-1],[-1,1],[1,1],[-1,0],[1,0]].forEach(function(q){ B.add('aluOrange',new THREE.CylinderGeometry(d*0.011,d*0.011,d*0.13,8),q[0]*d*0.07,d*0.065,q[1]*d*0.21); });
    B.add('pcb',new THREE.BoxGeometry(d*0.12,d*0.012,d*0.12),0,d*0.035,d*0.02); B.add('dark',new THREE.BoxGeometry(d*0.12,d*0.03,d*0.12),0,d*0.07,d*0.02);
    B.add('dark',GFX.rbox(d*0.085,d*0.085,d*0.07,d*0.012),0,d*0.07,-d*0.255,0.3,0,0);
    B.add('glass',new THREE.CylinderGeometry(d*0.028,d*0.028,d*0.03,14),0,d*0.082,-d*0.295,PI/2+0.3,0,0);
    B.add('grey',GFX.rbox(d*0.16,d*0.1,d*0.36,d*0.015),0,d*0.19,d*0.02);
    B.add('yellow',new THREE.BoxGeometry(d*0.163,d*0.05,d*0.2),0,d*0.19,d*0.02);
    B.add('rubber',new THREE.BoxGeometry(d*0.172,d*0.108,d*0.05),0,d*0.19,-d*0.06);
    [-1,1].forEach(function(s){ B.add('dark',GFX.tube([s*d*0.05,d*0.13,d*0.24],[s*d*0.1,d*0.3,d*0.36],d*0.006,d*0.006,6)); B.add('rubber',new THREE.SphereGeometry(d*0.014,8,6),s*d*0.1,d*0.3,d*0.36); });
    O.mot.forEach(function(m){
      B.add('carbon',GFX.beam([0,0,0],[m.x,0,m.z],d*0.11,d*0.085,d*0.02));
      B.add('rubber',new THREE.CylinderGeometry(d*0.02,d*0.014,gear,8),m.x*0.82,-gear/2,m.z*0.82);
      propY=motorY(B,m.x,d*0.01,m.z,rm,m.front);
      if(whoop) B.add(m.front?'orange':'dark',new THREE.TorusGeometry(D/2*1.1,d*0.02,6,GFX.q.geo?28:16),m.x,propY,m.z,PI/2,0,0);
      led(B,m.x,-d*0.016,m.z,d*0.016,m.front);
    });
    O.cam=null; O.top=[0,d*0.25,d*0.1]; O.camBuilt=true;
  } else if(!pro){
    var hubR=d*0.17; gear=Math.max(d*0.17,O.minGear);
    B.add('carbon',new THREE.CylinderGeometry(hubR,hubR,d*0.008,24),0,d*0.022,0); B.add('carbon',new THREE.CylinderGeometry(hubR*0.92,hubR*0.92,d*0.008,24),0,-d*0.022,0);
    B.add('dark',new THREE.CylinderGeometry(hubR*0.55,hubR*0.55,d*0.04,16),0,0,0);
    var cg=new THREE.SphereGeometry(hubR*0.74,20,10,0,2*PI,0,PI/2); B.add('teal',cg,0,d*0.026,0,0,0,0,1,0.55,1.15);
    B.add('dark',GFX.tube([0,d*0.03,d*0.11],[0,d*0.13,d*0.11],d*0.006,d*0.006,6)); B.add('white',new THREE.CylinderGeometry(d*0.036,d*0.036,d*0.014,16),0,d*0.135,d*0.11);
    B.add('grey',GFX.rbox(d*0.11,d*0.06,d*0.3,d*0.012),0,-d*0.058,0); B.add('yellow',new THREE.BoxGeometry(d*0.112,d*0.03,d*0.16),0,-d*0.058,0); B.add('rubber',new THREE.BoxGeometry(d*0.118,d*0.066,d*0.035),0,-d*0.056,-d*0.05);
    O.mot.forEach(function(m){
      var ux=m.x/R, uz=m.z/R;
      B.add(m.front?'orange':'dark',GFX.beam([ux*hubR*0.5,0,uz*hubR*0.5],[m.x,0,m.z],d*0.075,d*0.05,d*0.036));
      B.add('dark',GFX.tube([m.x*0.6,-d*0.016,m.z*0.6],[m.x*0.72,-gear+d*0.012,m.z*0.72],d*0.013,d*0.01,6)); B.add('rubber',new THREE.SphereGeometry(d*0.018,8,6),m.x*0.72,-gear+d*0.016,m.z*0.72);
      propY=motorY(B,m.x,d*0.018,m.z,rm,m.front); led(B,m.x,-d*0.024,m.z,d*0.014,m.front);
    });
    O.cam=[0,-d*0.1,-d*0.12]; O.top=[0,d*0.1,-d*0.02]; O.camS=d*0.09;
  } else {
    var hubR2=d*(n>=6?0.17:0.15), tr=Math.max(0.008,d*0.016); gear=Math.max(d*0.3,O.minGear);
    var pg=new THREE.CylinderGeometry(hubR2,hubR2,d*0.006,n>=6?n:8); B.add('carbon',pg,0,d*0.022,0,0,PI/n,0); B.add('carbon',new THREE.CylinderGeometry(hubR2,hubR2,d*0.006,n>=6?n:8),0,-d*0.022,0,0,PI/n,0);
    B.add('dark',new THREE.CylinderGeometry(hubR2*0.6,hubR2*0.6,d*0.04,16),0,0,0);
    B.add('darkGloss',new THREE.SphereGeometry(hubR2*0.62,20,10,0,2*PI,0,PI/2),0,d*0.025,0,0,0,0,1,0.6,1);
    B.add('dark',GFX.tube([0,d*0.03,d*0.1],[0,d*0.17,d*0.1],d*0.005,d*0.005,6)); B.add('white',new THREE.CylinderGeometry(d*0.03,d*0.03,d*0.012,16),0,d*0.175,d*0.1);
    [-1,1].forEach(function(s){ B.add('grey',GFX.rbox(d*0.09,d*0.065,d*0.26,d*0.01),s*d*0.055,-d*0.062,0); B.add('yellow',new THREE.BoxGeometry(d*0.092,d*0.03,d*0.14),s*d*0.055,-d*0.062,0);
      B.add('carbon',GFX.tube([s*d*0.09,-d*0.03,0],[s*d*0.21,-gear+tr,0],tr*0.9,tr*0.9,8)); B.add('carbon',GFX.tube([s*d*0.21,-gear+tr,-d*0.25],[s*d*0.21,-gear+tr,d*0.25],tr*0.85,tr*0.85,8));
      [-1,1].forEach(function(e){ B.add('rubber',new THREE.SphereGeometry(tr*1.25,8,6),s*d*0.21,-gear+tr,e*d*0.25); }); });
    O.mot.forEach(function(m){
      var ux=m.x/R, uz=m.z/R;
      B.add('carbon',GFX.tube([ux*hubR2*0.55,0,uz*hubR2*0.55],[m.x,0,m.z],tr,tr,10));
      B.add(m.front?'aluOrange':'aluDark',new THREE.CylinderGeometry(tr*1.5,tr*1.5,d*0.03,10),ux*hubR2*0.95,0,uz*hubR2*0.95,PI/2,Math.atan2(ux,uz),0);
      B.add('aluDark',new THREE.CylinderGeometry(rm*1.15,rm*1.15,d*0.012,14),m.x,tr,m.z);
      propY=motorY(B,m.x,tr+d*0.006,m.z,rm,m.front); led(B,m.x,-tr*1.4,m.z,d*0.012,m.front);
    });
    O.cam=[0,-d*0.12,-d*0.1]; O.top=[0,d*0.09,-d*0.03]; O.camS=d*0.08;
  }
  O.mot.forEach(function(m){ var pr=mkProp(D,nb,m.front,'y'); pr.g.position.set(m.x,propY,m.z); pr.dir=m.dir; O.props.push(pr); });
  O.gear=gear;
}

/* ---------- drones comerciales ---------- */
function consumer(ac,B,O,M){
  var id=ac.cm.id, d=ac.frame.dim, R=d/2, D=ac.D, ang=armAngles(4), rm=clamp(D*0.1,0.005,0.045), nb=2, propY;
  ang.forEach(function(a,i){ O.mot.push({x:Math.sin(a)*R,z:-Math.cos(a)*R,front:Math.cos(a)>0.3,dir:(i%2?1:-1)}); });
  O.camBuilt=true;
  if(id==='dji-m350'){
    var g=Math.max(d*0.36,O.minGear), tr=d*0.022;
    B.add('dark',GFX.rbox(d*0.3,d*0.2,d*0.48,d*0.04),0,0,0); B.add('darkGloss',GFX.rbox(d*0.22,d*0.05,d*0.3,d*0.02),0,d*0.11,-d*0.02);
    B.add('grey',GFX.rbox(d*0.24,d*0.14,d*0.16,d*0.02),0,-d*0.01,d*0.27);
    [-1,1].forEach(function(s){ B.add('dark',GFX.tube([s*d*0.06,d*0.12,d*0.18],[s*d*0.1,d*0.34,d*0.24],d*0.008,d*0.006,6));
      B.add('dark',GFX.tube([s*d*0.12,-d*0.09,0],[s*d*0.3,-g+tr,0],tr*0.8,tr*0.8,8)); B.add('dark',GFX.tube([s*d*0.3,-g+tr,-d*0.24],[s*d*0.3,-g+tr,d*0.24],tr*0.7,tr*0.7,8));
      [-1,1].forEach(function(e){ B.add('rubber',new THREE.SphereGeometry(tr,8,6),s*d*0.3,-g+tr,e*d*0.24); }); });
    O.mot.forEach(function(m){ var ux=m.x/R, uz=m.z/R; B.add('dark',GFX.tube([ux*d*0.14,d*0.02,uz*d*0.2],[m.x,d*0.07,m.z],tr,tr*0.9,10));
      propY=motorY(B,m.x,d*0.07,m.z,rm*1.2,m.front,true); led(B,m.x,d*0.03,m.z,d*0.012,m.front); });
    B.add('dark',GFX.rbox(d*0.08,d*0.06,d*0.06,d*0.01),0,d*0.02,-d*0.26); B.add('glass',new THREE.CylinderGeometry(d*0.02,d*0.02,d*0.02,12),0,d*0.02,-d*0.295,PI/2,0,0);
    B.add('aluDark',new THREE.CylinderGeometry(d*0.03,d*0.03,d*0.05,12),0,-d*0.12,-d*0.14); B.add('dark',GFX.rbox(d*0.05,d*0.12,d*0.05,d*0.01),d*0.085,-d*0.19,-d*0.14);
    B.add('lgrey',GFX.rbox(d*0.13,d*0.11,d*0.15,d*0.02),0,-d*0.2,-d*0.15); B.add('glass',new THREE.CylinderGeometry(d*0.032,d*0.032,d*0.03,16),-d*0.025,-d*0.2,-d*0.235,PI/2,0,0); B.add('glass',new THREE.CylinderGeometry(d*0.018,d*0.018,d*0.03,12),d*0.035,-d*0.185,-d*0.235,PI/2,0,0);
    O.gear=g; O.top=[0,d*0.14,d*0.05]; nb=2;
  } else if(id==='dji-avata2'){
    var g2=Math.max(d*0.2,O.minGear);
    B.add('dark',GFX.rbox(d*0.36,d*0.22,d*0.78,d*0.05),0,0,0); B.add('grey',GFX.rbox(d*0.26,d*0.16,d*0.4,d*0.03),0,d*0.17,d*0.16);
    B.add('darkGloss',GFX.rbox(d*0.2,d*0.2,d*0.12,d*0.03),0,d*0.02,-d*0.42); B.add('glass',new THREE.CylinderGeometry(d*0.065,d*0.065,d*0.04,18),0,d*0.02,-d*0.49,PI/2,0,0);
    O.mot.forEach(function(m){ B.add('dark',GFX.beam([0,0,0],[m.x,-d*0.02,m.z],d*0.14,d*0.1,d*0.03)); propY=motorY(B,m.x,-d*0.02,m.z,rm,m.front,true);
      B.add('grey',new THREE.TorusGeometry(D/2*1.12,d*0.045,8,GFX.q.geo?32:18),m.x,propY,m.z,PI/2,0,0);
      for(var k=0;k<3;k++){ var a=k*2*PI/3+0.5; B.add('grey',GFX.beam([m.x,propY-d*0.05,m.z],[m.x+Math.sin(a)*D/2*1.1,propY-d*0.02,m.z+Math.cos(a)*D/2*1.1],d*0.025,d*0.025,d*0.012)); }
      B.add('rubber',new THREE.CylinderGeometry(d*0.03,d*0.02,g2-d*0.05,8),m.x,-(g2+d*0.05)/2,m.z); led(B,m.x*1.05,-d*0.06,m.z*1.05,d*0.018,m.front); });
    O.gear=g2; O.top=[0,d*0.27,d*0.2]; nb=3;
  } else {
    var tello=id==='tello', big=(id==='dji-air3s'||id==='dji-mavic4pro'), shell=tello?'white':(big?'cgrey':'lgrey');
    var L=d*(tello?0.8:0.66), W=d*(tello?0.42:0.3), H=d*(tello?0.3:0.21), g3=Math.max(H/2+d*0.05,O.minGear);
    B.add(shell,GFX.fuse([{z:-L/2,rx:W*0.22,ry:H*0.24,y:-H*0.06,e:2.6},{z:-L*0.43,rx:W*0.42,ry:H*0.42,y:-H*0.02,e:2.8},{z:-L*0.22,rx:W/2,ry:H/2,e:3},{z:L*0.25,rx:W/2,ry:H/2,e:3},{z:L*0.44,rx:W*0.43,ry:H*0.42,e:2.8},{z:L/2,rx:W*0.26,ry:H*0.26,e:2.6}],GFX.q.geo?20:12),0,0,0);
    B.add(tello?'dark':'darkGloss',GFX.rbox(W*0.56,H*0.06,L*0.5,W*0.08),0,H*0.49,L*0.08);
    O.mot.forEach(function(m){ var s=Math.sign(m.x), ay=m.front?H*0.16:-H*0.12;
      B.add(shell,GFX.beam([s*W*0.4,m.front?H*0.1:-H*0.15,m.front?-L*0.3:L*0.3],[m.x,ay,m.z],d*0.055,d*0.042,d*0.032));
      propY=motorY(B,m.x,ay+d*0.012,m.z,rm,m.front,true);
      B.add(shell,GFX.tube([m.x,ay,m.z],[m.x,-g3+d*0.008,m.z],d*0.012,d*0.009,6)); B.add('rubber',new THREE.SphereGeometry(d*0.012,6,5),m.x,-g3+d*0.01,m.z);
      led(B,m.x,ay-d*0.02,m.z+(m.front?-1:1)*d*0.02,d*0.012,m.front);
      if(tello){ B.add('white',new THREE.TorusGeometry(D/2*1.12,d*0.016,6,GFX.q.geo?28:16),m.x,propY-d*0.01,m.z,PI/2,0,0); for(var k=0;k<3;k++){ var ga=k*2*PI/3+0.4; B.add('white',GFX.beam([m.x,ay,m.z],[m.x+Math.sin(ga)*D/2*1.1,propY-d*0.012,m.z+Math.cos(ga)*D/2*1.1],d*0.02,d*0.02,d*0.01)); } }
    });
    if(!tello){ var cr=H*(id==='dji-mavic4pro'?0.4:0.3);
      B.add('dark',GFX.rbox(W*0.5,H*0.3,L*0.1,d*0.01),0,-H*0.12,-L*0.47); B.add('darkGloss',new THREE.SphereGeometry(cr,16,12),0,-H*0.2,-L*0.5-cr*0.5,0,0,0,1,0.92,1);
      B.add('glass',new THREE.CylinderGeometry(cr*0.55,cr*0.55,cr*0.3,16),0,-H*0.2,-L*0.5-cr*1.35,PI/2,0,0); B.add('alu',new THREE.TorusGeometry(cr*0.58,cr*0.07,6,18),0,-H*0.2,-L*0.5-cr*1.42);
      if(big) [-1,1].forEach(function(s){ B.add('glass',new THREE.CylinderGeometry(H*0.1,H*0.1,d*0.01,12),s*W*0.2,H*0.22,-L*0.455,PI/2-0.5,0,0); });
    } else { B.add('glass',new THREE.CylinderGeometry(H*0.14,H*0.14,d*0.03,12),0,-H*0.02,-L*0.5,PI/2,0,0); }
    O.gear=g3; O.top=[0,H*0.55,L*0.1]; O.frontY=H*0.16; O.rearY=-H*0.12;
  }
  O.mot.forEach(function(m){ var pr=mkProp(D,nb,m.front,'y',true); var y=propY; if(O.frontY!==undefined){ var hm=rm*1.25; y=(m.front?O.frontY:O.rearY)+d*0.012+hm*1.16; } pr.g.position.set(m.x,y,m.z); pr.dir=m.dir; O.props.push(pr); });
  M.cgrey=new THREE.MeshStandardMaterial({color:0x565b63,roughness:0.5,metalness:0.1});
}

/* ---------- helicóptero ---------- */
function heli(ac,B,O){
  var d=ac.frame.dim, L=d*0.75, g=Math.max(L*0.2,O.minGear), r=L*0.012;
  B.add('orange',GFX.fuse([{z:-L*0.42,rx:L*0.02,ry:L*0.02,y:-L*0.02},{z:-L*0.36,rx:L*0.07,ry:L*0.07,y:-L*0.012},{z:-L*0.2,rx:L*0.105,ry:L*0.115},{z:0,rx:L*0.1,ry:L*0.11},{z:L*0.15,rx:L*0.065,ry:L*0.075,y:L*0.012},{z:L*0.27,rx:L*0.028,ry:L*0.034,y:L*0.03}],GFX.q.geo?18:12),0,0,0);
  B.add('canopy',new THREE.SphereGeometry(L*0.088,18,12),0,L*0.035,-L*0.25,0,0,0,0.95,0.82,1.55);
  B.add('carbon',GFX.tube([0,L*0.03,L*0.2],[0,L*0.05,L*1.1],L*0.03,L*0.018,10));
  B.add('orange',GFX.fin([{s:-L*0.1,c:L*0.11,le:L*1.02},{s:L*0.17,c:L*0.06,le:L*1.09}]),0,L*0.05,0);
  B.add('orange',GFX.wing([{s:-L*0.13,c:L*0.06,le:L*0.84,t:0.1},{s:0,c:L*0.075,le:L*0.82,t:0.1},{s:L*0.13,c:L*0.06,le:L*0.84,t:0.1}]),0,L*0.045,0);
  B.add('aluDark',new THREE.BoxGeometry(L*0.03,L*0.04,L*0.05),0,L*0.055,L*1.1);
  B.add('steel',GFX.tube([0,L*0.09,-L*0.05],[0,L*0.275,-L*0.05],r,r,8)); B.add('aluDark',new THREE.CylinderGeometry(L*0.035,L*0.035,L*0.012,14),0,L*0.19,-L*0.05);
  B.add('alu',new THREE.BoxGeometry(L*0.12,L*0.022,L*0.03),0,L*0.275,-L*0.05); B.add('aluDark',new THREE.CylinderGeometry(L*0.05,L*0.06,L*0.07,12),0,L*0.13,-L*0.05);
  [-1,1].forEach(function(s){ B.add('aluDark',GFX.tube([s*L*0.14,-g+r,-L*0.32],[s*L*0.14,-g+r,L*0.2],r*0.9,r*0.9,8)); B.add('aluDark',GFX.tube([s*L*0.14,-g+r,-L*0.32],[s*L*0.14,-g+r*3,-L*0.37],r*0.9,r*0.9,6));
    [-L*0.2,L*0.08].forEach(function(z){ B.add('aluDark',GFX.tube([s*L*0.06,-L*0.09,z],[s*L*0.14,-g+r,z],r*0.8,r*0.8,6)); }); });
  var tr=mkProp(L*0.22,2,false,'x'); tr.g.position.set(L*0.035,L*0.055,L*1.1); tr.dir=1; tr.axis='x'; tr.tail=true; O.props.push(tr);
  var mr={g:new THREE.Group(),k:0,dir:-1,main:true}, Rr=d/2, c=d*0.048;
  var one=GFX.wing([{s:Rr*0.08,c:c*0.6,le:-c*0.3,tw:0.12,t:0.12},{s:Rr*0.16,c:c,le:-c*0.5,tw:0.1,t:0.12},{s:Rr*0.97,c:c,le:-c*0.5,tw:0.04,t:0.12},{s:Rr,c:c*0.6,le:-c*0.3,tw:0.04,t:0.1}]), two=one.clone(); two.rotateY(PI);
  mr.bl=new THREE.Mesh(GFX.merge([one,two]),new THREE.MeshStandardMaterial({color:0x1b1e22,roughness:0.4,transparent:true})); mr.bl.castShadow=true; mr.g.add(mr.bl);
  mr.dk=new THREE.Mesh(new THREE.CircleGeometry(Rr,GFX.q.geo?40:24),new THREE.MeshBasicMaterial({map:GFX.blurTex('rgba(241,194,50,0.55)'),transparent:true,opacity:0,depthWrite:false,side:THREE.DoubleSide})); mr.dk.rotation.x=-PI/2; mr.dk.visible=false; mr.g.add(mr.dk);
  mr.g.position.set(0,L*0.29,-L*0.05); O.props.push(mr);
  O.gear=g; O.cam=[0,-L*0.1,-L*0.3]; O.top=[0,L*0.12,L*0.1]; O.camS=L*0.07; O.tailTop=[0,L*0.22,L*1.1];
}

/* ---------- ala volante (también eBee X y base de los tail-sitter) ---------- */
function flyingWing(B,b,ch,rootC,tipC,sweep,mkC,mkT,tw){
  /* tramo central y dos exteriores para poder darles color distinto */
  function st(s){ var u=Math.abs(s)/(b/2); return {s:s,c:ch*(rootC-(rootC-tipC)*u),le:ch*(-rootC/2+sweep*u),y:b/2*u*0.035,tw:-(tw||0.04)*u,t:0.13-0.03*u,m:0.01}; }
  var k=0.42, N=GFX.q.geo>=2?4:2, mid=[], out=[];
  for(var i=-N;i<=N;i++) mid.push(st(i/N*k*b/2));
  for(var j=0;j<=N;j++) out.push(st((k+(1-k)*j/N)*b/2));
  B.add(mkC,GFX.wing(mid)); B.add(mkT,GFX.wing(out)); var lf=GFX.wing(out.map(function(q){ return {s:-q.s,c:q.c,le:q.le,y:q.y,tw:q.tw,t:q.t,m:q.m}; }).reverse()); B.add(mkT,lf);
  return st(b/2);
}
function fixed(ac,B,O){
  var fr=ac.frame, b=fr.b, ch=fr.S/b, D=ac.D, ebee=!!(ac.cm&&ac.cm.id==='ebee-x');
  if(ac.type.id==='fw-wing'||ebee){
    var tip=flyingWing(B,b,ch,1.5,0.5,1.05,ebee?'foamDark':'grey',ebee?'foamYellow':'foam');
    B.add(ebee?'foamDark':'dark',GFX.fuse([{z:-ch*0.95,rx:ch*0.03,ry:ch*0.03},{z:-ch*0.72,rx:ch*0.12,ry:ch*0.1},{z:-ch*0.2,rx:ch*0.17,ry:ch*0.135,y:ch*0.01},{z:ch*0.4,rx:ch*0.13,ry:ch*0.11,y:ch*0.01},{z:ch*0.82,rx:ch*0.05,ry:ch*0.05}],14));
    if(!ebee) B.add('orange',GFX.rbox(ch*0.16,ch*0.02,ch*0.9,ch*0.05),0,ch*0.135,-ch*0.15);
    [-1,1].forEach(function(s){ B.add(ebee?'foamYellow':'foamOrange',GFX.fin([{s:0,c:ch*0.46,le:tip.le+ch*0.06},{s:ch*0.42,c:ch*0.22,le:tip.le+ch*0.34}]),s*b/2,tip.y,0);
      B.add(ebee?'foamYellow':'grey',new THREE.BoxGeometry(b*0.2,ch*0.012,ch*0.14),s*b*0.33,tip.y*0.66+ch*0.01,ch*0.66); });
    B.add('aluDark',new THREE.CylinderGeometry(ch*0.045,ch*0.045,ch*0.09,12),0,ch*0.01,ch*0.86,PI/2,0,0);
    var pr=mkProp(D,2,false,'z'); pr.g.position.set(0,ch*0.01,ch*0.93); pr.dir=1; pr.axis='z'; O.props.push(pr);
    O.gear=Math.max(ch*0.2,0.085); O.cam=[0,-ch*0.12,-ch*0.4]; O.top=[0,ch*0.14,ch*0.25]; O.camS=ch*0.2; O.fixedAcc=true;
  } else {
    var fl=b*0.62, y0=ch*0.13, zLE=-fl*0.05-ch*0.5;
    var fw=b*0.042, fh=b*0.05; y0=fh*0.95;
    B.add('foam',GFX.fuse([{z:-fl*0.4,rx:fw*0.35,ry:fh*0.35,e:2},{z:-fl*0.34,rx:fw*0.8,ry:fh*0.75,e:2.4},{z:-fl*0.18,rx:fw,ry:fh,e:2.8},{z:fl*0.02,rx:fw,ry:fh,e:2.8},{z:fl*0.25,rx:fw*0.6,ry:fh*0.62,y:fh*0.15,e:2.4},{z:fl*0.6,rx:fw*0.22,ry:fh*0.3,y:fh*0.4,e:2}],GFX.q.geo?16:10));
    B.add('orange',GFX.rbox(fw*2.02,fh*0.5,fl*0.3,fw*0.3),0,-fh*0.35,-fl*0.12);
    B.add('darkGloss',new THREE.SphereGeometry(fw*0.8,14,10),0,fh*0.75,-fl*0.24,0,0,0,0.85,0.6,2.0);
    function ws(s){ var u=Math.abs(s)/(b/2); return {s:s,c:ch*(1.12-0.5*u),le:zLE+ch*0.22*u,y:y0+b/2*u*0.06,tw:0.03-0.04*u,t:0.13,m:0.03}; }
    var k=0.62, mid=[], out=[]; for(var i=-3;i<=3;i++) mid.push(ws(i/3*k*b/2)); for(var j=0;j<=2;j++) out.push(ws((k+(1-k)*j/2)*b/2));
    B.add('foam',GFX.wing(mid)); B.add('foamOrange',GFX.wing(out)); B.add('foamOrange',GFX.wing(out.map(function(q){ return Object.assign({},q,{s:-q.s}); }).reverse()));
    B.add('foam',GFX.wing([{s:-b*0.18,c:ch*0.38,le:fl*0.5+ch*0.08,t:0.09,m:0.0001},{s:0,c:ch*0.52,le:fl*0.5,t:0.09,m:0.0001},{s:b*0.18,c:ch*0.38,le:fl*0.5+ch*0.08,t:0.09,m:0.0001}]),0,fh*0.42,0);
    B.add('foamOrange',GFX.fin([{s:fh*0.4,c:ch*0.56,le:fl*0.43},{s:fh*0.4+ch*0.6,c:ch*0.3,le:fl*0.57}]));
    B.add('aluDark',new THREE.CylinderGeometry(fw*0.4,fw*0.4,ch*0.05,12),0,0,-fl*0.4-ch*0.01,PI/2,0,0); B.add('orange',new THREE.ConeGeometry(fw*0.4,ch*0.14,14),0,0,-fl*0.4-ch*0.1,-PI/2,0,0);
    var pr2=mkProp(D,2,false,'z'); pr2.g.position.set(0,0,-fl*0.4-ch*0.045); pr2.dir=1; pr2.axis='z'; O.props.push(pr2);
    O.gear=fh; O.cam=[0,-fh*1.05,-fl*0.2]; O.top=[0,y0+ch*0.06,fl*0.05]; O.camS=ch*0.2; O.fixedAcc=true;
  }
}

/* ---------- tail-sitter ---------- */
function tailsitter(ac,B,O){
  var fr=ac.frame, tb=fr.b, tch=fr.S/tb, D=ac.D, tid=ac.type.id, tsd=ac.ts, rn=Math.max(0.018,D*0.1), legL=tch*1.05;
  var tip=flyingWing(B,tb,tch,1.5,0.55,0.925,'foamOrange','foam',0.02);
  B.add('dark',GFX.fuse([{z:-tch*0.8,rx:tch*0.03,ry:tch*0.03},{z:-tch*0.55,rx:tch*0.1,ry:tch*0.085},{z:0,rx:tch*0.13,ry:tch*0.1},{z:tch*0.6,rx:tch*0.07,ry:tch*0.06},{z:tch*0.78,rx:tch*0.02,ry:tch*0.02}],12));
  if(tsd.surf) [-1,1].forEach(function(s){ B.add('teal',new THREE.BoxGeometry(tb*0.3,tch*0.014,tch*0.16),s*tb*0.3,tip.y*0.6+tch*0.012,tch*0.64); });
  function leg(x,y){ B.add('carbon',GFX.tube([x,y,tch*0.25],[x,y,legL],0.008,0.008,6)); B.add('rubber',new THREE.SphereGeometry(0.016,8,6),x,y,legL); }
  function tsMotor(x,y,z,dir,front,pod){ var pz=nacelleZ(B,x,y,z+tch*0.05,rn,tch*0.6,pod||'dark',front); var pr=mkProp(D,2,front,'z'); pr.g.position.set(x,y,pz); pr.dir=dir; pr.axis='z'; O.props.push(pr); }
  if(tid==='ts-single'){
    tsMotor(0,0,-tch*0.82,1,true);
    [-1,1].forEach(function(s){ B.add('foamOrange',GFX.fin([{s:0,c:tch*0.7,le:tch*0.1},{s:tch*0.5,c:tch*0.4,le:tch*0.45}]),0,0,0,0,0,s<0?PI:0); leg(0,s*tch*0.42); leg(s*tb*0.3,0); });
  } else if(tid==='ts-twin'||tid==='ts-twinvec'){
    var vec=tid==='ts-twinvec';
    [-1,1].forEach(function(s,i){ tsMotor(s*tb*0.19,0,-tch*0.62,(i?1:-1),true,vec?'teal':'dark');
      B.add('foamOrange',GFX.fin([{s:-tch*0.3,c:tch*0.42,le:tip.le+tch*0.1},{s:0,c:tch*0.55,le:tip.le},{s:tch*0.3,c:tch*0.42,le:tip.le+tch*0.1}]),s*tb/2,tip.y,0);
      leg(s*tb/2,tip.y+tch*0.26); leg(s*tb/2,tip.y-tch*0.26); });
  } else if(tid==='ts-tri'){
    [-1,1].forEach(function(s,i){ tsMotor(s*tb*0.28,0,-tch*0.55,(i?1:-1),true); leg(s*tb*0.3,0); });
    B.add('foamOrange',GFX.fin([{s:0,c:tch*0.75,le:-tch*0.1},{s:tch*0.9,c:tch*0.4,le:tch*0.2}])); tsMotor(0,tch*0.92+D*0.2,-tch*0.12,1,false); leg(0,tch*0.8);
    B.add('foamOrange',GFX.fin([{s:0,c:tch*0.5,le:tch*0.2},{s:tch*0.45,c:tch*0.3,le:tch*0.45}]),0,0,0,0,0,PI); leg(0,-tch*0.42);
  } else {
    var yq=Math.max(tch*0.5,D*0.62);
    [[-1,1],[1,1],[-1,-1],[1,-1]].forEach(function(q,i){ var xq=q[0]*tb*0.3, yy=q[1]*yq; B.add('carbon',GFX.beam([xq,0,-tch*0.05],[xq,yy,-tch*0.05],0.014,0.014,tch*0.16)); tsMotor(xq,yy,-tch*0.2,(i%2?1:-1),q[1]>0); leg(xq,yy*0.8); });
  }
  O.legL=legL; O.gear=0; O.cam=[0,-tch*0.11,-tch*0.45]; O.top=[0,tch*0.11,tch*0.2]; O.camS=tch*0.2; O.fixedAcc=true;
}

/* ---------- accesorios ---------- */
function accessories(ac,B,O,body){
  var dim=ac.frame.dim, s=Math.max(dim,0.25), fx=O.fixedAcc, top=O.top||[0,s*0.1,0], spin=[], strobe=null;
  if(!O.camBuilt&&O.cam&&(ac.has('camhd')||ac.has('camir')||ac.has('camfpv'))){ var c=O.cam, k=O.camS||s*0.08;
    if(ac.has('camhd')||ac.has('camir')){ B.add('aluDark',new THREE.CylinderGeometry(k*0.3,k*0.3,k*0.4,10),c[0],c[1]+k*0.9,c[2]); B.add('dark',GFX.rbox(k*0.3,k*1.0,k*0.3,k*0.06),c[0]+k*0.75,c[1]+k*0.3,c[2]); B.add('dark',new THREE.BoxGeometry(k*0.8,k*0.22,k*0.3),c[0]+k*0.4,c[1]+k*0.7,c[2]);
      B.add(ac.has('camir')?'grey':'darkGloss',GFX.rbox(k*1.1,k*0.9,k*1.1,k*0.15),c[0],c[1],c[2]); B.add(ac.has('camir')?'gold':'glass',new THREE.CylinderGeometry(k*0.32,k*0.32,k*0.25,16),c[0],c[1],c[2]-k*0.62,PI/2,0,0); B.add('alu',new THREE.TorusGeometry(k*0.34,k*0.05,6,16),c[0],c[1],c[2]-k*0.72); }
    else { B.add('dark',GFX.rbox(k*0.7,k*0.7,k*0.6,k*0.1),c[0],c[1]+k*0.3,c[2]); B.add('glass',new THREE.CylinderGeometry(k*0.22,k*0.22,k*0.2,12),c[0],c[1]+k*0.3,c[2]-k*0.36,PI/2,0,0); } }
  if(ac.has('lidar')){ B.add('dark',new THREE.CylinderGeometry(s*0.05,s*0.055,s*0.04,16),top[0],top[1]+s*0.02,top[2]);
    var lh=new THREE.Mesh(GFX.merge([new THREE.CylinderGeometry(s*0.046,s*0.046,s*0.045,18),new THREE.BoxGeometry(s*0.03,s*0.02,s*0.095)]),O.M.darkGloss); lh.position.set(top[0],top[1]+s*0.063,top[2]); lh.castShadow=true; body.add(lh); spin.push(lh); }
  if(ac.has('chute')){ var cz=top[2]+s*0.12; B.add('white',new THREE.CylinderGeometry(s*0.045,s*0.045,s*0.1,14),top[0],top[1]+s*0.05,cz); B.add('orange',new THREE.CylinderGeometry(s*0.048,s*0.048,s*0.02,14),top[0],top[1]+s*0.105,cz); }
  if(ac.has('strobe')){ strobe=new THREE.Mesh(new THREE.SphereGeometry(s*0.03,10,8),new THREE.MeshBasicMaterial({color:0x7dff8e,toneMapped:false})); var sp=O.tailTop||[top[0],top[1]+s*0.03,top[2]+s*0.2]; strobe.position.set(sp[0],sp[1],sp[2]);
    var gl=new THREE.Sprite(new THREE.SpriteMaterial({map:GFX.glowTex(),color:0x55ff77,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false})); gl.scale.setScalar(s*0.5); strobe.add(gl); body.add(strobe); }
  /* luz de posición roja (siempre encendida) */
  var np=fx?[0,top[1]+s*0.01,top[2]+s*0.25]:[top[0],top[1]+s*0.012,top[2]+s*0.08];
  var nl=new THREE.Mesh(new THREE.SphereGeometry(Math.min(s,dim*1.4)*0.018,8,6),new THREE.MeshBasicMaterial({color:0xff4040,toneMapped:false})); nl.position.set(np[0],np[1],np[2]); body.add(nl);
  if(GFX.q.geo){ var g2=new THREE.Sprite(new THREE.SpriteMaterial({map:GFX.glowTex(),color:0xff3030,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,opacity:0.7})); g2.scale.setScalar(Math.min(s,dim*1.4)*0.13); nl.add(g2); }
  return {spin:spin,strobe:strobe};
}

/* construye el modelo dentro de `body`; devuelve hélices, piezas giratorias, luz estroboscópica, altura del tren y longitud de patas (tail-sitter) */
GFX.buildModel=function(ac,body,vk){
  var B=new GFX.Batch(), M=GFX.droneMats(), O={mot:[],props:[],M:M,minGear:ac.frame.dim<0.5?0.1/vk:0};
  M.ledG=new THREE.MeshBasicMaterial({color:0x3dff7a,toneMapped:false}); M.ledR=new THREE.MeshBasicMaterial({color:0xff3838,toneMapped:false});
  if(ac.kind==='multi'){ if(ac.cm) consumer(ac,B,O,M); else multiGeneric(ac,B,O); }
  else if(ac.kind==='heli') heli(ac,B,O);
  else if(ac.kind==='tailsitter') tailsitter(ac,B,O);
  else fixed(ac,B,O);
  var A=accessories(ac,B,O,body);
  B.build(body,M);
  O.props.forEach(function(p){ body.add(p.g); });
  return {props:O.props,spin:A.spin,strobe:A.strobe,gear:O.gear||0,legL:O.legL||0};
};
})();
