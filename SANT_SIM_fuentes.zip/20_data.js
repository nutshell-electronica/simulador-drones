/* ===== DATOS: aeronaves, componentes, meteo, enlaces ===== */
var SD = {};
SD.G = 9.80665;

/* Tipos de aeronave */
SD.TYPES = [
  {id:'quad',  name:'Cuadricóptero (4 rotores)', kind:'multi', rotors:4},
  {id:'tri',   name:'Tricóptero (3 rotores)',    kind:'multi', rotors:3},
  {id:'hexa',  name:'Hexacóptero (6 rotores)',   kind:'multi', rotors:6},
  {id:'octo',  name:'Octocóptero (8 rotores)',   kind:'multi', rotors:8},
  {id:'heli',  name:'Helicóptero RC (1 rotor + cola)', kind:'heli', rotors:1},
  {id:'fw-trainer', name:'Ala fija · entrenador', kind:'fixed', rotors:1},
  {id:'fw-wing',    name:'Ala fija · ala volante', kind:'fixed', rotors:1},
  {id:'fw-long',    name:'Ala fija · largo alcance', kind:'fixed', rotors:1},
  /* VTOL tail-sitter (ArduPilot Plane con Q_TAILSIT_ENABLE): despega y aterriza vertical sobre la cola */
  {id:'ts-single',   name:'Tail-sitter · monomotor 3D (ala + superficies)',   kind:'tailsitter', rotors:1},
  {id:'ts-twin',     name:'Tail-sitter · bimotor (ala volante con elevones)', kind:'tailsitter', rotors:2},
  {id:'ts-twinvec',  name:'Tail-sitter · bimotor vectorial (motores orientables)', kind:'tailsitter', rotors:2},
  {id:'ts-tri',      name:'Tail-sitter · tres motores con superficies',       kind:'tailsitter', rotors:3},
  {id:'ts-quadsurf', name:'Tail-sitter · cuatro motores con superficies',     kind:'tailsitter', rotors:4},
  {id:'ts-quadpure', name:'Tail-sitter · cuatro motores sin superficies',     kind:'tailsitter', rotors:4}
];

/* Variantes tail-sitter de ArduPilot: enable = Q_TAILSIT_ENABLE, cls = Q_FRAME_CLASS, typ = Q_FRAME_TYPE,
   motmx = Q_TAILSIT_MOTMX (máscara de motores que siguen en vuelo adelante), fw = nº de motores activos en vuelo adelante,
   surf = lleva superficies de control, vec = empuje vectorial (servos de inclinación), diff = guiñada por empuje diferencial */
SD.TS = {
  'ts-single':  {enable:1, cls:10, clsName:'Single/Dual', typ:0, motmx:0, fw:1, surf:true,  vec:false, diff:false, outputs:'Throttle + elevones/ailerones + timón', label:'Monomotor 3D'},
  'ts-twin':    {enable:1, cls:10, clsName:'Single/Dual', typ:0, motmx:0, fw:2, surf:true,  vec:false, diff:true,  outputs:'Throttle Left + Throttle Right + elevones', label:'Bimotor'},
  'ts-twinvec': {enable:1, cls:10, clsName:'Single/Dual', typ:0, motmx:0, fw:2, surf:true,  vec:true,  diff:true,  outputs:'Throttle Left/Right + Tilt Left/Right + elevones', label:'Bimotor vectorial'},
  'ts-tri':     {enable:1, cls:7,  clsName:'Tri',         typ:1, motmx:3, fw:2, surf:true,  vec:false, diff:false, outputs:'Motor 1–3 + elevones', label:'Tricóptero tail-sitter'},
  'ts-quadsurf':{enable:1, cls:1,  clsName:'Quad',        typ:1, motmx:3, fw:2, surf:true,  vec:false, diff:false, outputs:'Motor 1–4 + elevones', label:'Copter con superficies'},
  'ts-quadpure':{enable:2, cls:1,  clsName:'Quad',        typ:17,motmx:0, fw:4, surf:false, vec:false, diff:false, outputs:'Motor 1–4 (sin superficies; control como copter en todos los modos)', label:'Copter sin superficies'}
};
SD.PROPS_TS = ['7x5','8x6','9x6','9x7','10x7','11x7','12x8'];

/* Bastidores: m = masa de estructura+controladora (kg), dim = diagonal/envergadura (m),
   maxProp (pulgadas), maxPay (kg), cdA = área de arrastre frontal (m2), maxWind (m/s) */
SD.FRAMES = [
  {id:'quad-3', type:'quad', name:'3" micro (140 mm)',   m:0.085, dim:0.14, maxProp:3.5, maxPay:0.12, cdA:0.010, maxWind:6,  tilt:45, yawRate:200},
  {id:'quad-5', type:'quad', name:'5" FPV (220 mm)',     m:0.120, dim:0.22, maxProp:5.1, maxPay:0.30, cdA:0.016, maxWind:9,  tilt:50, yawRate:220},
  {id:'quad-450', type:'quad', name:'450 mm (tipo fotografía)', m:0.300, dim:0.45, maxProp:10.2, maxPay:1.2, cdA:0.040, maxWind:10, tilt:35, yawRate:120},
  {id:'quad-650', type:'quad', name:'650 mm (profesional)', m:0.650, dim:0.65, maxProp:15.5, maxPay:3.5, cdA:0.075, maxWind:12, tilt:32, yawRate:100},
  {id:'tri-450', type:'tri', name:'450 mm', m:0.280, dim:0.45, maxProp:10.2, maxPay:1.0, cdA:0.038, maxWind:9, tilt:32, yawRate:110},
  {id:'hexa-550', type:'hexa', name:'550 mm', m:0.560, dim:0.55, maxProp:12.2, maxPay:3.0, cdA:0.060, maxWind:12, tilt:32, yawRate:100},
  {id:'hexa-800', type:'hexa', name:'800 mm (carga pesada)', m:1.150, dim:0.80, maxProp:18.2, maxPay:6.0, cdA:0.110, maxWind:13, tilt:30, yawRate:80},
  {id:'octo-800', type:'octo', name:'800 mm', m:1.400, dim:0.80, maxProp:15.5, maxPay:6.0, cdA:0.120, maxWind:13, tilt:30, yawRate:80},
  {id:'octo-1000', type:'octo', name:'1000 mm (cine / carga)', m:2.200, dim:1.00, maxProp:18.2, maxPay:10.0, cdA:0.170, maxWind:14, tilt:28, yawRate:70},
  {id:'heli-450', type:'heli', name:'Clase 450 (rotor 0,72 m)', m:0.55, dim:0.72, fixedProp:0.72, tipSpeed:150, ctMax:0.022, maxPay:0.4, cdA:0.030, maxWind:9, tilt:40, yawRate:150},
  {id:'heli-700', type:'heli', name:'Clase 700 (rotor 1,40 m)', m:1.60, dim:1.40, fixedProp:1.40, tipSpeed:170, ctMax:0.015, maxPay:1.5, cdA:0.075, maxWind:13, tilt:35, yawRate:130},
  /* ala fija: S = superficie alar (m2), b = envergadura (m) */
  {id:'fwt-14', type:'fw-trainer', name:'Envergadura 1,4 m', m:0.65, dim:1.4, b:1.4, S:0.30, CL0:0.35, CLa:4.6, CD0:0.032, e:0.80, aMax:14, maxProp:12, maxPay:0.8, cdA:0.0, maxWind:9, vne:30},
  {id:'fww-10', type:'fw-wing', name:'Envergadura 1,0 m', m:0.42, dim:1.0, b:1.0, S:0.20, CL0:0.20, CLa:4.0, CD0:0.020, e:0.82, aMax:13, maxProp:10, maxPay:0.5, cdA:0.0, maxWind:10, vne:45},
  /* tail-sitter: aerodinámica como ala fija + datos de multirrotor (tilt, yawRate); cdA = resistencia de la ala vista de canto al viento horizontal en estacionario */
  {id:'tss-12', type:'ts-single',   name:'Envergadura 1,2 m', m:0.60, dim:1.2, b:1.2, S:0.26, CL0:0.20, CLa:4.0, CD0:0.024, e:0.80, aMax:13, maxProp:12, maxPay:0.6, cdA:0.20, maxWind:9, vne:40, tilt:35, yawRate:90},
  {id:'tst-12', type:'ts-twin',     name:'Envergadura 1,2 m', m:0.62, dim:1.2, b:1.2, S:0.24, CL0:0.20, CLa:4.0, CD0:0.022, e:0.80, aMax:13, maxProp:10, maxPay:0.6, cdA:0.19, maxWind:9, vne:40, tilt:35, yawRate:90},
  {id:'tst-16', type:'ts-twin',     name:'Envergadura 1,6 m', m:1.20, dim:1.6, b:1.6, S:0.40, CL0:0.22, CLa:4.2, CD0:0.022, e:0.84, aMax:13, maxProp:12, maxPay:1.2, cdA:0.30, maxWind:10, vne:45, tilt:32, yawRate:80},
  {id:'tsv-14', type:'ts-twinvec',  name:'Envergadura 1,4 m', m:0.85, dim:1.4, b:1.4, S:0.30, CL0:0.22, CLa:4.2, CD0:0.022, e:0.82, aMax:13, maxProp:11, maxPay:0.8, cdA:0.22, maxWind:11, vne:42, tilt:40, yawRate:110},
  {id:'tsr-14', type:'ts-tri',      name:'Envergadura 1,4 m', m:0.90, dim:1.4, b:1.4, S:0.30, CL0:0.20, CLa:4.0, CD0:0.024, e:0.80, aMax:13, maxProp:10, maxPay:0.8, cdA:0.22, maxWind:9, vne:40, tilt:35, yawRate:100},
  {id:'tsq-14', type:'ts-quadsurf', name:'Envergadura 1,4 m', m:1.10, dim:1.4, b:1.4, S:0.32, CL0:0.20, CLa:4.0, CD0:0.026, e:0.80, aMax:13, maxProp:10, maxPay:1.0, cdA:0.24, maxWind:10, vne:38, tilt:38, yawRate:100},
  {id:'tsp-10', type:'ts-quadpure', name:'Envergadura 1,0 m', m:0.80, dim:1.0, b:1.0, S:0.20, CL0:0.18, CLa:3.8, CD0:0.026, e:0.78, aMax:13, maxProp:8,  maxPay:0.5, cdA:0.17, maxWind:10, vne:36, tilt:40, yawRate:140},
  {id:'fwl-22', type:'fw-long', name:'Envergadura 2,2 m', m:1.30, dim:2.2, b:2.2, S:0.52, CL0:0.40, CLa:5.0, CD0:0.022, e:0.88, aMax:13, maxProp:14, maxPay:1.5, cdA:0.0, maxWind:9, vne:35}
];

/* Motores: kv, m (kg), imax (A continuos), maxS (celdas recomendadas), pmax (W, para helis) */
SD.MOTORS = [
  {id:'m1404', name:'1404 · 3800 KV',  kv:3800, m:0.016, imax:14,  maxS:4},
  {id:'m2306', name:'2306 · 2450 KV',  kv:2450, m:0.033, imax:40,  maxS:6},
  {id:'m2212', name:'2212 · 920 KV',   kv:920,  m:0.052, imax:22,  maxS:4},
  {id:'m2814', name:'2814 · 700 KV',   kv:700,  m:0.085, imax:28,  maxS:6},
  {id:'m3510', name:'3510 · 360 KV',   kv:360,  m:0.120, imax:30,  maxS:8},
  {id:'m4114', name:'4114 · 400 KV',   kv:400,  m:0.160, imax:38,  maxS:12},
  {id:'m5008', name:'5008 · 340 KV',   kv:340,  m:0.150, imax:25,  maxS:12},
  {id:'m2820', name:'2820 · 1100 KV (ala fija)', kv:1100, m:0.090, imax:35, maxS:4},
  {id:'m2208', name:'2208 · 1500 KV (ala fija)', kv:1500, m:0.045, imax:24, maxS:3},
  {id:'m3536', name:'3536 · 910 KV (ala fija)',  kv:910,  m:0.115, imax:38, maxS:6},
  {id:'mh450', name:'Helicóptero 450 · 3700 W pico', kv:1200, m:0.130, imax:60, maxS:6},
  {id:'mh700', name:'Helicóptero 700 · 5500 W pico', kv:700,  m:0.320, imax:100, maxS:12}
];

SD.PROPS_MULTI = ['3x3','5x4.3','7x4','8x4.5','9x4.7','10x4.5','11x4.7','12x4.5','13x4.4','15x5.5','17x5.8','18x6.1'];
SD.PROPS_FW = ['8x6','9x6','10x6','11x7','12x8','13x8','14x10'];

SD.ESC = [6,12,20,30,40,60,80,100,120];

SD.CHEM = [
  {id:'lipo25', name:'LiPo 25C',            vc:3.7, wh:150, c:25, hi:false},
  {id:'lipo75', name:'LiPo alta descarga 75C', vc:3.7, wh:140, c:75, hi:true},
  {id:'liion',  name:'Li-ion 21700 (autonomía)', vc:3.6, wh:210, c:5, hi:false}
];
SD.CAPS = [450,850,1300,1500,2200,3000,4500,5200,6000,10000,16000,22000];

/* Accesorios */
SD.ACC = [
  {id:'camfpv', name:'Cámara FPV + VTX', m:0.030, w:3.0, cdA:0.001, desc:'Permite volar en modo FPV'},
  {id:'camhd',  name:'Cámara 4K con gimbal', m:0.250, w:6.0, cdA:0.004, desc:'Vídeo estabilizado'},
  {id:'camir',  name:'Cámara térmica',       m:0.400, w:8.0, cdA:0.005, desc:'Inspección térmica'},
  {id:'lidar', name:'LiDAR 360° (escáner 2D, 25 m)', m:0.190, w:3.0, cdA:0.002, desc:'Escanea 120 puntos en un plano; muestra el entorno y construye un mapa'},
  {id:'lr-f', name:'Telémetro láser ToF · frontal (12 m)', m:0.025, w:0.4, cdA:0.0, desc:'Distancia hacia delante'},
  {id:'lr-b', name:'Telémetro láser ToF · trasero (12 m)', m:0.025, w:0.4, cdA:0.0, desc:'Distancia hacia atrás'},
  {id:'lr-l', name:'Telémetro láser ToF · izquierda (12 m)', m:0.025, w:0.4, cdA:0.0, desc:'Distancia a la pared izquierda'},
  {id:'lr-r', name:'Telémetro láser ToF · derecha (12 m)', m:0.025, w:0.4, cdA:0.0, desc:'Distancia a la pared derecha'},
  {id:'lr-u', name:'Telémetro láser ToF · arriba (12 m)', m:0.025, w:0.4, cdA:0.0, desc:'Distancia al techo'},
  {id:'lr-d', name:'Telémetro láser ToF · abajo (12 m)', m:0.025, w:0.4, cdA:0.0, desc:'Distancia al suelo'},
  {id:'flow', name:'Flujo óptico + altímetro', m:0.020, w:0.5, cdA:0.0, desc:'Mantiene la posición sin GNSS (interior, hasta 10 m de altura)'},
  {id:'alt',    name:'Altímetro láser',      m:0.050, w:1.5, cdA:0.0,  desc:'Altura sobre el suelo precisa'},
  {id:'rtk',    name:'GNSS RTK',             m:0.060, w:2.0, cdA:0.0,  desc:'Posición con error de cm'},
  {id:'obs',    name:'Sensores anticolisión',m:0.120, w:4.0, cdA:0.0,  desc:'Frena ante obstáculos frontales'},
  {id:'chute',  name:'Paracaídas',           m:0.150, w:0.5, cdA:0.0,  desc:'Tecla X: reduce velocidad de impacto'},
  {id:'strobe', name:'Luz estroboscópica verde', m:0.020, w:0.5, cdA:0.0, desc:'Obligatoria en vuelo nocturno (UE, cat. abierta)'},
  {id:'rid',    name:'Identificación remota', m:0.020, w:0.3, cdA:0.0, desc:'Exigida en clases C1–C3 (UE)'}
];

/* Configuraciones estándar */
SD.STD = {
  'quad':  {frame:'quad-450', motor:'m2212', prop:'10x4.5', esc:30, chem:'lipo25', cells:4, cap:3000, acc:['camhd','rid'], pay:0},
  'tri':   {frame:'tri-450',  motor:'m2212', prop:'10x4.5', esc:30, chem:'lipo25', cells:4, cap:3000, acc:['camfpv','rid'], pay:0},
  'hexa':  {frame:'hexa-550', motor:'m2814', prop:'12x4.5', esc:30, chem:'lipo25', cells:4, cap:5200, acc:['camhd','rid'], pay:0},
  'octo':  {frame:'octo-800', motor:'m3510', prop:'15x5.5', esc:40, chem:'lipo25', cells:6, cap:10000, acc:['camhd','rid'], pay:0},
  'heli':  {frame:'heli-450', motor:'mh450', prop:'',       esc:80, chem:'lipo25', cells:6, cap:3000, acc:['camfpv','rid'], pay:0},
  'fw-trainer': {frame:'fwt-14', motor:'m2820', prop:'10x6', esc:40, chem:'lipo25', cells:3, cap:3000, acc:['camfpv','rid'], pay:0},
  'fw-wing':    {frame:'fww-10', motor:'m2208', prop:'8x6',  esc:30, chem:'lipo25', cells:3, cap:2200, acc:['camfpv','rid'], pay:0},
  'ts-single':  {frame:'tss-12', motor:'m2814', prop:'11x7', esc:60, chem:'lipo25', cells:6, cap:3000, acc:['camfpv','rid'], pay:0},
  'ts-twin':    {frame:'tst-12', motor:'m2820', prop:'9x6',  esc:40, chem:'lipo25', cells:4, cap:3000, acc:['camfpv','rid'], pay:0},
  'ts-twinvec': {frame:'tsv-14', motor:'m3536', prop:'9x6',  esc:40, chem:'lipo25', cells:6, cap:5200, acc:['camfpv','rid'], pay:0},
  'ts-tri':     {frame:'tsr-14', motor:'m2820', prop:'10x7', esc:30, chem:'lipo25', cells:3, cap:5200, acc:['camfpv','rid'], pay:0},
  'ts-quadsurf':{frame:'tsq-14', motor:'m2212', prop:'9x7',  esc:60, chem:'lipo25', cells:4, cap:3000, acc:['camfpv','rid'], pay:0},
  'ts-quadpure':{frame:'tsp-10', motor:'m2820', prop:'8x6',  esc:40, chem:'lipo25', cells:4, cap:3000, acc:['camfpv','rid'], pay:0},
  'fw-long':    {frame:'fwl-22', motor:'m3536', prop:'11x7', esc:40, chem:'liion',  cells:4, cap:10000, acc:['camfpv','camhd','rid'], pay:0}
};

/* Equipo recomendado de cada bastidor que no es el estándar de su tipo (al cambiar de bastidor se reponen motor, hélice, ESC y batería) */
SD.FSTD = {
  'quad-3':   {motor:'m1404', prop:'3x3',    esc:12,  chem:'lipo25', cells:4, cap:850, acc:['camfpv','rid']},
  'quad-5':   {motor:'m2306', prop:'5x4.3',  esc:30,  chem:'lipo75', cells:4, cap:1500, acc:['camfpv','rid']},
  'quad-650': {motor:'m3510', prop:'15x5.5', esc:40,  chem:'lipo25', cells:6, cap:6000},
  'hexa-800': {motor:'m4114', prop:'17x5.8', esc:60,  chem:'lipo25', cells:6, cap:16000},
  'octo-1000':{motor:'m4114', prop:'17x5.8', esc:60,  chem:'lipo25', cells:6, cap:22000},
  'heli-700': {motor:'mh700', prop:'',       esc:100, chem:'lipo25', cells:12, cap:6000},
  'tst-16':   {motor:'m3536', prop:'10x6',   esc:60,  chem:'lipo25', cells:6, cap:5200}
};
SD.frameStd = function(frameId){
  var fr=SD.byId(SD.FRAMES,frameId); if(!fr) return null;
  var std=SD.STD[fr.type]; var src=(std&&std.frame===frameId)?std:SD.FSTD[frameId]; if(!src) return null;
  var r=JSON.parse(JSON.stringify(src)); r.frame=frameId; return r;
};


/* Meteorología: dir = de dónde viene el viento (grados) */
SD.WX = {
  calma:    {name:'Calma',            wind:0.5, dir:270, gust:0,  turb:0.0, temp:20, qnh:1015, vis:20, rain:0},
  brisa:    {name:'Brisa suave',      wind:4,   dir:250, gust:1.5,turb:0.15,temp:22, qnh:1015, vis:18, rain:0},
  viento:   {name:'Viento moderado',  wind:9,   dir:300, gust:3,  turb:0.35,temp:16, qnh:1008, vis:20, rain:0},
  racheado: {name:'Racheado',         wind:7,   dir:320, gust:8,  turb:0.65,temp:14, qnh:1004, vis:15, rain:0},
  lluvia:   {name:'Lluvia',           wind:6,   dir:230, gust:3,  turb:0.35,temp:11, qnh:1000, vis:4,  rain:8},
  niebla:   {name:'Niebla',           wind:1.2, dir:90,  gust:0,  turb:0.05,temp:6,  qnh:1022, vis:0.25,rain:0},
  temporal: {name:'Temporal',         wind:15,  dir:210, gust:11, turb:1.0, temp:9,  qnh:990,  vis:2.5, rain:18},
  calor:    {name:'Calor intenso',    wind:2,   dir:100, gust:1,  turb:0.5, temp:39, qnh:1006, vis:12, rain:0},
  frio:     {name:'Frío (−6 °C)',     wind:3,   dir:20,  gust:1,  turb:0.1, temp:-6, qnh:1028, vis:25, rain:0}
};

/* Enlaces de radio. sens = sensibilidad (dBm), lim = límite orientativo UE (mW EIRP/ERP) */
SD.CTRL_LINKS = [
  {id:'elrs868', name:'ELRS 868 MHz',        f:868,  sens:-112, lim:25,  powers:[10,25,100,500,1000]},
  {id:'elrs24',  name:'ELRS / Crossfire 2,4 GHz', f:2400, sens:-105, lim:100, powers:[10,25,100,250,500]},
  {id:'dig24',   name:'Enlace digital comercial 2,4 GHz', f:2400, sens:-92, lim:100, powers:[25,100,200]},
  {id:'lrs433',  name:'Telemetría 433 MHz',  f:433,  sens:-117, lim:10,  powers:[10,100,500,1000]}
];
SD.VID_LINKS = [
  {id:'ana58', name:'Vídeo analógico 5,8 GHz', f:5800, sens:-90, lim:25, powers:[25,200,600,1000], analog:true},
  {id:'dig58', name:'Vídeo digital HD 5,8 GHz', f:5800, sens:-88, lim:25, powers:[25,200,600], analog:false},
  {id:'ana12', name:'Vídeo analógico 1,2 GHz', f:1200, sens:-95, lim:25, powers:[25,200,600,1000], analog:true}
];
SD.GANT = [
  {id:'omni', name:'Omnidireccional (dipolo) 2 dBi', g:2, bw:0},
  {id:'patch', name:'Panel / patch 8 dBi (apuntado)', g:8, bw:70},
  {id:'helix', name:'Helicoidal 12 dBi (apuntado)', g:12, bw:45}
];

/* Utilidades */
SD.clamp = function(v,a,b){return v<a?a:(v>b?b:v)};
SD.lerp = function(a,b,t){return a+(b-a)*t};
SD.deg = Math.PI/180;
SD.interp = function(tab,x){ /* tab=[[x,y],...] ascendente */
  if(x<=tab[0][0])return tab[0][1];
  for(var i=1;i<tab.length;i++){ if(x<=tab[i][0]){ var t=(x-tab[i-1][0])/(tab[i][0]-tab[i-1][0]); return tab[i-1][1]+t*(tab[i][1]-tab[i-1][1]); } }
  return tab[tab.length-1][1];
};
SD.byId = function(arr,id){ for(var i=0;i<arr.length;i++) if(arr[i].id===id) return arr[i]; return null; };
SD.propDims = function(s){ var p=s.split('x'); return {D:parseFloat(p[0])*0.0254, P:parseFloat(p[1]), Din:parseFloat(p[0])}; };
if(typeof module!=='undefined') module.exports=SD;
