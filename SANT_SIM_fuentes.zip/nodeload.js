global.SD=require('./20_data.js');global.SM=require('./30a_build.js');
require('vm').runInThisContext(require('fs').readFileSync('./35_comm.js','utf8'));
require('vm').runInThisContext(require('fs').readFileSync('./30b_env.js','utf8'));
require('vm').runInThisContext(require('fs').readFileSync('./30c_dyn.js','utf8'));
require('vm').runInThisContext(require('fs').readFileSync('./31_tail.js','utf8'));
global.SW=require('./40_world.js');
require('vm').runInThisContext(require('fs').readFileSync('./46_comp.js','utf8'));
