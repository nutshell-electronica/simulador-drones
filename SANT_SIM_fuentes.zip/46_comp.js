/* ===== MODO COMPETICIÓN: recorrido de aros (lógica pura, sin gráficos) ===== */
(function(){
var DEG=Math.PI/180;
function lcg(seed){ var a=(seed>>>0)||1; return function(){ a=(a*1664525+1013904223)>>>0; return a/4294967296; }; }
SW.compLevel=function(n){ return n<=3?'Muy fácil':(n<=7?'Fácil':(n<=12?'Media':(n<=17?'Difícil':'Experto'))); };
/* parámetros por dificultad: a más aros, aros más pequeños, más separados y a alturas más distintas */
SW.compParams=function(n,fixed,indoor){
  var t=(Math.max(1,Math.min(20,n))-1)/19;
  if(indoor) return {r:1.9-0.5*t, d0:7, d1:11+5*t, h0:1.4, h1:4+6*t, maxD:38, turn:60+25*t};
  if(fixed)  return {r:13-6*t, d0:170, d1:240+80*t, h0:45, h1:70+40*t, maxD:900, turn:45+15*t};
  return {r:4.2-2.0*t, d0:22, d1:32+26*t, h0:2, h1:8+24*t, maxD:220+110*t, turn:55+25*t};
};
SW.compGen=function(w,o){
  var n=Math.max(1,Math.min(20,o.n|0)), P=SW.compParams(n,!!o.fixed,!!w.indoor), rnd=lcg(o.seed||1);
  var pts=[], px=w.home.x, pz=w.home.z, py=w.homeY+1.5, hd=(w.startHeading||0)*DEG+(rnd()-0.5)*0.3;
  function ok(x,y,z,r,h,att){
    if(w.indoor){ var I=w.indoor; if(x<I.x0+r+1||x>I.x1-r-1||z<I.z0+r+1||z>I.z1-r-1||y<r+0.6||y>I.h-r-0.6) return false; }
    else if(Math.abs(x)>SW.EXT*0.85||Math.abs(z)>SW.EXT*0.85) return false;
    if(Math.hypot(x-w.home.x,z-w.home.z)>P.maxD) return false;
    if(y-r<w.floorH(x,1e6,z)+0.7) return false;
    var tx=Math.cos(h), tz=Math.sin(h);
    for(var k=0;k<8;k++){ var a=k*Math.PI/4, sx=x+tx*Math.cos(a)*r, sy=y+Math.sin(a)*r, sz=z+tz*Math.cos(a)*r;
      if(sy<w.floorH(sx,1e6,sz)+0.4) return false; if(w.collide(sx,sy,sz,0.9)) return false; }
    if(w.collide(x,y,z,0.9)) return false;
    if(att<110){ var dx=x-px, dy=y-py, dz=z-pz, L=Math.sqrt(dx*dx+dy*dy+dz*dz)||1; if(w.ray(px,py,pz,dx/L,dy/L,dz/L,L).hit) return false; }
    return true;
  }
  for(var i=0;i<n;i++){
    var pl=null;
    for(var att=0;att<160&&!pl;att++){
      var far=Math.hypot(px-w.home.x,pz-w.home.z)>0.75*P.maxD, turn=P.turn*DEG*(att<40?1:1.7);
      var h2=far?Math.atan2(w.home.x-px,-(w.home.z-pz))+(rnd()-0.5)*1.4:hd+(rnd()*2-1)*turn;
      if(i===0&&att<60) h2=hd+(rnd()-0.5)*0.6;
      var d=P.d0+rnd()*(P.d1-P.d0), x=px+Math.sin(h2)*d, z=pz-Math.cos(h2)*d;
      var base=w.floorH(x,1e6,z), y=base+Math.max(P.h0+rnd()*(P.h1-P.h0),P.r+1.0);
      if(w.indoor) y=Math.max(P.r+0.7,Math.min(w.indoor.h-P.r-0.7,y));
      var md=d*0.45; y=Math.max(py-md,Math.min(py+md,y)); y=Math.max(y,base+P.r+0.9);
      if(ok(x,y,z,P.r,h2,att)) pl={x:x,y:y,z:z,h:h2};
    }
    if(!pl){   /* último recurso: por encima de lo que haya */
      var h3=hd, x3=px+Math.sin(h3)*P.d0, z3=pz-Math.cos(h3)*P.d0, y3=w.indoor?Math.min(w.indoor.h-P.r-0.7,py+1):Math.max(w.blockTop(x3,z3).top,w.floorH(x3,1e6,z3))+P.r+3;
      pl={x:x3,y:y3,z:z3,h:h3};
    }
    pts.push(pl); hd=pl.h; px=pl.x; py=pl.y; pz=pl.z;
  }
  /* normal de cada aro = bisectriz de la entrada y la salida */
  return pts.map(function(p,i){
    var a=i?pts[i-1]:{x:w.home.x,z:w.home.z}, ix=p.x-a.x, iz=p.z-a.z, il=Math.hypot(ix,iz)||1; ix/=il; iz/=il;
    var ox=ix, oz=iz; if(i<pts.length-1){ var b=pts[i+1]; ox=b.x-p.x; oz=b.z-p.z; var ol=Math.hypot(ox,oz)||1; ox/=ol; oz/=ol; }
    var nx=ix+ox, nz=iz+oz, nl=Math.hypot(nx,nz); if(nl<0.3){ nx=ix; nz=iz; nl=1; }
    return {k:i,x:p.x,y:p.y,z:p.z,r:P.r,nx:nx/nl,nz:nz/nl};
  });
};
SW.compNew=function(){ return {idx:0,t:0,running:false,done:false,failed:false,splits:[],prev:null,miss:0,missT:-9}; };
/* devuelve 1 = aro superado, 2 = recorrido completado, -1 = pasó por fuera */
SW.compStep=function(s,R,pos,dt,flying){
  if(s.done||s.failed){ s.prev=null; return 0; }
  if(!s.running&&flying) s.running=true;
  if(s.running) s.t+=dt;
  var res=0, g=R[s.idx], p=s.prev;
  if(g&&p){
    var s0=(p.x-g.x)*g.nx+(p.z-g.z)*g.nz, s1=(pos.x-g.x)*g.nx+(pos.z-g.z)*g.nz;
    if(s0!==s1&&((s0<=0&&s1>0)||(s0>=0&&s1<0))){
      var u=s0/(s0-s1), ix=p.x+(pos.x-p.x)*u, iy=p.y+(pos.y-p.y)*u, iz=p.z+(pos.z-p.z)*u;
      var lat=(ix-g.x)*(-g.nz)+(iz-g.z)*g.nx, dy=iy-g.y, dist=Math.hypot(lat,dy);
      if(dist<=g.r){ s.splits.push(s.t); s.idx++; res=1; if(s.idx>=R.length){ s.done=true; s.running=false; res=2; } }
      else if(dist<=g.r*2.5){ s.miss++; s.missT=s.t; res=-1; }
    }
  }
  s.prev={x:pos.x,y:pos.y,z:pos.z};
  return res;
};
})();
