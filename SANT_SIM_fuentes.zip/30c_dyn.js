/* ===== MODELO: dinámica de vuelo (multirrotor / helicóptero / ala fija) ===== */
(function(){
var D_ = (typeof SD!=='undefined'?SD:require('./20_data.js'));
var deg = D_.deg, clamp = D_.clamp, G = D_.G;
function angDiff(a,b){ var d=(a-b)%(2*Math.PI); if(d>Math.PI)d-=2*Math.PI; if(d<-Math.PI)d+=2*Math.PI; return d; }
SM.angDiff = angDiff;

SM.Flight = function(ac, world, wx, st){
  this.ac=ac; this.world=world; this.wx=wx; this.st=st;
  this.wind = new SM.Wind(wx,world,st.seed||11);
  this.reset();
};
var F = SM.Flight.prototype;

F.reset = function(){
  var ac=this.ac, w=this.world, h=w.home;
  this.t=0; this.pos={x:h.x,y:w.homeY+0.02,z:h.z}; this.vel={x:0,y:0,z:0};
  this.yaw=(w.startHeading||0)*deg; this.pitch=0; this.roll=0;
  this.status='ground'; this.crashMsg=''; this.landMsg='';
  this.thr=0; this.Tcur=0; this.thrPct=0; this.rpm=0;
  this.ahUsed=0; this.V=ac.cfg.cells*SM.vcell(ac.chem,0); this.I=0; this.P=0; this.dod=0;
  this.mode='GPS'; this.rth=false; this.rthPhase=''; this.rthReason='';
  this.iF=0; this.iR=0; this.iZ=0;
  this.fail=false; this.chute=0; this.chuteOpen=false;
  this.alpha=0; this.gamma=0; this.Va=0; this.stalled=false; this.CL=0; this.LoD=0;
  this.accel={x:0,y:0,z:0}; this.gload=1;
  this.atm=SM.atmo(w.elev,this.wx.qnh,this.wx.temp,0);
  this.wcur={x:0,y:0,z:0,mean:0,gust:0,speed:0};
  this.sens={gnss:{sats:16,hdop:1}, ctrl:null, vid:null, nextT:0, obsDist:99, obsLabel:''};
  this.landNow=false; this.landUser=false; this.fsBatt=false; this.fsBattLow=false; this.vLowT=0; this.fenceFired=false; this.fenceMsg=''; this.apWarn='';
  this.linkLostT=0; this.fsActive=''; this.maxAlt=0; this.maxDist=0; this.maxSpd=0; this.dist=0; this.flightT=0;
  this.sat=false; this.cmd={pitch:0,roll:0,yaw:0,thr:0};
  this.wind = new SM.Wind(this.wx,this.world,this.st.seed||11);
  this.motorOut=-1; this.mapPts=[]; this.mapSet={}; this.lidar=null; this.holdSrc='GNSS';
  if(this.ac.kind==='fixed'){ this.Va=0; this.pitch=0; }
  this.updateSensors();
};

F.agl = function(){ return this.pos.y-this.world.floorH(this.pos.x,this.pos.y,this.pos.z); };
F.hdist = function(){ var h=this.world.home; return Math.hypot(this.pos.x-h.x,this.pos.z-h.z); };
F.hspeed = function(){ return Math.hypot(this.vel.x,this.vel.z); };

F.crash = function(msg){ if(this.status==='crashed')return; this.status='crashed'; this.crashMsg=msg; this.Tcur=0; this.I=0; this.P=0; this.vel={x:0,y:0,z:0}; };

/* ---- enlaces y GNSS (10 Hz) ---- */
F.linkCalc = function(L,pw,ant){
  var w=this.world, h=w.home, ha={x:h.x,y:w.homeY+1.8,z:h.z}, p=this.pos;
  var dx=p.x-ha.x, dy=p.y-ha.y, dz=p.z-ha.z, hd=Math.hypot(dx,dz), d=Math.sqrt(hd*hd+dy*dy);
  var elev=Math.atan2(dy,Math.max(hd,1))/deg;
  var pt=SM.dbmFromMw(pw), gt=2, gr=ant.g+SM.antPattern(ant,elev);
  var fs=SM.fspl(d,L.f), pl=SM.pathLoss(w,ha,p,L.f), rain=SM.rainAtt(L.f,this.wx.rain,d);
  var noise=(w.rfNoise||0)+(this.st.rfNoise||0);
  var prx=pt+gt+gr-fs-pl.loss-rain-1.0, sens=L.sens+noise;
  return {d:d,elev:elev,pt:pt,gt:gt,gr:gr,fs:fs,obst:pl.loss,fol:pl.foliage,nu:pl.nu,clear:pl.clear,rain:rain,noise:noise,prx:prx,sens:sens,margin:prx-sens,cable:1.0,
          free:SM.rangeFree(pt,gt,ant.g,L.sens+noise,L.f,1.0)};
};
F.updateSensors = function(){
  var s=this.sens, st=this.st;
  s.gnss=SM.gnss(this.world,this.pos,this.wx.rain,st.jam);
  s.ctrl=this.linkCalc(st.ctrlLink,st.ctrlPw,st.ctrlAnt);
  s.vid =this.linkCalc(st.vidLink,st.vidPw,st.vidAnt);
  var o=this.world.nearestObstacle(this.pos.x,this.pos.y,this.pos.z,this.yaw);
  s.obsDist=o.dist; s.obsLabel=o.label; s.obsAhead=o.ahead;
  this.scanSensors();
};
/* rotación de un vector del sistema del dron al del mundo (mismo orden que el modelo 3D) */
F.rot=function(x,y,z){ var b=-this.roll,a=-this.pitch,c=-this.yaw,t,u;
  t=x*Math.cos(b)-y*Math.sin(b); u=x*Math.sin(b)+y*Math.cos(b); x=t; y=u;
  t=y*Math.cos(a)-z*Math.sin(a); u=y*Math.sin(a)+z*Math.cos(a); y=t; z=u;
  t=x*Math.cos(c)+z*Math.sin(c); u=-x*Math.sin(c)+z*Math.cos(c); return [t,y,u]; };
var RFDIR={'lr-f':['f',0,0,-1],'lr-b':['b',0,0,1],'lr-l':['l',-1,0,0],'lr-r':['r',1,0,0],'lr-u':['u',0,1,0],'lr-d':['d',0,-1,0]};
F.scanSensors=function(){
  var ac=this.ac, w=this.world, p=this.pos, L=this.lidar={rf:{},scan:null,min:99,any:false,max:0};
  var rng=this.rngS||(this.rngS=SM.rng(5)); function gs(){ return (rng()+rng()+rng()-1.5)*1.15; }
  var fac=1-Math.min(0.4,this.wx.rain/50), sunny=!w.indoor && this.st.tod==='dia', oy=p.y+0.05, self=this;
  Object.keys(RFDIR).forEach(function(id){ if(!ac.has(id)) return; var q=RFDIR[id], v=self.rot(q[1],q[2],q[3]), mx=12*fac*(sunny?0.5:1);
    var r=w.ray(p.x,oy,p.z,v[0],v[1],v[2],mx), d=r.hit?Math.max(0.03,r.d+gs()*(0.015+0.005*r.d)):null;
    L.rf[q[0]]={d:d,label:r.hit?r.label:'',max:mx}; L.any=true; if(d!==null&&d<L.min) L.min=d; });
  if(ac.has('lidar')){
    var N=120, mx2=25*fac, sc=new Array(N); L.max=mx2; L.any=true;
    for(var k=0;k<N;k++){ var a=k*Math.PI*2/N, v=this.rot(Math.sin(a),0,-Math.cos(a)), r=w.ray(p.x,oy,p.z,v[0],v[1],v[2],mx2);
      var d=r.hit?r.d+gs()*0.012:null; sc[k]={a:a,d:d};
      if(d!==null){ if(d<L.min)L.min=d; var hx=p.x+v[0]*d, hz=p.z+v[2]*d, key=Math.round(hx*5)+','+Math.round(hz*5);
        if(!this.mapSet[key]){ this.mapSet[key]=1; this.mapPts.push(hx,hz); if(this.mapPts.length>16000){ this.mapPts.splice(0,2); } } } }
    L.scan=sc;
  }
};

/* ---- ruta de regreso a casa / failsafes ---- */
F.bearingHome = function(){ var h=this.world.home; return Math.atan2(h.x-this.pos.x, -(h.z-this.pos.z)); };
F.startRTH = function(reason){ if(this.rth||this.status==='crashed')return; this.rth=true; this.rthPhase='climb'; this.rthReason=reason||'manual'; };
F.cancelRTH = function(){ this.rth=false; this.rthPhase=''; this.fsActive=''; };

F.ap = function(){ return this.st.ap||{}; };
F.rtlAlt = function(){ var ap=this.st.ap; return (ap&&ap.rtlAlt)?ap.rtlAlt:this.st.rthAlt; };
/* velocidad de descenso al aterrizar: perfil suave por defecto o el de los parámetros ArduPilot */
F.landRate = function(agl){
  var ap=this.st.ap||{};
  if(ap.landSpeed||ap.landSpeedHigh||ap.landAltLow){ return agl>(ap.landAltLow||10)?(ap.landSpeedHigh||1.5):(ap.landSpeed||0.5); }
  return clamp(0.35+agl*0.25,0.4,2.2);
};
F.toggleLand = function(){
  if(this.status!=='flying') return;
  if(this.landNow){ this.landNow=false; this.landUser=false; }
  else { this.cancelRTH(); this.landNow=true; this.landUser=true; }
};
F.checkFence = function(){
  var ap=this.st.ap; this.fenceMsg='';
  if(!ap||!ap.fenceOn||this.status!=='flying') { this.fenceFired=false; return; }
  var agl=this.agl(), dh=this.hdist(), br='';
  if(ap.fenceAltMax>0&&agl>ap.fenceAltMax) br='altura '+agl.toFixed(0)+' m > '+ap.fenceAltMax.toFixed(0)+' m';
  else if(ap.fenceRadius>0&&dh>ap.fenceRadius) br='distancia '+dh.toFixed(0)+' m > '+ap.fenceRadius.toFixed(0)+' m';
  if(br){ this.fenceMsg=br; if(!this.fenceFired){ this.fenceFired=true; if(ap.fenceAct==='rth') this.startRTH('Geovalla'); else if(ap.fenceAct==='land'){ this.landNow=true; this.landUser=false; } } }
  else this.fenceFired=false;
};

F.checkFailsafe = function(dt){
  var st=this.st, flying=this.status==='flying';
  if(!flying) return;
  var lost=this.sens.ctrl.margin<0;
  this.linkLostT = lost? this.linkLostT+dt : 0;
  var battPct=(1-this.dod)*100;
  if(this.linkLostT>1.5 && !this.fsActive){
    this.fsActive='link'; var a=(this.st.ap&&this.st.ap.fsLink)||st.fsLink;
    if(a==='rth') this.startRTH('Pérdida de enlace'); else if(a==='land') this.landNow=true;
  }
  if(!lost && this.fsActive==='link' && this.linkLostT===0 && this.rthReason==='Pérdida de enlace'){ /* recuperado: se mantiene RTH hasta que el piloto mueva mandos */ }
  var ap=this.st.ap||{}, remMah=(1-this.dod)*this.ac.battAh*SM.capFactor(this.wx.temp)*1000;
  var hasCrt=ap.battCrtV||ap.battCrtMah, hasLow=ap.battLowV||ap.battLowMah;
  if(ap.battCrtV||ap.battLowV){ this.vLowT = (this.V<(ap.battCrtV||0)||this.V<(ap.battLowV||0))? this.vLowT+dt : 0; }
  var crit = hasCrt ? ((ap.battCrtV&&this.V<ap.battCrtV&&this.vLowT>3)||(ap.battCrtMah&&remMah<ap.battCrtMah)) : battPct<15;
  var low = hasLow && ((ap.battLowV&&this.V<ap.battLowV&&this.vLowT>3)||(ap.battLowMah&&remMah<ap.battLowMah));
  if(low && !crit && !this.fsBattLow){ this.fsBattLow=true; var bl=ap.battLowAct||'none'; if(bl==='rth') this.startRTH('Batería baja'); else if(bl==='land'){ this.landNow=true; this.landUser=false; } }
  if(crit && !this.fsBatt){ this.fsBatt=true; var b=(hasCrt&&ap.battCrtAct)?ap.battCrtAct:st.fsBatt; if(b==='rth'){ this.startRTH('Batería crítica'); } else if(b==='land'){ this.landNow=true; this.landUser=false; } }
};

/* ============ PASO DE SIMULACIÓN ============ */
F.step = function(dt,cmd){
  if(this.status==='crashed') return;
  this.t+=dt;
  var ac=this.ac, w=this.world, p=this.pos;
  var agl=this.agl();
  this.atm=SM.atmo(w.elev,this.wx.qnh,this.wx.temp,Math.max(0,p.y-w.homeY));
  var rho=this.atm.rho;
  this.wcur=this.wind.step(dt,p.x,p.y,p.z,agl);
  /* batería: tensión bajo carga con la corriente del paso anterior */
  var T=this.wx.temp, rpack=ac.rcell*ac.cfg.cells*SM.rintFactor(T);
  this.dod=this.ahUsed/(ac.battAh*SM.capFactor(T));
  var voc=ac.cfg.cells*SM.vcell(ac.chem,this.dod);
  this.V=Math.max(ac.cfg.cells*2.5,voc-this.I*rpack);
  if(this.t>=this.sens.nextT){ this.sens.nextT=this.t+0.1; this.updateSensors(); }
  this.checkFailsafe(dt); this.checkFence();
  /* mando efectivo: cancelar RTH con mandos si hay enlace */
  var anyIn=Math.abs(cmd.pitch)+Math.abs(cmd.roll)+Math.abs(cmd.yaw)+(cmd.thrAbs!==undefined?0:Math.abs(cmd.thr))>0.3;
  if(this.rth && anyIn && this.sens.ctrl.margin>3 && this.status!=='ground'){ this.cancelRTH(); }
  if(this.landNow&&this.landUser&&cmd.thr>0.3) { this.landNow=false; this.landUser=false; }
  var c=cmd;
  if(this.sens.ctrl.margin<0 && this.status!=='ground') c={pitch:0,roll:0,yaw:0,thr:(ac.kind==='fixed'?0:0)};   /* sin enlace: no hay mandos */
  this.cmd=c;
  if(ac.kind==='fixed') this.stepFixed(dt,c,rho); else this.stepRotor(dt,c,rho);
  /* colisiones con el entorno */
  if(this.status!=='crashed'){
    var hit=w.collide(p.x,p.y,p.z,Math.max(0.1,ac.frame.dim*0.35));
    if(hit) this.crash('Colisión con '+hit.label+' a '+(this.hspeed()*3.6).toFixed(0)+' km/h.');
  }
  /* batería: energía */
  var Pel=this.P;
  var Ib=Pel/Math.max(this.V,1);
  this.I=Ib; this.ahUsed+=Ib*dt/3600;
  if(this.dod>1.05 && this.status==='flying') { /* batería agotada: el sistema ya no entrega empuje */ }
  /* estadísticas */
  if(this.status==='flying'){ this.flightT+=dt; this.dist+=this.hspeed()*dt; }
  this.maxAlt=Math.max(this.maxAlt,agl); this.maxDist=Math.max(this.maxDist,this.hdist()); this.maxSpd=Math.max(this.maxSpd,this.hspeed());
};

/* ---------- multirrotor y helicóptero ---------- */
F.stepRotor = function(dt,c,rho){
  var ac=this.ac, fr=ac.frame, w=this.world, p=this.pos, v=this.vel, m=ac.mass, W=ac.W;
  var nm=ac.nMotors, Vb=this.V;
  var Tm1=SM.maxThrust(ac,Vb,rho), Tmax=Tm1*nm;
  /* fallo de motor */
  var lossOfCtrl=false;
  if(this.fail){
    if(ac.kind==='heli'){ var vd=Math.max(0,-v.y); Tmax=Math.min(Tmax,W*(0.5+0.5*Math.min(1,vd/5))); if(this.agl()<6&&c.thr>0.2) Tmax=Math.min(Tm1,W*1.1); }
    else if(ac.rotors>=6) Tmax*=(ac.rotors-1)/ac.rotors*0.95;
    else { lossOfCtrl=true; Tmax*=0.7; }
  }
  var cutMotors = this.chuteOpen || this.dod>1.08;
  if(cutMotors) Tmax=0;
  var gpsOk=this.sens.gnss.sats>=6 && !this.world.noGnss;
  var flowOk=ac.has('flow') && this.agl()<10; this.holdSrc=gpsOk?'GNSS':(flowOk?'FLUJO':'');
  var gpsMode = this.mode==='GPS' && (gpsOk||flowOk);
  this.gpsActive=gpsMode;
  var ap=this.st.ap||{};
  var tiltLim=Math.min(fr.tilt*deg, Math.acos(clamp(W*1.08/Math.max(Tmax,1e-3),0,1)));
  if(ap.angleMax) tiltLim=Math.min(tiltLim,ap.angleMax*deg);
  var sy=Math.sin(this.yaw), cy=Math.cos(this.yaw), fx=sy, fz=-cy, rx=cy, rz=sy;
  var vf=v.x*fx+v.z*fz, vr=v.x*rx+v.z*rz;
  var agl=this.agl();
  /* órdenes de velocidad */
  var vmaxH = Math.min(ac.kind==='heli'?14:16, 4+10*Math.sqrt(Math.max(0,Math.tan(tiltLim))));
  if(ap.loitSpeed) vmaxH=Math.min(vmaxH,ap.loitSpeed);
  var vUp=Math.min(5,2+0.5*Tmax/W); if(ap.climbUp) vUp=Math.min(vUp,ap.climbUp);
  var vDnLim=3.0;
  if(ac.spec){ vmaxH=ac.spec.vmax; vUp=ac.spec.vUp; vDnLim=ac.spec.vDn; if(ap.loitSpeed) vmaxH=Math.min(vmaxH,ap.loitSpeed); if(ap.climbUp) vUp=Math.min(vUp,ap.climbUp); }
  var cf=c.pitch*vmaxH, cr=c.roll*vmaxH, cz=c.thr>0?c.thr*vUp:c.thr*(ap.climbDn||vDnLim), cyaw=c.yaw*(ap.yawRate||fr.yawRate)*deg;
  var tf=null,tr=null;
  if(this.rth && this.status!=='ground'){
    if(!gpsOk){ this.cancelRTH(); }
    else {
      var rthAlt=Math.max(this.rtlAlt(), 0), b=this.bearingHome(), ed=angDiff(b,this.yaw), dh=this.hdist();
      cf=0; cr=0; cyaw=0;
      if(this.rthPhase==='climb'){ cz=clamp((rthAlt-agl)*0.8,-3,3); if(agl>=rthAlt-2) this.rthPhase='cruise'; }
      if(this.rthPhase==='cruise'){
        cz=clamp((rthAlt-agl)*0.8,-3,3); cyaw=clamp(ed*1.5,-1,1)*fr.yawRate*deg*0.5;
        cf=Math.abs(ed)<0.5?Math.min(ap.rtlSpeed||ap.wpSpeed||9,0.35*dh):0;
        if(dh<2.5){ this.rthPhase='land'; }
      }
      if(this.rthPhase==='land'){ cz=-this.landRate(agl); cf=clamp(-vf*0.8,-2,2); cr=clamp(-vr*0.8,-2,2); }
    }
  }
  if(this.landNow){ cf=gpsMode?clamp(-vf*0.8,-2,2):0; cr=gpsMode?clamp(-vr*0.8,-2,2):0; cz=-this.landRate(agl); cyaw=0; }
  /* control horizontal */
  var tcP,tcR;
  if(gpsMode){
    var ef=cf-vf, er=cr-vr, kP=(ap.velxyP||2)/2, kI=(ap.velxyI!==undefined?ap.velxyI:1);
    this.iF=clamp(this.iF+0.6*kI*ef*dt,-4,4); this.iR=clamp(this.iR+0.6*kI*er*dt,-4,4);
    if(Math.abs(cf)<0.01&&Math.abs(vf)>0.01 && false) this.iF=0;
    tcP=Math.atan((1.5*kP*ef+this.iF)/G); tcR=Math.atan((1.5*kP*er+this.iR)/G);
  } else {
    var lim=tiltLim*0.65; tcP=this.landNow?0:c.pitch*lim; tcR=this.landNow?0:c.roll*lim; this.iF=this.iR=0;
  }
  if(this.status==='ground'){ tcP=0; tcR=0; }
  tcP=clamp(tcP,-tiltLim,tiltLim); tcR=clamp(tcR,-tiltLim,tiltLim);
  var tau=0.07+0.12*fr.dim; if(ac.kind==='heli') tau=0.10+0.05*fr.dim; if(ap.angP) tau*=clamp(4.5/ap.angP,0.4,3);
  if(lossOfCtrl){ this.roll+=5.2*dt; this.pitch+=2.1*dt; cyaw=3.5; }
  else { this.pitch+=(tcP-this.pitch)*Math.min(1,dt/tau); this.roll+=(tcR-this.roll)*Math.min(1,dt/tau); }
  this.yaw+= ((cyaw)-(this.yawRate||0))*Math.min(1,dt/0.15)*0 + 0; /* (ver abajo) */
  this.yawRate = (this.yawRate||0)+(cyaw-(this.yawRate||0))*Math.min(1,dt/0.18);
  this.yaw+=this.yawRate*dt;
  /* freno automático con sensores anticolisión */
  if(ac.has('obs') && this.sens.obsAhead<6 && this.pitch>0 && gpsMode){ this.pitch=Math.min(this.pitch,0); this.obsBrake=true; } else this.obsBrake=false;
  /* control vertical */
  var ez=cz-v.y; this.iZ=clamp(this.iZ+0.9*ez*dt,-3.5,3.5);
  var az=3.0*((ap.velzP||5)/5)*ez+this.iZ;
  var cosT=Math.max(0.45,Math.cos(this.pitch)*Math.cos(this.roll));
  var Treq=m*(G+az)/cosT;
  var gnd=(this.status==='ground'||this.status==='landed');
  if(gnd && c.thr<=0.02) Treq=0;
  if(gnd && c.thr>0.02) Treq=Math.max(Treq,W*(0.4+0.9*c.thr));
  var Tc=clamp(Treq,0,Tmax);
  this.sat=Treq>Tmax*0.98;
  if(lossOfCtrl) Tc=Tmax*0.55;
  this.Tcur+=(Tc-this.Tcur)*Math.min(1,dt/0.06);
  var Tt=this.Tcur;
  /* aceleraciones */
  var sP=Math.sin(this.pitch), sR=Math.sin(this.roll), cP=Math.cos(this.pitch), cR=Math.cos(this.roll);
  var a_f=Tt/m*sP*cR, a_r=Tt/m*sR*cP, a_z=Tt/m*cP*cR-G;
  var wd=this.wcur, rvx=v.x-wd.x, rvy=v.y-wd.y, rvz=v.z-wd.z, sp=Math.sqrt(rvx*rvx+rvy*rvy+rvz*rvz);
  var cdA=ac.cdA, cdAz=cdA*(ac.kind==='heli'?1.2:1.7);
  var chA=this.chuteOpen?0.065*W:0;
  var dkx=0.5*rho*(cdA+chA)*sp/m, dky=0.5*rho*(cdAz+chA)*sp/m;
  var ax=a_f*fx+a_r*rx-dkx*rvx, az2=a_f*fz+a_r*rz-dkx*rvz, ay=a_z-dky*rvy;
  if(gnd){ if(c.thr>0.05 && Tt>=W*1.0){ this.status='flying'; } else { ax=ay=az2=0; v.x=v.y=v.z=0; } }
  v.x+=ax*dt; v.y+=ay*dt; v.z+=az2*dt;
  p.x+=v.x*dt; p.y+=v.y*dt; p.z+=v.z*dt;
  this.accel={x:ax,y:ay+G,z:az2}; this.gload=Math.sqrt(ax*ax+(ay+G)*(ay+G)+az2*az2)/G;
  /* paracaídas: se abre 1,2 s tras la orden */
  if(this.chute>0){ this.chute-=dt; if(this.chute<=0){ this.chuteOpen=true; } }
  /* potencia */
  var n1=SM.rotorPower(ac,Tt/nm,rho);
  var Vh=Math.hypot(rvx,rvz), tl=1-0.18*Math.min(1,Vh/12);
  var Psh=n1.P*tl*nm*(ac.kind==='heli'?1.08:1)*(this.fail&&ac.rotors>=6?1:1);
  if(cutMotors||this.status==='landed'||(this.status==='ground'&&Tt<1)) Psh=0;
  this.P=Psh/(ac.effM*ac.effE)+ac.accW+ac.avW;
  this.rpm=ac.kind==='heli'?ac.nHeli*60:n1.n*60; this.nmax=SM.maxN(ac,this.V);
  this.thrPct = ac.kind==='heli'? Math.sqrt(Tt/(Tm1*nm))*100 : (Tmax>0?Math.min(100,100*n1.n/this.nmax):0);
  this.Tmax=Tmax; this.TWR=Tmax/W;
  /* suelo */
  var gh=w.floorH(p.x,p.y,p.z)+0.02;
  if(p.y<=gh && this.status!=='ground'&&this.status!=='landed'){
    var vs=-v.y, tilt=Math.max(Math.abs(this.pitch),Math.abs(this.roll)), hs=this.hspeed();
    var lim=this.chuteOpen?9:(ac.kind==='heli'?4.5:5.5);
    if(w.isWater && w.isWater(p.x,p.z)) this.crash('Amerizaje: el dron cae al agua.');
    else if(vs>lim) this.crash('Impacto contra el suelo a '+vs.toFixed(1)+' m/s (máx. admisible '+lim.toFixed(1)+' m/s).');
    else if(tilt>35*deg && !this.chuteOpen) this.crash('Impacto con inclinación de '+(tilt/deg).toFixed(0)+'° (máx. 35°).');
    else if(hs>6 && !this.chuteOpen) this.crash('Impacto con velocidad horizontal de '+hs.toFixed(1)+' m/s (máx. 6 m/s).');
    else if(Math.atan(Math.hypot(w.slope(p.x,p.z).x,w.slope(p.x,p.z).z))>20*deg) this.crash('Vuelco: terreno demasiado inclinado ('+(Math.atan(Math.hypot(w.slope(p.x,p.z).x,w.slope(p.x,p.z).z))/deg).toFixed(0)+'°, máx. 20°).');
    else { p.y=gh; v.x=v.y=v.z=0; this.status='landed'; this.landMsg=(vs<0.8?'Aterrizaje muy suave':(vs<2?'Aterrizaje suave':'Aterrizaje firme'))+' ('+vs.toFixed(1)+' m/s) a '+this.hdist().toFixed(0)+' m de casa'; this.pitch=this.roll=0; this.Tcur=0; this.rth=false; this.landNow=false; this.iZ=0; }
  } else if(p.y<gh){ p.y=gh; }
};

/* ---------- ala fija ---------- */
F.stepFixed = function(dt,c,rho){
  var ac=this.ac, fr=ac.frame, w=this.world, p=this.pos, v=this.vel, m=ac.mass, W=ac.W;
  var S=fr.S, AR=fr.b*fr.b/S, k=1/(Math.PI*fr.e*AR);
  var Tm1=SM.maxThrust(ac,this.V,rho);
  var onG=(this.status==='ground'||this.status==='landed'||this.status==='rolling');
  var ap=this.st.ap||{}, aglF=this.agl(), VsRef=this.Vs||10;
  /* gas persistente */
  if(!this.rth && !this.landNow){ if(c.thrAbs!==undefined) this.thr=clamp(this.thr+clamp(c.thrAbs-this.thr,-3*dt,3*dt),0,1); else this.thr=clamp(this.thr+c.thr*0.6*dt,0,1); }
  if(this.landNow){   /* aterrizaje asistido: aproximación estable y reducción del descenso antes de tocar */
    var thT=aglF<0.7?0:clamp(0.14+1.1*(1.28*VsRef-this.Va)/VsRef,0,0.9);
    this.thr+=clamp(thT-this.thr,-0.8*dt,0.6*dt);
  }
  var cutM = this.dod>1.08 || this.chuteOpen;
  var u=cutM?0:Math.min(this.thr,ap.thrMax||1);
  this.apWarn=(ap.arspdMin&&this.status==='flying'&&this.Va<ap.arspdMin)?'VELOCIDAD '+this.Va.toFixed(0)+' m/s < ARSPD_FBW_MIN ('+ap.arspdMin+' m/s)':'';
  /* viento en el sistema de referencia de masa de aire */
  var wd=this.wcur;
  /* estado de vuelo: Va (aerodinámica), gamma (ángulo de trayectoria aire), chi (rumbo trayectoria) */
  if(this.chi===undefined) this.chi=this.yaw;
  var Va=this.Va, ga=this.gamma, chi=this.chi;
  var phiC=c.roll*(ap.limRoll||55)*deg, pitchIn=-c.pitch;     /* flecha arriba = morro abajo */
  var rudder=c.yaw;
  /* RTH */
  if(this.rth){
    var gpsOk=this.sens.gnss.sats>=6;
    if(!gpsOk){ this.cancelRTH(); }
    else{
      var b=this.bearingHome(), ed=angDiff(b,chi), dh=this.hdist();
      var rthAlt=Math.max(this.rtlAlt(),30);
      phiC=clamp(ed*1.6,-0.7,0.7);
      if(dh<120) phiC=0.45;
      pitchIn=clamp((rthAlt-this.agl())*0.02,-0.4,0.6);
      this.thr=clamp(Math.max(this.thr,0.5),0,1); u=cutM?0:this.thr;
      this.rthPhase=dh<120?'circulando':'rumbo a casa';
    }
  }
  if(this.landNow){
    phiC=0;
    var vT=-(aglF>25?2.0:Math.max(0.55,aglF*0.14)), vzNow=Va*Math.sin(ga);
    pitchIn=clamp(0.16*(vT-vzNow),-0.5,0.7);                      /* redondeo: el descenso objetivo tiende a ~0,3 m/s al tocar */
  }
  var nmax=SM.maxN(ac,this.V), n=u*nmax;
  var Vp=0.0254*ac.P*n*0.85;
  var T0=ac.ct*rho*n*n*Math.pow(ac.D,4);
  var Tthr=T0*Math.max(0,1-Math.max(Va,0)/Math.max(Vp,0.1));
  var q=0.5*rho*Math.max(Va,0.01)*Math.max(Va,0.01);
  if(onG){
    /* carrera en tierra: no hay ángulo de trayectoria, el morro se levanta con el timón de profundidad */
    var aoa=2*deg+Math.max(0,pitchIn)*12*deg; this.alpha=aoa;
    var CL=fr.CL0+fr.CLa*aoa, L=q*S*CL, Dd=q*S*(fr.CD0+k*CL*CL)+ (Va>0?0.02*W:0);
    var N=Math.max(0,W-L);
    var fricc=(u<0.05?0.25:0.035)*N;
    var dV=(Tthr*Math.cos(aoa)-Dd-fricc*(Va>0.2?1:0))/m;
    if(this.status==='landed'&&u>0.02) this.status='rolling';
    if(this.status==='ground'&&u>0.02) this.status='rolling';
    Va=Math.max(0,Va+dV*dt);
    var steer=rudder*0.9*(Va/(Va+3));
    chi+=steer*dt; ga=0;
    if(this.status==='rolling' && Va<0.3 && u<0.02){ this.status='landed'; Va=0; }
    this.pitch+=((pitchIn>0?pitchIn*10*deg*Math.min(1,Va/6):0)-this.pitch)*Math.min(1,dt/0.3);
    this.roll=0;
    if(L>W*1.0 && pitchIn>0.05 && Va>3){ this.status='flying'; ga=0.02; }
    this.CL=CL; this.LoD=L/Math.max(Dd,0.01);
    this.stalled=false;
  } else {
    /* ángulo de ataque ordenado: nivelar + entrada − estabilización de la trayectoria */
    var phi=this.roll, cphi=Math.max(0.35,Math.cos(phi));
    var CLreq=m*G*Math.cos(ga)/(Math.max(q,1)*S*cphi);
    var aLvl=(CLreq-fr.CL0)/fr.CLa;
    var aCmd=aLvl+pitchIn*12*deg-0.6*ga;
    aCmd=clamp(aCmd,-6*deg,fr.aMax*deg*1.35);
    this.alpha+=(aCmd-this.alpha)*Math.min(1,dt/0.22);
    var al=this.alpha, aS=fr.aMax*deg;
    var CL=fr.CL0+fr.CLa*al;
    this.stalled = al>aS && Va<40;
    if(al>aS){ var ex=(al-aS)/(6*deg); CL=(fr.CL0+fr.CLa*aS)*(1-0.45*Math.min(1,ex)); }
    var L=q*S*CL, Dd=q*S*(fr.CD0+k*CL*CL)+0.5*rho*Va*Va*ac.accCd + (u<0.03?0.5*rho*Va*Va*0.0025*ac.D*ac.D*40:0);
    if(this.stalled) Dd*=1.6;
    var Th=Tthr;
    Va=Math.max(0.5,Va+((Th*Math.cos(al)-Dd)/m-G*Math.sin(ga))*dt);
    var gdot=((L*Math.cos(phi)+Th*Math.sin(al))/m-G*Math.cos(ga))/Math.max(Va,4);
    ga+=gdot*dt;
    var chidot=(L*Math.sin(phi)/m)/(Math.max(Va,4)*Math.max(0.3,Math.cos(ga)))+rudder*0.14;
    chi+=chidot*dt;
    this.roll+=(phiC-this.roll)*Math.min(1,dt/0.30);
    if(this.stalled){ this.roll+=(Math.sin(this.t*7)*0.9)*dt*(Va<9?1:0.5); }
    this.pitch=-(ga+al)*0.0+ (-(ga+al));     /* pitch visual (positiva = morro abajo) */
    this.CL=CL; this.LoD=L/Math.max(Dd,0.01);
    if(Va>fr.vne*1.25) this.crash('Fallo estructural: velocidad '+Va.toFixed(0)+' m/s superó el VNE de '+fr.vne+' m/s.');
  }
  this.Va=Va; this.gamma=ga; this.chi=chi; this.yaw=chi;
  /* velocidad respecto al suelo */
  var cg=Math.cos(ga);
  v.x=Va*cg*Math.sin(chi)+wd.x; v.z=-Va*cg*Math.cos(chi)+wd.z; v.y=Va*Math.sin(ga)+wd.y;
  if(onG && this.status!=='flying'){ v.y=0; v.x=Va*Math.sin(chi); v.z=-Va*Math.cos(chi); }
  p.x+=v.x*dt; p.y+=v.y*dt; p.z+=v.z*dt;
  this.accel={x:0,y:0,z:0}; this.gload=(L/(m*G))||1;
  /* potencia */
  var Pm=ac.cp*rho*n*n*n*Math.pow(ac.D,5)*(1-0.3*Math.min(1,Va/Math.max(Vp,1)))*(ac.pK||1);
  if(cutM) Pm=0;
  this.P=Pm/(ac.effM*ac.effE)+ac.accW+ac.avW; this.rpm=n*60; this.nmax=nmax;
  this.Tcur=Tthr; this.thrPct=u*100; this.Tmax=T0; this.TWR=Tm1/W;
  this.Vs=Math.sqrt(2*W/(rho*S*(fr.CL0+fr.CLa*fr.aMax*deg)));
  /* suelo */
  var gh=w.floorH(p.x,p.y,p.z)+0.02;
  if(p.y<=gh && this.status==='flying'){
    var vs=-v.y, bank=Math.abs(this.roll), pit=this.alpha+ga;
    if(w.isWater && w.isWater(p.x,p.z)) this.crash('Amerizaje: el avión cae al agua.');
    else if(vs>3.5) this.crash('Impacto con velocidad vertical de '+vs.toFixed(1)+' m/s (máx. 3,5 m/s para aterrizar).');
    else if(bank>20*deg) this.crash('Toma de tierra con alabeo de '+(bank/deg).toFixed(0)+'° (máx. 20°).');
    else if(Va>this.Vs*2.0) this.crash('Toma de tierra demasiado rápida: '+Va.toFixed(1)+' m/s (≈ '+(Va/this.Vs).toFixed(1)+' × Vs).');
    else { p.y=gh; this.status='rolling'; this.landMsg=(vs<1?'Toma de tierra muy suave':(vs<2.2?'Toma de tierra suave':'Toma de tierra firme'))+' ('+vs.toFixed(1)+' m/s) a '+this.hdist().toFixed(0)+' m de casa'; this.gamma=0; this.landNow=false; this.rth=false; }
  } else if(p.y<gh){ p.y=gh; }
  if(this.status==='rolling'&&this.hspeed()<0.3&&u<0.02){ this.status='landed'; }
};

F.toggleFail = function(){ if(this.status==='flying'){ this.fail=!this.fail; } };
F.deployChute = function(){ if(this.ac.has('chute') && !this.chuteOpen && this.chute<=0 && this.status==='flying'){ this.chute=1.2; } };
F.toggleMode = function(){ this.mode=this.mode==='GPS'?'ATTI':'GPS'; };
})();
