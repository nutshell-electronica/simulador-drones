/* ===== ACTORES 3D y EFECTOS: personas instanciadas, gaviotas, cometas, operador, salpicadura, explosión ===== */
/* Se carga antes de 50_scene.js; usa THREE, GFX. Expone ACT3 (personas/aves/cometas) y FX3 (efectos). */
var ACT3={}, FX3={};
(function(){
var _m=new THREE.Matrix4(), _m2=new THREE.Matrix4(), _q=new THREE.Quaternion(), _p=new THREE.Vector3(), _s=new THREE.Vector3(), _e=new THREE.Euler(), _c=new THREE.Color();
function LM(o){ o=o||{}; if(o.roughness===undefined) o.roughness=0.85; o.metalness=o.metalness||0; if(o.envMapIntensity===undefined) o.envMapIntensity=0.3; return new THREE.MeshStandardMaterial(o); }
function shapeGeo(pts){ var sh=new THREE.Shape(); pts.forEach(function(p,i){ if(i===0) sh.moveTo(p[0],p[1]); else sh.lineTo(p[0],p[1]); }); sh.closePath(); return new THREE.ShapeGeometry(sh); }

/* ---------- PERSONAS: cada parte del cuerpo es un InstancedMesh (10 llamadas de dibujo para todas) ---------- */
var SKIN=[0xf1c9a5,0xe0b08a,0xc98e63,0x9a6540,0x6b4529,0xf5d6b8], HAIR=[0x1d1a17,0x3b2a1e,0x6b4a2c,0xa37a3a,0xd9c48a,0x474a52],
    SHIRT=[0xd9342b,0x2e6fb7,0xf1c232,0x3a9a5b,0xf2f2f2,0x8a4fb0,0xff8a3c,0x1d9a9a,0x2b2f38,0xf0a5c0], PANTS=[0x2b3a55,0x1e1f24,0x6a6f78,0x8c6b4a,0x3b5d8a,0xcfc8b8];
var PG=null;
function partGeo(){
  if(PG) return PG; PG={};
  PG.head=new THREE.SphereGeometry(0.105,12,9);
  PG.hair=new THREE.SphereGeometry(0.112,12,8,0,Math.PI*2,0,Math.PI*0.58);
  PG.neck=new THREE.CylinderGeometry(0.04,0.045,0.07,8);
  PG.torso=new THREE.CylinderGeometry(0.135,0.17,0.52,12);   /* hombros arriba, cintura abajo */
  PG.shoul=new THREE.SphereGeometry(0.17,12,8,0,Math.PI*2,0,Math.PI*0.5); PG.shoul.scale(1,0.45,0.72);
  PG.hips=new THREE.CylinderGeometry(0.165,0.15,0.2,12);
  PG.leg=new THREE.CylinderGeometry(0.06,0.075,0.82,8); PG.leg.translate(0,-0.41,0);
  PG.arm=new THREE.CylinderGeometry(0.04,0.05,0.6,8); PG.arm.translate(0,-0.30,0);
  PG.hand=new THREE.SphereGeometry(0.045,8,6); PG.hand.translate(0,-0.62,0);
  PG.shoe=new THREE.BoxGeometry(0.1,0.07,0.25); PG.shoe.translate(0,-0.86,-0.05);
  return PG;
}
var PARTS=['head','hair','neck','torso','shoul','hips','legL','legR','armL','armR','handL','handR','shoeL','shoeR'];
function geoOf(k){ var g=partGeo(); return g[k.replace(/[LR]$/,'')]; }
ACT3.People=function(G,n){
  var P={n:n,i:0,list:[],mesh:{}};
  var mat=LM({color:0xffffff,roughness:0.9});
  PARTS.forEach(function(k){ var im=new THREE.InstancedMesh(geoOf(k),mat,n); im.castShadow=true; im.receiveShadow=true; im.frustumCulled=false; im.count=0; G.add(im); P.mesh[k]=im; });
  /* añade una persona; pose: 'walk'|'stand'|'crowd'|'tx' (operador con emisora)|'hold' (sujeta la cometa) */
  P.add=function(o){
    var i=P.i++; if(i>=n) return -1;
    var r=function(){ return Math.random(); };
    var per={i:i,x:o.x||0,y:o.y||0,z:o.z||0,hd:o.hd||0,ph:o.ph||r()*6.28,pose:o.pose||'stand',sc:o.sc||(0.92+r()*0.14),
      skin:SKIN[Math.floor(r()*SKIN.length)],hair:HAIR[Math.floor(r()*HAIR.length)],shirt:o.shirt!==undefined?o.shirt:SHIRT[Math.floor(r()*SHIRT.length)],pants:PANTS[Math.floor(r()*PANTS.length)],
      shoes:0x2a2622,longHair:r()<0.35,moving:false};
    P.list.push(per);
    var col={head:per.skin,hair:per.hair,neck:per.skin,torso:per.shirt,shoul:per.shirt,hips:per.pants,legL:per.pants,legR:per.pants,armL:per.shirt,armR:per.shirt,handL:per.skin,handR:per.skin,shoeL:per.shoes,shoeR:per.shoes};
    PARTS.forEach(function(k){ var im=P.mesh[k]; im.count=P.i; _c.setHex(col[k]); im.setColorAt(i,_c); im.instanceColor.needsUpdate=true; });
    return i;
  };
  function setPart(k,i,M,px,py,pz,rx,rz,ry){
    _p.set(px,py,pz); _e.set(rx||0,ry||0,rz||0,'YXZ'); _q.setFromEuler(_e); _s.set(1,1,1);
    _m2.compose(_p,_q,_s); _m.multiplyMatrices(M,_m2); P.mesh[k].setMatrixAt(i,_m);
  }
  var M=new THREE.Matrix4();
  P.pose=function(per,t){
    var i=per.i, sc=per.sc, bob=0, swing=0, armL=0, armR=0, armLz=0.06, armRz=-0.06, lean=0;
    if(per.pose==='walk'){ swing=Math.sin(t*6.5+per.ph)*0.55; bob=Math.abs(Math.sin(t*6.5+per.ph))*0.03; armL=-swing*0.6; armR=swing*0.6; lean=-0.06; }
    else if(per.pose==='crowd'||per.pose==='stand'){ var w=Math.sin(t*0.9+per.ph)*0.03; swing=0; armL=w; armR=-w; bob=0; }
    else if(per.pose==='tx'){ armL=1.15; armR=1.15; armLz=0.42; armRz=-0.42; lean=-0.04; }
    else if(per.pose==='hold'){ armR=2.3; armRz=-0.25; armL=-0.1; }
    _p.set(per.x,per.y+bob,per.z); _e.set(0,-per.hd,0,'YXZ'); _q.setFromEuler(_e); _s.set(sc,sc,sc); M.compose(_p,_q,_s);
    var hipY=0.86, shY=1.42;
    setPart('legL',i,M,-0.09,hipY,0,swing); setPart('legR',i,M,0.09,hipY,0,-swing);
    setPart('shoeL',i,M,-0.09,hipY,0,swing); setPart('shoeR',i,M,0.09,hipY,0,-swing);
    setPart('hips',i,M,0,hipY+0.04,0,0); setPart('torso',i,M,0,hipY+0.40,0,lean); setPart('shoul',i,M,0,hipY+0.60,0,lean);
    setPart('neck',i,M,0,shY+0.03,0.0,0); setPart('head',i,M,0,shY+0.17,0.0,lean*0.5);
    setPart('hair',i,M,0,shY+0.185,-0.012,per.longHair?0.15:0.0);
    setPart('armL',i,M,-0.21,shY-0.02,0,armL,armLz); setPart('armR',i,M,0.21,shY-0.02,0,armR,armRz);
    setPart('handL',i,M,-0.21,shY-0.02,0,armL,armLz); setPart('handR',i,M,0.21,shY-0.02,0,armR,armRz);
  };
  P.update=function(t){
    for(var k=0;k<P.list.length;k++) P.pose(P.list[k],t);
    PARTS.forEach(function(k){ P.mesh[k].instanceMatrix.needsUpdate=true; });
  };
  /* punto de las manos en coordenadas de mundo (para colocar la emisora o la línea de la cometa) */
  P.handPos=function(per,fwd,up,side){ var sc=per.sc, hd=per.hd; var fx=Math.sin(hd), fz=-Math.cos(hd); var rx=Math.cos(hd), rz=Math.sin(hd);
    return {x:per.x+(fx*fwd+rx*side)*sc,y:per.y+up*sc,z:per.z+(fz*fwd+rz*side)*sc}; };
  return P;
};

/* ---------- EMISORA RC (en manos del operador) ---------- */
ACT3.transmitter=function(){
  var g=new THREE.Group();
  var box=new THREE.Mesh(new THREE.BoxGeometry(0.19,0.11,0.05),LM({color:0x23272e,roughness:0.6})); g.add(box);
  var scr=new THREE.Mesh(new THREE.PlaneGeometry(0.08,0.04),new THREE.MeshBasicMaterial({color:0x8fd3ff})); scr.position.set(0,0.0,0.026); g.add(scr);
  [-0.055,0.055].forEach(function(x){ var st=new THREE.Mesh(new THREE.CylinderGeometry(0.004,0.004,0.035,6),LM({color:0x9aa0a8,metalness:0.6,roughness:0.4})); st.rotation.x=Math.PI/2; st.position.set(x,-0.015,0.04); g.add(st);
    var kn=new THREE.Mesh(new THREE.SphereGeometry(0.008,6,5),LM({color:0xd0d4d8})); kn.position.set(x,-0.015,0.058); g.add(kn); });
  var ant=new THREE.Mesh(new THREE.CylinderGeometry(0.004,0.006,0.14,6),LM({color:0x2a2a2a})); ant.position.set(0,0.11,-0.01); ant.rotation.x=-0.5; g.add(ant);
  g.traverse(function(o){ if(o.isMesh) o.castShadow=true; });
  return g;
};
ACT3.goggles=function(){ var g=new THREE.Group(); var b=new THREE.Mesh(new THREE.BoxGeometry(0.17,0.07,0.07),LM({color:0x1c1f24,roughness:0.5})); g.add(b);
  var strap=new THREE.Mesh(new THREE.TorusGeometry(0.105,0.008,6,20),LM({color:0x2a2d33})); strap.rotation.x=Math.PI/2; strap.position.z=-0.08; g.add(strap); return g; };

/* ---------- GAVIOTA ---------- */
var GM=null;
function gullMats(){ if(GM) return GM; GM={ wht:LM({color:0xf4f4f0,roughness:0.9}), grey:LM({color:0xa9b0b6,roughness:0.9,side:THREE.DoubleSide}), blk:LM({color:0x2a2d31,side:THREE.DoubleSide}), beak:LM({color:0xf2b233}), eye:new THREE.MeshBasicMaterial({color:0x111111}) };
  GM.body=new THREE.SphereGeometry(0.14,12,9); GM.head=new THREE.SphereGeometry(0.085,10,8);
  GM.beakG=new THREE.ConeGeometry(0.03,0.13,8); GM.beakG.rotateX(-Math.PI/2);
  GM.tail=shapeGeo([[-0.05,0],[0.05,0],[0.13,0.34],[-0.13,0.34]]); GM.tail.rotateX(Math.PI/2);
  /* alas en dos tramos: interior (hombro→muñeca) y exterior (muñeca→punta), planas, hacia +x (izquierda = espejo) */
  GM.win=shapeGeo([[0,-0.12],[0.4,-0.17],[0.4,0.05],[0,0.12]]); GM.win.rotateX(-Math.PI/2);
  GM.wout=shapeGeo([[0,-0.17],[0.3,-0.17],[0.5,-0.08],[0.52,-0.03],[0.28,0.04],[0,0.05]]); GM.wout.rotateX(-Math.PI/2);
  GM.tip=shapeGeo([[0.3,-0.17],[0.5,-0.08],[0.52,-0.03],[0.4,-0.07]]); GM.tip.rotateX(-Math.PI/2);
  return GM; }
ACT3.gull=function(){
  var M=gullMats(), g=new THREE.Group();
  var b=new THREE.Mesh(M.body,M.wht); b.scale.set(1,0.8,2.4); g.add(b);
  var h=new THREE.Mesh(M.head,M.wht); h.position.set(0,0.09,-0.33); g.add(h);
  var bk=new THREE.Mesh(M.beakG,M.beak); bk.position.set(0,0.07,-0.44); g.add(bk);
  [-0.045,0.045].forEach(function(x){ var e=new THREE.Mesh(new THREE.SphereGeometry(0.012,6,5),M.eye); e.position.set(x,0.11,-0.37); g.add(e); });
  var t=new THREE.Mesh(M.tail,M.wht); t.position.set(0,0.0,0.28); g.add(t);
  function wing(sg){ var sh=new THREE.Group(); sh.position.set(sg*0.1,0.03,-0.02); sh.scale.x=sg;
    var wi=new THREE.Mesh(M.win,M.grey); sh.add(wi); var wr=new THREE.Group(); wr.position.x=0.4; sh.add(wr);
    var wo=new THREE.Mesh(M.wout,M.grey); wr.add(wo); var tp=new THREE.Mesh(M.tip,M.blk); tp.position.y=0.002; wr.add(tp); return {sh:sh,wr:wr}; }
  var wl=wing(-1), wr=wing(1); g.add(wl.sh); g.add(wr.sh);
  g.traverse(function(o){ if(o.isMesh) o.castShadow=true; });
  return {g:g,wl:wl,wr:wr};
};
/* a: fase de aleteo; amp: amplitud (0 = planeo) */
ACT3.gullFlap=function(w,a,amp,bank){
  var s=Math.sin(a)*amp, s2=Math.sin(a-0.9)*amp;
  w.wl.sh.rotation.z=-(s*0.55+0.12); w.wr.sh.rotation.z=(s*0.55+0.12);
  w.wl.wr.rotation.z=-(s2*0.7-0.15); w.wr.wr.rotation.z=(s2*0.7-0.15);
  w.g.rotation.z=bank||0;
};

/* ---------- COMETA (delta de dos colores con varilla, brida y cola de cintas) ---------- */
var KC=[[0xe2552d,0xf7e39a],[0xf1c232,0x2e4a8a],[0x2e9ad0,0xf2f2f2],[0xd23c8c,0x7ad4e8],[0x3a9a5b,0xf1c232]];
ACT3.kite=function(ci){
  var c=KC[ci%KC.length], g=new THREE.Group();
  var mA=new THREE.MeshStandardMaterial({color:c[0],side:THREE.DoubleSide,roughness:0.6,envMapIntensity:0.3}), mB=new THREE.MeshStandardMaterial({color:c[1],side:THREE.DoubleSide,roughness:0.6,envMapIntensity:0.3});
  var L=new THREE.Mesh(shapeGeo([[0,0.8],[-0.62,-0.25],[0,-0.45]]),mA), R=new THREE.Mesh(shapeGeo([[0,0.8],[0.62,-0.25],[0,-0.45]]),mB); g.add(L); g.add(R);
  var str=new THREE.Mesh(shapeGeo([[-0.09,0.5],[0.09,0.5],[0.05,0.1],[-0.05,0.1]]),mB); str.position.z=0.001; L.add(str);
  var sp=new THREE.Mesh(new THREE.CylinderGeometry(0.008,0.008,1.26,5),LM({color:0x3a2c1f})); sp.position.set(0,0.17,0.004); g.add(sp);
  var sp2=new THREE.Mesh(new THREE.CylinderGeometry(0.007,0.007,1.24,5),LM({color:0x3a2c1f})); sp2.rotation.z=Math.PI/2; sp2.position.set(0,-0.25,0.004); g.add(sp2);
  /* cola: cintas */
  var tail=[], tm=[mA,mB]; for(var i=0;i<14;i++){ var t=new THREE.Mesh(new THREE.PlaneGeometry(0.11,0.3),tm[i%2]); g.add(t); tail.push(t); }
  var br=new THREE.BufferGeometry(); br.setAttribute('position',new THREE.BufferAttribute(new Float32Array(9),3));
  var bridle=new THREE.Line(br,new THREE.LineBasicMaterial({color:0x444444})); g.add(bridle);
  g.traverse(function(o){ if(o.isMesh) o.castShadow=true; });
  return {g:g,tail:tail,bridle:bridle,bk:0.0};
};
ACT3.kiteAnim=function(k,t,ph){
  for(var i=0;i<k.tail.length;i++){ var u=i/k.tail.length, s=Math.sin(t*4.2-i*0.55+ph), c=Math.cos(t*3.1-i*0.4+ph);
    k.tail[i].position.set(s*0.18*(0.3+u),-0.62-i*0.31,c*0.14*u); k.tail[i].rotation.set(c*0.5,0,s*0.6); }
  var a=k.bridle.geometry.attributes.position.array; a[0]=0; a[1]=0.55; a[2]=0.02; a[3]=0; a[4]=-0.15; a[5]=0.55; a[6]=0; a[7]=-0.35; a[8]=0.02; k.bridle.geometry.attributes.position.needsUpdate=true;
};

/* ---------- PARTÍCULAS con tamaño y alfa por punto ---------- */
var SPR=null;
function sprite(){ if(SPR) return SPR; var c=document.createElement('canvas'); c.width=c.height=64; var x=c.getContext('2d'); var g=x.createRadialGradient(32,32,0,32,32,32); g.addColorStop(0,'rgba(255,255,255,1)'); g.addColorStop(0.35,'rgba(255,255,255,0.85)'); g.addColorStop(1,'rgba(255,255,255,0)'); x.fillStyle=g; x.fillRect(0,0,64,64); SPR=new THREE.CanvasTexture(c); return SPR; }
function ptsMat(blend){ return new THREE.ShaderMaterial({uniforms:{map:{value:sprite()},scaleH:{value:600}},transparent:true,depthWrite:false,blending:blend||THREE.NormalBlending,fog:false,
  vertexShader:'attribute float aSize; attribute float aAlpha; attribute vec3 aCol; varying float vA; varying vec3 vC; uniform float scaleH; void main(){ vA=aAlpha; vC=aCol; vec4 mv=modelViewMatrix*vec4(position,1.0); gl_PointSize=aSize*scaleH/max(1.0,-mv.z); gl_Position=projectionMatrix*mv; }',
  fragmentShader:'uniform sampler2D map; varying float vA; varying vec3 vC; void main(){ vec4 t=texture2D(map,gl_PointCoord); if(t.a*vA<0.01) discard; gl_FragColor=vec4(vC,t.a*vA); }'}); }
function mkSys(n,blend){
  var g=new THREE.BufferGeometry(), pos=new Float32Array(n*3), col=new Float32Array(n*3), siz=new Float32Array(n), alp=new Float32Array(n);
  g.setAttribute('position',new THREE.BufferAttribute(pos,3)); g.setAttribute('aCol',new THREE.BufferAttribute(col,3)); g.setAttribute('aSize',new THREE.BufferAttribute(siz,1)); g.setAttribute('aAlpha',new THREE.BufferAttribute(alp,1));
  var pts=new THREE.Points(g,ptsMat(blend)); pts.frustumCulled=false; pts.renderOrder=30;
  return {pts:pts,g:g,n:n,pos:pos,col:col,siz:siz,alp:alp,vel:new Float32Array(n*3),age:new Float32Array(n),life:new Float32Array(n),p:[]};
}
/* ---------- gestor de efectos ---------- */
var scene=null, floorH=null, SYS=[], DEB=[], ONE=[], hudH=600;
FX3.init=function(sc,fh){ scene=sc; floorH=fh; };
FX3.setHeight=function(h){ hudH=h; SYS.forEach(function(s){ s.pts.material.uniforms.scaleH.value=h*0.9; }); };
FX3.clear=function(){ SYS.forEach(function(s){ scene.remove(s.pts); s.g.dispose(); s.pts.material.dispose(); }); SYS=[];
  DEB.forEach(function(d){ scene.remove(d.m); }); DEB=[]; ONE.forEach(function(o){ scene.remove(o.m); if(o.m.geometry) o.m.geometry.dispose(); }); ONE=[]; FX3.smoke=null; FX3.sinking=null; };
/* sistema de una sola ráfaga */
function burst(n,blend,spawn){ var s=mkSys(n,blend); s.pts.material.uniforms.scaleH.value=hudH*0.9; for(var i=0;i<n;i++){ var q=spawn(i); s.pos[i*3]=q.x; s.pos[i*3+1]=q.y; s.pos[i*3+2]=q.z; s.vel[i*3]=q.vx; s.vel[i*3+1]=q.vy; s.vel[i*3+2]=q.vz; s.life[i]=q.life; s.age[i]=q.delay?-q.delay:0; s.siz[i]=q.size; s.p[i]=q; s.alp[i]=0; }
  s.step=spawn.step; s.respawn=!!spawn.respawn; s.grav=spawn.grav===undefined?9.8:spawn.grav; s.drag=spawn.drag||0; s.floor=spawn.floor; scene.add(s.pts); SYS.push(s); return s; }
function rnd(a,b){ return a+Math.random()*(b-a); }
function rdir(){ var a=Math.random()*6.2832, z=Math.random()*2-1, r=Math.sqrt(1-z*z); return {x:Math.cos(a)*r,y:z,z:Math.sin(a)*r}; }

/* ---------- SALPICADURA en el agua ---------- */
FX3.splash=function(p,size,waterY){
  var y0=waterY!==undefined?waterY:p.y, k=Math.max(0.6,Math.min(2.2,size));
  /* gotas */
  burst(160,THREE.NormalBlending,Object.assign(function(i){ var d=rdir(); var up=rnd(2.5,7.5)*k, h=rnd(0.5,3.5)*k;
    return {x:p.x+d.x*0.2*k,y:y0+0.05,z:p.z+d.z*0.2*k,vx:d.x*h,vy:up,vz:d.z*h,life:rnd(0.6,1.4),size:rnd(0.06,0.16)*k,c:[0.86,0.93,1.0]}; },{floor:y0,step:function(s,i,u){ var q=s.p[i]; s.alp[i]=Math.min(1,(1-u)*2.2)*0.95; s.col[i*3]=q.c[0]; s.col[i*3+1]=q.c[1]; s.col[i*3+2]=q.c[2]; }}));
  /* columna/espuma central */
  burst(60,THREE.NormalBlending,Object.assign(function(i){ var a=Math.random()*6.28, r=Math.random()*0.35*k;
    return {x:p.x+Math.cos(a)*r,y:y0,z:p.z+Math.sin(a)*r,vx:Math.cos(a)*0.4,vy:rnd(1.5,4.5)*k,vz:Math.sin(a)*0.4,life:rnd(0.5,1.0),size:rnd(0.25,0.6)*k,c:[0.95,0.98,1.0]}; },{grav:6,floor:y0,step:function(s,i,u){ s.alp[i]=(1-u)*0.7; s.col[i*3]=0.95; s.col[i*3+1]=0.98; s.col[i*3+2]=1; }}));
  /* anillos y mancha de espuma */
  var rm=new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:0.8,depthWrite:false,fog:false});
  for(var r=0;r<3;r++){ var ring=new THREE.Mesh(new THREE.RingGeometry(0.85,1,48),rm.clone()); ring.rotation.x=-Math.PI/2; ring.position.set(p.x,y0+0.03,p.z); ring.renderOrder=25; scene.add(ring);
    ONE.push({m:ring,t:-r*0.35,dur:1.9,k:k,kind:'ring'}); }
  var foam=new THREE.Mesh(new THREE.CircleGeometry(1,40),new THREE.MeshBasicMaterial({color:0xeaf4ff,transparent:true,opacity:0.75,depthWrite:false,fog:false})); foam.rotation.x=-Math.PI/2; foam.position.set(p.x,y0+0.02,p.z); foam.renderOrder=24; scene.add(foam); ONE.push({m:foam,t:0,dur:4.5,k:k,kind:'foam'});
  /* burbujas mientras se hunde */
  var bub=burst(50,THREE.NormalBlending,Object.assign(function(i){ return {x:p.x,y:y0-0.3,z:p.z,vx:0,vy:0.6,vz:0,life:rnd(0.8,1.6),size:rnd(0.04,0.1)*k,delay:Math.random()*3.5,c:[1,1,1]}; },{grav:-0.4,step:function(s,i,u){ s.alp[i]=u<0.9?0.55:0; s.col[i*3]=s.col[i*3+1]=s.col[i*3+2]=1; },respawn:false}));
  bub.ceil=y0;
};
/* hundimiento: y del modelo respecto al punto de siniestro */
FX3.sink=function(t,rate){ return -Math.min(2.2,Math.pow(t,1.3)*(rate||0.45)); };

/* ---------- EXPLOSIÓN ---------- */
FX3.explode=function(p,size,colors){
  var k=Math.max(0.7,Math.min(3,size*1.6)), g=floorH?floorH(p.x,p.y,p.z):p.y-0.1;
  /* bola de fuego */
  burst(90,THREE.AdditiveBlending,Object.assign(function(i){ var d=rdir(); var v=rnd(1,7)*k;
    return {x:p.x,y:p.y+0.1,z:p.z,vx:d.x*v,vy:Math.abs(d.y)*v+1.5,vz:d.z*v,life:rnd(0.35,0.8),size:rnd(0.5,1.3)*k}; },{grav:-2,drag:3.5,step:function(s,i,u){ var w=1-u; s.alp[i]=w*0.9; s.siz[i]=s.p[i].size*(1+u*1.6); s.col[i*3]=1; s.col[i*3+1]=0.25+0.6*w*w; s.col[i*3+2]=0.05*w; }}));
  /* chispas */
  burst(120,THREE.AdditiveBlending,Object.assign(function(i){ var d=rdir(); var v=rnd(4,16)*k;
    return {x:p.x,y:p.y+0.1,z:p.z,vx:d.x*v,vy:Math.abs(d.y)*v+2,vz:d.z*v,life:rnd(0.5,1.3),size:rnd(0.05,0.12)*k}; },{floor:g,step:function(s,i,u){ s.alp[i]=1-u; s.col[i*3]=1; s.col[i*3+1]=0.85-0.5*u; s.col[i*3+2]=0.3*(1-u); }}));
  /* humo persistente (emisor que respawnea) */
  var sm=burst(70,THREE.NormalBlending,Object.assign(function(i){ return {x:p.x+rnd(-0.3,0.3)*k,y:p.y+0.2,z:p.z+rnd(-0.3,0.3)*k,vx:rnd(-0.5,0.5),vy:rnd(1.2,2.6),vz:rnd(-0.5,0.5),life:rnd(2.5,5),size:rnd(0.6,1.4)*k,delay:Math.random()*3}; },{grav:-0.3,drag:0.4,respawn:true,step:function(s,i,u){ var dk=0.12+0.22*u; s.alp[i]=Math.sin(u*Math.PI)*0.55; s.siz[i]=s.p[i].size*(1+u*2.2); s.col[i*3]=dk; s.col[i*3+1]=dk; s.col[i*3+2]=dk+0.01; }}));
  sm.origin=p; FX3.smoke=sm;
  /* destello */
  var lt=new THREE.PointLight(0xffa040,0,80); lt.position.set(p.x,p.y+1,p.z); scene.add(lt); ONE.push({m:lt,t:0,dur:0.9,kind:'light'});
  /* mancha quemada */
  var sc=new THREE.Mesh(new THREE.CircleGeometry(1.15*k,32),new THREE.MeshBasicMaterial({color:0x0b0b0b,transparent:true,opacity:0.0,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-4,polygonOffsetUnits:-4})); sc.rotation.x=-Math.PI/2; sc.position.set(p.x,g+0.05,p.z); sc.renderOrder=23; scene.add(sc); ONE.push({m:sc,t:0,dur:1e9,kind:'scorch'});
  /* restos */
  var cols=colors&&colors.length?colors:[0x23262b,0x5a5e66,0xc0392b,0x9aa0a6];
  for(var i=0;i<14;i++){ var sz=rnd(0.05,0.18)*k; var m=new THREE.Mesh(new THREE.BoxGeometry(sz,sz*rnd(0.3,1),sz*rnd(0.5,2)),LM({color:cols[i%cols.length],roughness:0.7})); m.castShadow=true;
    m.position.set(p.x,p.y+0.1,p.z); var d=rdir(), v=rnd(3,11)*k; scene.add(m);
    DEB.push({m:m,vx:d.x*v,vy:Math.abs(d.y)*v+2,vz:d.z*v,wx:rnd(-9,9),wy:rnd(-9,9),wz:rnd(-9,9),rest:false,r:sz*0.5}); }
};
/* ---------- actualización ---------- */
FX3.update=function(dt){
  if(!scene) return; dt=Math.min(dt,0.05);
  for(var si=SYS.length-1;si>=0;si--){ var s=SYS[si], alive=0;
    for(var i=0;i<s.n;i++){ var a=s.age[i]+dt; var L=s.life[i];
      if(a<0){ s.age[i]=a; s.alp[i]=0; alive++; continue; }
      if(a>=L){ if(s.respawn&&(s===FX3.smoke)){ var q=s.p[i]; var o=s.origin; s.pos[i*3]=o.x+rnd(-0.3,0.3); s.pos[i*3+1]=o.y+0.2; s.pos[i*3+2]=o.z+rnd(-0.3,0.3); s.vel[i*3]=rnd(-0.5,0.5); s.vel[i*3+1]=rnd(1.2,2.6); s.vel[i*3+2]=rnd(-0.5,0.5); a=0; } else { s.alp[i]=0; s.age[i]=L; continue; } }
      alive++; s.age[i]=a; var k3=i*3;
      s.vel[k3+1]-=s.grav*dt; if(s.drag){ var dg=Math.max(0,1-s.drag*dt); s.vel[k3]*=dg; s.vel[k3+1]*=dg; s.vel[k3+2]*=dg; }
      s.pos[k3]+=s.vel[k3]*dt; s.pos[k3+1]+=s.vel[k3+1]*dt; s.pos[k3+2]+=s.vel[k3+2]*dt;
      if(s.floor!==undefined && s.pos[k3+1]<s.floor){ s.age[i]=L; s.alp[i]=0; continue; }
      if(s.ceil!==undefined && s.pos[k3+1]>s.ceil){ s.age[i]=L; s.alp[i]=0; continue; }
      s.step(s,i,a/L);
    }
    s.g.attributes.position.needsUpdate=true; s.g.attributes.aCol.needsUpdate=true; s.g.attributes.aSize.needsUpdate=true; s.g.attributes.aAlpha.needsUpdate=true;
    if(!alive && !(s.respawn&&s===FX3.smoke)){ scene.remove(s.pts); s.g.dispose(); s.pts.material.dispose(); SYS.splice(si,1); }
  }
  for(var di=0;di<DEB.length;di++){ var d=DEB[di]; if(d.rest) continue; d.vy-=9.8*dt; var m=d.m; m.position.x+=d.vx*dt; m.position.y+=d.vy*dt; m.position.z+=d.vz*dt; m.rotation.x+=d.wx*dt; m.rotation.y+=d.wy*dt; m.rotation.z+=d.wz*dt;
    var fl=(floorH?floorH(m.position.x,m.position.y+1,m.position.z):0)+d.r; if(m.position.y<fl){ m.position.y=fl; d.vy=-d.vy*0.35; d.vx*=0.6; d.vz*=0.6; d.wx*=0.5; d.wz*=0.5; if(Math.abs(d.vy)<0.8){ d.rest=true; } } }
  for(var oi=ONE.length-1;oi>=0;oi--){ var o=ONE[oi]; o.t+=dt; var u=o.t/o.dur; if(o.t<0) continue;
    if(o.kind==='ring'){ var e=1-Math.pow(1-Math.min(1,u),2); var rr=0.4+e*5.5*o.k; o.m.scale.set(rr,rr,1); o.m.material.opacity=0.8*(1-u); }
    else if(o.kind==='foam'){ var ff=1+u*2.5; o.m.scale.set(ff*o.k,ff*o.k,1); o.m.material.opacity=0.75*(1-u)*(1-u); }
    else if(o.kind==='light'){ o.m.intensity=u<0.12?u/0.12*60:60*Math.max(0,1-(u-0.12)/0.88); }
    else if(o.kind==='scorch'){ o.m.material.opacity=Math.min(0.42,o.t*1.2); continue; }
    if(u>=1){ scene.remove(o.m); if(o.m.geometry) o.m.geometry.dispose(); ONE.splice(oi,1); }
  }
};
})();
