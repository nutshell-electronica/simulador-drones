/* ===== MODELO: construcción de la aeronave y validación ===== */
var SM = {};
(function(){
var G = (typeof SD!=='undefined'?SD:require('./20_data.js')).G;
var D_ = (typeof SD!=='undefined'?SD:require('./20_data.js'));
var RHO0 = 1.225;
SM.RHO0 = RHO0;

/* Coeficientes de hélice según relación paso/diámetro */
SM.propCoef = function(Din,P){
  var r = P/Din;
  return {ct:0.1*(0.6+0.5*r), cp:0.04*(0.5+0.8*r)};
};

/* Construye el objeto de aeronave a partir de la configuración */
SM.build = function(cfg){
  var type = D_.byId(D_.TYPES,cfg.type), fr = D_.byId(D_.FRAMES,cfg.frame), mo = D_.byId(D_.MOTORS,cfg.motor);
  var ch = D_.byId(D_.CHEM,cfg.chem);
  var ac = {cfg:cfg, type:type, kind:type.kind, rotors:type.rotors, frame:fr, motor:mo, chem:ch};
  if(ac.kind==='heli'){
    ac.D = fr.fixedProp; ac.Din = ac.D/0.0254; ac.P = 0; ac.propMass = 0;
    ac.nHeli = fr.tipSpeed/(Math.PI*ac.D);
  } else {
    var pd = D_.propDims(cfg.prop); ac.D = pd.D; ac.Din = pd.Din; ac.P = pd.P;
    ac.propMass = 0.4*Math.pow(pd.Din,1.7)/1000;
    var c = SM.propCoef(pd.Din,pd.P); ac.ct = c.ct; ac.cp = c.cp;
  }
  ac.escMass = (3+0.4*cfg.esc)/1000;
  ac.battAh = cfg.cap/1000;
  ac.battWh = cfg.cells*ch.vc*ac.battAh;
  ac.battMass = ac.battWh/ch.wh;
  ac.battCmax = ac.battAh*ch.c;
  ac.rcell = 0.5/(ac.battAh*ch.c);
  ac.accs = []; ac.accMass=0; ac.accW=0; ac.accCd=0;
  (cfg.acc||[]).forEach(function(id){ var a=D_.byId(D_.ACC,id); if(a){ac.accs.push(a); ac.accMass+=a.m; ac.accW+=a.w; ac.accCd+=a.cdA;} });
  ac.has = function(id){ return (cfg.acc||[]).indexOf(id)>=0; };
  ac.payMass = (cfg.pay||0)/1000;
  ac.avW = 3 + (ac.kind==='multi'?0.5*ac.rotors:1);        /* aviónica y controladora */
  var nm = (ac.kind==='heli'?1:ac.rotors);
  ac.nMotors = nm;
  ac.mass = fr.m + nm*(mo.m + ac.propMass + (ac.kind==='heli'?0:ac.escMass)) + (ac.kind==='heli'?ac.escMass:0)
          + ac.battMass + ac.accMass + ac.payMass;
  ac.W = ac.mass*G;
  ac.cdA = fr.cdA + ac.accCd;
  ac.effM = 0.82; ac.effE = 0.94;
  return ac;
};

/* Rotor: dado el empuje por rotor (N), densidad → potencia mecánica (W) y rpm/s */
SM.rotorPower = function(ac,T,rho){
  if(ac.kind==='heli'){
    var A = Math.PI*ac.D*ac.D/4, n = ac.nHeli;
    var pind = Math.pow(Math.max(T,0),1.5)/Math.sqrt(2*rho*A)/0.65;
    var pprof = 0.0025*rho*n*n*n*Math.pow(ac.D,5);
    return {n:n, P:(pind+pprof)*1.08};
  }
  var n = Math.sqrt(Math.max(T,0)/(ac.ct*rho*Math.pow(ac.D,4)));
  return {n:n, P:ac.cp*rho*n*n*n*Math.pow(ac.D,5)};
};

/* Empuje máximo por rotor (N) con tensión V bajo carga y densidad rho */
SM.maxThrust = function(ac,V,rho){
  if(ac.kind==='heli') return ac.frame.ctMax*rho*ac.nHeli*ac.nHeli*Math.pow(ac.D,4);
  var n = 0.72*ac.motor.kv*V/60;
  return ac.ct*rho*n*n*Math.pow(ac.D,4);
};
SM.maxN = function(ac,V){ return ac.kind==='heli'?ac.nHeli:0.72*ac.motor.kv*V/60; };

/* Estadísticas y validación de la configuración (atmósfera estándar) */
SM.validate = function(cfg){
  var ac = SM.build(cfg), fr=ac.frame, mo=ac.motor, E=[], W=[], I={};
  var Vn = cfg.cells*ac.chem.vc, V = Vn*1.12;       /* batería llena, tensión en carga ≈ nominal×1.12 */
  var rho = RHO0, pa = ac.accW + ac.avW;
  /* Estimación de tensión bajo carga (2 iteraciones) */
  var Tm, Pm, Im, Itot;
  for(var k=0;k<3;k++){
    Tm = SM.maxThrust(ac,V,rho);
    Pm = SM.rotorPower(ac,Tm,rho).P*(ac.kind==='heli'?1.0:1);
    Im = Pm/(ac.effM*ac.effE*V);
    Itot = ac.nMotors*Im + pa/V;
    V = Math.max(cfg.cells*3.0, Vn*1.12 - Itot*ac.rcell*cfg.cells);
  }
  var Ttot = Tm*ac.nMotors;
  I.mass=ac.mass; I.weight=ac.W; I.Tmax=Ttot; I.twr=Ttot/ac.W; I.Imotor=Im; I.Itot=Itot; I.Vload=V;
  I.battWh=ac.battWh; I.battMass=ac.battMass; I.capA=ac.battCmax;
  I.tip = ac.kind==='heli'?Math.PI*ac.D*ac.nHeli:Math.PI*SM.maxN(ac,V)*ac.D;
  /* hover */
  var Th = ac.W/ac.nMotors, hp = SM.rotorPower(ac,Th,rho);
  var Phov = ac.nMotors*hp.P/(ac.effM*ac.effE) + (ac.kind==='heli'?0.08*hp.P/(ac.effM*ac.effE):0) + pa;
  I.hoverW = Phov; I.hoverI = Phov/Vn; I.hoverMin = ac.battWh*0.8/Phov*60;
  I.hoverThr = ac.kind==='heli'?Math.sqrt(Th/Tm):hp.n/SM.maxN(ac,V);
  /* categoría UE según MTOM */
  var m=ac.mass;
  I.cat = m<0.25?'C0 · subcategoría A1':m<0.9?'C1 · subcategoría A1':m<4?'C2 · subcategoría A2':m<25?'C3/C4 · subcategoría A3':'Categoría específica (>25 kg)';
  I.needReg = m>=0.25 || ac.has('camfpv')||ac.has('camhd')||ac.has('camir');
  /* ---- reglas comunes ---- */
  var payTot = ac.accMass+ac.payMass;
  if(payTot>fr.maxPay) E.push('Carga útil total '+Math.round(payTot*1000)+' g (accesorios + carga) supera el máximo del bastidor ('+Math.round(fr.maxPay*1000)+' g).');
  if(cfg.cells>mo.maxS) E.push(cfg.cells+'S ('+Vn.toFixed(1)+' V) supera las '+mo.maxS+'S máximas del motor «'+mo.name+'»: sobretensión, rpm y corriente excesivas.');
  var heliMotor = mo.id.indexOf('mh')===0;
  if(ac.kind==='heli' && !heliMotor) E.push('El motor «'+mo.name+'» no sirve para helicóptero: no tiene par ni reductora para mover un rotor principal.');
  if(ac.kind!=='heli' && heliMotor) E.push('El motor «'+mo.name+'» es de helicóptero (con reductora): no es válido para hélices directas.');
  if(ac.kind!=='fixed' && /ala fija/.test(mo.name)) W.push('El motor «'+mo.name+'» está pensado para ala fija; en un multirrotor funcionará con poco rendimiento.');
  if(Im>cfg.esc) E.push('Corriente máxima por motor '+Im.toFixed(1)+' A > ESC de '+cfg.esc+' A: el ESC se quemaría a plena potencia.');
  else if(Im>0.85*cfg.esc) W.push('El ESC ('+cfg.esc+' A) trabaja al '+Math.round(100*Im/cfg.esc)+' % a plena potencia: sin margen térmico.');
  if(Im>1.3*mo.imax) E.push('El motor pide '+Im.toFixed(1)+' A (máx. continuo '+mo.imax+' A): se sobrecalentaría y desmagnetizaría. Usa una hélice menor o menos celdas.');
  else if(Im>mo.imax) W.push('Motor por encima de su corriente continua ('+Im.toFixed(1)+' A > '+mo.imax+' A): válido en ráfagas cortas, no en vuelo sostenido.');
  if(Itot>1.5*ac.battCmax) E.push('La batería sólo puede entregar '+ac.battCmax.toFixed(0)+' A (capacidad × C) y el sistema demanda '+Itot.toFixed(0)+' A a plena potencia: la tensión se hundiría y la batería se dañaría.');
  else if(Itot>ac.battCmax) W.push('A plena potencia se piden '+Itot.toFixed(0)+' A y la batería da '+ac.battCmax.toFixed(0)+' A: evita el 100 % de gas sostenido.');
  if(ac.kind!=='fixed' && I.hoverI>ac.battCmax) E.push('Sólo para mantenerse en el aire se necesitan '+I.hoverI.toFixed(0)+' A y la batería ofrece '+ac.battCmax.toFixed(0)+' A.');
  if(I.tip>240) E.push('Velocidad en punta de pala '+I.tip.toFixed(0)+' m/s (≈ Mach '+(I.tip/340).toFixed(2)+'): régimen compresible, rendimiento nulo y ruido extremo.');
  if(ac.kind!=='heli'){
    if(ac.Din>fr.maxProp+0.01) E.push('Hélice de '+ac.Din+'" no cabe en el bastidor (máx. '+fr.maxProp+'").');
    if(ac.Din<fr.maxProp*0.45 && ac.kind==='multi') W.push('Hélice muy pequeña para este bastidor ('+ac.Din+'" frente a '+fr.maxProp+'" máx.): poco empuje y mucho consumo.');
  }
  if(ac.kind==='multi'||ac.kind==='heli'){
    if(I.twr<1.25) E.push('Empuje máximo '+Ttot.toFixed(1)+' N = '+I.twr.toFixed(2)+' × el peso ('+ac.W.toFixed(1)+' N): no hay margen para despegar. Mínimo recomendado 1,5 (2 para volar con viento).');
    else if(I.twr<2) W.push('Relación empuje/peso '+I.twr.toFixed(2)+': poco margen; con viento o carga extra perderás control de altura.');
    if(ac.kind==='multi' && ac.rotors>=6 && I.twr<ac.rotors/(ac.rotors-1)*1.1) W.push('Con '+ac.rotors+' rotores la redundancia ante fallo de motor exige TWR > '+(ac.rotors/(ac.rotors-1)*1.1).toFixed(2)+'.');
  } else {
    /* ala fija */
    var S=fr.S, q=ac.mass, CLmax = fr.CL0+fr.CLa*fr.aMax*D_.deg;
    var Vs = Math.sqrt(2*ac.W/(rho*S*CLmax)); I.Vs=Vs; I.CLmax=CLmax; I.wingLoad=ac.mass/S;
    if(Vs>20) E.push('Velocidad de pérdida '+Vs.toFixed(1)+' m/s (carga alar '+(ac.mass/S).toFixed(1)+' kg/m²): demasiado alta para despegar y aterrizar con seguridad.');
    else if(Vs>14) W.push('Velocidad de pérdida alta ('+Vs.toFixed(1)+' m/s): aterrizajes rápidos y exigentes.');
    var T0 = Tm;
    if(T0<0.28*ac.W) E.push('Empuje estático '+T0.toFixed(1)+' N < 0,28 × peso ('+ (0.28*ac.W).toFixed(1)+' N): no acelera lo suficiente para alcanzar la velocidad de despegue.');
    var Vc = 1.4*Vs, AR=fr.b*fr.b/S, CLc = 2*ac.W/(rho*Vc*Vc*S);
    var Dc = 0.5*rho*Vc*Vc*S*(fr.CD0+CLc*CLc/(Math.PI*fr.e*AR));
    var nmax=SM.maxN(ac,V), Vp=0.0254*ac.P*nmax*0.85, Tc = T0*Math.max(0,1-Vc/Vp);
    I.cruiseV = Vc; I.dragC = Dc; I.thrC = Tc; I.LD = ac.W/Dc;
    if(Tc<1.15*Dc) E.push('A '+Vc.toFixed(0)+' m/s el empuje disponible ('+Tc.toFixed(1)+' N) no supera la resistencia aerodinámica ('+Dc.toFixed(1)+' N): no puede mantener vuelo nivelado. Pasa a una hélice de más paso o más celdas.');
    if(Vp<1.35*Vs) E.push('La hélice de paso '+ac.P+'" sólo da '+Vp.toFixed(0)+' m/s de velocidad máxima de empuje, por debajo de 1,35 × Vs: nunca despegaría.');
    I.twr = T0/ac.W;
    I.cruiseW = Dc*Vc/(0.6*ac.effM*ac.effE)+pa; I.cruiseMin = ac.battWh*0.8/I.cruiseW*60; I.hoverMin=I.cruiseMin; I.hoverW=I.cruiseW;
  }
  if(I.hoverMin<3 && ac.kind!=='fixed') W.push('Autonomía en estacionario ≈ '+I.hoverMin.toFixed(1)+' min: batería muy pequeña para este peso.');
  if(ac.has('camfpv')===false && ac.has('camhd')===false && ac.has('camir')===false) W.push('Sin cámara: no tendrá modo FPV (sólo vuelo a la vista).');
  if(ac.has('lidar') && !ac.has('rtk')) W.push('LiDAR sin GNSS RTK: el mapeo tendrá error de posición de varios metros.');
  if(!ac.has('rid') && m>=0.25) W.push('Sin identificación remota (obligatoria en clases C1–C3 de la UE).');
  if(ac.chem.id==='liion' && Itot>ac.battCmax*0.7) W.push('Li-ion con descarga exigente: hundimiento de tensión notable.');
  return {ac:ac, errors:E, warns:W, info:I};
};
if(typeof module!=='undefined') module.exports=SM;
})();
