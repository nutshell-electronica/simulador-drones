#!/bin/bash
cd "$(dirname "$0")"
OUT=${1:-simulador_drones.html}
python3 - "$OUT" <<'PY'
import sys
out=sys.argv[1]
r=lambda f:open(f,encoding='utf-8').read()
av=r('avatar.b64').strip()
three=r('three.min.js')
body=r('10_body.html').replace('@@AVATAR@@',av)
head,tail=body.split('@@THREE@@')
js=''.join(r(f)+'\n' for f in ['20_data.js','30a_build.js','30b_env.js','30c_dyn.js','40_world.js','50_scene.js','55_audio.js','60_ui_a.js','60_ui_b.js','70_main.js'])
html=r('00_head.html')+head+three.replace('</script','<\\/script')+tail+js.replace('</script','<\\/script')+'</script>\n</body>\n</html>\n'
open(out,'w',encoding='utf-8').write(html)
print(len(html))
PY
