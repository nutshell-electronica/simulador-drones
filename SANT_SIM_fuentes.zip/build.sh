#!/bin/bash
cd "$(dirname "$0")"
OUT=${1:-simulador_drones.html}
python3 - "$OUT" <<'PY'
import sys
out=sys.argv[1]
r=lambda f:open(f,encoding='utf-8').read()
av=r('avatar.b64').strip()
three=r('three.min.js')
libs=r('peerjs.min.js').split('//# sourceMappingURL')[0]+'\n'+r('qrcode.min.js')+'\n'
body=r('10_body.html').replace('@@AVATAR@@',av)
fav=r('favicon.b64').strip()
head,tail=body.split('@@THREE@@')
js=libs+''.join(r(f)+'\n' for f in ['05_i18n_dict.js','06_i18n.js','20_data.js','30a_build.js','35_comm.js','30b_env.js','30c_dyn.js','31_tail.js','40_world.js','45_actors.js','46_comp.js','47_actors3d.js','47b_mars3d.js','48_gfx.js','49_models.js','50_scene.js','55_audio.js','60_ui_a.js','62_params.js','65_pad.js','66_mob.js','60_ui_b.js','70_main.js'])
html=r('00_head.html').replace('@@FAVICON@@',fav)+head+three.replace('</script','<\\/script')+tail+js.replace('</script','<\\/script')+'</script>\n</body>\n</html>\n'
open(out,'w',encoding='utf-8').write(html)
print(len(html))
PY
