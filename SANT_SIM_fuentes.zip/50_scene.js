/* ===== ESCENA 3D (three.js) ===== */
var R3D = {};
(function(){
var deg=Math.PI/180, clamp=SD.clamp;
var S={}, scn=null, world=null, drone=null, dyn=[], trailPts=[], trailT=0;

R3D.init=function(canvas){
  S.r=new THREE.WebGLRenderer({canvas:canvas,antialias:true,preserveDrawingBuffer:false});
  S.r.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
  S.scene=new THREE.Scene();
  S.cam=new THREE.PerspectiveCamera(60,1,0.15,9000);
  S.hemi=new THREE.HemisphereLight(0xffffff,0x6b7a5a,0.9); S.scene.add(S.hemi);
  S.sun=new THREE.DirectionalLight(0xffffff,0.9); S.sun.position.set(-0.5,0.8,0.35); S.scene.add(S.sun);
  /* cielo */
  var g=new THREE.SphereGeometry(5200,24,14), col=new Float32Array(g.attributes.position.count*3);
  g.setAttribute('color',new THREE.BufferAttribute(col,3));
  S.sky=new THREE.Mesh(g,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.BackSide,fog:false,depthWrite:false}));
  S.sky.renderOrder=-10; S.scene.add(S.sky);
  var sc=document.createElement('canvas'); sc.width=sc.height=128; var sg=sc.getContext('2d'), gr=sg.createRadialGradient(64,64,0,64,64,64);
  gr.addColorStop(0,'rgba(255,255,255,1)'); gr.addColorStop(0.07,'rgba(255,252,235,1)'); gr.addColorStop(0.12,'rgba(255,240,200,0.55)'); gr.addColorStop(0.4,'rgba(255,225,170,0.16)'); gr.addColorStop(1,'rgba(255,220,160,0)');
  sg.fillStyle=gr; sg.fillRect(0,0,128,128);
  S.sunSpr=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(sc),transparent:true,depthTest:false,depthWrite:false,fog:false,blending:THREE.AdditiveBlending}));
  S.sunSpr.scale.set(1300,1300,1); S.sunSpr.renderOrder=-9; S.sunSpr.visible=false; S.sky.add(S.sunSpr); S.sunDir=new THREE.Vector3(0,1,0);
  S.fog=new THREE.FogExp2(0xcfe3f1,0.0002); S.scene.fog=S.fog;
  /* lluvia */
  var n=1400, pos=new Float32Array(n*6);
  var lg=new THREE.BufferGeometry(); lg.setAttribute('position',new THREE.BufferAttribute(pos,3));
  S.rain=new THREE.LineSegments(lg,new THREE.LineBasicMaterial({color:0x6d8aa5,transparent:true,opacity:0.5,fog:false}));
  S.rain.frustumCulled=false; S.rain.visible=false; S.scene.add(S.rain); S.rainN=n;
  for(var i=0;i<n;i++){ S.rain.userData[i]=[Math.random()*60-30,Math.random()*30,Math.random()*60-30]; }
  /* sombra */
  var sm=new THREE.Mesh(new THREE.CircleGeometry(1,20),new THREE.MeshBasicMaterial({color:0x000000,transparent:true,opacity:0.35,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-4,polygonOffsetUnits:-4}));
  sm.rotation.x=-Math.PI/2; S.shadow=sm; S.scene.add(sm);
  /* estela */
  var tg=new THREE.BufferGeometry(); tg.setAttribute('position',new THREE.BufferAttribute(new Float32Array(900*3),3)); tg.setDrawRange(0,0);
  S.trail=new THREE.Line(tg,new THREE.LineBasicMaterial({color:0xe2552d})); S.trail.frustumCulled=false; S.scene.add(S.trail);
  S.camMode='vlos'; S.chasePos=new THREE.Vector3(); S.uptilt=10;
  S.worldGroup=new THREE.Group(); S.scene.add(S.worldGroup);
  R3D.resize();
};
R3D.resize=function(){
  var c=S.r.domElement.parentNode, w=c.clientWidth, h=c.clientHeight;
  S.r.setSize(w,h,false); S.cam.aspect=w/h; S.cam.updateProjectionMatrix();
};
R3D.camera=function(){return S.cam;};
R3D.sunInfo=function(){return {dir:S.sunDir,el:S.sunEl};};
R3D.setCamMode=function(m){S.camMode=m;};
R3D.getCamMode=function(){return S.camMode;};

function disposeGroup(g){
  g.traverse(function(o){ if(o.geometry)o.geometry.dispose(); if(o.material){ if(o.material.map)o.material.map.dispose(); o.material.dispose&&o.material.dispose(); } });
  while(g.children.length) g.remove(g.children[0]);
}
function canvasTex(w,h,fn,rep){ var c=document.createElement('canvas'); c.width=w; c.height=h; fn(c.getContext('2d'),w,h); var t=new THREE.CanvasTexture(c); if(rep){t.wrapS=t.wrapT=THREE.RepeatWrapping;} t.anisotropy=4; return t; }

function lin(v){ return v<=0.04045?v/12.92:Math.pow((v+0.055)/1.055,2.4); }
R3D.loadWorld=function(w){
  S.rings=null; world=w; disposeGroup(S.worldGroup); dyn=[]; trailPts=[];
  var G=S.worldGroup, EXT=SW.EXT;
  /* terreno */
  if(w.voxel){ var V=w.voxel, P=[],N3=[],C3=[],IX=[], rc=function(hx){ return [lin(((hx>>16)&255)/255),lin(((hx>>8)&255)/255),lin((hx&255)/255)]; };
    function quad(a,b,c,d,nx,ny,nz,col){ var o=P.length/3; [a,b,c,d].forEach(function(v){ P.push(v[0],v[1],v[2]); N3.push(nx,ny,nz); C3.push(col[0],col[1],col[2]); }); IX.push(o,o+1,o+2,o,o+2,o+3); }
    for(var vj=0;vj<V.n;vj++) for(var vi=0;vi<V.n;vi++){ var vk=vj*V.n+vi, vh=V.H[vk], col=rc(V.C[vk]), x0=-EXT+vi*V.cell, x1=x0+V.cell, z0=-EXT+vj*V.cell, z1=z0+V.cell;
      quad([x0,vh,z0],[x0,vh,z1],[x1,vh,z1],[x1,vh,z0],0,1,0,col);
      var nb=[[vi,vj-1,0,-1],[vi,vj+1,0,1],[vi-1,vj,-1,0],[vi+1,vj,1,0]];
      nb.forEach(function(q){ var hn=(q[0]<0||q[1]<0||q[0]>=V.n||q[1]>=V.n)?-8:V.H[q[1]*V.n+q[0]]; if(hn>=vh) return;
        if(q[3]===-1) quad([x0,hn,z0],[x0,vh,z0],[x1,vh,z0],[x1,hn,z0],0,0,-1,col);
        else if(q[3]===1) quad([x1,hn,z1],[x1,vh,z1],[x0,vh,z1],[x0,hn,z1],0,0,1,col);
        else if(q[2]===-1) quad([x0,hn,z1],[x0,vh,z1],[x0,vh,z0],[x0,hn,z0],-1,0,0,col);
        else quad([x1,hn,z0],[x1,vh,z0],[x1,vh,z1],[x1,hn,z1],1,0,0,col); }); }
    var vg=new THREE.BufferGeometry(); vg.setAttribute('position',new THREE.Float32BufferAttribute(P,3)); vg.setAttribute('normal',new THREE.Float32BufferAttribute(N3,3)); vg.setAttribute('color',new THREE.Float32BufferAttribute(C3,3)); vg.setIndex(IX);
    var vm=new THREE.Mesh(vg,new THREE.MeshLambertMaterial({vertexColors:true})); vm.frustumCulled=false; G.add(vm);
  } else {
  var flat=(w.id==='campo'||w.id==='aeropuerto'||w.id==='ciudad'||w.id==='barrio');
  var seg=flat?90:190;
  var geo=new THREE.PlaneGeometry(EXT*2,EXT*2,seg,seg); geo.rotateX(-Math.PI/2);
  var pa=geo.attributes.position, col=new Float32Array(pa.count*3);
  for(var i=0;i<pa.count;i++){
    var x=pa.getX(i), z=pa.getZ(i), h=w.land(x,z); pa.setY(i,h);
    var c=w.pal(x,z,h); if(w.shapes) c=[lin(c[0]),lin(c[1]),lin(c[2])]; col[i*3]=c[0]; col[i*3+1]=c[1]; col[i*3+2]=c[2];
  }
  geo.setAttribute('color',new THREE.BufferAttribute(col,3)); geo.computeVertexNormals();
  G.add(new THREE.Mesh(geo,new THREE.MeshLambertMaterial({vertexColors:true})));
  }
  if(w.shapes){ w.shapes.forEach(function(q,i){
    var g=q.ell?new THREE.CircleGeometry(1,48):new THREE.PlaneGeometry(1,1); g.rotateX(-Math.PI/2);
    var m=new THREE.Mesh(g,new (q.glow?THREE.MeshBasicMaterial:THREE.MeshLambertMaterial)({color:q.hex,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-2,depthWrite:false}));
    m.scale.set(q.ell?q.w/2:q.w,1,q.ell?q.d/2:q.d); m.rotation.y=q.rot; m.position.set(q.x,0.04,q.z); m.renderOrder=1+i; G.add(m); }); }
  if(w.sea){ var sg=new THREE.PlaneGeometry(EXT*2,EXT*2); sg.rotateX(-Math.PI/2);
    var sea=new THREE.Mesh(sg,new THREE.MeshLambertMaterial({color:0x2f7fa6,transparent:true,opacity:0.82})); sea.position.y=0.02; G.add(sea); }
  /* decales */
  if(w.showRunway){ var r=w.showRunway;
    var tex=canvasTex(64,512,function(c,W,H){ c.fillStyle='#4a4f55'; c.fillRect(0,0,W,H); c.fillStyle='#e9e9e9'; for(var y=10;y<H;y+=48) c.fillRect(W/2-2,y,4,26); c.fillRect(2,0,3,H); c.fillRect(W-5,0,3,H); });
    var m=new THREE.Mesh(new THREE.PlaneGeometry(r.wid,r.len),new THREE.MeshLambertMaterial({map:tex}));
    m.rotation.x=-Math.PI/2; m.position.set(r.x,w.terrainH(r.x,r.z)+0.06,r.z); G.add(m); }
  if(w.id==='ciudad'){
    var a=new THREE.Mesh(new THREE.PlaneGeometry(1500,900),new THREE.MeshLambertMaterial({color:0x3a3d42})); a.rotation.x=-Math.PI/2; a.position.set(0,0.03,-520); G.add(a);
    var pl=new THREE.Mesh(new THREE.CircleGeometry(w.plaza.r,36),new THREE.MeshLambertMaterial({color:0xcfcabd})); pl.rotation.x=-Math.PI/2; pl.position.set(0,0.05,0); G.add(pl);
  }
  if(w.id==='barrio'){
    var a2=new THREE.Mesh(new THREE.PlaneGeometry(1300,1000),new THREE.MeshLambertMaterial({color:0x3d4046})); a2.rotation.x=-Math.PI/2; a2.position.set(0,0.03,-300); G.add(a2);
    var pm=new THREE.InstancedMesh(new THREE.BoxGeometry(36,0.12,36),new THREE.MeshLambertMaterial({color:0xffffff}),w.blocks.length), dm2=new THREE.Object3D(), c3=new THREE.Color();
    w.blocks.forEach(function(b,i){ dm2.position.set(b.x,0.08,b.z); dm2.updateMatrix(); pm.setMatrixAt(i,dm2.matrix); c3.setHex(((Math.abs(b.x)*7+Math.abs(b.z)*13)|0)%3===0?0x9fb08a:0xb9b4a5); pm.setColorAt(i,c3); });
    pm.instanceMatrix.needsUpdate=true; pm.instanceColor.needsUpdate=true; G.add(pm);
    var pl2=new THREE.Mesh(new THREE.CircleGeometry(w.plaza.r,36),new THREE.MeshLambertMaterial({color:0xcfcabd})); pl2.rotation.x=-Math.PI/2; pl2.position.set(w.plaza.x,0.2,w.plaza.z); G.add(pl2);
  }
  /* pista de aterrizaje de césped en campo ya incluida; helipuerto / base */
  var hp=canvasTex(128,128,function(c,W,H){ c.fillStyle='#f5c842'; c.beginPath(); c.arc(64,64,62,0,6.3); c.fill(); c.fillStyle='#222'; c.font='bold 84px sans-serif'; c.textAlign='center'; c.textBaseline='middle'; c.fillText('H',64,70); });
  var pad=new THREE.Mesh(new THREE.CircleGeometry(1.4,24),new THREE.MeshBasicMaterial({map:hp,transparent:true}));
  pad.rotation.x=-Math.PI/2; pad.position.set(w.home.x,w.homeY+0.09,w.home.z); G.add(pad);
  if(w.floor){ var fl=new THREE.Mesh(new THREE.PlaneGeometry(w.floor.w,w.floor.d),new THREE.MeshLambertMaterial({color:0x8e949a})); fl.rotation.x=-Math.PI/2; fl.position.set(w.floor.x,0.04,w.floor.z); G.add(fl);
    var ln=new THREE.MeshBasicMaterial({color:0xe8c52e}); [-3,3].forEach(function(o){ var l=new THREE.Mesh(new THREE.PlaneGeometry(0.2,50),ln); l.rotation.x=-Math.PI/2; l.position.set(o*3,0.06,w.floor.z-1); G.add(l); }); }
  if(w.decor){ var dm=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshBasicMaterial({color:0xffffff}),w.decor.length), dd=new THREE.Object3D(), dc=new THREE.Color();
    w.decor.forEach(function(q,i){ dd.position.set(q.x,q.y,q.z); dd.scale.set(q.sx,q.sy,q.sz); dd.updateMatrix(); dm.setMatrixAt(i,dd.matrix); dc.setHex(q.color); dm.setColorAt(i,dc); }); G.add(dm); }
  /* obstáculos instanciados */
  var boxes=[],cyls=[],trees=[],extras=[];
  w.obstacles.forEach(function(o){ if(o.kind==='box')boxes.push(o); else if(o.kind==='tree')trees.push(o); else cyls.push(o); });
  var dummy=new THREE.Object3D(), cc=new THREE.Color();
  function inst(geom,list,mat,fn){
    if(!list.length) return null;
    var im=new THREE.InstancedMesh(geom,mat,list.length);
    list.forEach(function(o,i){ fn(o,dummy,cc); dummy.updateMatrix(); im.setMatrixAt(i,dummy.matrix); im.setColorAt(i,cc); });
    im.instanceMatrix.needsUpdate=true; im.instanceColor.needsUpdate=true; G.add(im); return im;
  }
  var bg=new THREE.BoxGeometry(1,1,1);
  inst(bg,boxes,new THREE.MeshLambertMaterial(),function(o,d,c){ var bh=o.body||o.h; d.position.set(o.x,o.y0+bh/2,o.z); d.scale.set(o.dx,bh,o.dz); d.rotation.set(0,0,0); c.setHex(o.color); });
  inst(new THREE.CylinderGeometry(1,1,1,14),cyls,new THREE.MeshLambertMaterial(),function(o,d,c){ var bh=o.body||o.h; d.position.set(o.x,o.y0+bh/2,o.z); d.scale.set(o.dx,bh,o.dx); d.rotation.set(0,0,0); c.setHex(o.color); });
  inst(new THREE.ConeGeometry(1,1,8),trees,new THREE.MeshLambertMaterial(),function(o,d,c){ d.position.set(o.x,o.y0+o.h*0.28+o.h*0.36,o.z); d.scale.set(o.dx*1.1,o.h*0.72,o.dx*1.1); d.rotation.set(0,0,0); c.setHex(o.color); });
  inst(new THREE.CylinderGeometry(1,1,1,6),trees,new THREE.MeshLambertMaterial(),function(o,d,c){ d.position.set(o.x,o.y0+o.h*0.14,o.z); d.scale.set(0.3,o.h*0.28,0.3); d.rotation.set(0,0,0); c.setHex(0x5b4330); });
  /* detalles: torres con bandas, aerogeneradores, buque */
  w.obstacles.forEach(function(o){
    if(o.cone){ var cn=new THREE.Mesh(new THREE.ConeGeometry(1,1,o.kind==='box'?4:14),new THREE.MeshLambertMaterial({color:o.cone.color})); var cr=o.kind==='box'?o.dx*0.78:o.dx*1.25; cn.scale.set(cr,o.cone.h,cr); if(o.kind==='box') cn.rotation.y=Math.PI/4; cn.position.set(o.x,o.y0+o.body+o.cone.h/2,o.z); G.add(cn); }
    if(o.mast){ var band=new THREE.Mesh(new THREE.CylinderGeometry(o.dx*1.08,o.dx*1.08,o.h*0.12,10),new THREE.MeshLambertMaterial({color:0xf2f2f2})); band.position.set(o.x,o.y0+o.h*0.9,o.z); G.add(band); }
    if(o.turbine){ var gr=new THREE.Group(); gr.position.set(o.x,o.y0+o.h,o.z); var nac=new THREE.Mesh(new THREE.BoxGeometry(3,3,8),new THREE.MeshLambertMaterial({color:0xdfe4e8})); gr.add(nac);
      var rot=new THREE.Group(); rot.position.set(0,0,-4.5); for(var k=0;k<3;k++){ var bl=new THREE.Mesh(new THREE.BoxGeometry(1.2,38,0.4),new THREE.MeshLambertMaterial({color:0xf4f6f7})); bl.position.y=19; var pv=new THREE.Group(); pv.rotation.z=k*2.094; pv.add(bl); rot.add(pv);} gr.add(rot); gr.rotation.y=(w.wxDirRad||0); G.add(gr); dyn.push({rot:rot,turbine:true,grp:gr}); }
    if(o.ship){ var br=new THREE.Mesh(new THREE.BoxGeometry(14,14,16),new THREE.MeshLambertMaterial({color:0xf0f0f0})); br.position.set(o.x+o.dx/2-14,o.y0+o.h+7,o.z); G.add(br); var st=new THREE.Mesh(new THREE.CylinderGeometry(2,2,10,10),new THREE.MeshLambertMaterial({color:0xc2382e})); st.position.set(o.x+o.dx/2-14,o.y0+o.h+19,o.z); G.add(st); }
    if(o.lighthouse){ var top=new THREE.Mesh(new THREE.CylinderGeometry(o.dx*0.9,o.dx*0.9,5,12),new THREE.MeshLambertMaterial({color:0xc2382e})); top.position.set(o.x,o.y0+o.h+2.5,o.z); G.add(top); }
  });
  /* zonas normativas */
  w.zones.forEach(function(z){
    var hgt=z.type==='restricted'?500:(z.type==='crowd'?130:130);
    var cm=new THREE.Mesh(new THREE.CylinderGeometry(z.r,z.r,hgt,48,1,true),new THREE.MeshBasicMaterial({color:z.color,transparent:true,opacity:z.type==='restricted'?0.07:0.10,side:THREE.DoubleSide,depthWrite:false,fog:false}));
    cm.position.set(z.x,hgt/2,z.z); G.add(cm);
    var ring=new THREE.Mesh(new THREE.RingGeometry(z.r-1.2,z.r,64),new THREE.MeshBasicMaterial({color:z.color,side:THREE.DoubleSide,transparent:true,opacity:0.7,depthWrite:false,fog:false}));
    ring.rotation.x=-Math.PI/2; ring.position.set(z.x,w.terrainH(z.x+z.r,z.z)+0.2,z.z); if(z.r<400) ring.position.y=w.terrainH(z.x,z.z)+0.2; G.add(ring);
  });
  /* tráfico tripulado */
  if(w.traffic){
    var tp=new THREE.Group();
    var fu=new THREE.Mesh(new THREE.CylinderGeometry(0.9,0.5,8,10),new THREE.MeshLambertMaterial({color:0xf2f2f2})); fu.rotation.z=Math.PI/2; tp.add(fu);
    var wg=new THREE.Mesh(new THREE.BoxGeometry(1.6,0.2,11),new THREE.MeshLambertMaterial({color:0xcc3333})); tp.add(wg);
    var tl=new THREE.Mesh(new THREE.BoxGeometry(1,1.8,0.2),new THREE.MeshLambertMaterial({color:0xcc3333})); tl.position.set(-3.6,0.9,0); tp.add(tl);
    G.add(tp); dyn.push({traffic:true,grp:tp});
  }
  S.shadow.visible=true;
  buildActors(G,w);
};

/* ---------- aves, cometas y personas ---------- */
var AM={};
function buildActors(G,w){
  S.act={birds:[],kites:[],people:[]}; var A=w.actors; if(!A) return;
  if(!AM.wht){
    AM.wht=new THREE.MeshLambertMaterial({color:0xf2f2ee}); AM.tip=new THREE.MeshLambertMaterial({color:0x44484e}); AM.leg=new THREE.MeshLambertMaterial({color:0x2c3340}); AM.skin=new THREE.MeshLambertMaterial({color:0xd9a98a});
    AM.shirts=[0xd9342b,0x2e6fb7,0xf1c232,0x3a9a5b,0xf2f2f2,0x8a4fb0].map(function(c){ return new THREE.MeshLambertMaterial({color:c}); });
    AM.kite=[0xe2552d,0xf1c232,0x2e9ad0,0xd23c8c,0x3a9a5b].map(function(c){ return new THREE.MeshBasicMaterial({color:c,side:THREE.DoubleSide}); });
    AM.gBody=new THREE.SphereGeometry(0.16,8,6); AM.gWing=new THREE.BoxGeometry(0.7,0.025,0.2); AM.gTip=new THREE.BoxGeometry(0.16,0.027,0.18);
    AM.pLeg=new THREE.BoxGeometry(0.22,0.8,0.3); AM.pTor=new THREE.CylinderGeometry(0.2,0.2,0.62,8); AM.pHead=new THREE.SphereGeometry(0.13,8,6);
    var sh=new THREE.Shape(); sh.moveTo(0,0.75); sh.lineTo(0.5,0.1); sh.lineTo(0,-0.55); sh.lineTo(-0.5,0.1); sh.closePath(); AM.kGeo=new THREE.ShapeGeometry(sh);
    AM.tailGeo=new THREE.PlaneGeometry(0.16,0.34);
  }
  A.birds.forEach(function(b){
    var g=new THREE.Group(), body=new THREE.Mesh(AM.gBody,AM.wht); body.scale.set(1,0.85,2.6); g.add(body);
    var wl=new THREE.Group(), wr=new THREE.Group(); wl.position.set(-0.08,0.02,0); wr.position.set(0.08,0.02,0);
    var m1=new THREE.Mesh(AM.gWing,AM.wht); m1.position.x=-0.35; var t1=new THREE.Mesh(AM.gTip,AM.tip); t1.position.x=-0.76; wl.add(m1); wl.add(t1);
    var m2=new THREE.Mesh(AM.gWing,AM.wht); m2.position.x=0.35; var t2=new THREE.Mesh(AM.gTip,AM.tip); t2.position.x=0.76; wr.add(m2); wr.add(t2);
    g.add(wl); g.add(wr); g.scale.setScalar(1.8); G.add(g); S.act.birds.push({g:g,wl:wl,wr:wr,b:b});
  });
  A.kites.forEach(function(k){
    var g=new THREE.Group(), m=new THREE.Mesh(AM.kGeo,AM.kite[k.col%AM.kite.length]); g.add(m);
    for(var i=0;i<7;i++){ var t=new THREE.Mesh(AM.tailGeo,AM.kite[(k.col+i+1)%AM.kite.length]); t.position.set(Math.sin(i*0.9)*0.12,-0.75-i*0.36,0); g.add(t); }
    var tg=new THREE.BufferGeometry(); tg.setAttribute('position',new THREE.BufferAttribute(new Float32Array(6),3));
    var line=new THREE.Line(tg,new THREE.LineBasicMaterial({color:0x2b2b2b})); line.frustumCulled=false; G.add(line);
    var holder=mkPerson(k.col%6); holder.position.set(k.ax,k.ay,k.az); G.add(holder);
    G.add(g); S.act.kites.push({g:g,line:line,k:k});
  });
  A.people.forEach(function(p){ var g=mkPerson(p.col); G.add(g); S.act.people.push({g:g,p:p}); });
}
function mkPerson(col){
  var g=new THREE.Group(), legs=new THREE.Mesh(AM.pLeg,AM.leg); legs.position.y=0.4; g.add(legs);
  var tor=new THREE.Mesh(AM.pTor,AM.shirts[col%AM.shirts.length]); tor.position.y=1.11; g.add(tor);
  var hd=new THREE.Mesh(AM.pHead,AM.skin); hd.position.y=1.6; g.add(hd); return g;
}
function updateActors(T){
  if(!S.act) return;
  S.act.birds.forEach(function(o){ var b=o.b; o.g.position.set(b.x,b.y,b.z); o.g.rotation.y=-b.hd; var a=Math.sin(T*13+b.ph*3)*0.75; o.wl.rotation.z=a; o.wr.rotation.z=-a; });
  S.act.kites.forEach(function(o){ var k=o.k; o.g.position.set(k.x,k.y,k.z); o.g.lookAt(k.ax,k.ay+1.7,k.az); o.g.rotateZ(k.bank);
    var a=o.line.geometry.attributes.position.array; a[0]=k.ax; a[1]=k.ay+1.7; a[2]=k.az; a[3]=k.x; a[4]=k.y-0.3; a[5]=k.z; o.line.geometry.attributes.position.needsUpdate=true; });
  S.act.people.forEach(function(o){ var p=o.p; o.g.position.set(p.x,p.y+(p.moving?Math.abs(Math.sin(T*6+p.ph))*0.03:0),p.z); o.g.rotation.y=-p.hd; });
}

/* Meteo y hora del día */
function mixc(a,b,t){ return new THREE.Color(a).lerp(new THREE.Color(b),t); }
R3D.setWeather=function(wx,tod,sun){
  var oc=clamp(wx.rain/10+(wx.vis<6?0.5:0)+(wx.turb>0.9?0.3:0),0,1);
  var hz,zn,hI,sI,sc,gc;
  if(tod==='noche'){ hz=new THREE.Color(0x1d2b42); zn=new THREE.Color(0x050914); hI=0.30; sI=0.18; sc=0x9db5e8; gc=0x1a2236; }
  else if(tod==='atardecer'){ hz=new THREE.Color(0xf4b07a); zn=new THREE.Color(0x4d6a9f); hI=0.55; sI=0.75; sc=0xffc890; gc=0x7a6a58; }
  else { hz=new THREE.Color(0xd2e6f4); zn=new THREE.Color(0x5f9fd6); hI=0.95; sI=0.85; sc=0xffffff; gc=0x7b8a63; }
  var gray=tod==='noche'?0x20262e:0xa9b2ba;
  hz.lerp(new THREE.Color(gray),oc*0.75); zn.lerp(new THREE.Color(gray),oc*0.6);
  S.hemi.color.setHex(0xffffff); S.hemi.groundColor.setHex(gc); S.hemi.intensity=hI*(1-0.3*oc); S.sun.color.setHex(sc); S.sun.intensity=sI*(1-0.6*oc);
  var sel=sun?sun.el:(tod==='noche'?-30:(tod==='atardecer'?3:55)), saz=sun?sun.az:250;
  var se=Math.max(sel,0)*deg, sdx=Math.sin(saz*deg)*Math.cos(sel*deg), sdy=Math.sin(sel*deg), sdz=-Math.cos(saz*deg)*Math.cos(sel*deg);
  S.sunDir.set(sdx,sdy,sdz); S.sunEl=sel;
  if(sel>-2){ S.sun.position.set(sdx,Math.max(sdy,0.04),sdz); if(tod==='dia'){ sI=0.55+0.4*clamp(sel/45,0,1); S.sun.color.setHex(sel<22?0xfff0d8:0xffffff); S.sun.intensity=sI*(1-0.6*oc); } }
  else S.sun.position.set(-0.3,0.8,0.4);
  S.sunSpr.visible=(sel>-3); S.sunSpr.position.copy(S.sunDir).multiplyScalar(4800);
  S.sunSpr.material.opacity=clamp(1-Math.max(0,oc-0.2)*1.1,0.12,1);
  if(wx.vis<1) hz.lerp(new THREE.Color(tod==='noche'?0x1a2028:0xdfe3e6),0.9);
  var g=S.sky.geometry, p=g.attributes.position, c=g.attributes.color;
  for(var i=0;i<p.count;i++){ var t=clamp(p.getY(i)/5200,0,1); t=Math.pow(t,0.55); var k=hz.clone().lerp(zn,t);
    if(sel>-3){ var dt0=(p.getX(i)*sdx+p.getY(i)*sdy+p.getZ(i)*sdz)/5200, gl=(Math.pow(Math.max(0,dt0),10)*0.35+Math.pow(Math.max(0,dt0),90)*0.5)*(1-oc*0.8); k.r+=gl; k.g+=gl*0.9; k.b+=gl*0.7; }
    c.setXYZ(i,k.r,k.g,k.b); }
  c.needsUpdate=true;
  S.fog.color.copy(hz); S.fog.density=3.912/(Math.max(wx.vis,0.1)*1000);
  S.r.setClearColor(hz);
  S.rain.visible=wx.rain>0.2; S.rain.material.opacity=0.25+Math.min(0.4,wx.rain/40);
  S.rainAmt=clamp(wx.rain/12,0.12,1); S.wxDir=wx.dir; S.tod=tod;
  S.nightMode=(tod==='noche');
};

/* ---------- modelo del dron ---------- */
function mat(c,e){ return new THREE.MeshLambertMaterial({color:c,emissive:e||0x000000}); }
function wingGeom(b,rc,tc,sw,th){
  var sh=new THREE.Shape(); var h=b/2;
  sh.moveTo(-h,sw-tc/2); sh.lineTo(0,-rc/2); sh.lineTo(h,sw-tc/2); sh.lineTo(h,sw+tc/2); sh.lineTo(0,rc/2); sh.lineTo(-h,sw+tc/2); sh.closePath();
  var g=new THREE.ExtrudeGeometry(sh,{depth:th,bevelEnabled:false}); g.rotateX(Math.PI/2); g.translate(0,th/2,0); return g;
}
R3D.buildDrone=function(ac){
  if(drone){ S.scene.remove(drone.root); disposeGroup(drone.root); }
  var root=new THREE.Group(), body=new THREE.Group(); root.add(body);
  var fr=ac.frame, dim=fr.dim, props=[], spin=[], light=[];
  var dark=mat(0x2a3139), org=mat(0xe2552d), wht=mat(0xf3f3f0), teal=mat(0x1f8a8a);
  var strobe=null, drone_legL=0;
  if(ac.kind==='multi'){
    var n=ac.rotors, R=dim/2, off=n===4?Math.PI/4:(n===3?Math.PI:Math.PI/n);
    var cb=new THREE.Mesh(new THREE.BoxGeometry(dim*0.26,dim*0.09,dim*0.34),dark); body.add(cb);
    var top=new THREE.Mesh(new THREE.BoxGeometry(dim*0.2,dim*0.04,dim*0.26),teal); top.position.y=dim*0.065; body.add(top);
    for(var i=0;i<n;i++){
      var a=i*2*Math.PI/n+off*(n===3?0:1)+(n===3?0:0); if(n===3) a=i*2*Math.PI/3+Math.PI;   /* tri: un brazo hacia atrás */
      var dx=Math.sin(a)*R, dz=-Math.cos(a)*R;
      var front=Math.cos(a)>0.3;
      var arm=new THREE.Mesh(new THREE.BoxGeometry(0.025+dim*0.02,0.02+dim*0.02,R),front?org:dark);
      arm.position.set(dx/2,0,dz/2); arm.rotation.y=Math.atan2(-dx,-dz)+Math.PI/2*0; arm.lookAt(new THREE.Vector3(dx,0,dz)); arm.position.set(dx/2,0,dz/2); body.add(arm);
      var mot=new THREE.Mesh(new THREE.CylinderGeometry(dim*0.035,dim*0.035,dim*0.07,10),dark); mot.position.set(dx,dim*0.04,dz); body.add(mot);
      var pr=new THREE.Group(); pr.position.set(dx,dim*0.085,dz);
      var Dp=ac.D;
      var bl=new THREE.Mesh(new THREE.BoxGeometry(Dp,0.004,Dp*0.07),mat(front?0xe2552d:0x39424b)); pr.add(bl);
      var dsk=new THREE.Mesh(new THREE.CircleGeometry(Dp/2,24),new THREE.MeshBasicMaterial({color:0x2a3139,transparent:true,opacity:0.14,side:THREE.DoubleSide,depthWrite:false})); dsk.rotation.x=-Math.PI/2; pr.add(dsk);
      body.add(pr); props.push({g:pr,dir:(i%2?1:-1)});
      var led=new THREE.Mesh(new THREE.SphereGeometry(dim*0.018,6,6),new THREE.MeshBasicMaterial({color:front?0x25d366:0xff3030})); led.position.set(dx,-dim*0.01,dz); body.add(led);
    }
  } else if(ac.kind==='heli'){
    var L=dim*0.75;
    var fu=new THREE.Mesh(new THREE.BoxGeometry(L*0.22,L*0.2,L*0.55),org); fu.position.set(0,0,-L*0.05); body.add(fu);
    var cp=new THREE.Mesh(new THREE.SphereGeometry(L*0.11,10,8),mat(0x9ec9e0)); cp.position.set(0,L*0.03,-L*0.3); cp.scale.set(1,0.9,1.4); body.add(cp);
    var boom=new THREE.Mesh(new THREE.CylinderGeometry(L*0.025,L*0.035,L*0.9,8),dark); boom.rotation.x=Math.PI/2; boom.position.set(0,L*0.03,L*0.68); body.add(boom);
    var fin=new THREE.Mesh(new THREE.BoxGeometry(0.01,L*0.2,L*0.14),org); fin.position.set(0,L*0.1,L*1.1); body.add(fin);
    var tr=new THREE.Group(); tr.position.set(L*0.03,L*0.16,L*1.12); var tb=new THREE.Mesh(new THREE.BoxGeometry(0.005,L*0.2,L*0.015),dark); tr.add(tb); body.add(tr); props.push({g:tr,dir:1,axis:'x',tail:true});
    var mast=new THREE.Mesh(new THREE.CylinderGeometry(L*0.015,L*0.015,L*0.18,6),dark); mast.position.set(0,L*0.18,-L*0.05); body.add(mast);
    var mr=new THREE.Group(); mr.position.set(0,L*0.28,-L*0.05); var b1=new THREE.Mesh(new THREE.BoxGeometry(dim,0.006,dim*0.04),dark); mr.add(b1);
    var dsk2=new THREE.Mesh(new THREE.CircleGeometry(dim/2,28),new THREE.MeshBasicMaterial({color:0x2a3139,transparent:true,opacity:0.10,side:THREE.DoubleSide,depthWrite:false})); dsk2.rotation.x=-Math.PI/2; mr.add(dsk2);
    body.add(mr); props.push({g:mr,dir:-1,main:true});
    [-1,1].forEach(function(s){ var sk=new THREE.Mesh(new THREE.BoxGeometry(0.01,0.01,L*0.5),dark); sk.position.set(s*L*0.12,-L*0.14,-L*0.05); body.add(sk); var lg=new THREE.Mesh(new THREE.BoxGeometry(0.01,L*0.12,0.01),dark); lg.position.set(s*L*0.12,-L*0.08,-L*0.05); body.add(lg); });
  } else if(ac.kind==='tailsitter'){
    var tsd=ac.ts, tb=fr.b, tch=fr.S/tb, rc=tch*1.5, Dp2=ac.D, tid=ac.type.id;
    body.add(new THREE.Mesh(wingGeom(tb,rc,tch*0.55,tch*0.45,0.03),wht));
    var tst=new THREE.Mesh(wingGeom(tb*0.45,rc*0.7,tch*0.5,tch*0.3,0.034),org); tst.position.y=0.002; body.add(tst);
    if(tsd.surf){ [-1,1].forEach(function(sg){ var ev=new THREE.Mesh(new THREE.BoxGeometry(tb*0.34,0.012,tch*0.2),teal); ev.position.set(sg*tb*0.3,0.01,tch*0.45+tch*0.1); body.add(ev); }); }
    var legL=tch*1.05;
    var legX=(tid==='ts-single')?[0]:[-1,1];
    /* patas (trasera en hover) */
    [-1,1].forEach(function(sg){ var lx=(tid==='ts-single')?sg*tb*0.12:sg*tb*0.28; var lg=new THREE.Mesh(new THREE.CylinderGeometry(0.008,0.008,legL-tch*0.2,6),dark); lg.rotation.x=Math.PI/2; lg.position.set(lx,0.0,(legL+tch*0.2)/2); body.add(lg); var ft=new THREE.Mesh(new THREE.SphereGeometry(0.014,6,6),dark); ft.position.set(lx,0,legL); body.add(ft); });
    function tsMotor(x,y,z,dir,col,pods){
      var pd=new THREE.Mesh(new THREE.CylinderGeometry(0.022,0.026,tch*0.7,10),pods||dark); pd.rotation.x=Math.PI/2; pd.position.set(x,y,z+tch*0.3); body.add(pd);
      var pg=new THREE.Group(); pg.position.set(x,y,z-tch*0.08);
      var bl=new THREE.Mesh(new THREE.BoxGeometry(Dp2,Dp2*0.07,0.004),mat(col||0x39424b)); pg.add(bl);
      var dk=new THREE.Mesh(new THREE.CircleGeometry(Dp2/2,24),new THREE.MeshBasicMaterial({color:0x2a3139,transparent:true,opacity:0.14,side:THREE.DoubleSide,depthWrite:false})); pg.add(dk);
      body.add(pg); props.push({g:pg,dir:dir,axis:'z'});
    }
    if(tid==='ts-single'){
      tsMotor(0,0,-rc*0.5,1,0xe2552d);
      [-1,1].forEach(function(sg){ var fn=new THREE.Mesh(new THREE.BoxGeometry(0.012,tch*0.7*sg*sg,tch*0.5),org); fn.position.set(0,sg*tch*0.35,tch*0.1); body.add(fn); });
    } else if(tid==='ts-twin'||tid==='ts-twinvec'){
      var vec=tid==='ts-twinvec';
      [-1,1].forEach(function(sg,i){ tsMotor(sg*tb*0.19,0,-rc*0.42,(i?1:-1),0xe2552d,vec?teal:dark); });
      [-1,1].forEach(function(sg){ var wl=new THREE.Mesh(new THREE.BoxGeometry(0.01,tch*0.5,tch*0.3),org); wl.position.set(sg*tb/2,tch*0.08,tch*0.35); body.add(wl); });
    } else if(tid==='ts-tri'){
      [-1,1].forEach(function(sg,i){ tsMotor(sg*tb*0.28,0,-rc*0.42,(i?1:-1),0xe2552d); });
      var fn3=new THREE.Mesh(new THREE.BoxGeometry(0.012,tch*0.9,tch*0.55),org); fn3.position.set(0,tch*0.45,tch*0.1); body.add(fn3);
      tsMotor(0,tch*0.9+Dp2*0.2,-rc*0.1,1,0x39424b);
    } else {
      var yq=Math.max(tch*0.5,Dp2*0.62);
      [[-1,1],[1,1],[-1,-1],[1,-1]].forEach(function(q,i){ var xq=q[0]*tb*0.3, front=q[1]>0; var py=new THREE.Mesh(new THREE.BoxGeometry(0.012,Math.abs(yq),0.02),dark); py.position.set(xq,q[1]*yq/2,-rc*0.1); body.add(py); tsMotor(xq,q[1]*yq,-rc*0.1,(i%2?1:-1),front?0xe2552d:0x39424b); });
    }
    drone_legL=legL;
  } else {
    var b=fr.b, ch=fr.S/b;
    var isWing=ac.type.id==='fw-wing';
    if(isWing){
      var wg=new THREE.Mesh(wingGeom(b,ch*1.5,ch*0.5,ch*0.55,0.025),wht); body.add(wg);
      var stripe=new THREE.Mesh(wingGeom(b*0.5,ch*1.5*0.7,ch*0.5*0.9,ch*0.3,0.03),org); stripe.position.y=0.002; body.add(stripe);
      var pod=new THREE.Mesh(new THREE.SphereGeometry(ch*0.28,10,8),dark); pod.scale.set(0.8,0.7,1.4); pod.position.set(0,0.01,0); body.add(pod);
      [-1,1].forEach(function(s){ var wl=new THREE.Mesh(new THREE.BoxGeometry(0.01,ch*0.5,ch*0.3),org); wl.position.set(s*b/2,ch*0.1,ch*0.6); body.add(wl); });
      var pm=new THREE.Group(); pm.position.set(0,0.01,ch*0.9); var pb=new THREE.Mesh(new THREE.BoxGeometry(ac.D,0.004,ac.D*0.07),dark); pb.rotation.x=0; pm.rotation.x=Math.PI/2; pm.add(pb); var pd=new THREE.Mesh(new THREE.CircleGeometry(ac.D/2,20),new THREE.MeshBasicMaterial({color:0x222,transparent:true,opacity:0.12,side:THREE.DoubleSide,depthWrite:false})); pm.add(pd); body.add(pm); props.push({g:pm,dir:1,axis:'z'});
    } else {
      var fl=b*0.62;
      var fu2=new THREE.Mesh(new THREE.CylinderGeometry(ch*0.11,ch*0.07,fl,10),wht); fu2.rotation.x=Math.PI/2; fu2.position.z=fl*0.1; body.add(fu2);
      var wg2=new THREE.Mesh(wingGeom(b,ch,ch*0.8,0,0.025),wht); wg2.position.set(0,ch*0.1,-fl*0.05); body.add(wg2);
      var st2=new THREE.Mesh(new THREE.BoxGeometry(b*0.99,0.027,ch*0.18),org); st2.position.set(0,ch*0.1,-fl*0.05-ch*0.4); body.add(st2);
      var ht=new THREE.Mesh(wingGeom(b*0.36,ch*0.55,ch*0.45,0,0.02),wht); ht.position.set(0,ch*0.05,fl*0.55); body.add(ht);
      var vt=new THREE.Mesh(new THREE.BoxGeometry(0.02,ch*0.55,ch*0.5),org); vt.position.set(0,ch*0.3,fl*0.55); body.add(vt);
      var nose=new THREE.Mesh(new THREE.SphereGeometry(ch*0.1,8,8),dark); nose.position.set(0,0,-fl*0.4); body.add(nose);
      var pm2=new THREE.Group(); pm2.position.set(0,0,-fl*0.4-ch*0.1); pm2.rotation.x=Math.PI/2; var pb2=new THREE.Mesh(new THREE.BoxGeometry(ac.D,0.004,ac.D*0.07),dark); pm2.add(pb2); var pd2=new THREE.Mesh(new THREE.CircleGeometry(ac.D/2,20),new THREE.MeshBasicMaterial({color:0x222,transparent:true,opacity:0.12,side:THREE.DoubleSide,depthWrite:false})); pm2.add(pd2); body.add(pm2); props.push({g:pm2,dir:1,axis:'z'});
    }
  }
  /* accesorios */
  var s=Math.max(dim,0.25);
  if(ac.has('camhd')||ac.has('camir')||ac.has('camfpv')){ var cm=new THREE.Mesh(new THREE.SphereGeometry(s*0.06,10,8),mat(ac.has('camir')?0x8d5a2b:0x20262c)); cm.position.set(0,-s*0.07,-s*((ac.kind==='fixed'||ac.kind==='tailsitter')?0.0:0.12)); if(ac.kind==='fixed'||ac.kind==='tailsitter') cm.position.set(0,-0.03,-0.1); body.add(cm); }
  if(ac.has('lidar')){ var ld=new THREE.Mesh(new THREE.CylinderGeometry(s*0.05,s*0.05,s*0.07,12),mat(0x3c4a57)); ld.position.set(0,s*0.12,s*0.04); if(ac.kind==='fixed'||ac.kind==='tailsitter') ld.position.set(0,0.06,0); body.add(ld); spin.push(ld); }
  if(ac.has('chute')){ var ch2=new THREE.Mesh(new THREE.CylinderGeometry(s*0.05,s*0.05,s*0.09,10),mat(0xffffff)); ch2.position.set(0,s*0.1,s*0.1); if(ac.kind==='fixed'||ac.kind==='tailsitter') ch2.position.set(0,0.05,0.1); body.add(ch2); }
  if(ac.has('strobe')){ strobe=new THREE.Mesh(new THREE.SphereGeometry(s*0.035,8,8),new THREE.MeshBasicMaterial({color:0x22ff44})); strobe.position.set(0,s*0.09,s*0.15); if(ac.kind==='fixed'||ac.kind==='tailsitter') strobe.position.set(0,0.08,0.3); body.add(strobe); }
  /* luz de posición (siempre visible) */
  var nl=new THREE.Mesh(new THREE.SphereGeometry(s*0.02,6,6),new THREE.MeshBasicMaterial({color:0xff4040})); nl.position.set(0,s*0.05,s*0.14); body.add(nl);
  /* ayuda de visibilidad: los modelos pequeños se dibujan más grandes (sólo visual) */
  var vk=clamp(0.5/dim,1,3.2), lift=dim<0.5?0.1:dim*0.12; root.scale.setScalar(vk);
  if(ac.kind==='multi'&&dim<0.5){ var lgL=lift/vk, lgm=mat(0x20262c); for(var li=0;li<ac.rotors;li++){ var la=li*2*Math.PI/ac.rotors+(ac.rotors===4?Math.PI/4:(ac.rotors===3?Math.PI:Math.PI/ac.rotors)); if(ac.rotors===3) la=li*2*Math.PI/3+Math.PI; var lg=new THREE.Mesh(new THREE.CylinderGeometry(0.006,0.006,lgL,5),lgm); lg.position.set(Math.sin(la)*dim*0.3,-lgL/2,-Math.cos(la)*dim*0.3); body.add(lg); } } S.scene.add(root);
  S.shadow.scale.setScalar(Math.max(0.3,dim*vk*0.45));
  if(!S.beacon){ var bt=canvasTex(128,128,function(c){ c.clearRect(0,0,128,128); c.lineWidth=9; c.strokeStyle='rgba(255,122,26,0.95)'; c.beginPath(); c.arc(64,64,52,0,6.3); c.stroke(); c.lineWidth=4; c.strokeStyle='rgba(255,255,255,0.95)'; c.beginPath(); c.arc(64,64,40,0,6.3); c.stroke(); c.fillStyle='rgba(255,225,74,0.95)'; c.beginPath(); c.arc(64,64,7,0,6.3); c.fill(); });
    S.beacon=new THREE.Sprite(new THREE.SpriteMaterial({map:bt,transparent:true,depthTest:false,depthWrite:false,fog:false})); S.beacon.renderOrder=20; S.beacon.visible=false; S.scene.add(S.beacon); }
  drone={root:root,body:body,props:props,spin:spin,strobe:strobe,dim:dim,vk:vk,lift:lift,ac:ac,legL:drone_legL};
};

R3D.project=function(v3){ var v=v3.clone().project(S.cam); var c=S.r.domElement; return {x:(v.x*0.5+0.5)*c.clientWidth,y:(-v.y*0.5+0.5)*c.clientHeight,z:v.z}; };
R3D.dronePos=function(){ return drone?drone.root.position.clone():new THREE.Vector3(); };

/* incendio al caer a la lava */
var FIRE=null, FN=70;
function fireUpdate(on,p,dt,size){
  if(!FIRE){ if(!on) return;
    var g=new THREE.BufferGeometry(), pos=new Float32Array(FN*3), col=new Float32Array(FN*3), age=new Float32Array(FN);
    for(var i=0;i<FN;i++) age[i]=Math.random();
    g.setAttribute('position',new THREE.BufferAttribute(pos,3)); g.setAttribute('color',new THREE.BufferAttribute(col,3));
    var pts=new THREE.Points(g,new THREE.PointsMaterial({size:Math.max(1.3,size*1.1),map:canvasTex(32,32,function(c,W,H){ var gr=c.createRadialGradient(16,16,0,16,16,16); gr.addColorStop(0,'rgba(255,255,255,1)'); gr.addColorStop(1,'rgba(255,255,255,0)'); c.fillStyle=gr; c.fillRect(0,0,W,H); }),vertexColors:true,transparent:true,opacity:0.55,depthWrite:false,blending:THREE.AdditiveBlending,fog:false}));
    pts.frustumCulled=false; var lt=new THREE.PointLight(0xff7a22,2,60); S.scene.add(pts); S.scene.add(lt); FIRE={pts:pts,age:age,lt:lt,g:g,t:0}; }
  FIRE.pts.visible=on; FIRE.lt.visible=on; if(!on) return;
  FIRE.t+=dt; var pa=FIRE.g.attributes.position, ca=FIRE.g.attributes.color, sp=Math.max(0.8,size*0.6);
  for(var i=0;i<FN;i++){ var a=FIRE.age[i]+dt*0.9; if(a>=1){ a=0; pa.setXYZ(i,p.x+(Math.random()-0.5)*sp,p.y+Math.random()*0.3,p.z+(Math.random()-0.5)*sp); }
    else pa.setXYZ(i,pa.getX(i)+(Math.random()-0.5)*dt*1.2,pa.getY(i)+dt*(2.2+3*Math.random()),pa.getZ(i)+(Math.random()-0.5)*dt*1.2);
    FIRE.age[i]=a; var k=1-a; ca.setXYZ(i,0.35+0.65*k,k*k*0.55,0.02); }
  pa.needsUpdate=true; ca.needsUpdate=true; FIRE.lt.position.set(p.x,p.y+2,p.z); FIRE.lt.intensity=1.6+Math.random()*1.2;
}
/* actualización por fotograma */
var _v=new THREE.Vector3(), _q=new THREE.Euler();
R3D.update=function(f,dt,opts){
  if(!drone||!world) return;
  var p=f.pos, ac=f.ac, T=f.t;
  drone.root.position.set(p.x,p.y+drone.lift,p.z);
  fireUpdate(f.status==='crashed'&&!!world.lava&&/lava/.test(f.crashMsg||''),p,dt,drone.dim);
  drone.root.rotation.set(-f.pitch,-f.yaw,-f.roll,'YXZ');
  if(ac.kind==='tailsitter'){ var ex=f.tsFw?0:Math.PI/2; drone.body.rotation.x=ex; var el=ex-f.pitch; drone.body.position.y=drone.legL*Math.max(0,Math.sin(el)); drone.root.position.y=p.y; }
  /* hélices */
  var vis=(f.status==='flying'||f.status==='rolling'||f.status==='ground'&&f.Tcur>1)&&f.status!=='crashed';
  var run=(f.P>0 && (f.status==='flying'||f.status==='rolling'||f.Tcur>0.5))?1:0;
  var w0=(18+26*(f.thrPct/100))*run;
  drone.props.forEach(function(pr,i){ var a=pr.dir*w0*dt; if(pr.axis==='x') pr.g.rotation.x+=a*1.5; else if(pr.axis==='z') pr.g.rotation.z+=a; else pr.g.rotation.y+=a; });
  drone.spin.forEach(function(m){ m.rotation.y+=8*dt; });
  if(drone.strobe) drone.strobe.visible=(Math.floor(T*2.2)%2===0)||(T%0.45<0.06);
  /* sombra */
  var gh=world.floorH(p.x,p.y,p.z); S.shadow.position.set(p.x,gh+Math.min(0.12,0.012+drone.dim*0.1),p.z);
  var ah=Math.max(0,p.y-gh); S.shadow.material.opacity=clamp(0.4-ah*0.004,0.06,0.4)*(S.nightMode?0.4:1);
  var base=Math.max(0.3,drone.dim*drone.vk*0.45); S.shadow.scale.setScalar(base*(1+ah*0.012));
  /* estela */
  if(opts.trail){ trailT-=dt; if(trailT<=0&&f.status!=='ground'){ trailT=0.25; trailPts.push(p.x,p.y,p.z); if(trailPts.length>900*3) trailPts.splice(0,3); var a=S.trail.geometry.attributes.position; a.array.set(trailPts); a.needsUpdate=true; S.trail.geometry.setDrawRange(0,trailPts.length/3); } S.trail.visible=true; } else S.trail.visible=false;
  /* aerogeneradores / tráfico */
  dyn.forEach(function(d){ if(d.turbine){ d.rot.rotation.z+=0.6*dt; d.grp.rotation.y=(180-S.wxDir)*deg*0+Math.PI+(-S.wxDir*deg); } if(d.traffic&&world.dynamic[0]){ var t=world.dynamic[0]; d.grp.position.set(t.x,t.y,t.z); d.grp.rotation.y=(t.dir>0?0:Math.PI); } });
  updateActors(f.t);
  /* cámara */
  var cam=S.cam, mode=S.camMode, dh=drone.dim*drone.vk;
  var fx=Math.sin(f.yaw), fz=-Math.cos(f.yaw);
  if(mode==='vlos'){
    var h=world.home, ey=world.homeY+1.75; cam.position.set(h.x+0.0,ey,h.z+1.5);
    var tgt=_v.set(p.x,p.y,p.z); cam.up.set(0,1,0); cam.lookAt(tgt);
    var d=Math.hypot(p.x-h.x,p.y-ey,p.z-h.z); cam.fov=opts.zoom>1?40/opts.zoom*1.0:55; cam.near=0.5;
  } else if(mode==='fpv'){
    var ptilt=opts.gimbal?0:f.pitch, rtilt=opts.gimbal?0:f.roll;
    cam.position.set(p.x+fx*dh*0.18,p.y+dh*0.12,p.z+fz*dh*0.18);
    cam.up.set(0,1,0);
    cam.rotation.order='YXZ';
    var tsx=f.ac.kind==='tailsitter'&&(f.tsMode==='toFw'||f.tsMode==='toVt'); if(tsx){ ptilt=0; } var up=(SM.fwNow(f)||tsx?0:S.uptilt)*deg;
    cam.rotation.set(-ptilt+(opts.gimbal?-0.12:up)*1.0,-f.yaw,-rtilt);
    if(!SM.fwNow(f) && !tsx && !opts.gimbal) cam.rotation.x=-f.pitch+up;
    cam.fov=opts.gimbal?70:78; cam.near=0.1;
  } else if(mode==='chase'){
    var dd=Math.max(3.2,dh*5+2.5), tx=p.x-fx*dd, ty=p.y+dd*0.35, tz=p.z-fz*dd;
    S.chasePos.lerp(_v.set(tx,ty,tz),Math.min(1,dt*4)); if(S.chasePos.distanceTo(_v)>60) S.chasePos.copy(_v);
    var gy=world.terrainH(S.chasePos.x,S.chasePos.z)+1.2; if(S.chasePos.y<gy) S.chasePos.y=gy;
    cam.position.copy(S.chasePos); cam.up.set(0,1,0); cam.lookAt(p.x,p.y+dh*0.15,p.z); cam.fov=62; cam.near=0.2;
  } else { /* top */
    cam.position.set(p.x,p.y+Math.max(60,opts.topH||90),p.z+0.01); cam.up.set(0,0,-1); cam.lookAt(p.x,p.y,p.z); cam.fov=55; cam.near=1;
  }
  /* baliza de localización: anillo naranja cuando el dron se ve demasiado pequeño */
  if(S.beacon){ var bd=Math.max(1,cam.position.distanceTo(_v.set(p.x,p.y,p.z))), bsz=drone.dim*drone.vk;
    var ang=bsz/bd*(55/Math.max(20,cam.fov)), need=mode!=='fpv'&&(ang<0.02||(f.status==='ground'&&mode==='vlos'&&ang<0.12))&&f.status!=='crashed';
    S.beacon.visible=need; if(need){ S.beacon.position.set(p.x,p.y+drone.lift,p.z); var ks=Math.max(bsz*2,bd*0.045); S.beacon.scale.set(ks,ks,1); S.beacon.material.opacity=clamp((0.02-ang)/0.012,0.25,1)*(0.75+0.25*Math.sin(T*5)); } }
  cam.updateProjectionMatrix();
  S.sky.position.copy(cam.position);
  /* lluvia alrededor de la cámara */
  if(S.rain.visible){
    var a=S.rain.geometry.attributes.position.array, n=Math.floor(S.rainN*S.rainAmt), sl=opts.windX||0, sz=opts.windZ||0;
    for(var i=0;i<S.rainN;i++){
      var u=S.rain.userData[i]; u[1]-=26*dt; u[0]-=sl*dt*0.6; u[2]-=sz*dt*0.6;
      if(u[1]<-6||Math.abs(u[0])>30||Math.abs(u[2])>30){ u[0]=(Math.random()-0.5)*60; u[1]=18+Math.random()*10; u[2]=(Math.random()-0.5)*60; }
      var k=i*6, on=i<n;
      a[k]=cam.position.x+u[0]; a[k+1]=cam.position.y+u[1]; a[k+2]=cam.position.z+u[2];
      a[k+3]=a[k]+(on?sl*0.03:0); a[k+4]=a[k+1]+(on?0.7:0); a[k+5]=a[k+2]+(on?sz*0.03:0);
      if(!on){ a[k+3]=a[k]; a[k+4]=a[k+1]; a[k+5]=a[k+2]; }
    }
    S.rain.geometry.attributes.position.needsUpdate=true;
  }
  S.r.render(S.scene,cam);
};
/* aros del modo competición */
R3D.setRings=function(rings){
  if(S.rings&&S.rings.grp){ S.worldGroup.remove(S.rings.grp); disposeGroup(S.rings.grp); }
  S.rings=null; if(!rings||!rings.length) return;
  var grp=new THREE.Group(), items=[];
  rings.forEach(function(g,i){
    var it=new THREE.Group(); it.position.set(g.x,g.y,g.z); it.rotation.y=Math.atan2(g.nx,g.nz);
    var tube=Math.max(0.14,g.r*0.075);
    var mat=new THREE.MeshBasicMaterial({color:0xff7a1a,fog:false});
    var tor=new THREE.Mesh(new THREE.TorusGeometry(g.r,tube,10,48),mat); it.add(tor);
    var dmat=new THREE.MeshBasicMaterial({color:0xffe14a,transparent:true,opacity:0.18,side:THREE.DoubleSide,depthWrite:false,fog:false});
    var disc=new THREE.Mesh(new THREE.CircleGeometry(g.r,40),dmat); disc.visible=false; it.add(disc);
    var fl=world.floorH(g.x,g.y,g.z), ph=g.y-g.r-fl;
    if(ph>0.3){ var pole=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,ph,6),new THREE.MeshBasicMaterial({color:0x6b7785,transparent:true,opacity:0.55,fog:false})); pole.position.set(0,-g.r-ph/2,0); it.add(pole); }
    var tex=canvasTex(64,64,function(c,W,H){ c.fillStyle='rgba(20,40,58,0.85)'; c.beginPath(); c.arc(32,32,30,0,6.3); c.fill(); c.fillStyle='#fff'; c.font='bold 34px sans-serif'; c.textAlign='center'; c.textBaseline='middle'; c.fillText(String(i+1),32,35); });
    var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,depthTest:false,fog:false})); sp.position.set(0,g.r+tube+Math.max(0.9,g.r*0.35),0); sp.scale.set(Math.max(1.6,g.r*0.7),Math.max(1.6,g.r*0.7),1); sp.renderOrder=20; it.add(sp);
    grp.add(it); items.push({tor:tor,mat:mat,disc:disc,dmat:dmat,sp:sp,r:g.r});
  });
  S.worldGroup.add(grp); S.rings={grp:grp,items:items,last:-2};
};
R3D.ringFlash=function(idx,t0,fin){
  var R=S.rings; if(!R||!R.items[idx]) return; var it=R.items[idx], src=R.grp.children[idx];
  var col=fin?0xffe14a:0xffffff, g=new THREE.Group(); g.position.copy(src.position); g.rotation.copy(src.rotation);
  var tm=new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:1,depthWrite:false,depthTest:false,fog:false});
  var tor=new THREE.Mesh(new THREE.TorusGeometry(it.r,Math.max(0.2,it.r*0.1),8,48),tm); tor.renderOrder=15; g.add(tor);
  var dm=new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:0.7,side:THREE.DoubleSide,depthWrite:false,depthTest:false,fog:false});
  var dc=new THREE.Mesh(new THREE.CircleGeometry(it.r,36),dm); dc.renderOrder=14; g.add(dc);
  R.grp.add(g); (R.fl||(R.fl=[])).push({g:g,tor:tor,tm:tm,dc:dc,dm:dm,t0:t0,fin:!!fin});
};
R3D.updateRings=function(idx,done,tms){
  var R=S.rings; if(!R) return;
  if(R.fl){ R.fl=R.fl.filter(function(f){ var k=(tms-f.t0)/(f.fin?1100:700); if(k>=1){ R.grp.remove(f.g); f.tor.geometry.dispose(); f.dc.geometry.dispose(); f.tm.dispose(); f.dm.dispose(); return false; }
    var e=1-Math.pow(1-Math.max(0,k),2); f.tor.scale.set(1+1.6*e,1+1.6*e,1); f.tm.opacity=1-k; f.dc.scale.set(1+0.25*e,1+0.25*e,1); f.dm.opacity=0.7*(1-k)*(1-k); return true; }); }
  R.items.forEach(function(it,i){
    var passed=done||i<idx, nxt=!done&&i===idx;
    it.mat.color.setHex(passed?0x2ecc71:(nxt?0xffe14a:0xff7a1a));
    it.disc.visible=nxt; var p=nxt?1+0.06*Math.sin(tms/180):1; it.tor.scale.set(p,p,1); it.dmat.opacity=nxt?0.14+0.1*Math.sin(tms/180):0;
    it.sp.material.opacity=passed?0.45:1;
  });
};
R3D.setUptilt=function(d){S.uptilt=d;};
R3D.clearTrail=function(){ trailPts=[]; if(S.trail) S.trail.geometry.setDrawRange(0,0); };
R3D.worldRef=function(){return world;};
})();
