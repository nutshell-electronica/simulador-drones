/* ===== ESCENA 3D (three.js) ===== */
var R3D = {};
(function(){
var deg=Math.PI/180, clamp=SD.clamp;
var S={}, scn=null, world=null, drone=null, dyn=[], trailPts=[], trailT=0;

R3D.init=function(canvas){
  S.r=new THREE.WebGLRenderer({canvas:canvas,antialias:true,preserveDrawingBuffer:false,powerPreference:'high-performance'});
  S.r.setPixelRatio(GFX.pixelRatio());
  S.r.toneMapping=THREE.ACESFilmicToneMapping; S.r.toneMappingExposure=0.92;
  S.r.shadowMap.enabled=GFX.q.shadow>0; S.r.shadowMap.type=THREE.PCFSoftShadowMap;
  S.scene=new THREE.Scene();
  S.cam=new THREE.PerspectiveCamera(60,1,0.15,9000);
  S.hemi=new THREE.HemisphereLight(0xffffff,0x6b7a5a,0.9); S.scene.add(S.hemi);
  S.sun=new THREE.DirectionalLight(0xffffff,0.9); S.sun.position.set(-0.5,0.8,0.35); S.scene.add(S.sun); S.scene.add(S.sun.target);
  S.lightDir=new THREE.Vector3(-0.5,0.8,0.35).normalize(); S.shadowOn=false;
  /* cielo: degradado, sol, nubes procedurales y estrellas en un sombreador */
  S.skyU={uSun:{value:new THREE.Vector3(0,1,0)},uZen:{value:new THREE.Color(0x5f9fd6)},uHor:{value:new THREE.Color(0xd2e6f4)},uSunCol:{value:new THREE.Color(0xffffff)},uGround:{value:new THREE.Color(0x4a5140)},
    uCloudLit:{value:new THREE.Color(0xffffff)},uCloudDark:{value:new THREE.Color(0x8a94a0)},uOc:{value:0},uNightK:{value:0},uT:GFX.uTime,uCov:{value:0.3},uWind:{value:new THREE.Vector2(0.004,0.002)},uDisc:{value:1},uMoon:{value:new THREE.Vector3(0,-1,0)},uMoonE1:{value:new THREE.Vector3(1,0,0)},uMoonE2:{value:new THREE.Vector3(0,0,1)},uMoonK:{value:0},uMoonR:{value:0.02},uGal:{value:new THREE.Vector3(0,1,0)},uGC:{value:new THREE.Vector3(1,0,0)},uDark:{value:0},uMwK:{value:1}};
  S.sky=new THREE.Mesh(new THREE.SphereGeometry(5200,32,16),skyMat());
  S.sky.renderOrder=-10; S.sky.frustumCulled=false; S.scene.add(S.sky);
  S.sunSpr={visible:false,position:new THREE.Vector3(),material:{opacity:1}}; S.sunDir=new THREE.Vector3(0,1,0);
  S.fog=new THREE.FogExp2(0xcfe3f1,0.0002); S.scene.fog=S.fog;
  /* lluvia */
  var n=1400, pos=new Float32Array(n*6);
  var lg=new THREE.BufferGeometry(); lg.setAttribute('position',new THREE.BufferAttribute(pos,3));
  S.rain=new THREE.LineSegments(lg,new THREE.LineBasicMaterial({color:0x6d8aa5,transparent:true,opacity:0.5,fog:false}));
  S.rain.frustumCulled=false; S.rain.visible=false; S.scene.add(S.rain); S.rainN=n;
  for(var i=0;i<n;i++){ S.rain.userData[i]=[Math.random()*60-30,Math.random()*30,Math.random()*60-30]; }
  /* sombra */
  var sm=new THREE.Mesh(new THREE.CircleGeometry(1,20),new THREE.MeshBasicMaterial({color:0x000000,transparent:true,opacity:0.35,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-4,polygonOffsetUnits:-4}));
  sm.rotation.x=-Math.PI/2; S.shadow=sm; S.scene.add(sm);
  /* estela */
  var tg=new THREE.BufferGeometry(); tg.setAttribute('position',new THREE.BufferAttribute(new Float32Array(900*3),3)); tg.setDrawRange(0,0);
  S.trail=new THREE.Line(tg,new THREE.LineBasicMaterial({color:0xe2552d})); S.trail.frustumCulled=false; S.scene.add(S.trail);
  S.camMode='vlos'; S.chasePos=new THREE.Vector3(); S.uptilt=10;
  S.worldGroup=new THREE.Group(); S.scene.add(S.worldGroup);
  setupShadow(); R3D.resize();
};
function skyMat(){
  return new THREE.ShaderMaterial({uniforms:S.skyU,side:THREE.BackSide,depthWrite:false,fog:false,defines:{CL_OCT:GFX.q.clouds},
    vertexShader:'varying vec3 vDir; void main(){ vDir=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
    fragmentShader:['uniform vec3 uSun,uZen,uHor,uSunCol,uGround,uCloudLit,uCloudDark; uniform vec3 uMoon,uMoonE1,uMoonE2,uGal,uGC; uniform float uOc,uNightK,uT,uCov,uDisc,uMoonK,uMoonR,uDark,uMwK; uniform vec2 uWind; varying vec3 vDir;',
    'float h21(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }',
    'float stars(vec3 d,float N,float p,float rad){ float lat=asin(clamp(d.y,-1.0,1.0)); float lon=atan(d.z,d.x); float la0=floor(lat*N); float best=0.0;',
    ' for(int i=-1;i<=1;i++){ float la=la0+float(i); float latc=(la+0.5)/N; float cnt=max(1.0,floor(cos(clamp(latc,-1.5,1.5))*6.28318*N)); float u=(lon+3.14159)/6.28318*cnt; float lo0=floor(u);',
    '  for(int j=-1;j<=1;j++){ float lo=lo0+float(j); float loc=mod(lo,cnt); vec2 id=vec2(la,loc); float r1=h21(id); if(r1>p) continue; vec2 sp=vec2(0.1+0.8*h21(id+17.3),0.1+0.8*h21(id+41.7));',
    '   float dla=(lat*N-la-sp.x)/N; float dlo=((u-lo-sp.y)/cnt*6.28318)*cos(lat); best=max(best,smoothstep(rad,0.0,length(vec2(dla,dlo)))*(0.3+0.7*h21(id+5.5))); } }',
    ' return best; }',
    'float vn(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(h21(i),h21(i+vec2(1.0,0.0)),f.x),mix(h21(i+vec2(0.0,1.0)),h21(i+vec2(1.0,1.0)),f.x),f.y); }',
    '#if CL_OCT > 0',
    'float fbm(vec2 p){ float a=0.5,s=0.0; for(int i=0;i<CL_OCT;i++){ s+=a*vn(p); p=p*2.03+vec2(17.3,9.1); a*=0.5; } return s; }',
    '#endif',
    'void main(){ vec3 d=normalize(vDir); float h=max(d.y,0.0); vec3 col=mix(uHor,uZen,pow(h,0.5));',
    ' float sd=max(dot(d,uSun),0.0); float vis=1.0-uOc*0.85; float up=step(-0.03,uSun.y);',
    ' col+=uSunCol*(pow(sd,8.0)*0.10+pow(sd,48.0)*0.22+pow(sd,400.0)*0.7)*vis*up;',
    ' col+=uSunCol*smoothstep(0.99955,0.9998,sd)*30.0*vis*up*uDisc;',
    ' float st=stars(d,120.0,mix(0.005,0.016,uDark),0.0019)*uNightK*smoothstep(0.02,0.25,d.y); col+=vec3(st)*1.1*(1.0-uOc);',
    ' if(uDark>0.01&&uNightK>0.5){ float st2=stars(d,200.0,0.018,0.0012)*smoothstep(0.02,0.2,d.y); col+=vec3(0.8,0.85,1.0)*st2*0.8*uDark*(1.0-uOc)*(1.0-0.7*uMoonK); }',
    ' if(uDark>0.01&&uNightK>0.5){ float b=dot(d,uGal); vec3 ex=uGC; vec3 ey=cross(uGal,uGC); float lon=atan(dot(d,ey),dot(d,ex));',
    '  float band=exp(-pow(b/0.17,2.0)); float bulge=exp(-pow(lon/0.95,2.0))*exp(-pow(b/0.40,2.0));',
    '  float nz=vn(vec2(lon*5.0,b*16.0))*0.55+vn(vec2(lon*13.0,b*38.0))*0.3+vn(vec2(lon*31.0,b*90.0))*0.15;',
    '  float lane=exp(-pow((b-0.03*sin(lon*2.0))/0.035,2.0))*smoothstep(0.35,0.75,vn(vec2(lon*4.0+3.0,1.7)));',
    '  float lum=band*(0.35+0.9*nz)*(0.55+1.3*bulge)-lane*0.45*band; lum=max(lum,0.0);',
    '  vec3 mc=mix(vec3(0.50,0.58,0.82),vec3(1.0,0.84,0.62),clamp(bulge*1.3,0.0,1.0));',
    '  float fine=stars(d,260.0,0.35*band,0.0009)*1.0;',
    '  col+=(mc*lum*0.17+vec3(fine)*0.5)*uDark*(1.0-uOc)*smoothstep(0.0,0.18,d.y)*(1.0-0.85*uMoonK); }',
    ' if(uMoonK>0.001){ float md=dot(d,uMoon); if(md>0.97){ float x=dot(d,uMoonE1)/uMoonR, y=dot(d,uMoonE2)/uMoonR, rr=x*x+y*y;',
    '  float dayk=1.0-uNightK; float vv=uMoonK*(1.0-uOc*0.92);',
    '  if(rr<1.0){ float z=sqrt(1.0-rr); vec3 n=uMoonE1*x+uMoonE2*y-uMoon*z; float lit=smoothstep(-0.10,0.16,dot(n,uSun));',
    '   float tex=0.78+0.34*(vn(vec2(x,y)*6.0+4.0)-0.5)+0.55*(vn(vec2(x,y)*2.3+9.0)-0.5); tex=clamp(tex,0.35,1.15); float limb=0.62+0.38*z;',
    '   vec3 lc=vec3(0.96,0.93,0.85)*tex*limb*lit*1.15; vec3 ec=vec3(0.30,0.36,0.50)*tex*limb*0.13*uNightK*(1.0-lit);',
    '   float al=smoothstep(1.0,0.93,rr)*vv; col=mix(col,(lc+ec)*mix(1.7,1.0,dayk*0.5),clamp(al,0.0,1.0)); }',
    '  col+=vec3(0.55,0.62,0.85)*pow(md,mix(3000.0,700.0,uNightK))*0.35*uMoonK*uNightK*(1.0-uOc); } }',

    '#if CL_OCT > 0',
    ' if(d.y>0.01){ vec2 p=d.xz/(d.y+0.12)*1.5+uWind*uT; float n=fbm(p); float th=mix(0.60,0.27,uCov); float a=smoothstep(th,th+0.2,n);',
    '  float n2=fbm(p+uSun.xz*0.22); float sh=clamp(0.6+(n-n2)*3.2,0.0,1.0); vec3 cc=mix(uCloudDark,uCloudLit,sh)+uSunCol*pow(sd,10.0)*0.22*vis*up;',
    '  a*=smoothstep(0.01,0.16,d.y); col=mix(col,cc,a*0.94); }',
    '#endif',
    ' col=mix(col,uGround,smoothstep(0.0,-0.1,d.y));',
    ' gl_FragColor=vec4(col,1.0);',
    ' #include <tonemapping_fragment>',
    ' #include <colorspace_fragment>',
    '}'].join('\n')});
}
/* mapa de entorno (reflejos y luz ambiente) a partir del cielo */
function updateEnv(){
  if(!GFX.q.env){ S.scene.environment=null; if(S.envRT){ S.envRT.dispose(); S.envRT=null; } return; }
  if(!S.pm){ S.pm=new THREE.PMREMGenerator(S.r); S.envScene=new THREE.Scene(); S.envSky=new THREE.Mesh(new THREE.SphereGeometry(40,24,12),S.sky.material); S.envSky.frustumCulled=false; S.envScene.add(S.envSky); }
  S.envSky.material=S.sky.material; S.skyU.uDisc.value=0;
  var rt=S.pm.fromScene(S.envScene,0,1,100); S.skyU.uDisc.value=1;
  if(S.envRT) S.envRT.dispose(); S.envRT=rt; S.scene.environment=rt.texture;
}
/* sombras reales del sol: tamaño del mapa y volumen según el nivel */
function setupShadow(){
  var q=GFX.q, sh=S.sun.shadow; S.r.shadowMap.enabled=q.shadow>0;
  if(sh.map){ sh.map.dispose(); sh.map=null; }
  if(q.shadow){ sh.mapSize.set(q.shadow,q.shadow); var c=sh.camera; c.left=-q.shR; c.right=q.shR; c.top=q.shR; c.bottom=-q.shR; c.near=1; c.far=440; c.updateProjectionMatrix(); sh.bias=-0.00006; sh.normalBias=2*q.shR/q.shadow*1.2; }
}
/* cambia el nivel de calidad en caliente: reconstruye escenario y aeronave */
R3D.applyQuality=function(){
  S.r.setPixelRatio(GFX.pixelRatio()); R3D.resize(); setupShadow();
  var old=S.sky.material; S.sky.material=skyMat(); old.dispose(); GFX.flushTex(); GFX.flushModels();
  if(world){ var rg=S.ringsSrc, ac=drone&&drone.ac; R3D.loadWorld(world); if(ac) R3D.buildDrone(ac); if(rg) R3D.setRings(rg); }
  if(S.lastWx) R3D.setWeather(S.lastWx[0],S.lastWx[1],S.lastWx[2]);
};
R3D.resize=function(){
  var c=S.r.domElement.parentNode, w=c.clientWidth, h=c.clientHeight;
  S.r.setSize(w,h,false); S.cam.aspect=w/h; S.cam.updateProjectionMatrix(); FX3.setHeight(h);
};
R3D.camera=function(){return S.cam;};
R3D.sunInfo=function(){return {dir:S.sunDir,el:S.sunEl};};
R3D.setCamMode=function(m){S.camMode=m;};
R3D.getCamMode=function(){return S.camMode;};

function disposeGroup(g){
  g.traverse(function(o){ if(o.geometry)o.geometry.dispose(); if(o.material){ if(o.material.map)o.material.map.dispose(); o.material.dispose&&o.material.dispose(); } });
  while(g.children.length) g.remove(g.children[0]);
}
function canvasTex(w,h,fn,rep){ var c=document.createElement('canvas'); c.width=w; c.height=h; fn(c.getContext('2d'),w,h); var t=new THREE.CanvasTexture(c); if(rep){t.wrapS=t.wrapT=THREE.RepeatWrapping;} t.anisotropy=4; t.colorSpace=THREE.SRGBColorSpace; return t; }

/* material estándar (PBR) mate para el escenario */
function LM(o){ o=o||{}; if(o.roughness===undefined) o.roughness=0.88; o.metalness=o.metalness||0; if(o.envMapIntensity===undefined) o.envMapIntensity=0.3; return new THREE.MeshStandardMaterial(o); }
function groundKind(w){ return w.ground==='urban'?'urban':((w.id==='montana'||w.id==='fortaleza')?'rock':'grass'); }
function groundMat(w,o,kind,tile){ var m=LM(o); if(GFX.q.tex){ var t=GFX.ground(kind||groundKind(w)); m.map=t.map; m.normalMap=t.nrm; m.normalScale=new THREE.Vector2(0.9,0.9); m.userData.multi=true; GFX.posUV(m,1/(tile||9),false); } return m; }
var WM={};
function waterMat(hex,op){ var m=new THREE.MeshStandardMaterial({color:hex,roughness:0.1,metalness:0.02,transparent:op<1,opacity:op,envMapIntensity:1.25});
  if(GFX.q.tex){ m.normalMap=GFX.waterNormal(); m.normalScale=new THREE.Vector2(0.55,0.55); m.userData.dual=true; GFX.posUV(m,1/14,false,'0.021,0.013'); } return m; }
function lavaMat(hex){ var m=new THREE.MeshStandardMaterial({color:0x140400,roughness:0.9,emissive:GFX.q.tex?0xffffff:hex,emissiveIntensity:GFX.q.tex?1.7:1.2}); if(GFX.q.tex){ m.emissiveMap=GFX.lavaTex(); GFX.posUV(m,1/38,false,'0.004,0.0025'); } return m; }
function lin(v){ return v<=0.04045?v/12.92:Math.pow((v+0.055)/1.055,2.4); }
R3D.loadWorld=function(w){
  S.rings=null; world=w; disposeGroup(S.worldGroup); dyn=[]; trailPts=[]; FX3.clear(); S.crashFx=null; FX3.init(S.scene,function(x,y,z){ return w.floorH(x,y,z); });
  var G=S.worldGroup, EXT=SW.EXT;
  /* terreno */
  if(w.voxel){ var V=w.voxel, P=[],N3=[],C3=[],IX=[], rc=function(hx){ return [lin(((hx>>16)&255)/255),lin(((hx>>8)&255)/255),lin((hx&255)/255)]; };
    function quad(a,b,c,d,nx,ny,nz,col){ var o=P.length/3; [a,b,c,d].forEach(function(v){ P.push(v[0],v[1],v[2]); N3.push(nx,ny,nz); C3.push(col[0],col[1],col[2]); }); IX.push(o,o+1,o+2,o,o+2,o+3); }
    for(var vj=0;vj<V.n;vj++) for(var vi=0;vi<V.n;vi++){ var vk=vj*V.n+vi, vh=V.H[vk], col=rc(V.C[vk]), x0=-EXT+vi*V.cell, x1=x0+V.cell, z0=-EXT+vj*V.cell, z1=z0+V.cell;
      quad([x0,vh,z0],[x0,vh,z1],[x1,vh,z1],[x1,vh,z0],0,1,0,col);
      var nb=[[vi,vj-1,0,-1],[vi,vj+1,0,1],[vi-1,vj,-1,0],[vi+1,vj,1,0]];
      nb.forEach(function(q){ var hn=(q[0]<0||q[1]<0||q[0]>=V.n||q[1]>=V.n)?-8:V.H[q[1]*V.n+q[0]]; if(hn>=vh) return;
        if(q[3]===-1) quad([x0,hn,z0],[x0,vh,z0],[x1,vh,z0],[x1,hn,z0],0,0,-1,col);
        else if(q[3]===1) quad([x1,hn,z1],[x1,vh,z1],[x0,vh,z1],[x0,hn,z1],0,0,1,col);
        else if(q[2]===-1) quad([x0,hn,z1],[x0,vh,z1],[x0,vh,z0],[x0,hn,z0],-1,0,0,col);
        else quad([x1,hn,z0],[x1,vh,z0],[x1,vh,z1],[x1,hn,z1],1,0,0,col); }); }
    var vg=new THREE.BufferGeometry(); vg.setAttribute('position',new THREE.Float32BufferAttribute(P,3)); vg.setAttribute('normal',new THREE.Float32BufferAttribute(N3,3)); vg.setAttribute('color',new THREE.Float32BufferAttribute(C3,3)); vg.setIndex(IX);
    var vm=new THREE.Mesh(vg,LM({vertexColors:true})); vm.frustumCulled=false; vm.castShadow=true; vm.userData.keepCast=true; G.add(vm);
  } else {
  var flat=(w.id==='campo'||w.id==='aeropuerto'||w.id==='ciudad'||w.id==='barrio');
  var seg=flat?90:[190,250,320][GFX.q.seg];
  var geo=new THREE.PlaneGeometry(EXT*2,EXT*2,seg,seg); geo.rotateX(-Math.PI/2);
  var pa=geo.attributes.position, col=new Float32Array(pa.count*3);
  for(var i=0;i<pa.count;i++){
    var x=pa.getX(i), z=pa.getZ(i), h=w.land(x,z); pa.setY(i,h);
    var c=w.pal(x,z,h); c=[lin(c[0]),lin(c[1]),lin(c[2])]; col[i*3]=c[0]; col[i*3+1]=c[1]; col[i*3+2]=c[2];
  }
  geo.setAttribute('color',new THREE.BufferAttribute(col,3)); geo.computeVertexNormals();
  G.add(new THREE.Mesh(geo,groundMat(w,{vertexColors:true})));
  }
  WM={};
  if(w.shapes){ w.shapes.forEach(function(q,i){
    var g=q.ell?new THREE.CircleGeometry(1,48):new THREE.PlaneGeometry(1,1); g.rotateX(-Math.PI/2);
    var mk=(q.glow?'l':(q.water?'w':'s'))+q.hex, sm=WM[mk]; if(!sm){ sm=WM[mk]=q.glow?lavaMat(q.hex):(q.water?waterMat(q.hex,1):groundMat(w,{color:q.hex},'urban',6)); sm.polygonOffset=true; sm.polygonOffsetFactor=-1; sm.polygonOffsetUnits=-2; sm.depthWrite=false; }
    var m=new THREE.Mesh(g,sm);
    m.scale.set(q.ell?q.w/2:q.w,1,q.ell?q.d/2:q.d); m.rotation.y=q.rot; m.position.set(q.x,0.04,q.z); m.renderOrder=1+i; G.add(m); }); }
  if(w.sea){ var sg=new THREE.PlaneGeometry(EXT*2,EXT*2); sg.rotateX(-Math.PI/2);
    var sea=new THREE.Mesh(sg,waterMat(0x1d5f86,0.86)); sea.position.y=0.02; G.add(sea); }
  /* decales */
  if(w.showRunway){ var r=w.showRunway;
    var tex=canvasTex(64,512,function(c,W,H){ c.fillStyle='#4a4f55'; c.fillRect(0,0,W,H); c.fillStyle='#e9e9e9'; for(var y=10;y<H;y+=48) c.fillRect(W/2-2,y,4,26); c.fillRect(2,0,3,H); c.fillRect(W-5,0,3,H); });
    var m=new THREE.Mesh(new THREE.PlaneGeometry(r.wid,r.len),LM({map:tex}));
    m.rotation.x=-Math.PI/2; m.position.set(r.x,w.terrainH(r.x,r.z)+0.06,r.z); G.add(m); }
  if(w.id==='ciudad'){
    var a=new THREE.Mesh(new THREE.PlaneGeometry(1500,900),LM({color:0x3a3d42})); a.rotation.x=-Math.PI/2; a.position.set(0,0.03,-520); G.add(a);
    var pl=new THREE.Mesh(new THREE.CircleGeometry(w.plaza.r,36),LM({color:0xcfcabd})); pl.rotation.x=-Math.PI/2; pl.position.set(0,0.05,0); G.add(pl);
  }
  if(w.id==='barrio'){
    var a2=new THREE.Mesh(new THREE.PlaneGeometry(1300,1000),LM({color:0x3d4046})); a2.rotation.x=-Math.PI/2; a2.position.set(0,0.03,-300); G.add(a2);
    var pm=new THREE.InstancedMesh(new THREE.BoxGeometry(36,0.12,36),LM({color:0xffffff}),w.blocks.length), dm2=new THREE.Object3D(), c3=new THREE.Color();
    w.blocks.forEach(function(b,i){ dm2.position.set(b.x,0.08,b.z); dm2.updateMatrix(); pm.setMatrixAt(i,dm2.matrix); c3.setHex(((Math.abs(b.x)*7+Math.abs(b.z)*13)|0)%3===0?0x9fb08a:0xb9b4a5); pm.setColorAt(i,c3); });
    pm.instanceMatrix.needsUpdate=true; pm.instanceColor.needsUpdate=true; G.add(pm);
    var pl2=new THREE.Mesh(new THREE.CircleGeometry(w.plaza.r,36),LM({color:0xcfcabd})); pl2.rotation.x=-Math.PI/2; pl2.position.set(w.plaza.x,0.2,w.plaza.z); G.add(pl2);
  }
  /* pista de aterrizaje de césped en campo ya incluida; helipuerto / base */
  var hp=canvasTex(128,128,function(c,W,H){ c.fillStyle='#f5c842'; c.beginPath(); c.arc(64,64,62,0,6.3); c.fill(); c.fillStyle='#222'; c.font='bold 84px sans-serif'; c.textAlign='center'; c.textBaseline='middle'; c.fillText('H',64,70); });
  var pad=new THREE.Mesh(new THREE.CircleGeometry(1.4,32),LM({map:hp,transparent:true,roughness:0.8}));
  pad.rotation.x=-Math.PI/2; pad.position.set(w.home.x,w.homeY+0.075,w.home.z); pad.material.polygonOffset=true; pad.material.polygonOffsetFactor=-3; pad.material.polygonOffsetUnits=-3; pad.renderOrder=400; G.add(pad);
  if(w.floor){ var fl=new THREE.Mesh(new THREE.PlaneGeometry(w.floor.w,w.floor.d),LM({color:0x8e949a})); fl.rotation.x=-Math.PI/2; fl.position.set(w.floor.x,0.04,w.floor.z); G.add(fl);
    var ln=new THREE.MeshBasicMaterial({color:0xe8c52e}); [-3,3].forEach(function(o){ var l=new THREE.Mesh(new THREE.PlaneGeometry(0.2,50),ln); l.rotation.x=-Math.PI/2; l.position.set(o*3,0.06,w.floor.z-1); G.add(l); }); }
  if(w.decor){ var dm=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshBasicMaterial({color:0xffffff}),w.decor.length), dd=new THREE.Object3D(), dc=new THREE.Color();
    w.decor.forEach(function(q,i){ dd.position.set(q.x,q.y,q.z); dd.scale.set(q.sx,q.sy,q.sz); dd.updateMatrix(); dm.setMatrixAt(i,dd.matrix); dc.setHex(q.color); dm.setColorAt(i,dc); }); G.add(dm); }
  /* obstáculos instanciados */
  var boxes=[],cyls=[],trees=[],bWin=[],bMas=[],cMas=[], Q=GFX.q;
  var reWin=/edificio|casa|chalet|vivienda|bloque de pisos|hotel|terminal|oficina|torre de control/i, reMas=/torre[oó]n|muralla|castillo|Alcazaba|Catedral|faro|Farola|pared|chimenea|torre de la|refugio|Gibralfaro/i;
  w.obstacles.forEach(function(o){ var lb=o.label||''; if(o.custom) return;
    if(o.kind==='box'){ if(Q.facade&&!w.voxel&&o.h>=5&&reWin.test(lb)) bWin.push(o); else if(Q.facade&&!w.voxel&&reMas.test(lb)) bMas.push(o); else boxes.push(o); }
    else if(o.kind==='tree') trees.push(o); else { if(Q.facade&&reMas.test(lb)) cMas.push(o); else cyls.push(o); } });
  var dummy=new THREE.Object3D(), cc=new THREE.Color();
  function inst(geom,list,mat,fn){
    if(!list.length) return null;
    var im=new THREE.InstancedMesh(geom,mat,list.length);
    list.forEach(function(o,i){ fn(o,dummy,cc); dummy.updateMatrix(); im.setMatrixAt(i,dummy.matrix); im.setColorAt(i,cc); });
    im.instanceMatrix.needsUpdate=true; im.instanceColor.needsUpdate=true; im.castShadow=true; im.userData.keepCast=true; G.add(im); return im;
  }
  var bg=new THREE.BoxGeometry(1,1,1);
  function boxFn(o,d,c){ var bh=o.body||o.h; d.position.set(o.x,o.y0+bh/2,o.z); d.scale.set(o.dx,bh,o.dz); d.rotation.set(0,0,0); c.setHex(o.color); }
  function cylFn(o,d,c){ var bh=o.body||o.h; d.position.set(o.x,o.y0+bh/2,o.z); d.scale.set(o.dx,bh,o.dx); d.rotation.set(0,0,0); c.setHex(o.color); }
  inst(bg,boxes,LM(),boxFn);
  inst(bg.clone(),bWin,GFX.facade(LM({roughness:0.82}),1),boxFn);
  inst(bg.clone(),bMas,GFX.facade(LM({roughness:0.95}),2),boxFn);
  inst(new THREE.CylinderGeometry(1,1,1,Q.geo>=2?24:14),cyls,LM({roughness:0.7}),cylFn);
  inst(new THREE.CylinderGeometry(1,1,1,Q.geo>=2?28:16),cMas,GFX.facade(LM({roughness:0.95}),2),cylFn);
  function th(o){ var v=Math.abs(Math.sin(o.x*12.9898+o.z*78.233)*43758.5453); return v-Math.floor(v); }
  if(Q.geo<1){
    inst(new THREE.ConeGeometry(1,1,8),trees,LM(),function(o,d,c){ d.position.set(o.x,o.y0+o.h*0.28+o.h*0.36,o.z); d.scale.set(o.dx*1.1,o.h*0.72,o.dx*1.1); d.rotation.set(0,0,0); c.setHex(o.color); });
    inst(new THREE.CylinderGeometry(1,1,1,6),trees,LM(),function(o,d,c){ d.position.set(o.x,o.y0+o.h*0.14,o.z); d.scale.set(0.3,o.h*0.28,0.3); d.rotation.set(0,0,0); c.setHex(0x5b4330); });
  } else if(trees.length){
    var conif=(w.id==='bosque'||w.id==='montana'), tcn=[], tbl=[], sg=Q.geo>=2?11:8;
    trees.forEach(function(o){ var h=th(o); ((conif?h<0.82:h<0.12)?tcn:tbl).push(o); });
    var gC=GFX.merge([new THREE.ConeGeometry(1,0.52,sg).translate(0,0.26,0),new THREE.ConeGeometry(0.78,0.46,sg).translate(0,0.55,0),new THREE.ConeGeometry(0.52,0.42,sg).translate(0,0.8,0)]);
    var det=Q.geo>=2?2:1, gB=GFX.merge([new THREE.IcosahedronGeometry(0.5,det).scale(1,0.86,1).translate(0,0.5,0),new THREE.IcosahedronGeometry(0.36,det).translate(0.31,0.4,0.1),new THREE.IcosahedronGeometry(0.34,det).translate(-0.27,0.47,-0.2),new THREE.IcosahedronGeometry(0.3,det).translate(0.03,0.76,0.06),new THREE.IcosahedronGeometry(0.28,det).translate(-0.05,0.36,0.3)]);
    var pb=gB.attributes.position; for(var bi=0;bi<pb.count;bi++){ var bx=pb.getX(bi), by=pb.getY(bi), bz=pb.getZ(bi), k=1+0.1*Math.sin(bx*23.1+by*17.7+bz*29.3); pb.setXYZ(bi,bx*k,by,bz*k); }
    function leafCol(o,c,h){ c.setHex(o.color); c.offsetHSL((h-0.5)*0.03,(h-0.5)*0.12,(h-0.5)*0.1); }
    inst(gC,tcn,LM({roughness:1}),function(o,d,c){ var h=th(o), r=o.dx*1.15*(0.85+0.3*h); d.position.set(o.x,o.y0+o.h*0.22,o.z); d.scale.set(r,o.h*0.78,r); d.rotation.set(0,h*6.28,0); leafCol(o,c,h); });
    inst(gB,tbl,LM({roughness:1}),function(o,d,c){ var h=th(o), r=o.dx*1.75*(0.85+0.3*h); d.position.set(o.x,o.y0+o.h*0.3,o.z); d.scale.set(r,o.h*0.74,r); d.rotation.set(0,h*6.28,0); leafCol(o,c,h); });
    inst(new THREE.CylinderGeometry(0.6,1,1,7),trees,LM({roughness:1}),function(o,d,c){ var h=th(o), r=0.16+o.dx*0.06; d.position.set(o.x,o.y0+o.h*0.2,o.z); d.scale.set(r,o.h*0.4,r); d.rotation.set(0,0,0); c.setHex(0x5b4330); c.offsetHSL(0,0,(h-0.5)*0.08); });
  }
  /* detalles: torres con bandas, aerogeneradores, buque */
  w.obstacles.forEach(function(o){
    if(o.cone){ var cn=new THREE.Mesh(new THREE.ConeGeometry(1,1,o.kind==='box'?4:14),LM({color:o.cone.color})); var cr=o.kind==='box'?o.dx*0.78:o.dx*1.25; cn.scale.set(cr,o.cone.h,cr); if(o.kind==='box') cn.rotation.y=Math.PI/4; cn.position.set(o.x,o.y0+o.body+o.cone.h/2,o.z); G.add(cn); }
    if(o.mast){ var band=new THREE.Mesh(new THREE.CylinderGeometry(o.dx*1.08,o.dx*1.08,o.h*0.12,10),LM({color:0xf2f2f2})); band.position.set(o.x,o.y0+o.h*0.9,o.z); G.add(band); }
    if(o.turbine){ var gr=new THREE.Group(); gr.position.set(o.x,o.y0+o.h,o.z); var nac=new THREE.Mesh(new THREE.BoxGeometry(3,3,8),LM({color:0xdfe4e8})); gr.add(nac);
      var rot=new THREE.Group(); rot.position.set(0,0,-4.5); for(var k=0;k<3;k++){ var bl=new THREE.Mesh(new THREE.BoxGeometry(1.2,38,0.4),LM({color:0xf4f6f7})); bl.position.y=19; var pv=new THREE.Group(); pv.rotation.z=k*2.094; pv.add(bl); rot.add(pv);} gr.add(rot); gr.rotation.y=(w.wxDirRad||0); G.add(gr); dyn.push({rot:rot,turbine:true,grp:gr}); }
    if(o.ship){ var br=new THREE.Mesh(new THREE.BoxGeometry(14,14,16),LM({color:0xf0f0f0})); br.position.set(o.x+o.dx/2-14,o.y0+o.h+7,o.z); G.add(br); var st=new THREE.Mesh(new THREE.CylinderGeometry(2,2,10,10),LM({color:0xc2382e})); st.position.set(o.x+o.dx/2-14,o.y0+o.h+19,o.z); G.add(st); }
    if(o.lighthouse){ var top=new THREE.Mesh(new THREE.CylinderGeometry(o.dx*0.9,o.dx*0.9,5,12),LM({color:0xc2382e})); top.position.set(o.x,o.y0+o.h+2.5,o.z); G.add(top); }
  });
  /* zonas normativas */
  w.zones.forEach(function(z){
    var hgt=z.type==='restricted'?500:(z.type==='crowd'?130:130);
    var cm=new THREE.Mesh(new THREE.CylinderGeometry(z.r,z.r,hgt,48,1,true),new THREE.MeshBasicMaterial({color:z.color,transparent:true,opacity:z.type==='restricted'?0.07:0.10,side:THREE.DoubleSide,depthWrite:false,fog:false}));
    cm.position.set(z.x,hgt/2,z.z); G.add(cm);
    var ring=new THREE.Mesh(new THREE.RingGeometry(z.r-1.2,z.r,64),new THREE.MeshBasicMaterial({color:z.color,side:THREE.DoubleSide,transparent:true,opacity:0.7,depthWrite:false,fog:false}));
    ring.rotation.x=-Math.PI/2; ring.position.set(z.x,w.terrainH(z.x+z.r,z.z)+0.2,z.z); if(z.r<400) ring.position.y=w.terrainH(z.x,z.z)+0.2; G.add(ring);
  });
  /* tráfico tripulado */
  if(w.traffic){
    var tp=new THREE.Group();
    var fu=new THREE.Mesh(new THREE.CylinderGeometry(0.9,0.5,8,10),LM({color:0xf2f2f2})); fu.rotation.z=Math.PI/2; tp.add(fu);
    var wg=new THREE.Mesh(new THREE.BoxGeometry(1.6,0.2,11),LM({color:0xcc3333})); tp.add(wg);
    var tl=new THREE.Mesh(new THREE.BoxGeometry(1,1.8,0.2),LM({color:0xcc3333})); tl.position.set(-3.6,0.9,0); tp.add(tl);
    G.add(tp); dyn.push({traffic:true,grp:tp});
  }
  S.shadow.visible=true;
  buildActors(G,w);
  /* sombras: todo recibe; proyectan los volúmenes (no los planos del suelo) */
  G.traverse(function(o){ if(!o.isMesh||!o.material||!o.material.isMeshStandardMaterial) return; o.receiveShadow=true; var t=o.geometry.type; if(o.userData.keepCast||!(t==='PlaneGeometry'||t==='CircleGeometry'||t==='RingGeometry'||t==='ShapeGeometry')) o.castShadow=true; });
};

/* ---------- aves, cometas y personas (modelos en 47_actors3d.js) ---------- */
function buildActors(G,w){
  S.act={birds:[],kites:[],people:null,oper:null,cars:[],beacons:[]}; var A=w.actors||{birds:[],kites:[],people:[],lines:[],wires:[],towers:[],cars:[]};
  /* infraestructura: torres de celosía y de telefonía en un solo lote por material */
  if((A.lines&&A.lines.length)||(A.towers&&A.towers.length)){
    var IB=new GFX.Batch(), IM=ACT3.infraMats();
    A.lines.forEach(function(l){ l.pylons.forEach(function(p){ ACT3.pylon(IB,p); }); });
    A.towers.forEach(function(tw){ var bz=ACT3.cellTower(IB,tw); G.add(bz); S.act.beacons.push(bz); });
    IB.build(G,IM);
    if(A.wires.length) G.add(ACT3.wires(A.wires));
  }
  (A.cars||[]).forEach(function(c){ var v=ACT3.vehicle(c.kind,c.col); G.add(v.g); S.act.cars.push({v:v,c:c}); });
  var np=A.people.length+A.kites.length+2, P=ACT3.People(G,np); S.act.people=P;
  A.birds.forEach(function(b){ var gl=ACT3.gull(); gl.g.scale.setScalar(1.8); G.add(gl.g); S.act.birds.push({w:gl,b:b,amp:0.6+Math.random()*0.4,ph:Math.random()*6.28,soar:Math.random()*6.28}); });
  A.kites.forEach(function(k){
    var kt=ACT3.kite(k.col); G.add(kt.g);
    var tg=new THREE.BufferGeometry(); tg.setAttribute('position',new THREE.BufferAttribute(new Float32Array(6),3));
    var line=new THREE.Line(tg,new THREE.LineBasicMaterial({color:0x2b2b2b})); line.frustumCulled=false; G.add(line);
    var hi=P.add({x:k.ax,y:k.ay,z:k.az,hd:k.wTo,pose:'hold'});
    S.act.kites.push({kt:kt,line:line,k:k,holder:P.list[hi],ph:Math.random()*6.28});
  });
  A.people.forEach(function(p){ var i=P.add({x:p.x,y:p.y,z:p.z,hd:p.hd,pose:p.kind==='walk'?'walk':(p.kind==='crowd'?'crowd':'stand')}); p._i=i; });
  /* operador junto a la zona de despegue, con la emisora en las manos */
  var hx=w.home.x, hz=w.home.z, hh=(w.startHeading||0)*deg, best=null;
  [[hh-Math.PI/2,2.3],[hh+Math.PI/2,2.3],[hh-Math.PI/2,1.3],[hh+Math.PI/2,1.3],[hh+Math.PI,2.6],[hh+Math.PI,1.4]].forEach(function(c){ if(best) return;
    var x=hx+Math.sin(c[0])*c[1], z=hz-Math.cos(c[0])*c[1], fy=w.floorH(x,1e9,z);
    if(Math.abs(fy-w.homeY)<0.3 && !(w.isWater&&w.isWater(x,z)) && !w.collide(x,fy+0.9,z,0.3)) best={x:x,y:fy,z:z}; });
  if(!best) best={x:hx+Math.sin(hh-Math.PI/2)*2.3,y:w.homeY,z:hz-Math.cos(hh-Math.PI/2)*2.3};
  var oi=P.add({x:best.x,y:best.y,z:best.z,hd:hh,pose:'tx',sc:1.0,shirt:0x2e6fb7});
  var tx=ACT3.transmitter(), gg=ACT3.goggles(); gg.visible=false; G.add(tx); G.add(gg);
  S.act.oper={per:P.list[oi],tx:tx,gg:gg};
}
function updateActors(T,dp){
  if(!S.act) return; var P=S.act.people;
  S.act.cars.forEach(function(o){ var c=o.c; o.v.g.position.set(c.x,c.y,c.z); o.v.g.rotation.y=-c.hd; var wl=o.v.wheels; for(var i=0;i<wl.length;i++){ wl[i].rotation.x=-c.dist/0.4; } });
  if(S.act.beacons.length){ var on=(T%1.2)<0.25||(GFX.uNight&&GFX.uNight.value>0.3&&(T%1.2)<0.5); S.act.beacons.forEach(function(b){ b.visible=on; }); }
  S.act.birds.forEach(function(o){ var b=o.b; o.w.g.position.set(b.x,b.y,b.z); o.w.g.rotation.y=-b.hd;
    var soar=0.5+0.5*Math.sin(T*0.23+o.soar); var amp=soar>0.72?0.08:o.amp;            /* planea a ratos */
    ACT3.gullFlap(o.w,T*11+o.ph,amp,-0.28*b.fl.dir); });
  S.act.kites.forEach(function(o){ var k=o.k; o.kt.g.position.set(k.x,k.y,k.z); o.kt.g.lookAt(k.ax,k.ay+1.7,k.az); o.kt.g.rotateZ(k.bank); ACT3.kiteAnim(o.kt,T,o.ph);
    var h=o.holder; h.hd=Math.atan2(k.x-h.x,-(k.z-h.z)); var hp=P.handPos(h,0.25,1.75,0.21);
    var a=o.line.geometry.attributes.position.array; a[0]=hp.x; a[1]=hp.y; a[2]=hp.z; a[3]=k.x; a[4]=k.y-0.3; a[5]=k.z; o.line.geometry.attributes.position.needsUpdate=true; });
  if(world&&world.actors) world.actors.people.forEach(function(p){ var per=P.list[p._i]; if(!per) return; per.x=p.x; per.y=p.y; per.z=p.z; per.hd=p.hd; });
  var op=S.act.oper; if(op&&dp){ var per=op.per; var dx=dp.x-per.x, dz=dp.z-per.z; if(dx*dx+dz*dz>0.4) per.hd=Math.atan2(dx,-dz);
    var hp=P.handPos(per,0.52,1.17,0); op.tx.position.set(hp.x,hp.y,hp.z); op.tx.rotation.set(-0.5,-per.hd,0,'YXZ');
    var fpv=S.camMode==='fpv'; op.gg.visible=fpv; if(fpv){ var gp=P.handPos(per,0.07,1.61,0); op.gg.position.set(gp.x,gp.y,gp.z); op.gg.rotation.set(0,-per.hd,0); } }
  P.update(T);
}

/* Meteo y hora del día */
function mixc(a,b,t){ return new THREE.Color(a).lerp(new THREE.Color(b),t); }
R3D.setWeather=function(wx,tod,sun){
  var oc=clamp(wx.rain/10+(wx.vis<6?0.5:0)+(wx.turb>0.9?0.3:0),0,1);
  var hz,zn,hI,sI,sc,gc;
  if(tod==='noche'){ hz=new THREE.Color(0x1d2b42); zn=new THREE.Color(0x050914); hI=0.30; sI=0.18; sc=0x9db5e8; gc=0x1a2236; }
  else if(tod==='atardecer'){ hz=new THREE.Color(0xf4b07a); zn=new THREE.Color(0x4d6a9f); hI=0.55; sI=0.75; sc=0xffc890; gc=0x7a6a58; }
  else { hz=new THREE.Color(0xd2e6f4); zn=new THREE.Color(0x5f9fd6); hI=0.95; sI=0.85; sc=0xffffff; gc=0x7b8a63; }
  var gray=tod==='noche'?0x20262e:0xa9b2ba;
  hz.lerp(new THREE.Color(gray),oc*0.75); zn.lerp(new THREE.Color(gray),oc*0.6);
  var SUNK=3.2, HEMK=GFX.q.env?0.4:1.0;
  S.hemi.color.setHex(0xffffff); S.hemi.groundColor.setHex(gc); S.hemi.intensity=hI*(1-0.3*oc)*HEMK; S.sun.color.setHex(sc);
  var sel=sun?sun.el:(tod==='noche'?-30:(tod==='atardecer'?3:55)), saz=sun?sun.az:250;
  var se=Math.max(sel,0)*deg, sdx=Math.sin(saz*deg)*Math.cos(sel*deg), sdy=Math.sin(sel*deg), sdz=-Math.cos(saz*deg)*Math.cos(sel*deg);
  S.sunDir.set(sdx,sdy,sdz); S.sunEl=sel;
  if(sel>-2){ S.lightDir.set(sdx,Math.max(sdy,0.04),sdz).normalize(); if(tod==='dia'){ sI=0.55+0.4*clamp(sel/45,0,1); S.sun.color.setHex(sel<22?0xfff0d8:0xffffff); } }
  else S.lightDir.set(-0.3,0.8,0.4).normalize();
  S.sun.intensity=sI*(1-0.6*oc)*SUNK;
  S.shadowOn=GFX.q.shadow>0&&sel>3&&oc<0.8&&!(world&&world.indoor); if(world&&world.indoor){ S.hemi.intensity*=1.6; } if(S.sun.castShadow!==S.shadowOn){ S.sun.castShadow=S.shadowOn; }
  if(wx.vis<1) hz.lerp(new THREE.Color(tod==='noche'?0x1a2028:0xdfe3e6),0.9);
  var U=S.skyU, nt=tod==='noche', at=tod==='atardecer';
  var dk=(world&&['campo','bosque','montana','costa'].indexOf(world.id)>=0&&!world.indoor)?1:0;
  if(nt&&dk){ hz.setHex(0x0a1322); zn.setHex(0x02040a); hz.lerp(new THREE.Color(0x20262e),oc*0.7); S.hemi.intensity*=0.8; }
  var tms=(world&&world.timeMs0)||Date.now(), lat=(typeof ST!=='undefined'&&ST.lat!=null)?ST.lat:36.77, lon=(typeof ST!=='undefined'&&ST.lon!=null)?ST.lon:-4.39;
  var mp=SM.moonPos(tms,lat,lon), mv=new THREE.Vector3(mp.x,mp.y,mp.z).normalize(), upv=new THREE.Vector3(0,1,0);
  var e1=new THREE.Vector3().crossVectors(mv,upv); if(e1.lengthSq()<1e-6) e1.set(1,0,0); e1.normalize(); var e2=new THREE.Vector3().crossVectors(e1,mv).normalize();
  var illum=(1-mv.dot(S.sunDir))/2*0+0.5*(1+(-mv.dot(S.sunDir))); /* fracción iluminada: 1 = llena */
  U.uMoon.value.copy(mv); U.uMoonE1.value.copy(e1); U.uMoonE2.value.copy(e2);
  var mk=clamp((mp.el+2)/6,0,1); U.uMoonK.value=mk; S.moonEl=mp.el; S.moonIllum=illum;
  var gv=SM.galVecs(tms,lat,lon); U.uGal.value.set(gv.pole.x,gv.pole.y,gv.pole.z).normalize(); U.uGC.value.set(gv.gc.x,gv.gc.y,gv.gc.z).normalize();
  U.uDark.value=(nt&&dk)?1:0;
  if(nt){ S.hemi.intensity+=0.10*mk*illum*HEMK; }
  U.uSun.value.copy(S.sunDir); U.uZen.value.copy(zn); U.uHor.value.copy(hz); U.uSunCol.value.setHex(nt?0x000000:(at?0xffb070:(sel<22?0xffe8c8:0xfff6e8))); U.uOc.value=oc; U.uNightK.value=nt?1:0;
  U.uCov.value=clamp(0.3+oc*0.8,0,1); var wd=(wx.dir||0)*deg, wk=0.0025+(wx.speed||wx.wind||0)*0.0007; U.uWind.value.set(Math.sin(wd)*wk,-Math.cos(wd)*wk);
  U.uGround.value.setHex(gc).multiplyScalar(nt?0.5:0.8);
  if(nt){ U.uCloudLit.value.setRGB(0.05,0.06,0.09); U.uCloudDark.value.setRGB(0.015,0.02,0.035); }
  else if(at){ U.uCloudLit.value.setRGB(1.0,0.72,0.5); U.uCloudDark.value.setRGB(0.32,0.27,0.33); }
  else { U.uCloudLit.value.setRGB(1,1,1).multiplyScalar(1-0.4*oc); U.uCloudDark.value.setRGB(0.5,0.56,0.64).lerp(new THREE.Color(0.25,0.27,0.3),oc); }
  GFX.uNight.value=nt?1:(at?0.25:0); S.lastWx=[wx,tod,sun];
  S.fog.color.copy(hz); S.fog.density=3.912/(Math.max(wx.vis,0.1)*1000);
  S.r.setClearColor(hz);
  S.rain.visible=wx.rain>0.2; S.rain.material.opacity=0.25+Math.min(0.4,wx.rain/40);
  S.rainAmt=clamp(wx.rain/12,0.12,1); S.wxDir=wx.dir; S.tod=tod;
  S.nightMode=(tod==='noche');
  updateEnv();
};

/* ---------- modelo del dron ---------- */
function mat(c,e){ return LM({color:c,emissive:e||0x000000}); }
function wingGeom(b,rc,tc,sw,th){
  var sh=new THREE.Shape(); var h=b/2;
  sh.moveTo(-h,sw-tc/2); sh.lineTo(0,-rc/2); sh.lineTo(h,sw-tc/2); sh.lineTo(h,sw+tc/2); sh.lineTo(0,rc/2); sh.lineTo(-h,sw+tc/2); sh.closePath();
  var g=new THREE.ExtrudeGeometry(sh,{depth:th,bevelEnabled:false}); g.rotateX(Math.PI/2); g.translate(0,th/2,0); return g;
}
R3D.buildDrone=function(ac){
  if(drone){ S.scene.remove(drone.root); disposeGroup(drone.root); }
  var root=new THREE.Group(), body=new THREE.Group(); root.add(body);
  var dim=ac.frame.dim, vk=clamp(0.5/dim,1,3.2);   /* los modelos pequeños se dibujan más grandes (sólo visual) */
  var mdl=GFX.buildModel(ac,body,vk);
  root.scale.setScalar(vk); S.scene.add(root);
  var lift=(ac.kind==='tailsitter'?0:mdl.gear*vk)+0.06;   /* +6 cm: apoya sobre la plataforma de despegue */
  S.shadow.scale.setScalar(Math.max(0.3,dim*vk*0.45));
  if(!S.beacon){ var bt=canvasTex(128,128,function(c){ c.clearRect(0,0,128,128); c.lineWidth=9; c.strokeStyle='rgba(255,122,26,0.95)'; c.beginPath(); c.arc(64,64,52,0,6.3); c.stroke(); c.lineWidth=4; c.strokeStyle='rgba(255,255,255,0.95)'; c.beginPath(); c.arc(64,64,40,0,6.3); c.stroke(); c.fillStyle='rgba(255,225,74,0.95)'; c.beginPath(); c.arc(64,64,7,0,6.3); c.fill(); });
    S.beacon=new THREE.Sprite(new THREE.SpriteMaterial({map:bt,transparent:true,depthTest:false,depthWrite:false,fog:false,toneMapped:false})); S.beacon.renderOrder=20; S.beacon.visible=false; S.scene.add(S.beacon); }
  drone={root:root,body:body,props:mdl.props,spin:mdl.spin,strobe:mdl.strobe,dim:dim,vk:vk,lift:lift,ac:ac,legL:mdl.legL};
};
R3D._dbg=function(){ return {S:S,drone:drone,world:world}; };

R3D.project=function(v3){ var v=v3.clone().project(S.cam); var c=S.r.domElement; return {x:(v.x*0.5+0.5)*c.clientWidth,y:(-v.y*0.5+0.5)*c.clientHeight,z:v.z}; };
R3D.dronePos=function(){ return drone?drone.root.position.clone():new THREE.Vector3(); };

/* incendio al caer a la lava */
var FIRE=null, FN=70;
function fireUpdate(on,p,dt,size){
  if(!FIRE){ if(!on) return;
    var g=new THREE.BufferGeometry(), pos=new Float32Array(FN*3), col=new Float32Array(FN*3), age=new Float32Array(FN);
    for(var i=0;i<FN;i++) age[i]=Math.random();
    g.setAttribute('position',new THREE.BufferAttribute(pos,3)); g.setAttribute('color',new THREE.BufferAttribute(col,3));
    var pts=new THREE.Points(g,new THREE.PointsMaterial({size:Math.max(1.3,size*1.1),map:canvasTex(32,32,function(c,W,H){ var gr=c.createRadialGradient(16,16,0,16,16,16); gr.addColorStop(0,'rgba(255,255,255,1)'); gr.addColorStop(1,'rgba(255,255,255,0)'); c.fillStyle=gr; c.fillRect(0,0,W,H); }),vertexColors:true,transparent:true,opacity:0.55,depthWrite:false,blending:THREE.AdditiveBlending,fog:false}));
    pts.frustumCulled=false; var lt=new THREE.PointLight(0xff7a22,2,60); S.scene.add(pts); S.scene.add(lt); FIRE={pts:pts,age:age,lt:lt,g:g,t:0}; }
  FIRE.pts.visible=on; FIRE.lt.visible=on; if(!on) return;
  FIRE.t+=dt; var pa=FIRE.g.attributes.position, ca=FIRE.g.attributes.color, sp=Math.max(0.8,size*0.6);
  for(var i=0;i<FN;i++){ var a=FIRE.age[i]+dt*0.9; if(a>=1){ a=0; pa.setXYZ(i,p.x+(Math.random()-0.5)*sp,p.y+Math.random()*0.3,p.z+(Math.random()-0.5)*sp); }
    else pa.setXYZ(i,pa.getX(i)+(Math.random()-0.5)*dt*1.2,pa.getY(i)+dt*(2.2+3*Math.random()),pa.getZ(i)+(Math.random()-0.5)*dt*1.2);
    FIRE.age[i]=a; var k=1-a; ca.setXYZ(i,0.35+0.65*k,k*k*0.55,0.02); }
  pa.needsUpdate=true; ca.needsUpdate=true; FIRE.lt.position.set(p.x,p.y+2,p.z); FIRE.lt.intensity=1.6+Math.random()*1.2;
}
/* actualización por fotograma */
var _v=new THREE.Vector3(), _q=new THREE.Euler();
/* ---------- paracaídas: campana naranja/blanca con líneas, se despliega al abrirse y se desinfla al tocar suelo ---------- */
function chuteBuild(){
  var R=Math.max(0.55,drone.dim*drone.vk*1.15), L=R*2.3, g=new THREE.Group(), N=12;
  var sph=new THREE.SphereGeometry(R,N*2,8,0,Math.PI*2,0,Math.PI/2*0.96), pos=sph.attributes.position, col=new Float32Array(pos.count*3), c1=new THREE.Color(0xe8671b), c2=new THREE.Color(0xf4f1ea);
  for(var i=0;i<pos.count;i++){ var an=Math.atan2(pos.getZ(i),pos.getX(i)); var sec=Math.floor(((an+Math.PI)/(Math.PI*2))*N)%2; var c=sec?c1:c2; col[i*3]=c.r; col[i*3+1]=c.g; col[i*3+2]=c.b; }
  sph.setAttribute('color',new THREE.BufferAttribute(col,3)); sph.scale(1,0.62,1);
  var can=new THREE.Mesh(sph,new THREE.MeshStandardMaterial({vertexColors:true,roughness:0.85,metalness:0,side:THREE.DoubleSide})); can.position.y=L; can.castShadow=true; g.add(can);
  var lp=[]; for(var k=0;k<8;k++){ var a=k/8*Math.PI*2; lp.push(Math.cos(a)*R*0.96,L+0.05*R,Math.sin(a)*R*0.96, 0,0.02,0); }
  var ln=new THREE.LineSegments(new THREE.BufferGeometry().setAttribute('position',new THREE.Float32BufferAttribute(lp,3)),new THREE.LineBasicMaterial({color:0xdfe6ea})); g.add(ln);
  g.userData={d:drone,R:R,L:L}; g.visible=false; S.scene.add(g); return g;
}
function chuteUpdate(f,p,dt,T){
  if(S.chute&&S.chute.userData.d!==drone){ S.scene.remove(S.chute); S.chute=null; }
  if(!f.chuteOpen){ if(S.chute){ S.chute.visible=false; } S.chT=0; S.chCol=0; return; }
  if(!S.chute) S.chute=chuteBuild();
  var g=S.chute; S.chT=(S.chT||0)+dt;
  var gh=world.floorH(p.x,p.y,p.z), low=(p.y-gh)<0.5||f.status==='ground'||f.status==='landed';
  S.chCol=low?(S.chCol||0)+dt:0;
  var op=Math.min(1,S.chT/0.9), e=op*op*(3-2*op), cl=Math.min(1,S.chCol/1.6);
  var sw=Math.sin(T*1.7)*0.07*(1-cl), sw2=Math.sin(T*1.3+1)*0.05*(1-cl);
  g.visible=true; g.position.set(p.x,p.y+drone.lift,p.z);
  g.rotation.set(sw2,0,sw);
  g.scale.set(Math.max(0.05,e*(1+0.35*cl)),Math.max(0.04,e*(1-0.9*cl)),Math.max(0.05,e*(1+0.35*cl)));
}
R3D.update=function(f,dt,opts){
  if(!drone||!world) return;
  var p=f.pos, ac=f.ac, T=f.t;
  drone.root.position.set(p.x,p.y+drone.lift,p.z);
  drone.root.visible=(S.camMode!=='fpv')||f.status==='crashed';
  fireUpdate(f.status==='crashed'&&!!world.lava&&/lava/.test(f.crashMsg||''),p,dt,drone.dim);
  drone.root.rotation.set(-f.pitch,-f.yaw,-f.roll,'YXZ');
  /* siniestro: salpicadura y hundimiento (agua/lava) o explosión (impacto violento) */
  if(f.status==='crashed'){
    if(!S.crashFx){ S.crashFx={kind:f.crashKind||'hit',t:0,y:p.y}; var wy=(world.waterY!==undefined&&world.waterY!==null)?world.waterY:p.y;
      if(S.crashFx.kind==='water'){ S.crashFx.y=Math.min(p.y,wy); FX3.splash(p,drone.dim*drone.vk,S.crashFx.y); }
      else if(S.crashFx.kind==='explode'){ FX3.explode(p,drone.dim*drone.vk,[0x23262b,0x5a5e66,0x9aa0a6,0xc0392b]); drone.root.visible=false; S.shadow.visible=false; } }
    var cf=S.crashFx; cf.t+=dt;
    if(cf.kind==='water'||cf.kind==='lava'){ var sk=FX3.sink(cf.t,cf.kind==='lava'?0.12:0.45); drone.root.position.y=cf.y+drone.lift+sk; drone.root.rotation.x+=Math.min(0.9,cf.t*0.25); drone.root.rotation.z+=Math.min(0.5,cf.t*0.12); drone.root.visible=sk>-2.1; }
  } else if(S.crashFx){ S.crashFx=null; FX3.clear(); drone.root.visible=true; }
  FX3.update(dt);
  chuteUpdate(f,p,dt,T);
  if(ac.kind==='tailsitter'){ var ex=f.tsFw?0:Math.PI/2; drone.body.rotation.x=ex; var el=ex-f.pitch; drone.body.position.y=drone.legL*Math.max(0,Math.sin(el)); }
  /* hélices */
  var vis=(f.status==='flying'||f.status==='rolling'||f.status==='ground'&&f.Tcur>1)&&f.status!=='crashed';
  var run=(f.P>0 && (f.status==='flying'||f.status==='rolling'||f.Tcur>0.5))?1:0;
  var kT=run?clamp(0.42+0.58*(f.thrPct/100),0,1):0;
  drone.props.forEach(function(pr,i){ pr.k+=(kT-pr.k)*Math.min(1,dt*(kT>pr.k?5:1.4)); if(pr.k<0.004) pr.k=0;
    var a=pr.dir*46*pr.k*dt; if(pr.axis==='x') pr.g.rotation.x+=a*1.5; else if(pr.axis==='z') pr.g.rotation.z+=a; else pr.g.rotation.y+=a;
    var bo=1-0.9*clamp((pr.k-0.12)/0.4,0,1); pr.bl.material.opacity=bo; pr.bl.castShadow=pr.k<0.35; pr.dk.visible=pr.k>0.1; pr.dk.material.opacity=clamp((pr.k-0.1)/0.4,0,1)*0.6; });
  drone.spin.forEach(function(m){ m.rotation.y+=8*dt; });
  if(drone.strobe) drone.strobe.visible=(Math.floor(T*2.2)%2===0)||(T%0.45<0.06);
  /* tiempo de animación, medidor de fotogramas y nivel automático */
  var now=performance.now(), dtr=(now-(S.lastNow||now))/1000; S.lastNow=now; GFX.uTime.value=(now/1000)%20000;
  if(GFX.tick(dtr)){ R3D.applyQuality(); if(R3D.onQuality) R3D.onQuality(); }
  /* sombra */
  var gh=world.floorH(p.x,p.y,p.z); S.shadow.position.set(p.x,gh+Math.min(0.12,0.012+drone.dim*0.1),p.z);
  var ah=Math.max(0,p.y-gh); S.shadow.material.opacity=clamp(0.4-ah*0.004,0.06,0.4)*(S.nightMode?0.4:1);
  var base=Math.max(0.3,drone.dim*drone.vk*0.45); S.shadow.scale.setScalar(base*(1+ah*0.012)); S.shadow.visible=!S.shadowOn&&!(S.crashFx&&S.crashFx.kind==='explode');
  if(S.shadowOn){ var Qs=GFX.q, hc=ah*Math.sqrt(Math.max(0,1-S.lightDir.y*S.lightDir.y)), sK=Math.max(0,1-0.8*Qs.shR/Math.max(hc,0.01)), tx=2*Qs.shR/Qs.shadow*8;
    var fx0=Math.round(p.x/tx)*tx, fz0=Math.round(p.z/tx)*tx, fy0=gh+ah*sK;
    S.sun.target.position.set(fx0,fy0,fz0); S.sun.position.set(fx0+S.lightDir.x*220,fy0+S.lightDir.y*220,fz0+S.lightDir.z*220); }
  else { S.sun.target.position.set(0,0,0); S.sun.position.copy(S.lightDir); }
  S.sun.target.updateMatrixWorld();
  /* estela */
  if(opts.trail){ trailT-=dt; if(trailT<=0&&f.status!=='ground'){ trailT=0.25; trailPts.push(p.x,p.y,p.z); if(trailPts.length>900*3) trailPts.splice(0,3); var a=S.trail.geometry.attributes.position; a.array.set(trailPts); a.needsUpdate=true; S.trail.geometry.setDrawRange(0,trailPts.length/3); } S.trail.visible=true; } else S.trail.visible=false;
  /* aerogeneradores / tráfico */
  dyn.forEach(function(d){ if(d.turbine){ d.rot.rotation.z+=0.6*dt; d.grp.rotation.y=(180-S.wxDir)*deg*0+Math.PI+(-S.wxDir*deg); } if(d.traffic&&world.dynamic[0]){ var t=world.dynamic[0]; d.grp.position.set(t.x,t.y,t.z); d.grp.rotation.y=(t.dir>0?0:Math.PI); } });
  updateActors(f.t,p);
  /* cámara */
  var cam=S.cam, mode=S.camMode, dh=drone.dim*drone.vk;
  var fx=Math.sin(f.yaw), fz=-Math.cos(f.yaw);
  if(mode==='vlos'){
    /* la cámara se coloca DETRÁS del dron según su rumbo inicial (antes siempre al sur, aunque el rumbo no fuera norte)
       y siempre por detrás del operador, para que ni el dron quede encima ni las manos del operador queden dentro del plano cercano */
    var h=world.home, ey=world.homeY+1.75, h0=(world.startHeading||0)*deg, f0x=Math.sin(h0), f0z=-Math.cos(h0), back=3.8, op=S.act&&S.act.oper;
    if(op){ var ob=-((op.per.x-h.x)*f0x+(op.per.z-h.z)*f0z); if(ob>0) back=Math.max(back,ob+2.2); }
    cam.position.set(h.x-f0x*back,ey,h.z-f0z*back);
    S.vlosBack=back;
    var tgt=_v.set(p.x,p.y,p.z); cam.up.set(0,1,0); cam.lookAt(tgt);
    var d=Math.hypot(p.x-h.x,p.y-ey,p.z-h.z); cam.fov=opts.zoom>1?40/opts.zoom*1.0:55; cam.near=0.5;
  } else if(mode==='fpv'){
    var ptilt=(opts.gimbal||opts.fpvStab)?0:f.pitch, rtilt=(opts.gimbal||(opts.fpvStab&&opts.fpvHS))?0:f.roll;
    /* cámara en el morro, fuera del modelo; el propio dron no se dibuja en FPV */
    cam.position.set(p.x+fx*dh*0.55,p.y+dh*0.10,p.z+fz*dh*0.55);
    cam.up.set(0,1,0);
    cam.rotation.order='YXZ';
    var tsx=f.ac.kind==='tailsitter'&&(f.tsMode==='toFw'||f.tsMode==='toVt'); if(tsx){ ptilt=0; } var up=(SM.fwNow(f)||tsx?0:(opts.fpvAng!==null&&opts.fpvAng!==undefined?opts.fpvAng:S.uptilt))*deg;
    cam.rotation.set(-ptilt+(opts.gimbal?-0.12:up)*1.0,-f.yaw,-rtilt);
    if(!SM.fwNow(f) && !tsx && !opts.gimbal && !opts.fpvStab) cam.rotation.x=-f.pitch+up;
    if(opts.fpvStab) cam.rotation.x=-0.03;   /* gimbal de 1 eje: horizonte estable en cabeceo (RockSteady); el alabeo sigue al dron */
    cam.fov=opts.gimbal?70:78; cam.near=0.1;
  } else if(mode==='chase'){
    var dd=Math.max(3.2,dh*5+2.5), tx=p.x-fx*dd, ty=p.y+dd*0.35, tz=p.z-fz*dd;
    S.chasePos.lerp(_v.set(tx,ty,tz),Math.min(1,dt*4)); if(S.chasePos.distanceTo(_v)>60) S.chasePos.copy(_v);
    var gy=world.terrainH(S.chasePos.x,S.chasePos.z)+1.2; if(S.chasePos.y<gy) S.chasePos.y=gy;
    cam.position.copy(S.chasePos); cam.up.set(0,1,0); cam.lookAt(p.x,p.y+dh*0.15,p.z); cam.fov=62; cam.near=0.2;
  } else if(mode==='orbit'){ /* cámara orbital (inspección del modelo) */
    var ob=S.orb||(S.orb={a:0.7,e:0.32,d:3.2}), od=ob.d*Math.max(dh,0.35);
    cam.position.set(p.x+Math.sin(ob.a)*Math.cos(ob.e)*od,p.y+drone.lift+Math.sin(ob.e)*od,p.z+Math.cos(ob.a)*Math.cos(ob.e)*od); cam.up.set(0,1,0); cam.lookAt(p.x,p.y+drone.lift,p.z); cam.fov=40; cam.near=0.05;
  } else if(mode==='free'&&S.freeCam){ /* cámara libre (depuración) */
    cam.position.copy(S.freeCam.p); cam.up.set(0,1,0); cam.lookAt(S.freeCam.t); cam.fov=45; cam.near=0.1;
  } else { /* top */
    cam.position.set(p.x,p.y+Math.max(60,opts.topH||90),p.z+0.01); cam.up.set(0,0,-1); cam.lookAt(p.x,p.y,p.z); cam.fov=55; cam.near=1;
  }
  /* baliza de localización: anillo naranja cuando el dron se ve demasiado pequeño */
  if(S.beacon){ var bd=Math.max(1,cam.position.distanceTo(_v.set(p.x,p.y,p.z))), bsz=drone.dim*drone.vk;
    var ang=bsz/bd*(55/Math.max(20,cam.fov)), need=mode!=='fpv'&&(ang<0.02||(f.status==='ground'&&mode==='vlos'&&ang<0.12*(1.5/(S.vlosBack||1.5))))&&f.status!=='crashed';
    S.beacon.visible=need; if(need){ S.beacon.position.set(p.x,p.y+drone.lift,p.z); var ks=Math.max(bsz*2,bd*0.045); S.beacon.scale.set(ks,ks,1); S.beacon.material.opacity=clamp((0.02-ang)/0.012,0.25,1)*(0.75+0.25*Math.sin(T*5)); } }
  cam.updateProjectionMatrix();
  S.sky.position.copy(cam.position);
  /* lluvia alrededor de la cámara */
  if(S.rain.visible){
    var a=S.rain.geometry.attributes.position.array, n=Math.floor(S.rainN*S.rainAmt), sl=opts.windX||0, sz=opts.windZ||0;
    for(var i=0;i<S.rainN;i++){
      var u=S.rain.userData[i]; u[1]-=26*dt; u[0]-=sl*dt*0.6; u[2]-=sz*dt*0.6;
      if(u[1]<-6||Math.abs(u[0])>30||Math.abs(u[2])>30){ u[0]=(Math.random()-0.5)*60; u[1]=18+Math.random()*10; u[2]=(Math.random()-0.5)*60; }
      var k=i*6, on=i<n;
      a[k]=cam.position.x+u[0]; a[k+1]=cam.position.y+u[1]; a[k+2]=cam.position.z+u[2];
      a[k+3]=a[k]+(on?sl*0.03:0); a[k+4]=a[k+1]+(on?0.7:0); a[k+5]=a[k+2]+(on?sz*0.03:0);
      if(!on){ a[k+3]=a[k]; a[k+4]=a[k+1]; a[k+5]=a[k+2]; }
    }
    S.rain.geometry.attributes.position.needsUpdate=true;
  }
  S.r.render(S.scene,cam);
};
/* aros del modo competición */
R3D.setRings=function(rings){
  S.ringsSrc=rings;
  if(S.rings&&S.rings.grp){ S.worldGroup.remove(S.rings.grp); disposeGroup(S.rings.grp); }
  S.rings=null; if(!rings||!rings.length) return;
  var grp=new THREE.Group(), items=[];
  rings.forEach(function(g,i){
    var it=new THREE.Group(); it.position.set(g.x,g.y,g.z); it.rotation.y=Math.atan2(g.nx,g.nz);
    var tube=Math.max(0.14,g.r*0.075);
    var mat=new THREE.MeshBasicMaterial({color:0xff7a1a,fog:false});
    var tor=new THREE.Mesh(new THREE.TorusGeometry(g.r,tube,10,48),mat); it.add(tor);
    var dmat=new THREE.MeshBasicMaterial({color:0xffe14a,transparent:true,opacity:0.18,side:THREE.DoubleSide,depthWrite:false,fog:false});
    var disc=new THREE.Mesh(new THREE.CircleGeometry(g.r,40),dmat); disc.visible=false; it.add(disc);
    var fl=world.floorH(g.x,g.y,g.z), ph=g.y-g.r-fl;
    if(ph>0.3){ var pole=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,ph,6),new THREE.MeshBasicMaterial({color:0x6b7785,transparent:true,opacity:0.55,fog:false})); pole.position.set(0,-g.r-ph/2,0); it.add(pole); }
    var tex=canvasTex(64,64,function(c,W,H){ c.fillStyle='rgba(20,40,58,0.85)'; c.beginPath(); c.arc(32,32,30,0,6.3); c.fill(); c.fillStyle='#fff'; c.font='bold 34px sans-serif'; c.textAlign='center'; c.textBaseline='middle'; c.fillText(String(i+1),32,35); });
    var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,depthTest:false,fog:false})); sp.position.set(0,g.r+tube+Math.max(0.9,g.r*0.35),0); sp.scale.set(Math.max(1.6,g.r*0.7),Math.max(1.6,g.r*0.7),1); sp.renderOrder=20; it.add(sp);
    grp.add(it); items.push({tor:tor,mat:mat,disc:disc,dmat:dmat,sp:sp,r:g.r});
  });
  S.worldGroup.add(grp); S.rings={grp:grp,items:items,last:-2};
};
R3D.ringFlash=function(idx,t0,fin){
  var R=S.rings; if(!R||!R.items[idx]) return; var it=R.items[idx], src=R.grp.children[idx];
  var col=fin?0xffe14a:0xffffff, g=new THREE.Group(); g.position.copy(src.position); g.rotation.copy(src.rotation);
  var tm=new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:1,depthWrite:false,depthTest:false,fog:false});
  var tor=new THREE.Mesh(new THREE.TorusGeometry(it.r,Math.max(0.2,it.r*0.1),8,48),tm); tor.renderOrder=15; g.add(tor);
  var dm=new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:0.7,side:THREE.DoubleSide,depthWrite:false,depthTest:false,fog:false});
  var dc=new THREE.Mesh(new THREE.CircleGeometry(it.r,36),dm); dc.renderOrder=14; g.add(dc);
  R.grp.add(g); (R.fl||(R.fl=[])).push({g:g,tor:tor,tm:tm,dc:dc,dm:dm,t0:t0,fin:!!fin});
};
R3D.updateRings=function(idx,done,tms){
  var R=S.rings; if(!R) return;
  if(R.fl){ R.fl=R.fl.filter(function(f){ var k=(tms-f.t0)/(f.fin?1100:700); if(k>=1){ R.grp.remove(f.g); f.tor.geometry.dispose(); f.dc.geometry.dispose(); f.tm.dispose(); f.dm.dispose(); return false; }
    var e=1-Math.pow(1-Math.max(0,k),2); f.tor.scale.set(1+1.6*e,1+1.6*e,1); f.tm.opacity=1-k; f.dc.scale.set(1+0.25*e,1+0.25*e,1); f.dm.opacity=0.7*(1-k)*(1-k); return true; }); }
  R.items.forEach(function(it,i){
    var passed=done||i<idx, nxt=!done&&i===idx;
    it.mat.color.setHex(passed?0x2ecc71:(nxt?0xffe14a:0xff7a1a));
    it.disc.visible=nxt; var p=nxt?1+0.06*Math.sin(tms/180):1; it.tor.scale.set(p,p,1); it.dmat.opacity=nxt?0.14+0.1*Math.sin(tms/180):0;
    it.sp.material.opacity=passed?0.45:1;
  });
};
R3D.setUptilt=function(d){S.uptilt=d;};
R3D.clearTrail=function(){ trailPts=[]; if(S.trail) S.trail.geometry.setDrawRange(0,0); };
R3D.worldRef=function(){return world;};
})();
