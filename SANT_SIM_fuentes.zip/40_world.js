/* ===== ESCENARIOS: terreno, obstáculos, zonas (lógica, sin gráficos) ===== */
var SW = {};
(function(){
var clamp=(typeof SD!=='undefined'?SD:require('./20_data.js')).clamp;
function ss(a,b,x){ var t=clamp((x-a)/(b-a),0,1); return t*t*(3-2*t); }
SW.EXT = 3000;           /* semilado del mundo (m) */

SW.LIST = [
 {id:'campo', name:'Campo abierto', tag:'Sin obstáculos', wx:'brisa', desc:'Terreno llano con pista de césped, un granero y una línea de postes. El escenario de referencia: radioenlace en espacio casi libre y GNSS completo.'},
 {id:'ciudad', name:'Ciudad', tag:'Cañón urbano', wx:'viento', desc:'Edificios de 14 a 80 m, plaza con gente y suelo urbano. Sombras de radio, GNSS degradado, interferencias (+8 dB) y turbulencia entre edificios.'},
 {id:'bosque', name:'Bosque y colinas', tag:'Follaje', wx:'brisa', desc:'Colinas suaves cubiertas de arbolado y una torre de radio. El follaje atenúa el enlace y el relieve oculta el dron.'},
 {id:'montana', name:'Montaña (1800 m)', tag:'Relieve y altura', wx:'racheado', desc:'Valle encajonado con crestas de hasta 260 m. Aire poco denso (altitud de densidad alta), ascendentes de ladera, rachas y sombra radioeléctrica tras la cresta.'},
 {id:'costa', name:'Costa y parque eólico', tag:'Mar y viento', wx:'viento', desc:'Playa con bañistas, faro, buque y aerogeneradores en el mar. Viento marino constante y aterrizaje en el agua = pérdida.'},
 {id:'barrio', name:'Barrio residencial (azotea)', tag:'Casas bajas · azotea', wx:'brisa', desc:'Despegas desde la azotea de un edificio de 21 m en un barrio de casas bajas (6–9 m) con algunos bloques de hasta 34 m, calles de 12 m, una plaza con gente y antenas en las azoteas. Sobrevuelo de zona urbana: normativa, personas, turbulencia entre edificios y aterrizaje sobre cualquier azotea.'},
 {id:'nave', name:'Nave industrial (interior)', tag:'Interior · LiDAR', wx:'calma', desc:'Nave de 60 × 53 × 14 m sin GNSS, con columnas, estanterías, palés y una viga. Equipa telémetros láser o un LiDAR 360° y observa las distancias a paredes y obstáculos.'},
 {id:'aeropuerto', name:'Cercanía de aeropuerto', tag:'Normativa', wx:'calma', desc:'Zona geográfica UAS restringida de 2 km de radio alrededor de la pista y tráfico tripulado cruzando. Practica el respeto del espacio aéreo.'}
];

function Grid(){ this.c={}; this.cs=50; }
Grid.prototype.add=function(o){
  var cs=this.cs, x0=Math.floor((o.x-o.rx)/cs), x1=Math.floor((o.x+o.rx)/cs), z0=Math.floor((o.z-o.rz)/cs), z1=Math.floor((o.z+o.rz)/cs);
  for(var i=x0;i<=x1;i++)for(var j=z0;j<=z1;j++){ var k=i+','+j; (this.c[k]||(this.c[k]=[])).push(o); }
};
Grid.prototype.at=function(x,z){ return this.c[Math.floor(x/this.cs)+','+Math.floor(z/this.cs)]||EMPTY; };
var EMPTY=[];

SW.make = function(id, rngf){
  var rnd = rngf || (function(){var a=12345;return function(){a=(a*1664525+1013904223)>>>0;return a/4294967296;};})();
  var meta=null; SW.LIST.forEach(function(m){ if(m.id===id) meta=m; });
  var w={id:id, name:meta.name, meta:meta, elev:50, rough:0.14, home:{x:0,z:0}, startHeading:0, noGnss:false, rfNoise:0,
         obstacles:[], zones:[], dynamic:[], grid:new Grid(), isWater:null, waterY:null, showRunway:null, ground:'grass', fog:null, traffic:null};
  var land=function(x,z){return 0;};
  var pal=function(x,z,h){return [0.46,0.62,0.30];};
  function T(x,z){ return land(x,z); }
  w.terrainH=function(x,z){ return w.waterOnly? Math.max(0,land(x,z)) : land(x,z); };
  function add(kind,x,z,dx,dz,h,label,color,extra){
    var y0=w.terrainH(x,z)+((extra&&extra.lift)||0);
    var o={kind:kind,x:x,z:z,dx:dx,dz:dz,h:h,y0:y0,top:y0+h,label:label,color:color||0xb0b6bd,rx:(kind==='box'?dx/2:dx),rz:(kind==='box'?dz/2:dx)};
    if(extra) for(var k in extra) o[k]=extra[k];
    w.obstacles.push(o); w.grid.add(o); return o;
  }
  w.addObs=add;

  if(id==='campo'){
    w.elev=50; w.rough=0.12;
    land=function(x,z){ return 0.6*Math.sin(x/90)*Math.cos(z/120); };
    pal=function(x,z,h){ var n=0.5+0.5*Math.sin(x/37)*Math.cos(z/29); return [0.38+0.10*n,0.58+0.08*n,0.26+0.06*n]; };
    w.showRunway={x:0,z:-70,len:200,wid:14,hd:0};
    add('box',-130,-230,22,11,8,'el granero',0xa3402f);
    for(var i=0;i<9;i++) add('cyl',90,-120-i*45,0.35,0,11,'un poste de la línea eléctrica',0x6b5a45,{solid:true});
    for(var i=0;i<40;i++){ var ang=rnd()*6.28, rr=380+rnd()*180; add('tree',Math.sin(ang)*rr+120,-Math.cos(ang)*rr-350,3,0,9+rnd()*6,'un árbol',0x2f6b34); }
    w.fixed=true;
  }
  else if(id==='ciudad'){
    w.elev=30; w.rough=0.32; w.rfNoise=8;
    land=function(x,z){ return 0; };
    pal=function(x,z,h){ return [0.46,0.47,0.48]; };
    w.ground='urban';
    for(var i=-8;i<=8;i++) for(var j=1;j<=11;j++){
      var cx=i*70, cz=-j*70-20;
      var hh=14+rnd()*rnd()*66+(Math.abs(i)<3&&j>4?30*rnd():0);
      var c=[0xc9c3b6,0xb4b9bf,0xd0a58a,0x9fb2c2,0xc7cdd3][Math.floor(rnd()*5)];
      add('box',cx+(rnd()-0.5)*6,cz+(rnd()-0.5)*6,40+rnd()*10,40+rnd()*10,hh,'un edificio de '+Math.round(hh)+' m',c);
    }
    for(var i=0;i<14;i++){ var a=rnd()*6.28, r=15+rnd()*45; add('tree',Math.sin(a)*r,40+Math.cos(a)*r*0.8,3,0,7+rnd()*4,'un árbol',0x3f7a3a); }
    add('cyl',-20,-120,2,0,55,'una grúa torre',0xe0a82e,{solid:true});
    w.zones.push({type:'crowd',x:48,z:-12,r:32,label:'Reunión de personas (mercado)',color:0xd9342b});
    w.zones.push({type:'urban',x:0,z:-470,r:470,label:'Zona urbana / residencial',color:0xe0a82e});
    w.plaza={x:0,z:0,r:50};
  }
  else if(id==='barrio'){
    w.elev=40; w.rough=0.30; w.rfNoise=5; w.ground='urban'; w.startHeading=0;
    land=function(x,z){ return 0; };
    pal=function(x,z,h){ return (Math.abs(x)<640&&z<150&&z>-800)?[0.55,0.54,0.52]:[0.46,0.58,0.32]; };
    var HC=[0xefe9dc,0xe3d3b8,0xd9b99b,0xc9d6dc,0xf2e2c4,0xe8c8c0,0xdfe5e8,0xcfc3ae];
    w.blocks=[];
    for(var i=-12;i<=12;i++) for(var j=-3;j<=12;j++){
      var cx=i*48, cz=-j*48;
      if(i===0&&j===0) continue;                       /* manzana del edificio de despegue */
      w.blocks.push({x:cx,z:cz});
      if(i===0&&j===4){ for(var t=0;t<6;t++){ var a=t*1.047+0.3; add('tree',cx+Math.sin(a)*21,cz+Math.cos(a)*21,3,0,7+rnd()*3,'un árbol',0x3f7a3a); } continue; }   /* plaza */
      for(var u=0;u<2;u++) for(var v=0;v<2;v++){
        if(rnd()<0.06){ add('tree',cx+(u?9.5:-9.5),cz+(v?9.5:-9.5),3,0,6+rnd()*4,'un árbol',0x3f7a3a); continue; }
        var q=rnd(), hh=q<0.78?6+rnd()*3:(q<0.94?11+rnd()*8:20+rnd()*14);
        var bx=cx+(u?9.5:-9.5)+(rnd()-0.5)*1.5, bz=cz+(v?9.5:-9.5)+(rnd()-0.5)*1.5;
        var lab=hh<10?'una casa de '+Math.round(hh)+' m':'un edificio de '+Math.round(hh)+' m';
        add('box',bx,bz,14+rnd()*3,14+rnd()*3,hh,lab,HC[Math.floor(rnd()*HC.length)],{roof:true});
        if(hh>19&&rnd()<0.6) add('cyl',bx+2,bz+2,0.3,0,6,'una antena',0x888d92,{solid:true,lift:hh});
      }
    }
    add('box',0,0,20,16,21,'el edificio de despegue',0xd6cdbd,{roof:true});
    add('cyl',7,5,0.25,0,5,'una antena',0x888d92,{solid:true,lift:21});
    for(var i=0;i<120;i++){ var sx=(Math.floor(rnd()*25)-12)*48+(rnd()<0.5?-24:24), sz=-(Math.floor(rnd()*16)-3)*48+(rnd()-0.5)*40; if(Math.hypot(sx,sz)<25) continue; add('tree',sx,sz,2.5,0,6+rnd()*3,'un árbol',0x3f7a3a); }
    w.zones.push({type:'crowd',x:0,z:-192,r:22,label:'Plaza con terrazas y gente',color:0xd9342b});
    w.zones.push({type:'urban',x:0,z:-280,r:560,label:'Zona urbana / residencial',color:0xe0a82e});
    w.plaza={x:0,z:-192,r:21};
  }
  else if(id==='bosque'){
    w.elev=400; w.rough=0.26;
    var hh0=function(x,z){ return 26*Math.sin(x/190)*Math.cos(z/230)+16*Math.sin((x+z)/120)+9*Math.sin(x/53+1)*Math.cos(z/61); };
    land=function(x,z){ var r=Math.hypot(x,z); var f=ss(40,160,r); return hh0(x,z)*f+(1-f)*hh0(0,0); };
    pal=function(x,z,h){ var n=0.5+0.5*Math.sin(x/23)*Math.cos(z/19); return [0.20+0.07*n,0.40+0.10*n,0.19+0.04*n]; };
    for(var i=0;i<900;i++){ var x=(rnd()-0.5)*2800, z=(rnd()-0.5)*2800; if(Math.hypot(x,z)<60) continue; if(rnd()<0.35 && Math.hypot(x,z)>700) continue; add('tree',x,z,3,0,10+rnd()*9,'un árbol',[0x2b5f2f,0x356b36,0x24552b][Math.floor(rnd()*3)]); }
    add('cyl',-300,-250,1.6,0,48,'la torre de radio',0xd6483c,{solid:true,mast:true});
    add('box',-260,-210,8,6,4,'la caseta de la torre',0x8a8f94);
  }
  else if(id==='montana'){
    w.elev=1800; w.rough=0.10;
    land=function(x,z){
      var e=270*Math.exp(-Math.pow((x-640)/250,2))*(0.75+0.25*Math.sin(z/260+1));
      var o=190*Math.exp(-Math.pow((x+720)/290,2))*(0.8+0.2*Math.cos(z/230));
      var s=230*ss(450,1500,z), n=0.035*Math.max(0,-z)*0+ 0.04*(-z);
      var r=12*Math.sin(x/70)*Math.sin(z/85)+7*Math.sin(x/31+z/27);
      var f=ss(30,140,Math.hypot(x,z));
      return (e+o+s+Math.max(0,n)+r*f*0.8)*1.0 - (1-f)*0 + (1-f)*0;
    };
    pal=function(x,z,h){ var t=h; if(t>230) return [0.93,0.94,0.96]; if(t>140) return [0.52,0.50,0.47]; if(t>50) return [0.42,0.50,0.30]; return [0.36,0.50,0.27]; };
    add('box',636,-90,10,8,5,'el refugio de la cresta',0xb86a3a);
    add('cyl',650,-120,0.8,0,14,'el mástil repetidor',0xd6483c,{solid:true,mast:true});
    for(var i=0;i<120;i++){ var x=(rnd()-0.5)*900-100, z=(rnd()-0.5)*1500; if(Math.hypot(x,z)<70||w.terrainH(x,z)>150) continue; add('tree',x,z,2.5,0,6+rnd()*6,'un abeto',0x2a5030); }
  }
  else if(id==='costa'){
    w.elev=5; w.rough=0.07; w.waterOnly=true;
    var shore=function(z){ return 60+22*Math.sin(z/110); };
    land=function(x,z){ var l=clamp((shore(z)-x)*0.07,-3,7)+1.6*Math.sin(z/40)*Math.sin(x/38)*ss(-200,40,x); return l; };
    w.isWater=function(x,z){ return land(x,z)<0.05; };
    pal=function(x,z,h){ if(h<0.1) return [0.75,0.70,0.52]; if(h<1.4) return [0.88,0.82,0.62]; if(h<3.2) return [0.80,0.77,0.55]; return [0.52,0.60,0.33]; };
    w.sea=true;
    w.home={x:-35,z:0};
    add('cyl',420,-220,4.5,0,38,'el faro',0xf0f0f0,{solid:true,lighthouse:true});
    add('box',560,150,45,10,18,'el buque',0x35506b,{ship:true});
    for(var i=0;i<4;i++) add('cyl',760,-420+i*300,2.2,0,92,'un aerogenerador',0xe9edf0,{solid:true,turbine:true});
    add('box',-80,-130,10,8,4,'el chiringuito',0xd9a35f);
    w.zones.push({type:'crowd',x:10,z:60,r:45,label:'Playa con bañistas',color:0xd9342b});
  }
  else if(id==='nave'){
    w.elev=50; w.rough=0.05; w.noGnss=true; w.indoor={x0:-30.3,x1:30.3,z0:-45.3,z1:8.3,h:14}; w.mapExt=70; w.startHeading=0;
    land=function(x,z){ return 0; };
    pal=function(x,z,h){ var inH=x>-30&&x<30&&z>-45&&z<8; return inH?[0.62,0.63,0.65]:[0.42,0.58,0.30]; };
    var wc=0xb9c0c7;
    add('box',0,-45,60.6,0.6,14,'la pared norte',wc);
    add('box',-30,-18.5,0.6,53.6,14,'la pared oeste',wc);
    add('box',30,-18.5,0.6,53.6,14,'la pared este',wc);
    add('box',-22,8,16,0.6,14,'la pared sur',wc);
    add('box',12,8,36,0.6,14,'la pared sur',wc);
    add('box',-10,8,8,0.6,9,'el dintel de la puerta',wc,{lift:5});
    add('box',0,-18.5,60.6,53.6,0.6,'el techo',0x9aa3ab,{lift:14});
    [-18,0,18].forEach(function(x){ [-14,-32].forEach(function(z){ add('cyl',x,z,0.5,0,14,'una columna',0xd6a21c,{solid:true}); }); });
    [[-24,-25],[24,-25],[-8,-37],[8,-37]].forEach(function(r){ add('box',r[0],r[1],2.5,10,5,'una estantería',0x3f6fa8); });
    add('box',-6,-6,2,2,1.5,'un palé',0xb98a52); add('box',10,-10,3,2,2,'un palé',0xb98a52); add('box',-20,-5,2,2,2,'un palé',0xb98a52);
    add('box',0,-20,60,0.8,0.8,'la viga del puente grúa',0xc0392b,{lift:9});
    w.decor=[]; for(var ix=-24;ix<=24;ix+=12) for(var iz=-38;iz<=0;iz+=12) w.decor.push({x:ix,y:13.5,z:iz,sx:3,sy:0.15,sz:0.4,color:0xfffbe6});
    w.floor={x:0,z:-18.5,w:60,d:53};
    w.windScale=function(x,y,z){ var I=w.indoor; return (x>I.x0&&x<I.x1&&z>I.z0&&z<I.z1&&y<I.h)?0.03:1; };
  }
  else if(id==='aeropuerto'){
    w.elev=8; w.rough=0.05;
    land=function(x,z){ return 0.3*Math.sin(x/200)*Math.sin(z/260); };
    pal=function(x,z,h){ return [0.42,0.60,0.30]; };
    w.showRunway={x:0,z:-2500,len:2400,wid:45,hd:0};
    add('box',160,-2500,160,36,17,'la terminal',0xcfd3d8);
    add('cyl',-110,-2420,4,0,38,'la torre de control',0xf0efe8,{solid:true});
    add('box',-140,-2650,70,40,16,'un hangar',0xb4b9bf);
    for(var i=0;i<10;i++) add('tree',-300+rnd()*600,-300-rnd()*500,3,0,8+rnd()*5,'un árbol',0x35703a);
    w.zones.push({type:'restricted',x:0,z:-2500,r:2000,label:'ZONA UAS RESTRINGIDA · Aeropuerto',color:0xd9342b,maxAlt:0});
    w.traffic={path:'x',z:-1500,alt:90,speed:48,len:2800,label:'una aeronave tripulada'};
    w.startHeading=0;
  }
  w.land=land; w.pal=pal;
  w.terrainH=function(x,z){ var h=land(x,z); return w.waterOnly?Math.max(0,h):h; };
  /* actualizar y0/top de obstáculos con la altura real del terreno */
  w.obstacles.forEach(function(o){ o.y0=w.terrainH(o.x,o.z)+(o.lift||0); o.top=o.y0+o.h; });
  w.floorH=function(x,y,z){
    var best=w.terrainH(x,z), list=w.grid.at(x,z);
    for(var i=0;i<list.length;i++){ var o=list[i]; if(!o.roof||o.top<=best||o.top>y+0.2) continue;
      if(Math.abs(x-o.x)<o.dx/2&&Math.abs(z-o.z)<o.dz/2) best=o.top; }
    return best;
  };
  w.homeY=w.floorH(w.home.x,1e9,w.home.z); w.home.y=w.homeY;
  w.time=0;
  /* tráfico tripulado: objeto dinámico */
  if(w.traffic){ w.dynamic.push({x:-1400,y:w.traffic.alt,z:w.traffic.z,r:9,label:w.traffic.label,traffic:true}); }
  w.update=function(t){
    w.time=t;
    if(w.traffic){ var d=w.dynamic[0], L=w.traffic.len; var s=((t*w.traffic.speed)%(2*L)); d.x=(s<L? s : 2*L-s)-L/2; d.dir=s<L?1:-1; d.y=w.traffic.alt+w.terrainH(0,w.traffic.z); }
  };
  w.update(0);

  /* altura máxima de lo que bloquea en (x,z): terreno u obstáculo */
  w.blockTop=function(x,z,y){
    var th=w.terrainH(x,z), best=th, kind='terrain', list=w.grid.at(x,z);
    for(var i=0;i<list.length;i++){
      var o=list[i], inside;
      if(o.kind==='box') inside=Math.abs(x-o.x)<o.dx/2&&Math.abs(z-o.z)<o.dz/2; else inside=(x-o.x)*(x-o.x)+(z-o.z)*(z-o.z)<o.dx*o.dx;
      if(inside && o.lift && y!==undefined && y<o.y0) inside=false;
      if(inside && o.top>best){ best=o.top; kind=(o.kind==='tree')?'foliage':'solid'; }
    }
    return {top:best,kind:kind};
  };
  w.collide=function(x,y,z,r){
    var list=w.grid.at(x,z);
    for(var i=0;i<list.length;i++){
      var o=list[i], hit;
      if(o.kind==='box') hit=Math.abs(x-o.x)<o.dx/2+r&&Math.abs(z-o.z)<o.dz/2+r;
      else { var rr=(o.kind==='tree'?o.dx*0.8:o.dx)+r; hit=(x-o.x)*(x-o.x)+(z-o.z)*(z-o.z)<rr*rr; }
      if(hit && y<o.top+r*0.5 && y>(o.lift?o.y0-r:o.y0-2)){ if(o.roof && y>=o.top-0.25) continue; if(o.kind==='tree' && y>o.top) continue; return o; }
    }
    for(var k=0;k<w.dynamic.length;k++){ var d=w.dynamic[k]; var dd=Math.sqrt((x-d.x)*(x-d.x)+(y-d.y)*(y-d.y)+(z-d.z)*(z-d.z)); if(dd<d.r+r) return d; }
    return null;
  };
  /* distancia al obstáculo más cercano (aprox) y distancia delante (m) */
  w.nearestObstacle=function(x,y,z,yaw){
    var best=99,label='',cs=w.grid.cs;
    var ci=Math.floor(x/cs), cj=Math.floor(z/cs);
    for(var i=ci-1;i<=ci+1;i++)for(var j=cj-1;j<=cj+1;j++){
      var list=w.grid.c[i+','+j]; if(!list) continue;
      for(var n=0;n<list.length;n++){ var o=list[n]; if(y>o.top+3) continue;
        if(o.roof && y>=o.top-0.25 && Math.abs(x-o.x)<o.dx/2 && Math.abs(z-o.z)<o.dz/2) continue;   /* sobre la azotea: es suelo, no obstáculo */
        var dx,dz;
        if(o.kind==='box'){ dx=Math.max(0,Math.abs(x-o.x)-o.dx/2); dz=Math.max(0,Math.abs(z-o.z)-o.dz/2); }
        else { dx=Math.max(0,Math.hypot(x-o.x,z-o.z)-o.dx); dz=0; }
        var dy=Math.max(0,o.y0-y,y-o.top); var d=Math.hypot(dx,dz,dy); if(d<best){best=d;label=o.label;}
      }
    }
    var ahead=99, fx=Math.sin(yaw), fz=-Math.cos(yaw);
    for(var s=2;s<=24;s+=2){ var px=x+fx*s, pz=z+fz*s;
      if(w.collide(px,y,pz,0.8)||w.terrainH(px,pz)>y-0.4){ ahead=s; break; } }
    return {dist:best,label:label,ahead:ahead};
  };
  w.slope=function(x,z){ var e=12; return {x:(w.terrainH(x+e,z)-w.terrainH(x-e,z))/(2*e), z:(w.terrainH(x,z+e)-w.terrainH(x,z-e))/(2*e)}; };
  var tc={k:'',v:1};
  w.turbNear=function(x,y,z){
    var k=Math.round(x/8)+','+Math.round(y/6)+','+Math.round(z/8); if(k===tc.k) return tc.v;
    var v=1, list=w.grid.at(x,z);
    for(var i=0;i<list.length;i++){ var o=list[i]; if(o.kind==='tree'&&y>o.top+2) continue; if(y>o.top+10) continue;
      var d=o.kind==='box'?Math.hypot(Math.max(0,Math.abs(x-o.x)-o.dx/2),Math.max(0,Math.abs(z-o.z)-o.dz/2)):Math.max(0,Math.hypot(x-o.x,z-o.z)-o.dx);
      if(d<28){ v=Math.max(v,1+(o.kind==='tree'?0.7:1.6)*(1-d/28)); } }
    if(id==='ciudad') v*=1.3; if(id==='montana') v*=1.2;
    tc.k=k; tc.v=v; return v;
  };
  /* trazado de rayos: distancia al primer obstáculo o al suelo (m) */
  var stamp=0;
  w.ray=function(ox,oy,oz,dx,dy,dz,maxD){
    var best=maxD,label='',cs=w.grid.cs; stamp++;
    var ex=ox+dx*maxD, ez=oz+dz*maxD, i0=Math.floor(Math.min(ox,ex)/cs), i1=Math.floor(Math.max(ox,ex)/cs), j0=Math.floor(Math.min(oz,ez)/cs), j1=Math.floor(Math.max(oz,ez)/cs);
    for(var i=i0;i<=i1;i++)for(var j=j0;j<=j1;j++){ var list=w.grid.c[i+','+j]; if(!list) continue;
      for(var n=0;n<list.length;n++){ var o=list[n]; if(o._s===stamp) continue; o._s=stamp; var t=-1;
        if(o.kind==='box'){
          var tmin=0,tmax=best,ok=true, b=[[o.x-o.dx/2,o.x+o.dx/2,ox,dx],[o.y0,o.top,oy,dy],[o.z-o.dz/2,o.z+o.dz/2,oz,dz]];
          for(var a=0;a<3&&ok;a++){ var lo=b[a][0],hi=b[a][1],p=b[a][2],d=b[a][3];
            if(Math.abs(d)<1e-9){ if(p<lo||p>hi) ok=false; }
            else { var t1=(lo-p)/d,t2=(hi-p)/d; if(t1>t2){var q=t1;t1=t2;t2=q;} if(t1>tmin)tmin=t1; if(t2<tmax)tmax=t2; if(tmin>tmax) ok=false; } }
          if(ok) t=tmin;
        } else {
          var r=(o.kind==='tree'?o.dx*0.8:o.dx), px=ox-o.x, pz=oz-o.z, a2=dx*dx+dz*dz;
          if(a2>1e-9){ var b2=px*dx+pz*dz, c2=px*px+pz*pz-r*r, disc=b2*b2-a2*c2;
            if(disc>=0){ var sq=Math.sqrt(disc), t1=(-b2-sq)/a2; if(t1<0) t1=(-b2+sq)/a2; if(t1>=0){ var yy=oy+dy*t1; if(yy>=o.y0&&yy<=o.top) t=t1; } } }
          if(t<0 && dy<-1e-9 && oy>o.top){ var tc=(o.top-oy)/dy, cx=px+dx*tc, cz=pz+dz*tc; if(tc>=0&&cx*cx+cz*cz<r*r) t=tc; }
        }
        if(t>=0&&t<best){ best=t; label=o.label; } } }
    if(dy<0.05){ var st=0.5, lastT=0;
      for(var s2=st;s2<=best;s2+=st){ if(oy+dy*s2<w.terrainH(ox+dx*s2,oz+dz*s2)){ var lo2=lastT,hi2=s2; for(var k=0;k<6;k++){ var m=(lo2+hi2)/2; if(oy+dy*m<w.terrainH(ox+dx*m,oz+dz*m)) hi2=m; else lo2=m; } if(hi2<best){ best=hi2; label='el suelo'; } break; } lastT=s2; } }
    return {d:best,hit:best<maxD-1e-6,label:label};
  };
  /* zonas: comprobación normativa */
  w.zoneAt=function(x,z,type){
    for(var i=0;i<w.zones.length;i++){ var q=w.zones[i]; if(type&&q.type!==type) continue; var d=Math.hypot(x-q.x,z-q.z); if(d<q.r) return q; }
    return null;
  };
  w.zoneDist=function(x,z,type){ var best=1e9,zz=null; for(var i=0;i<w.zones.length;i++){ var q=w.zones[i]; if(q.type!==type) continue; var d=Math.hypot(x-q.x,z-q.z)-q.r; if(d<best){best=d;zz=q;} } return {d:best,zone:zz}; };
  return w;
};
})();
if(typeof module!=='undefined') module.exports=SW;
