/* ===== PARÁMETROS ARDUPILOT: lectura libre de .param y efecto en el simulador ===== */
(function(){
var $=function(id){return document.getElementById(id);};
var ST=SIM.ST, AP=SIM.AP={};

/* Lectura tolerante: "NOMBRE,valor", "NOMBRE valor", "NOMBRE=valor", tabulaciones, comentarios (# o //),
   líneas de QGroundControl ("1  1  NOMBRE  valor  tipo") y valores con coma decimal. */
AP.parse=function(text){
  var out={}, order=[], bad=0;
  String(text||'').split(/\r?\n/).forEach(function(line){
    line=line.replace(/\/\/.*$/,'').replace(/#.*$/,'').trim(); if(!line) return;
    var tk=line.split(/[\s,;=:]+/).filter(function(x){return x!=='';});
    if(tk.length>=4 && /^\d+$/.test(tk[0]) && /^\d+$/.test(tk[1]) && /^[A-Za-z_]/.test(tk[2])) tk=tk.slice(2);   /* QGC */
    if(tk.length<2 || !/^[A-Za-z][A-Za-z0-9_]*$/.test(tk[0])){ bad++; return; }
    var v=parseFloat(tk[1].replace(',','.')); if(isNaN(v)){ bad++; return; }
    var n=tk[0].toUpperCase(); if(!(n in out)) order.push(n); out[n]=v;
  });
  return {p:out,order:order,bad:bad};
};

function has(P,k){ return k in P; }
function cell(h){ return h; }

/* Construye los efectos y el informe. Devuelve {eff, rows, sugg, ignored, info} */
AP.build=function(text){
  var R=AP.parse(text), P=R.p, eff={}, rows=[], sugg=[], used={};
  function use(k,fx,txt,cls){ if(!has(P,k)) return false; used[k]=1; rows.push({n:k,v:P[k],t:txt||'',c:cls||'ok'}); if(fx) fx(P[k]); return true; }
  function info(k,txt,cls){ if(!has(P,k)) return; used[k]=1; rows.push({n:k,v:P[k],t:txt,c:cls||'info'}); }
  var actMap={0:'none',1:'land',2:'rth',3:'rth',4:'land',5:'land'}, actTxt={none:'sólo avisar',land:'aterrizar',rth:'regreso a casa'};

  /* --- maniobra y velocidades (Copter) --- */
  use('ANGLE_MAX',function(v){ if(v>0) eff.angleMax=v/100; },'Inclinación máxima del dron: '+(P.ANGLE_MAX/100).toFixed(0)+'°');
  use('LOIT_SPEED',function(v){ if(v>0) eff.loitSpeed=v/100; },'Velocidad horizontal máx. en GPS: '+(P.LOIT_SPEED/100).toFixed(1)+' m/s');
  info('WPNAV_SPEED','Velocidad en misión/RTL: '+(P.WPNAV_SPEED/100).toFixed(1)+' m/s (se usa en el RTL si RTL_SPEED = 0)');
  if(has(P,'WPNAV_SPEED')) eff.wpSpeed=P.WPNAV_SPEED/100;
  use('RTL_SPEED',function(v){ if(v>0) eff.rtlSpeed=v/100; },'Velocidad del regreso a casa: '+(P.RTL_SPEED/100).toFixed(1)+' m/s'+(P.RTL_SPEED===0?' (0 = usa WPNAV_SPEED)':''));
  use('PILOT_SPEED_UP',function(v){ if(v>0) eff.climbUp=v/100; },'Velocidad máx. de ascenso con mando: '+(P.PILOT_SPEED_UP/100).toFixed(1)+' m/s');
  use('PILOT_SPEED_DN',function(v){ if(v>0) eff.climbDn=v/100; },'Velocidad máx. de descenso con mando: '+(P.PILOT_SPEED_DN/100).toFixed(1)+' m/s'+(P.PILOT_SPEED_DN===0?' (0 = igual que el ascenso)':''));
  if(!has(P,'PILOT_SPEED_DN')&&eff.climbUp) eff.climbDn=eff.climbUp;
  if(has(P,'PILOT_SPEED_DN')&&P.PILOT_SPEED_DN===0&&eff.climbUp) eff.climbDn=eff.climbUp;
  use('PILOT_Y_RATE',function(v){ if(v>0) eff.yawRate=v; },'Velocidad de giro máx. (guiñada): '+P.PILOT_Y_RATE+' °/s');
  use('RTL_ALT',function(v){ if(v>0) eff.rtlAlt=v/100; },'Altura del regreso a casa: '+(P.RTL_ALT/100).toFixed(0)+' m'+(P.RTL_ALT===0?' (0 = altura actual: se ignora)':''));
  use('LAND_SPEED',function(v){ if(v>0) eff.landSpeed=v/100; },'Velocidad de aterrizaje final: '+(P.LAND_SPEED/100).toFixed(2)+' m/s');
  use('LAND_SPEED_HIGH',function(v){ if(v>0) eff.landSpeedHigh=v/100; },'Velocidad de descenso por encima de LAND_ALT_LOW: '+(P.LAND_SPEED_HIGH/100).toFixed(1)+' m/s');
  info('WPNAV_SPEED_DN','Velocidad de descenso en misión: '+(P.WPNAV_SPEED_DN/100).toFixed(1)+' m/s (se usa en aterrizaje si LAND_SPEED_HIGH = 0)');
  if(!eff.landSpeedHigh && has(P,'WPNAV_SPEED_DN') && P.WPNAV_SPEED_DN>0) eff.landSpeedHigh=P.WPNAV_SPEED_DN/100;
  use('LAND_ALT_LOW',function(v){ if(v>0) eff.landAltLow=v/100; },'Altura a la que pasa a la velocidad final: '+(P.LAND_ALT_LOW/100).toFixed(0)+' m');

  /* --- ganancias del control (Copter) --- */
  use('ATC_ANG_RLL_P',function(v){ if(v>0) eff.angP=v; },'Respuesta de actitud (P de ángulo): '+P.ATC_ANG_RLL_P+(P.ATC_ANG_RLL_P<4.5?' · más lenta que la de fábrica (4,5)':(P.ATC_ANG_RLL_P>4.5?' · más viva que la de fábrica (4,5)':'')));
  use('PSC_VELXY_P',function(v){ if(v>0) eff.velxyP=v; },'Ganancia P de velocidad horizontal: '+P.PSC_VELXY_P+' (fábrica 2,0)');
  use('PSC_VELXY_I',function(v){ if(v>=0) eff.velxyI=v; },'Ganancia I de velocidad horizontal: '+P.PSC_VELXY_I+' (fábrica 1,0)');
  use('PSC_VELZ_P',function(v){ if(v>0) eff.velzP=v; },'Ganancia P de velocidad vertical: '+P.PSC_VELZ_P+' (fábrica 5,0)');

  /* --- seguridad --- */
  use('FS_THR_ENABLE',function(v){ var m={0:'none',1:'rth',2:'none',3:'land',4:'rth',5:'land'}; eff.fsLink=m[v]||'rth'; },'Pérdida de enlace de radio: '+({0:'desactivado',1:'regreso a casa',2:'continuar misión (sin efecto en vuelo manual)',3:'aterrizar',4:'regreso a casa (SmartRTL)',5:'aterrizar (SmartRTL)'}[P.FS_THR_ENABLE]||'regreso a casa'));
  use('BATT_FS_LOW_ACT',function(v){ eff.battLowAct=actMap[v]||'none'; },'Batería baja → '+(actTxt[actMap[P.BATT_FS_LOW_ACT]||'none']));
  use('BATT_FS_CRT_ACT',function(v){ eff.battCrtAct=actMap[v]||'none'; },'Batería crítica → '+(actTxt[actMap[P.BATT_FS_CRT_ACT]||'none']));
  use('BATT_LOW_VOLT',function(v){ if(v>0) eff.battLowV=v; },'Umbral de batería baja: '+P.BATT_LOW_VOLT+' V en el pack');
  use('BATT_CRT_VOLT',function(v){ if(v>0) eff.battCrtV=v; },'Umbral de batería crítica: '+P.BATT_CRT_VOLT+' V en el pack');
  use('BATT_LOW_MAH',function(v){ if(v>0) eff.battLowMah=v; },'Batería baja si quedan < '+P.BATT_LOW_MAH+' mAh');
  use('BATT_CRT_MAH',function(v){ if(v>0) eff.battCrtMah=v; },'Batería crítica si quedan < '+P.BATT_CRT_MAH+' mAh');
  if(has(P,'FENCE_ENABLE')){
    used.FENCE_ENABLE=1; eff.fenceOn=P.FENCE_ENABLE===1; rows.push({n:'FENCE_ENABLE',v:P.FENCE_ENABLE,t:eff.fenceOn?'Geovalla activada':'Geovalla desactivada',c:'ok'});
    var ft=has(P,'FENCE_TYPE')?P.FENCE_TYPE:7; used.FENCE_TYPE=1;
    eff.fenceAltMax=(ft&1)?(has(P,'FENCE_ALT_MAX')?P.FENCE_ALT_MAX:100):0; eff.fenceRadius=(ft&2)?(has(P,'FENCE_RADIUS')?P.FENCE_RADIUS:300):0;
    if(has(P,'FENCE_TYPE')) rows.push({n:'FENCE_TYPE',v:P.FENCE_TYPE,t:'Tipos de valla: '+((ft&1)?'altura ':'')+((ft&2)?'círculo ':'')+((ft&4)?'polígono (no simulado) ':'')+((ft&8)?'altura mínima (no simulada)':''),c:'ok'});
    if(has(P,'FENCE_ALT_MAX')){ used.FENCE_ALT_MAX=1; rows.push({n:'FENCE_ALT_MAX',v:P.FENCE_ALT_MAX,t:'Altura máxima de la valla: '+P.FENCE_ALT_MAX+' m',c:'ok'}); }
    if(has(P,'FENCE_RADIUS')){ used.FENCE_RADIUS=1; rows.push({n:'FENCE_RADIUS',v:P.FENCE_RADIUS,t:'Radio de la valla: '+P.FENCE_RADIUS+' m',c:'ok'}); }
    var fa=has(P,'FENCE_ACTION')?P.FENCE_ACTION:1; used.FENCE_ACTION=1; eff.fenceAct=fa===0?'none':(fa===2?'land':'rth');
    if(has(P,'FENCE_ACTION')) rows.push({n:'FENCE_ACTION',v:P.FENCE_ACTION,t:'Al romper la valla: '+actTxt[eff.fenceAct],c:'ok'});
  }

  /* --- ala fija (Plane) --- */
  use('LIM_ROLL_CD',function(v){ if(v>0) eff.limRoll=v/100; },'Alabeo máximo: '+(P.LIM_ROLL_CD/100).toFixed(0)+'°');
  use('ARSPD_FBW_MIN',function(v){ if(v>0) eff.arspdMin=v; },'Velocidad mínima del aire: '+P.ARSPD_FBW_MIN+' m/s (aviso si baja de ahí)');
  info('ARSPD_FBW_MAX','Velocidad máxima del aire recomendada: '+P.ARSPD_FBW_MAX+' m/s');
  use('THR_MAX',function(v){ if(v>0) eff.thrMax=Math.min(1,v/100); },'Gas máximo permitido: '+P.THR_MAX+' %');
  info('TRIM_ARSPD_CM','Velocidad de crucero: '+(P.TRIM_ARSPD_CM/100).toFixed(1)+' m/s (referencia)');
  if(has(P,'ALT_HOLD_RTL')&&!has(P,'RTL_ALT')){ used.ALT_HOLD_RTL=1; eff.rtlAlt=P.ALT_HOLD_RTL/100; rows.push({n:'ALT_HOLD_RTL',v:P.ALT_HOLD_RTL,t:'Altura del regreso a casa (ala fija): '+(P.ALT_HOLD_RTL/100).toFixed(0)+' m',c:'ok'}); }


  /* --- Quadplane / tail-sitter (Q_*) --- */
  use('Q_ANGLE_MAX',function(v){ if(v>0) eff.angleMax=v/100; },'Inclinación máxima en VTOL: '+(P.Q_ANGLE_MAX/100).toFixed(0)+'°');
  use('Q_WP_SPEED',function(v){ if(v>0) eff.wpSpeed=v/100; },'Velocidad horizontal en VTOL (Q_WP_SPEED): '+(P.Q_WP_SPEED/100).toFixed(1)+' m/s');
  use('Q_LAND_SPEED',function(v){ if(v>0) eff.landSpeed=v/100; },'Velocidad de aterrizaje VTOL final: '+(P.Q_LAND_SPEED/100).toFixed(0)+' cm/s');
  use('Q_LAND_FINAL_SPD',function(v){ if(v>0) eff.landSpeed=v/100; },'Velocidad de aterrizaje VTOL final: '+P.Q_LAND_FINAL_SPD+' cm/s');
  use('Q_PILOT_SPD_UP',function(v){ if(v>0) eff.climbUp=v/100; },'Velocidad máx. de ascenso VTOL: '+(P.Q_PILOT_SPD_UP/100).toFixed(1)+' m/s');
  use('Q_PILOT_SPD_DN',function(v){ if(v>0) eff.climbDn=v/100; },'Velocidad máx. de descenso VTOL: '+(P.Q_PILOT_SPD_DN/100).toFixed(1)+' m/s');
  use('Q_RTL_ALT',function(v){ if(v>0) eff.rtlAlt=v; },'Altura del regreso a casa en VTOL: '+P.Q_RTL_ALT+' m');
  use('Q_TAILSIT_ANGLE',function(v){ if(v>5&&v<=85) eff.tsAngle=v; },'Ángulo de morro para dar por hecha la transición a adelante: '+P.Q_TAILSIT_ANGLE+'° (fábrica 60°)');
  use('Q_TAILSIT_ANG_VT',function(v){ if(v>=0&&v<=85) eff.tsAngVt=v; },'Ángulo de la transición a VTOL: '+P.Q_TAILSIT_ANG_VT+'° (0 = usa Q_TAILSIT_ANGLE)');
  use('Q_TAILSIT_RAT_FW',function(v){ if(v>0) eff.tsRatFw=v; },'Velocidad de la transición a adelante: '+P.Q_TAILSIT_RAT_FW+' °/s');
  use('Q_TAILSIT_RAT_VT',function(v){ if(v>0) eff.tsRatVt=v; },'Velocidad de la transición a VTOL: '+P.Q_TAILSIT_RAT_VT+' °/s');
  use('Q_TAILSIT_INPUT',function(v){ eff.tsInput=v; },'Mandos en VTOL: '+(P.Q_TAILSIT_INPUT===1?'tipo avión (alabeo/guiñada intercambiados respecto al cuerpo)':'tipo multicóptero'));
  use('Q_TAILSIT_MIN_VO',null,'Velocidad mínima de salida de la transición (sólo informativo)','info');
  ['Q_TAILSIT_MOTMX','Q_TAILSIT_THR_VT','Q_TAILSIT_VHGAIN','Q_TAILSIT_VFGAIN','Q_TAILSIT_VHPOW','Q_TAILSIT_GSCMSK','Q_TAILSIT_GSCMIN','Q_TAILSIT_RLL_MX','Q_TAILSIT_DSKLD','Q_TAILSIT_MIN_VO'].forEach(function(k){ info(k,'Ajuste fino real del tail-sitter: el simulador no lo emula (su control es ideal)'); });
  info('Q_A_ANGLE_BOOST','En tail-sitter debe ser 0 (el empuje no se compensa con la inclinación)');
  if(has(P,'Q_ENABLE')) info('Q_ENABLE','Quadplane '+(P.Q_ENABLE?'activado':'desactivado')+' (necesario para cualquier tail-sitter)');
  if(has(P,'Q_TAILSIT_ENABLE')) info('Q_TAILSIT_ENABLE',P.Q_TAILSIT_ENABLE===2?'Tail-sitter sin superficies de control (control como copter en todos los modos)':(P.Q_TAILSIT_ENABLE===1?'Tail-sitter con superficies de control':'Tail-sitter desactivado'));
  if(has(P,'Q_FRAME_CLASS')&&(has(P,'Q_TAILSIT_ENABLE')||has(P,'Q_ENABLE'))){ used.Q_FRAME_CLASS=1;
    var qc=P.Q_FRAME_CLASS, te=has(P,'Q_TAILSIT_ENABLE')?P.Q_TAILSIT_ENABLE:0, tid=null, ttx='';
    if(te>0){ if(te===2) tid='ts-quadpure'; else if(qc===7) tid='ts-tri'; else if(qc===1) tid='ts-quadsurf'; else if(qc===10) tid='ts-twin'; }
    ttx='Q_FRAME_CLASS: '+({1:'Quad',7:'Tri',10:'Single/Dual'}[qc]||'otro')+(tid?' → equivale a «'+SD.byId(SD.TYPES,tid).name+'»':'');
    rows.push({n:'Q_FRAME_CLASS',v:qc,t:ttx,c:'info'});
    if(tid&&ST.cfg.type!==tid&&SD.STD[tid]) sugg.push({t:'El archivo es de un tail-sitter distinto del que tienes seleccionado.',b:'Cambiar a «'+SD.byId(SD.TYPES,tid).name+'»',fn:function(){ ST.cfg.type=tid; var d=SD.STD[tid]; Object.keys(d).forEach(function(k){ ST.cfg[k]=d[k]; }); ST.cfg.type=tid; SIM.refreshAll(); }});
  }
  if(has(P,'Q_FRAME_TYPE')) info('Q_FRAME_TYPE','Disposición de motores del quadplane: sólo informativo');

  /* --- información que sirve para comprobar la aeronave --- */
  var V=SIM.validate? (function(){ try{ return SM.validate(ST.cfg); }catch(e){ return null; } })() : null, I=V&&V.info;
  var frameNames={1:'quad',2:'hexa',3:'octa',4:'octa',5:'hexa',6:'heli',7:'tri',13:'heli',15:'heli'}, typeNames={quad:'cuadricóptero',hexa:'hexacóptero',octa:'octocóptero',tri:'tricóptero',heli:'helicóptero'};
  if(has(P,'FRAME_CLASS')){ used.FRAME_CLASS=1; var ty=frameNames[P.FRAME_CLASS]; var stdKey={quad:'quad',hexa:'hexa',octa:'octo',tri:'tri',heli:'heli'}[ty];
    rows.push({n:'FRAME_CLASS',v:P.FRAME_CLASS,t:'Configuración de la aeronave: '+(typeNames[ty]||'no reconocida'),c:'info'});
    if(stdKey&&SD.STD[stdKey]&&ST.cfg.type!==stdKey) sugg.push({t:'El archivo es de un '+typeNames[ty]+' y tu aeronave es otra.',b:'Cambiar a '+typeNames[ty]+' estándar',fn:function(){ ST.cfg.type=stdKey; Object.assign(ST.cfg,JSON.parse(JSON.stringify(SD.STD[stdKey]))); SIM.refreshAll(); }}); }
  if(has(P,'FRAME_TYPE')) info('FRAME_TYPE','Disposición de motores (X, +, V…): sólo informativo');
  if(has(P,'MOT_BAT_VOLT_MAX')){ used.MOT_BAT_VOLT_MAX=1; var cells=Math.round(P.MOT_BAT_VOLT_MAX/4.2); rows.push({n:'MOT_BAT_VOLT_MAX',v:P.MOT_BAT_VOLT_MAX,t:'Tensión máxima del pack ≈ '+(cells>=1?cells+'S':'?')+' (4,2 V por celda)',c:'info'});
    if(cells>=1&&cells<=12&&cells!==ST.cfg.cells) sugg.push({t:'El archivo corresponde a una batería de '+cells+'S y la tuya es de '+ST.cfg.cells+'S.',b:'Poner '+cells+'S',fn:function(){ ST.cfg.cells=cells; SIM.refreshAll(); }}); }
  info('MOT_BAT_VOLT_MIN','Tensión mínima del pack para el cálculo de empuje: '+P.MOT_BAT_VOLT_MIN+' V');
  if(has(P,'BATT_CAPACITY')){ used.BATT_CAPACITY=1; var cap=P.BATT_CAPACITY, best=SD.CAPS.reduce(function(a,c){ return Math.abs(c-cap)<Math.abs(a-cap)?c:a; },SD.CAPS[0]);
    rows.push({n:'BATT_CAPACITY',v:cap,t:'Capacidad de la batería: '+cap+' mAh'+(best!==ST.cfg.cap?' (tu configuración: '+ST.cfg.cap+' mAh)':''),c:'info'});
    if(best!==ST.cfg.cap) sugg.push({t:'El archivo indica '+cap+' mAh y tu batería es de '+ST.cfg.cap+' mAh.',b:'Poner '+best+' mAh',fn:function(){ ST.cfg.cap=best; SIM.refreshAll(); }}); }
  if(has(P,'MOT_THST_HOVER')){ used.MOT_THST_HOVER=1; var hov=I&&I.hoverThr; var tx='Gas de estacionario del archivo: '+(P.MOT_THST_HOVER*100).toFixed(0)+' %'; var cl='info';
    if(hov){ tx+=' · el de tu aeronave: '+(hov*100).toFixed(0)+' %'; if(Math.abs(hov-P.MOT_THST_HOVER)>0.12){ cl='warn'; tx+=' · '+(hov>P.MOT_THST_HOVER?'tu aeronave tiene menos potencia sobrante que la del archivo':'tu aeronave tiene más potencia sobrante que la del archivo'); } }
    rows.push({n:'MOT_THST_HOVER',v:P.MOT_THST_HOVER,t:tx,c:cl}); }
  /* viento del simulador SITL */
  if(has(P,'SIM_WIND_SPD')||has(P,'SIM_WIND_DIR')||has(P,'SIM_WIND_TURB')){
    ['SIM_WIND_SPD','SIM_WIND_DIR','SIM_WIND_TURB'].forEach(function(k){ if(has(P,k)){ used[k]=1; rows.push({n:k,v:P[k],t:k==='SIM_WIND_SPD'?'Viento medio: '+P[k]+' m/s':(k==='SIM_WIND_DIR'?'Procedencia del viento: '+P[k]+'°':'Turbulencia: '+P[k]+' m/s'),c:'info'}); } });
    sugg.push({t:'El archivo define un viento de prueba (SITL).',b:'Aplicar el viento del archivo',fn:function(){ var w=ST.wx; if(has(P,'SIM_WIND_SPD')) w.wind=Math.max(0,Math.min(25,P.SIM_WIND_SPD)); if(has(P,'SIM_WIND_DIR')) w.dir=((P.SIM_WIND_DIR%360)+360)%360; if(has(P,'SIM_WIND_TURB')) w.turb=Math.max(0,Math.min(1,P.SIM_WIND_TURB/5)); ST.wxId='custom'; SIM.refreshAll(); }}); }
  var ignored=R.order.filter(function(k){ return !used[k]; });
  return {eff:eff,rows:rows,sugg:sugg,ignored:ignored,total:R.order.length,bad:R.bad};
};


/* generador de .param orientativo para cada variante tail-sitter */
AP.tsParams=function(tid){
  var d=SD.TS[tid]; if(!d) return '';
  var L=['# SANT·SIM — parámetros ORIENTATIVOS de ArduPlane para: '+SD.byId(SD.TYPES,tid).name,
   '# Revísalos con la documentación de ArduPilot antes de volar de verdad (versión de firmware, orden de salidas, sentido de giro de motores).',
   'Q_ENABLE,1','Q_TAILSIT_ENABLE,'+d.enable,'Q_FRAME_CLASS,'+d.cls,'Q_FRAME_TYPE,'+d.typ,'Q_TAILSIT_MOTMX,'+d.motmx,
   'Q_TAILSIT_ANGLE,'+SM.tsDefaults.angle,'Q_TAILSIT_ANG_VT,0','Q_TAILSIT_RAT_FW,'+SM.tsDefaults.ratFw,'Q_TAILSIT_RAT_VT,'+SM.tsDefaults.ratVt,
   'Q_TAILSIT_INPUT,'+(d.enable===2?0:1),'Q_A_ANGLE_BOOST,0','Q_ANGLE_MAX,3000','Q_WP_SPEED,500','Q_LAND_SPEED,50','Q_RTL_ALT,30','Q_RTL_MODE,1','Q_TAILSIT_THR_VT,-1',
   'KFF_RDDRMIX,0.5','LIM_ROLL_CD,4500','ARSPD_FBW_MIN,13','TRIM_ARSPD_CM,1800','THR_MAX,100','RTL_AUTOLAND,0'];
  L.push('# Salidas (SERVOn_FUNCTION): '+d.outputs);
  if(tid==='ts-single'){ L.push('SERVO1_FUNCTION,70','SERVO2_FUNCTION,77','SERVO3_FUNCTION,78'); }
  else if(tid==='ts-twin'||tid==='ts-twinvec'){ L.push('SERVO1_FUNCTION,73','SERVO2_FUNCTION,74','SERVO3_FUNCTION,77','SERVO4_FUNCTION,78'); if(tid==='ts-twinvec') L.push('# Servos de inclinación de los motores en SERVO5/6: asigna la función «Tilt» que corresponda a tu firmware'); }
  else if(tid==='ts-tri'){ L.push('SERVO1_FUNCTION,33','SERVO2_FUNCTION,34','SERVO3_FUNCTION,35','SERVO4_FUNCTION,77','SERVO5_FUNCTION,78','# Motor 3 (cola/inferior) con servo de guiñada según Q_FRAME_TYPE'); }
  else if(tid==='ts-quadsurf'){ L.push('SERVO1_FUNCTION,33','SERVO2_FUNCTION,34','SERVO3_FUNCTION,35','SERVO4_FUNCTION,36','SERVO5_FUNCTION,77','SERVO6_FUNCTION,78'); }
  else { L.push('SERVO1_FUNCTION,33','SERVO2_FUNCTION,34','SERVO3_FUNCTION,35','SERVO4_FUNCTION,36'); }
  return L.join('\n')+'\n';
};
AP.tsHint=function(){
  var el=$('tsHint'); if(!el) return; var tid=ST.cfg.type, d=SD.TS[tid];
  if(!d){ el.style.display='none'; el.innerHTML=''; return; }
  el.style.display='';
  el.innerHTML='<div class="note" style="margin-top:10px;border-top:1px solid var(--line);padding-top:8px"><b>Configuración ArduPilot (ArduPlane + Quadplane)</b><br>'+
   '<code>Q_ENABLE=1</code> · <code>Q_TAILSIT_ENABLE='+d.enable+'</code> · <code>Q_FRAME_CLASS='+d.cls+'</code> ('+d.clsName+') · <code>Q_FRAME_TYPE='+d.typ+'</code> · <code>Q_TAILSIT_MOTMX='+d.motmx+'</code><br>'+
   'Salidas: '+d.outputs+'. En vuelo adelante empujan '+d.fw+' motor'+(d.fw>1?'es':'')+(d.vec?' · empuje vectorial con servos de inclinación':'')+(d.diff?' · guiñada por empuje diferencial':'')+'.<br>'+
   'En vuelo: tecla <b>V</b> (o el botón de fase) para pasar de VTOL a adelante y viceversa. <button class="btn" id="bTsPar" type="button" style="margin-left:6px">Descargar .param orientativo</button></div>';
  $('bTsPar').onclick=function(){ var b=new Blob([I18N.tr(AP.tsParams(tid))],{type:'text/plain'}), a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='santsim_'+tid+'.param'; document.body.appendChild(a); a.click(); setTimeout(function(){ URL.revokeObjectURL(a.href); a.remove(); },500); };
};
/* efectos activos (null si no hay archivo cargado o está desactivado) */
var cacheT=null, cacheE=null;
SIM.apEff=function(){
  if(!ST.apOn||!ST.apText) return null;
  if(cacheT!==ST.apText){ cacheT=ST.apText; cacheE=AP.build(ST.apText).eff; }
  return cacheE;
};

function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }
function render(){
  var out=$('apOut'); if(!out) return;
  if(!ST.apText){ out.innerHTML='<div class="note" style="margin-top:0">Carga un archivo <b>.param</b> (Mission Planner, QGroundControl o el de la propia controladora) o pega el texto. El simulador aplica a la aeronave lo que sabe imitar y te cuenta qué ignora.</div>'; $('apState').textContent='Sin parámetros cargados: se usa el comportamiento por defecto del simulador.'; return; }
  var B=AP.build(ST.apText);
  $('apState').innerHTML=(ST.apOn?'<b style="color:var(--green)">✔ Activos</b>':'<b style="color:var(--amber)">En pausa (desactivados)</b>')+' · '+B.total+' parámetros leídos'+(B.bad?' ('+B.bad+' líneas no válidas)':'')+' · '+B.rows.length+' reconocidos · '+B.ignored.length+' sin efecto en el simulador';
  var h='';
  if(B.sugg.length){ h+='<h4 class="aph">Para parecerse más a esa aeronave</h4>'; B.sugg.forEach(function(s,i){ h+='<div class="apsg"><span>'+esc(s.t)+'</span><button class="btn" data-sg="'+i+'">'+esc(s.b)+'</button></div>'; }); }
  h+='<h4 class="aph">Parámetros reconocidos</h4><table class="aptb"><tr><th>Parámetro</th><th>Valor</th><th>Efecto en el simulador</th></tr>';
  B.rows.forEach(function(r){ h+='<tr class="'+r.c+'"><td><code>'+esc(r.n)+'</code></td><td>'+esc(r.v)+'</td><td>'+esc(r.t)+'</td></tr>'; });
  h+='</table>';
  if(B.ignored.length) h+='<details class="apign"><summary>'+B.ignored.length+' parámetros sin efecto en el simulador (sensores, calibraciones, canales, modos de vuelo…)</summary><div>'+B.ignored.map(function(k){return '<code>'+esc(k)+'</code>';}).join(' ')+'</div></details>';
  out.innerHTML=h; out._sg=B.sugg;
}
function setText(t,name){ ST.apText=t; ST.apOn=!!t; $('apOn').checked=ST.apOn; $('apText').value=t; $('apName').textContent=name||''; render(); SIM.save(); }
SIM.apInit=function(){
  var ta=$('apText'); ta.value=ST.apText||''; render(); $('apOn').checked=ST.apOn;
  $('apFile').onchange=function(e){ var f=e.target.files[0]; if(!f) return; var rd=new FileReader(); rd.onload=function(){ setText(String(rd.result),f.name); }; rd.readAsText(f); e.target.value=''; };
  $('bApApply').onclick=function(){ setText(ta.value,'texto pegado'); };
  $('bApClear').onclick=function(){ setText('',''); };
  $('apOn').onchange=function(){ ST.apOn=$('apOn').checked&&!!ST.apText; render(); SIM.save(); };
  $('apOut').onclick=function(e){ var b=e.target.closest&&e.target.closest('button[data-sg]'); if(!b) return; var s=$('apOut')._sg[+b.dataset.sg]; if(s){ s.fn(); render(); } };
};
})();
