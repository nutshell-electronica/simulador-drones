/* ============ FOTOGRAMETRÍA: planificador, misión manual guiada e informe ============ */
var ST=SIM.ST;
var PH={run:false,shots:[],plan:null,cov:null,last:null,done:false,c1:0,c3:0,nCell:0,lastX:null,lastZ:null,lastT:-9,hudT:0};
var PHCAM={
  mini4:{n:'DJI Mini 4 Pro (1/1,3″, 48 MP)',sw:9.6,iw:8064,ih:6048,f:6.7,tmin:2.0},
  air3s:{n:'DJI Air 3S (1″, 50 MP)',sw:13.2,iw:8192,ih:6144,f:8.9,tmin:2.0},
  mavic4:{n:'DJI Mavic 4 Pro (4/3″, 100 MP)',sw:17.3,iw:11648,ih:8736,f:12,tmin:2.0},
  m350:{n:'Matrice 350 + Zenmuse P1 (full frame, 45 MP)',sw:35.9,iw:8192,ih:5460,f:35,tmin:0.7},
  ebee:{n:'eBee X + S.O.D.A. (1″, 20 MP)',sw:13.2,iw:5472,ih:3648,f:10.6,tmin:1.5},
  gen1:{n:'Genérica 1″ de 20 MP',sw:13.2,iw:5472,ih:3648,f:8.8,tmin:1.5},
  gen2:{n:'Genérica 1/2,3″ de 12 MP',sw:6.17,iw:4000,ih:3000,f:4.5,tmin:2.5}
};
var PHDEF={on:false,cam:'auto',mode:'gsd',gsd:3,alt:80,front:80,side:70,shutter:1000,vel:0,e:0,n:150,w:200,l:200,ang:0};
SIM.photoOK=function(id){ var m=SW.LIST.filter(function(x){return x.id===(id||ST.scn);})[0]; return !!(m&&m.photo); };
var PHW={id:null,w:null};
function phWorld(){ if(PHW.id!==ST.scn){ PHW.w=SW.make(ST.scn); PHW.id=ST.scn; } return PHW.w; }
function phP(){ ST.photo=Object.assign({},PHDEF,ST.photo||{}); return ST.photo; }
function phCamId(V){
  var P=phP(); if(P.cam!=='auto') return P.cam; var cm=V.ac.cm;
  if(cm){ var m={'dji-mini4pro':'mini4','dji-mini5pro':'mini4','dji-air3s':'air3s','dji-mavic4pro':'mavic4','dji-m350':'m350','ebee-x':'ebee'}[cm.id]; if(m) return m; return 'gen1'; }
  return 'gen2';
}
function phHasCam(V){ return !!V.ac.cm || V.ac.has('camhd'); }
/* ---- cálculo de la misión (puro) ---- */
SIM.photoPlan=function(){
  var V=SIM.validate(), I=V.info, ac=V.ac, P=phP(), w=phWorld(), wx=ST.wx, fixed=(ac.kind==='fixed'), D2R=Math.PI/180;
  var cam=PHCAM[phCamId(V)], pix=cam.sw/cam.iw, texp=1/P.shutter, A=P.ang*D2R;
  var gsd,alt; if(P.mode==='gsd'){ gsd=P.gsd/100; alt=gsd*cam.f/pix; } else { alt=P.alt; gsd=alt*pix/cam.f; }
  var Wg=gsd*cam.iw, Hg=gsd*cam.ih, front=P.front/100, side=P.side/100;
  var lineSp=Wg*(1-side), phSp=Hg*(1-front);
  var nL=Math.max(1,Math.ceil(P.w/lineSp)+1), ls=nL>1?P.w/(nL-1):0;
  var ext=phSp, L=P.l+2*ext, nPh=Math.max(2,Math.ceil(L/phSp)+1);
  var vmaxD=ac.spec?ac.spec.vmax:(ac.kind==='heli'?14:16);
  var wl=Math.abs(wx.wind*Math.cos((wx.dir-P.ang)*D2R)), wt=wx.wind+(wx.gust||0);
  var vCam=phSp/cam.tmin, vBlur=0.5*gsd/texp, v, vg;
  if(fixed){ v=I.cruiseV||12; vg=v+wl; }
  else { v=P.vel>0?P.vel:Math.max(1,Math.min(0.9*vCam,0.85*vmaxD,vBlur)); vg=v; }
  var blur=vg*texp/gsd, interval=phSp/vg;
  /* geometría: centro y ejes locales */
  var cx=w.home.x+P.e, cz=w.home.z-P.n, rx=Math.cos(A), rz=Math.sin(A), dx=Math.sin(A), dz=-Math.cos(A);
  function W2(u,vv){ return {x:cx+u*rx+vv*dx, z:cz+u*rz+vv*dz}; }
  var wps=[], ph=[];
  for(var i=0;i<nL;i++){ var u=-P.w/2+i*ls, dir=(i%2===0)?1:-1, a=W2(u,-dir*L/2), b=W2(u,dir*L/2); wps.push(a,b);
    for(var j=0;j<nPh;j++){ var vv=-dir*L/2+dir*j*(L/(nPh-1)); ph.push(W2(u,vv)); } }
  var dLine=nL*L, dTurn=(nL-1)*ls, dIn=Math.hypot(wps[0].x-w.home.x,wps[0].z-w.home.z), dOut=Math.hypot(wps[wps.length-1].x-w.home.x,wps[wps.length-1].z-w.home.z);
  var turnT=fixed?25:4, vT=Math.min(vmaxD*0.7,10);
  var tMis=dLine/vg+(nL-1)*turnT+(fixed?nL*120/vg:0), tTr=(dIn+dOut)/vT, tVert=alt/3*2+45;
  var Ttot=(tMis+tTr+tVert)/60*(wl>5?1.1:1);
  var usable=fixed?I.cruiseMin:I.hoverMin*0.92, packs=Math.max(1,Math.ceil(Ttot/(usable*0.9)));
  /* terreno y obstáculos en la zona */
  var gmin=1e9,gmax=-1e9,gs=0,gn=0,water=0,maxTop=-1e9,maxObs=null,k,m;
  for(i=0;i<=10;i++)for(j=0;j<=10;j++){ var q=W2(-P.w/2+P.w*i/10,-P.l/2+P.l*j/10), h=w.terrainH(q.x,q.z); gmin=Math.min(gmin,h); gmax=Math.max(gmax,h); gs+=h; gn++; if(w.isWater&&w.isWater(q.x,q.z)) water++; }
  var gm=gs/gn, h0=w.terrainH(w.home.x,w.home.z), altTO=alt+(gm-h0), flyY=gm+alt;
  (w.obstacles||[]).forEach(function(o){ var rr=Math.max(o.rx||o.dx||0,o.rz||0), tx=o.x-cx, tz=o.z-cz, u=tx*rx+tz*rz, vv=tx*dx+tz*dz;
    if(Math.abs(u)<=P.w/2+rr&&Math.abs(vv)<=P.l/2+rr&&o.top>maxTop){ maxTop=o.top; maxObs=o; } });
  var far=0; wps.forEach(function(p){ far=Math.max(far,Math.hypot(p.x-w.home.x,p.z-w.home.z)); });
  var vlos=SIM.hud.vlosLimit({ac:ac},wx), sun=SIM.sunAt(SIM.flightMs()).el;
  var C=[]; function ck(l,t){ C.push({l:l,t:t}); }
  if(!phHasCam(V)) ck('bad','Esta aeronave no lleva cámara: añade la «Cámara 4K con gimbal» en la pestaña de configuración.');
  if(alt>120) ck('bad','Altura de '+alt.toFixed(0)+' m: supera el límite de 120 m de la categoría abierta. Sube el GSD o baja la altura.');
  else if(alt<15) ck('warn','Altura de '+alt.toFixed(0)+' m: muy baja, cualquier árbol o mástil es un riesgo.');
  else ck('ok','Altura de vuelo '+alt.toFixed(0)+' m sobre el terreno (dentro de los 120 m).');
  if(ac.spec&&ac.spec.ceiling&&altTO>ac.spec.ceiling) ck('bad','La altura supera el techo de servicio de la aeronave ('+ac.spec.ceiling+' m).');
  if(maxObs&&maxTop>flyY-10) ck('bad','Obstáculo en la zona ('+(maxObs.label||maxObs.kind)+', '+(maxTop-gm).toFixed(0)+' m sobre el suelo): la altura del plan no deja 10 m de margen.');
  else if(maxObs) ck('ok','Obstáculo más alto de la zona: '+(maxTop-gm).toFixed(0)+' m, con margen suficiente.');
  else ck('ok','Sin obstáculos dentro de la zona.');
  if(vg>vmaxD+0.01) ck('bad','Velocidad de misión '+vg.toFixed(1)+' m/s: la aeronave sólo alcanza '+vmaxD.toFixed(0)+' m/s.');
  if(interval<cam.tmin-0.01) ck('bad','Disparo cada '+interval.toFixed(1)+' s, pero esta cámara necesita al menos '+cam.tmin+' s. Reduce la velocidad, sube la altura o baja el solape longitudinal.');
  else ck('ok','Intervalo entre fotos '+interval.toFixed(1)+' s (mínimo de la cámara '+cam.tmin+' s).');
  if(blur>1.5) ck('bad','Desenfoque de movimiento de '+blur.toFixed(1)+' píxeles: las fotos saldrán movidas. Usa obturador más rápido o vuela más despacio.');
  else if(blur>0.5) ck('warn','Desenfoque de movimiento de '+blur.toFixed(1)+' píxeles (lo recomendable es ≤ 0,5).');
  else ck('ok','Desenfoque de movimiento '+blur.toFixed(2)+' píxeles (correcto).');
  if(!fixed&&P.vel===0&&v<2) ck('warn','La velocidad automática sale muy baja ('+v.toFixed(1)+' m/s): la misión será larguísima. Aumenta el GSD o baja el solape.');
  if(wt>0.8*vmaxD) ck('bad','Viento con rachas de '+wt.toFixed(0)+' m/s: la aeronave no puede mantener las líneas de vuelo.');
  else if(wt>8) ck('warn','Viento con rachas de '+wt.toFixed(0)+' m/s: desviará las líneas y empeora los solapes.');
  else ck('ok','Viento tolerable ('+wt.toFixed(0)+' m/s con rachas).');
  if(fixed&&wl>0.4*v) ck('warn','Viento de cara/cola de '+wl.toFixed(0)+' m/s: la velocidad sobre el suelo cambiará mucho entre líneas.');
  if(wx.rain>0) ck('bad','Con lluvia no se debe hacer fotogrametría (lente, motores y calidad de imagen).');
  if(wx.vis<3) ck('bad','Visibilidad de '+wx.vis+' km: insuficiente.'); else if(wx.vis<8) ck('warn','Visibilidad de '+wx.vis+' km: las fotos saldrán con velo.');
  if(sun<5) ck('bad','Sol a '+sun.toFixed(0)+'° o por debajo del horizonte: no hay luz para fotogrametría.');
  else if(sun<15) ck('warn','Sol bajo ('+sun.toFixed(0)+'°): sombras muy largas que confunden la reconstrucción. Lo ideal es más de 25°.');
  else ck('ok','Elevación del Sol '+sun.toFixed(0)+'° (buena luz).');
  if(far>vlos) ck('bad','Hay puntos a '+far.toFixed(0)+' m del despegue y tu límite de vuelo a la vista es de '+vlos.toFixed(0)+' m: se saldría de VLOS.');
  else ck('ok','Toda la zona está dentro del alcance visual ('+far.toFixed(0)+' m frente a '+vlos.toFixed(0)+' m).');
  if(packs>1) ck(packs>4?'bad':'warn','La misión dura unos '+Ttot.toFixed(0)+' min y una batería da ~'+(usable*0.9).toFixed(0)+' min útiles: harán falta '+packs+' baterías ('+(packs-1)+' relevo'+(packs>2?'s':'')+') o dividir la zona.');
  else ck('ok','Cabe en una batería: '+Ttot.toFixed(0)+' min de misión frente a '+(usable*0.9).toFixed(0)+' min útiles.');
  var rel=gmax-gmin; if(rel>0.2*alt) ck('warn','Desnivel de '+rel.toFixed(0)+' m en la zona ('+(100*rel/alt).toFixed(0)+' % de la altura): el GSD variará mucho. Planifica siguiendo el terreno.');
  var wf=water/gn; if(wf>0.7) ck('bad','Más del 70 % de la zona es agua: no hay puntos de enlace y no se reconstruye.'); else if(wf>0.3) ck('warn','Un '+(100*wf).toFixed(0)+' % de la zona es agua: esa parte saldrá con huecos.');
  if(ST.people) ck('warn','Hay personas en el escenario: no se puede sobrevolar a personas no participantes.');
  if(nPh*nL>2000) ck('warn','Volumen: '+(nPh*nL)+' fotos; el procesado será muy pesado. Divide la zona en bloques.');
  if(I.needReg) ck('info','Esta aeronave con cámara exige registro de operador y seguro para volar.');
  var verdict=C.some(function(c){return c.l==='bad';})?'bad':(C.some(function(c){return c.l==='warn';})?'warn':'ok');
  return {cam:cam,camId:phCamId(V),pix:pix,gsd:gsd,alt:alt,altTO:altTO,Wg:Wg,Hg:Hg,front:front,side:side,lineSp:lineSp,lineReal:ls,phSp:phSp,nL:nL,nPh:nPh,total:nL*nPh,
    v:v,vg:vg,vmaxD:vmaxD,vCam:vCam,vBlur:vBlur,blur:blur,interval:interval,dist:dLine+dTurn+dIn+dOut,tMis:tMis,Ttot:Ttot,usable:usable,packs:packs,
    area:P.w*P.l/10000,relief:rel,sun:sun,far:far,vlos:vlos,wps:wps,ph:ph,cx:cx,cz:cz,ang:P.ang,w:P.w,l:P.l,home:{x:w.home.x,z:w.home.z},checks:C,verdict:verdict,fixed:fixed,
    shutter:P.shutter,tmin:cam.tmin,gm:gm,h0:h0,front0:P.front,side0:P.side};
};
SIM.photoCSV=function(){
  var p=SIM.photoPlan(), la=ST.lat, lo=ST.lon, cl=Math.cos(la*Math.PI/180), s='punto;lat;lon;altura_sobre_despegue_m;velocidad_ms;foto\n';
  p.ph.forEach(function(q,i){ s+=(i+1)+';'+(la-(q.z-p.home.z)/111320).toFixed(7)+';'+(lo+(q.x-p.home.x)/(111320*cl)).toFixed(7)+';'+p.altTO.toFixed(1)+';'+p.vg.toFixed(1)+';1\n'; });
  return s;
};
function phDownload(name,txt){ var a=document.createElement('a'); a.href=URL.createObjectURL(new Blob(['﻿'+txt],{type:'text/csv'})); a.download=name; document.body.appendChild(a); a.click(); setTimeout(function(){ URL.revokeObjectURL(a.href); a.remove(); },500); }
/* ---- interfaz del hangar ---- */
var PHV={cv:null,ras:null,rasScn:null};
function phNum(id,lbl,val,min,max,step,unit){ return '<div class="row"><label>'+lbl+'</label><div class="val"><input type="number" id="'+id+'" value="'+val+'" min="'+min+'" max="'+max+'" step="'+step+'" style="width:90px">'+(unit?'<span>'+unit+'</span>':'')+'</div></div>'; }
SIM.photoUI=function(){
  var el=document.getElementById('phUI'); if(!el) return;
  if(!SIM.photoOK()){ el.innerHTML='<div class="card" style="grid-column:1/-1"><h3>Fotogrametría</h3><div class="bd"><div class="note"><b>Este escenario no admite fotogrametría.</b> Elige uno marcado con la cinta de cámara en la pestaña Escenario (campo, bosque, montaña, costa, Guadalhorce, barrio, ciudad o muelle). Los escenarios de interior, de fantasía y el aeropuerto no sirven: o no hay terreno que cartografiar o no tiene sentido hacerlo.</div></div></div>'; return; }
  var P=phP(), h='';
  h+='<div><div class="card"><h3>Cámara y calidad</h3><div class="bd">';
  h+='<div class="row"><label>Cámara</label><select id="phCam"><option value="auto">Automática (según la aeronave)</option>'+Object.keys(PHCAM).map(function(k){return '<option value="'+k+'">'+PHCAM[k].n+'</option>';}).join('')+'</select></div>';
  h+='<div class="note" id="phCamI"></div>';
  h+='<div class="row"><label>Fijar</label><select id="phMode"><option value="gsd">Resolución en el suelo (GSD)</option><option value="alt">Altura de vuelo</option></select></div>';
  h+=phNum('phGsd','GSD (cm/píxel)',P.gsd,0.3,15,0.1,'cm/px')+phNum('phAlt','Altura (m)',P.alt,10,300,1,'m');
  h+='<div class="row"><label>Solape longitudinal</label><div class="val"><input type="range" id="phFr" min="60" max="92" step="1"><span id="phFrV"></span></div></div>';
  h+='<div class="row"><label>Solape lateral</label><div class="val"><input type="range" id="phSd" min="40" max="85" step="1"><span id="phSdV"></span></div></div>';
  h+='<div class="row"><label>Obturador</label><select id="phSh"><option value="500">1/500 s</option><option value="1000">1/1000 s</option><option value="2000">1/2000 s</option><option value="4000">1/4000 s</option></select></div>';
  h+=phNum('phVel','Velocidad (m/s; 0 = auto)',P.vel,0,25,0.5,'m/s');
  h+='</div></div><div class="card"><h3>Zona a cartografiar</h3><div class="bd">';
  h+=phNum('phE','Centro: este (m)',P.e,-1500,1500,5,'m')+phNum('phN','Centro: norte (m)',P.n,-1500,1500,5,'m')+phNum('phW','Ancho (m)',P.w,30,600,10,'m')+phNum('phL','Largo (m)',P.l,30,600,10,'m')+phNum('phAng','Rumbo de las líneas (°)',P.ang,0,179,5,'°');
  h+='<div class="pre" style="margin:4px 0"><button class="btn" id="phCtr">Centrar frente al despegue</button><button class="btn" id="phCsv">Exportar puntos (CSV)</button></div>';
  h+='<div class="row"><label>Misión en el próximo vuelo</label><div class="val"><input type="checkbox" id="phOn"><span>Vuelo manual guiado con intervalómetro</span></div></div>';
  h+='<div class="pre" style="margin:4px 0"><button class="btn" id="phRep">Ver informe del último vuelo</button></div>';
  h+='<div class="note">Datos de las cámaras aproximados, con fines didácticos. Aquí se <b>valora</b> si la misión automática sería viable con estos parámetros; el vuelo lo haces tú a mano, con las líneas y las fotos guiadas en el minimapa.</div>';
  h+='</div></div></div>';
  h+='<div><div class="card"><h3>Vista previa</h3><div class="bd"><canvas id="phCv" width="420" height="420" style="width:100%;max-width:420px;border:1px solid var(--line2);cursor:crosshair"></canvas><div class="note">Pulsa en el mapa para colocar el centro de la zona. Amarillo = despegue, naranja = líneas de vuelo, puntos negros = fotos.</div></div></div>';
  h+='<div class="card"><h3>Resultado del plan</h3><div class="bd" id="phRes"></div></div></div>';
  el.innerHTML=h;
  var $p=function(i){return document.getElementById(i);};
  $p('phCam').value=P.cam; $p('phMode').value=P.mode; $p('phSh').value=String(P.shutter); $p('phFr').value=P.front; $p('phSd').value=P.side; $p('phOn').checked=!!P.on;
  function upd(){ SIM.save(); phRes(); }
  function bindN(id,key,f){ $p(id).onchange=function(){ var v=+$p(id).value; if(!isFinite(v)) v=PHDEF[key]; var a=$p(id); v=Math.max(+a.min,Math.min(+a.max,v)); a.value=v; phP()[key]=f?f(v):v; upd(); }; }
  bindN('phGsd','gsd'); bindN('phAlt','alt'); bindN('phVel','vel'); bindN('phE','e'); bindN('phN','n'); bindN('phW','w'); bindN('phL','l'); bindN('phAng','ang');
  $p('phCam').onchange=function(){ phP().cam=$p('phCam').value; upd(); };
  $p('phMode').onchange=function(){ phP().mode=$p('phMode').value; upd(); };
  $p('phSh').onchange=function(){ phP().shutter=+$p('phSh').value; upd(); };
  $p('phFr').oninput=function(){ phP().front=+$p('phFr').value; upd(); };
  $p('phSd').oninput=function(){ phP().side=+$p('phSd').value; upd(); };
  $p('phOn').onchange=function(){ phP().on=$p('phOn').checked; SIM.save(); };
  $p('phCtr').onclick=function(){ var P=phP(); P.e=0; P.n=Math.round(Math.max(P.l,P.w)/2+40); $p('phE').value=P.e; $p('phN').value=P.n; upd(); };
  $p('phCsv').onclick=function(){ phDownload('fotogrametria_puntos.csv',SIM.photoCSV()); };
  $p('phRep').onclick=function(){ if(PH.last) phReport(PH.last,true); else { var b=$p('phRep'); b.textContent='Aún no hay ningún vuelo con misión'; setTimeout(function(){ b.textContent='Ver informe del último vuelo'; },2200); } };
  PHV.cv=$p('phCv'); PHV.cv.onclick=function(e){ var r=PHV.cv.getBoundingClientRect(), v=PHV.view; if(!v) return; var x=(e.clientX-r.left)/r.width*PHV.cv.width, y=(e.clientY-r.top)/r.height*PHV.cv.height, w=phWorld(), P=phP();
    var wx=v.cx+(x/PHV.cv.width-0.5)*2*v.half, wz=v.cz+(y/PHV.cv.height-0.5)*2*v.half; P.e=Math.round((wx-w.home.x)/5)*5; P.n=Math.round(-(wz-w.home.z)/5)*5; $p('phE').value=P.e; $p('phN').value=P.n; upd(); };
  phRes();
};
function phRes(){
  var el=document.getElementById('phRes'); if(!el||!SIM.photoOK()) return; var p=SIM.photoPlan(), P=phP();
  document.getElementById('phGsd').disabled=(P.mode!=='gsd'); document.getElementById('phAlt').disabled=(P.mode!=='alt');
  document.getElementById('phFrV').textContent=P.front+' %'; document.getElementById('phSdV').textContent=P.side+' %';
  document.getElementById('phCamI').textContent='Sensor '+p.cam.sw+' mm de ancho · '+p.cam.iw+'×'+p.cam.ih+' px · focal '+p.cam.f+' mm · disparo mínimo cada '+p.cam.tmin+' s';
  function c(l,v){ return '<div><label>'+l+'</label><b>'+v+'</b></div>'; }
  var vt={ok:['VIABLE','#1b7a3a'],warn:['VIABLE CON AVISOS','#8a5500'],bad:['NO VIABLE','#b3261e']}[p.verdict];
  var h='<div style="font:700 16px/1.2 Arial;letter-spacing:.06em;color:'+vt[1]+';margin-bottom:6px">'+vt[0]+'</div><div class="cells" style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px 10px;font-size:12px">'
   +c('GSD',(p.gsd*100).toFixed(2)+' cm/px')+c('Altura',p.alt.toFixed(0)+' m')+c('Huella',p.Wg.toFixed(0)+'×'+p.Hg.toFixed(0)+' m')
   +c('Entre líneas',p.lineReal.toFixed(0)+' m')+c('Entre fotos',p.phSp.toFixed(1)+' m')+c('Líneas',p.nL)
   +c('Fotos',p.total)+c('Velocidad',p.vg.toFixed(1)+' m/s')+c('Intervalo',p.interval.toFixed(1)+' s')
   +c('Distancia',(p.dist/1000).toFixed(2)+' km')+c('Duración',p.Ttot.toFixed(0)+' min')+c('Baterías',p.packs)
   +c('Superficie',p.area.toFixed(1)+' ha')+c('Desenfoque',p.blur.toFixed(2)+' px')+c('Rango de fotos',p.fixed?'—':'≤ '+p.vCam.toFixed(1)+' m/s')+'</div>';
  h+='<ul style="list-style:none;margin:8px 0 0;padding:0;font-size:12px;line-height:1.4">'+p.checks.map(function(k){ var col={ok:'#1b7a3a',warn:'#8a5500',bad:'#b3261e',info:'#0b6aa8'}[k.l], ic={ok:'✔',warn:'▲',bad:'✖',info:'ℹ'}[k.l]; return '<li style="margin:3px 0;color:var(--ink)"><b style="color:'+col+'">'+ic+'</b> '+k.t+'</li>'; }).join('')+'</ul>';
  el.innerHTML=h; phPreview(p);
}
function phPreview(p){
  var cv=PHV.cv; if(!cv) return; var w=phWorld(), g=cv.getContext('2d'), S=cv.width, ext=SIM.SCN_EXT[ST.scn];
  if(PHV.rasScn!==ST.scn){ PHV.ras=SIM.mapRaster(w,420,ext); PHV.rasScn=ST.scn; }
  var half=Math.max(120,Math.min(ext,1.5*Math.max(p.w,p.l)+60)), cx=p.cx, cz=p.cz;
  /* la vista incluye el despegue si cabe */
  var dh=Math.max(Math.abs(p.home.x-cx),Math.abs(p.home.z-cz)); if(dh+40<ext) half=Math.max(half,Math.min(ext,dh+50));
  PHV.view={cx:cx,cz:cz,half:half}; var r=PHV.ras, step=r.step, k=S/(2*half);
  g.fillStyle='#d8dde2'; g.fillRect(0,0,S,S); g.imageSmoothingEnabled=true;
  g.drawImage(r.canvas,(cx-half+ext)/step,(cz-half+ext)/step,2*half/step,2*half/step,0,0,S,S);
  function X(x){return (x-cx+half)*k;} function Z(z){return (z-cz+half)*k;}
  /* huellas de las fotos (muy transparentes) */
  g.save(); g.translate(X(cx),Z(cz)); g.rotate(p.ang*Math.PI/180);
  g.fillStyle='rgba(11,106,168,.10)'; g.strokeStyle='rgba(11,106,168,.9)'; g.lineWidth=2; g.fillRect(-p.w/2*k,-p.l/2*k,p.w*k,p.l*k); g.strokeRect(-p.w/2*k,-p.l/2*k,p.w*k,p.l*k); g.restore();
  g.strokeStyle='#e2552d'; g.lineWidth=1.5; g.beginPath(); p.wps.forEach(function(q,i){ if(i===0) g.moveTo(X(q.x),Z(q.z)); else g.lineTo(X(q.x),Z(q.z)); }); g.stroke();
  g.fillStyle='#14283a'; var every=Math.max(1,Math.ceil(p.ph.length/260)); p.ph.forEach(function(q,i){ if(i%every) return; g.fillRect(X(q.x)-1.5,Z(q.z)-1.5,3,3); });
  g.setLineDash([5,4]); g.strokeStyle='#c27a00'; g.beginPath(); g.moveTo(X(p.home.x),Z(p.home.z)); g.lineTo(X(p.wps[0].x),Z(p.wps[0].z)); g.stroke(); g.setLineDash([]);
  g.fillStyle='#f5c842'; g.strokeStyle='#14283a'; g.lineWidth=2; g.beginPath(); g.arc(X(p.home.x),Z(p.home.z),6,0,6.3); g.fill(); g.stroke();
  g.fillStyle='#14283a'; g.font='bold 11px Arial'; g.fillText('N ↑',6,14); var sc=Math.pow(10,Math.floor(Math.log10(half*0.6))); g.fillRect(S-12-sc*k,S-14,sc*k,3); g.fillText(sc+' m',S-12-sc*k,S-18);
}
/* ---- misión en vuelo ---- */
function phInit(Fo){
  PH.F=Fo||PH.F;
  PH.run=false; PH.shots=[]; PH.done=false; PH.c1=PH.c3=0; PH.lastX=null; PH.lastT=-9; PH.cov=null;
  var hud=document.getElementById('phHud'); if(hud) hud.style.display='none';
  var P=phP(); if(!P.on||!SIM.photoOK()) return;
  var p=SIM.photoPlan(); PH.plan=p;
  var cell=Math.max(2,Math.sqrt(p.w*p.l/45000)), gw=Math.ceil(p.w/cell), gh=Math.ceil(p.l/cell), cvv=document.createElement('canvas'); cvv.width=gw; cvv.height=gh;
  PH.cov={cell:cell,gw:gw,gh:gh,cnt:new Uint8Array(gw*gh),cv:cvv,g:cvv.getContext('2d')}; PH.nCell=gw*gh; PH.run=true; phHud();
}
function phCell(c){ var s=c>=5?[47,143,74]:(c>=3?[143,191,106]:(c>=1?[230,168,0]:[192,57,43])); return s; }
function phShoot(){
  var F=PH.F; if(!F) return;
  var p=PH.plan, cv=PH.cov, agl=F.agl(), gsd=agl*p.pix/ (p.cam.f/1000*1000) ;
  gsd=agl*p.pix/p.cam.f; var Wg=gsd*p.cam.iw, Hg=gsd*p.cam.ih, hd=F.yaw, v=F.hspeed(), blur=v/p.shutter/gsd;
  var sx=Math.sin(hd), sz=-Math.cos(hd), rx=Math.cos(hd), rz=Math.sin(hd), A=p.ang*Math.PI/180, ux=Math.cos(A), uz=Math.sin(A), dx=Math.sin(A), dz=-Math.cos(A);
  var tx=F.pos.x-p.cx, tz=F.pos.z-p.cz, u0=tx*ux+tz*uz, y0=-(tx*dx+tz*dz), inA=Math.abs(u0)<=p.w/2+Wg/4&&Math.abs(y0)<=p.l/2+Hg/2;
  var R=Math.hypot(Wg,Hg)/2, i0=Math.max(0,Math.floor((u0-R+p.w/2)/cv.cell)), i1=Math.min(cv.gw-1,Math.floor((u0+R+p.w/2)/cv.cell)), j0=Math.max(0,Math.floor((y0-R+p.l/2)/cv.cell)), j1=Math.min(cv.gh-1,Math.floor((y0+R+p.l/2)/cv.cell));
  for(var j=j0;j<=j1;j++)for(var i=i0;i<=i1;i++){
    var u=-p.w/2+(i+0.5)*cv.cell, yy=-p.l/2+(j+0.5)*cv.cell, wx=p.cx+u*ux-yy*dx-F.pos.x, wz=p.cz+u*uz-yy*dz-F.pos.z;
    var al=wx*sx+wz*sz, ac=wx*rx+wz*rz;
    if(Math.abs(ac)<=Wg/2&&Math.abs(al)<=Hg/2){ var id=j*cv.gw+i, c=cv.cnt[id]; if(c<255){ cv.cnt[id]=++c; if(c===1) PH.c1++; if(c===3) PH.c3++; var s=phCell(c); cv.g.fillStyle='rgba('+s[0]+','+s[1]+','+s[2]+',.55)'; cv.g.fillRect(i,j,1,1); } } }
  PH.shots.push({t:F.t,x:F.pos.x,z:F.pos.z,agl:agl,amsl:F.pos.y,v:v,hd:hd*180/Math.PI,gsd:gsd,blur:blur,inA:inA,Wg:Wg,Hg:Hg});
  PH.lastX=F.pos.x; PH.lastZ=F.pos.z; PH.lastT=F.t; AUD.event('shot'); phHud();
}
function phTick(dt){
  var F=PH.F; if(!F) return;
  if(!PH.run||PH.done) return; var p=PH.plan;
  if(F.status==='crashed'){ PH.done=true; PH.run=false; if(PH.shots.length) phFinish(); return; }
  var fl=(F.status==='flying'), agl=F.agl();
  if(fl&&agl>=5){
    var gsd=agl*p.pix/p.cam.f, Wg=gsd*p.cam.iw, Hg=gsd*p.cam.ih, sp=Hg*(1-p.front), A=p.ang*Math.PI/180, tx=F.pos.x-p.cx, tz=F.pos.z-p.cz,
        u=tx*Math.cos(A)+tz*Math.sin(A), vv=tx*Math.sin(A)-tz*Math.cos(A);
    if(Math.abs(u)<=p.w/2+Wg/4&&Math.abs(vv)<=p.l/2+Hg/2&&F.t-PH.lastT>=p.tmin&&(PH.lastX===null||Math.hypot(F.pos.x-PH.lastX,F.pos.z-PH.lastZ)>=sp)) phShoot();
  }
  if(PH.shots.length>2&&F.status==='landed'&&F.t-PH.lastT>3) phFinish();
  if(F.t-PH.hudT>0.4){ PH.hudT=F.t; phHud(); }
}
function phHud(){
  var F=PH.F; if(!F) return;
  var el=document.getElementById('phHud'); if(!el) return; if(!PH.run||SIM.hangarOpen()){ el.style.display='none'; return; }
  var p=PH.plan, cov=PH.nCell?Math.round(100*PH.c3/PH.nCell):0, agl=F.agl(), ok=Math.abs(agl-p.alt)<=0.12*p.alt;
  el.style.display='block'; el.innerHTML='<div class="ct">Fotogrametría · '+p.cam.n.split(' (')[0]+'</div><div class="cr"><div class="cn">'+PH.shots.length+'<small> fotos</small></div><div class="cn">'+cov+'<small> % cobertura</small></div></div>'
   +'<div class="nxt">Altura <b style="color:'+(ok?'var(--green)':'var(--red)')+'">'+Math.round(agl)+' m</b> (plan '+Math.round(p.alt)+' m) · Vel <b style="color:'+(F.hspeed()>p.vg*1.15?'var(--red)':'inherit')+'">'+F.hspeed().toFixed(1)+'</b> / '+p.vg.toFixed(1)+' m/s</div>'
   +'<div class="nxt" style="pointer-events:auto"><button class="btn" id="phEnd" style="padding:2px 10px;font-size:11px">Terminar y ver informe</button></div>';
  var b=document.getElementById('phEnd'); if(b) b.onclick=function(){ if(PH.shots.length) phFinish(); else { PH.run=false; PH.done=true; el.style.display='none'; } };
}
SIM.photoDrawMap=function(g,k){
  if(!PH.run||!PH.plan) return; var p=PH.plan, cv=PH.cov;
  g.save(); g.translate(p.cx,p.cz); g.rotate(p.ang*Math.PI/180);
  g.imageSmoothingEnabled=false; g.drawImage(cv.cv,-p.w/2,-p.l/2,p.w,p.l);
  g.strokeStyle='#0b6aa8'; g.lineWidth=2/k; g.strokeRect(-p.w/2,-p.l/2,p.w,p.l); g.restore();
  g.strokeStyle='rgba(226,85,45,.85)'; g.lineWidth=1.2/k; g.setLineDash([6/k,4/k]); g.beginPath(); p.wps.forEach(function(q,i){ if(i===0) g.moveTo(q.x,q.z); else g.lineTo(q.x,q.z); }); g.stroke(); g.setLineDash([]);
  g.fillStyle='#14283a'; PH.shots.forEach(function(s){ g.fillRect(s.x-1.2/k,s.z-1.2/k,2.4/k,2.4/k); });
};
/* ---- informe ---- */
function phFinish(){
  var F=PH.F; if(!F) return;
  PH.done=true; PH.run=false; var el=document.getElementById('phHud'); if(el) el.style.display='none';
  var p=PH.plan, cv=PH.cov, n=cv.gw*cv.gh, hist=[0,0,0,0], sum=0;
  for(var i=0;i<n;i++){ var c=cv.cnt[i]; sum+=c; hist[c===0?0:(c<3?1:(c<5?2:3))]++; }
  var shots=PH.shots, ins=shots.filter(function(s){return s.inA;}).length, gs=0, bl=0, blOk=0;
  shots.forEach(function(s){ gs+=s.gsd; bl+=s.blur; if(s.blur<=0.5) blOk++; });
  var R={plan:p,grid:{gw:cv.gw,gh:cv.gh,cell:cv.cell,cnt:Array.prototype.slice.call(cv.cnt)},shots:shots.slice(),n:shots.length,
    cov3:(hist[2]+hist[3])/n, cov1:1-hist[0]/n, gaps:hist[0]/n, cov5:hist[3]/n, mean:sum/n, gsd:shots.length?gs/shots.length:0, blur:shots.length?bl/shots.length:0, blOk:shots.length?blOk/shots.length:0,
    outside:shots.length?1-ins/shots.length:0, t:shots.length?(shots[shots.length-1].t-shots[0].t):0, status:F.status};
  var gsdE=R.gsd?Math.abs(R.gsd/p.gsd-1):1;
  R.score=Math.max(0,Math.min(10,7*Math.min(1,R.cov3/0.95)+1.5*Math.max(0,1-gsdE/0.5)+1.5*R.blOk-(R.outside>0.3?1:0)-(F.status==='crashed'?3:0)));
  PH.last=R; phReport(R,false);
}
function phReport(R,fromHangar){
  var p=R.plan, d=document.getElementById('phDlg'); if(!d) return;
  var f=function(x,n){return (100*x).toFixed(n===undefined?0:n)+' %';};
  var nota=R.score>=8.5?'Excelente: el modelo saldría limpio.':(R.score>=6.5?'Buen trabajo: se reconstruiría con pequeños huecos.':(R.score>=5?'Aprobado justo: habría zonas sin reconstruir.':'Insuficiente: habría que repetir el vuelo.'));
  var lines=[];
  if(R.gaps>0.05) lines.push('Huecos: '+f(R.gaps)+' de la zona sin ninguna foto; revisa los huecos rojos y repite esas líneas.');
  if(R.cov3<0.9) lines.push('Cobertura baja: '+f(R.cov3)+' de la zona sale en 3 o más fotos, el mínimo para triangular bien.');
  if(R.blOk<0.8) lines.push('Desenfoque: '+f(1-R.blOk)+' de las fotos sale movido; vuela más despacio o usa obturador más rápido.');
  if(Math.abs(R.gsd/p.gsd-1)>0.2) lines.push('El GSD real ('+(R.gsd*100).toFixed(1)+' cm/px) se aleja del previsto ('+(p.gsd*100).toFixed(1)+' cm/px): mantén la altura del plan ('+p.alt.toFixed(0)+' m).');
  if(R.outside>0.3) lines.push('Fuera de zona: '+f(R.outside)+' de las fotos se hizo fuera del área.');
  if(R.status==='crashed') lines.push('El vuelo terminó en siniestro.');
  if(!lines.length) lines.push('Sin incidencias destacables.');
  d.innerHTML='<h2>INFORME DE FOTOGRAMETRÍA</h2><div class="phg"><canvas id="phRc" width="300" height="300"></canvas><div class="pht">'
   +'<div class="phs">'+R.score.toFixed(1)+'<small> / 10</small></div><div class="phn">'+nota+'</div>'
   +'<table><tr><td>Fotos</td><td><b>'+R.n+'</b> (previstas '+p.total+')</td></tr><tr><td>Cobertura ≥ 3 fotos</td><td><b>'+f(R.cov3)+'</b></td></tr><tr><td>Cobertura ≥ 5 fotos</td><td><b>'+f(R.cov5)+'</b></td></tr><tr><td>Huecos sin foto</td><td><b>'+f(R.gaps)+'</b></td></tr>'
   +'<tr><td>Solape medio</td><td><b>'+R.mean.toFixed(1)+'</b> fotos por punto</td></tr><tr><td>GSD real / previsto</td><td><b>'+(R.gsd*100).toFixed(2)+'</b> / '+(p.gsd*100).toFixed(2)+' cm/px</td></tr><tr><td>Desenfoque medio</td><td><b>'+R.blur.toFixed(2)+'</b> px ('+f(R.blOk)+' nítidas)</td></tr>'
   +'<tr><td>Fotos fuera de la zona</td><td><b>'+f(R.outside)+'</b></td></tr><tr><td>Tiempo de captura</td><td><b>'+Math.floor(R.t/60)+' min '+Math.round(R.t%60)+' s</b> (plan '+p.Ttot.toFixed(0)+' min)</td></tr></table></div></div>'
   +'<div class="phl"><span style="color:#c0392b">■</span> sin foto <span style="color:#e6a800">■</span> 1–2 <span style="color:#8fbf6a">■</span> 3–4 <span style="color:#2f8f4a">■</span> 5 o más</div>'
   +'<ul class="phw">'+lines.map(function(t){return '<li>'+t+'</li>';}).join('')+'</ul>'
   +'<div class="phb"><button class="btn" id="phRcsv">Descargar fotos (CSV)</button><button class="btn pri" id="phRx">Cerrar</button></div>';
  var cv=document.getElementById('phRc'), g=cv.getContext('2d'), S=300, gr=R.grid, sc=Math.min(S/p.w,S/p.l); cv.width=Math.round(p.w*sc); cv.height=Math.round(p.l*sc);
  g=cv.getContext('2d'); g.fillStyle='#e9ecef'; g.fillRect(0,0,cv.width,cv.height);
  for(var j=0;j<gr.gh;j++)for(var i=0;i<gr.gw;i++){ var c=gr.cnt[j*gr.gw+i], s=phCell(c); g.fillStyle='rgb('+s[0]+','+s[1]+','+s[2]+')'; g.fillRect(i*gr.cell*sc,j*gr.cell*sc,gr.cell*sc+1,gr.cell*sc+1); }
  var A=p.ang*Math.PI/180, ux=Math.cos(A), uz=Math.sin(A), dx=Math.sin(A), dz=-Math.cos(A);
  g.fillStyle='rgba(20,40,58,.85)'; R.shots.forEach(function(s){ var tx=s.x-p.cx, tz=s.z-p.cz, u=tx*ux+tz*uz, y=-(tx*dx+tz*dz); g.fillRect((u+p.w/2)*sc-1,(y+p.l/2)*sc-1,2.4,2.4); });
  document.getElementById('phRx').onclick=function(){ d.style.display='none'; };
  document.getElementById('phRcsv').onclick=function(){ var s='n;t_s;x_m;z_m;agl_m;amsl_m;vel_ms;rumbo_deg;gsd_cm;desenfoque_px;dentro\n'; R.shots.forEach(function(q,i){ s+=(i+1)+';'+q.t.toFixed(1)+';'+q.x.toFixed(1)+';'+q.z.toFixed(1)+';'+q.agl.toFixed(1)+';'+q.amsl.toFixed(1)+';'+q.v.toFixed(1)+';'+q.hd.toFixed(0)+';'+(q.gsd*100).toFixed(2)+';'+q.blur.toFixed(2)+';'+(q.inA?1:0)+'\n'; }); phDownload('fotogrametria_fotos.csv',s); };
  d.style.display='block';
}
SIM.photoInit=phInit; SIM.photoTick=phTick; SIM.photoHud=phHud;
