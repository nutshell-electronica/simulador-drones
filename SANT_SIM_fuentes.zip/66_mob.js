/* ===== MANDO MÓVIL (prototipo): el móvil hace de mando por WebRTC directo (PeerJS) =====
   · Ordenador: botón «Usar móvil como mando» del hangar → código QR con un enlace a esta misma página con ?mando=CÓDIGO.
   · Móvil: al abrir ese enlace no arranca el simulador, sólo el mando (dos joysticks, pausa y hangar).
   · El broker público de PeerJS sólo sirve para el apretón de manos inicial; después los datos van directos (o por TURN).
   · Si la red del centro bloquea el broker se puede usar uno propio con ?peerhost=…&peerport=…&peerpath=…&peersecure=0|1  */
(function(){
var $=function(id){return document.getElementById(id);};
var PUB='https://nutshell-electronica.github.io/simulador-drones/';
var PROTO=1, ALPHA='ABCDEFGHJKMNPQRSTUVWXYZ23456789', PEER_ID='santsim-';
var Q=new URLSearchParams(location.search);
var CODE=(Q.get('mando')||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,12);
var MOB=SIM.MOB={out:{on:false,yaw:0,thr:0,roll:0,pitch:0}, hooks:{}, state:'off', rate:0, rtt:0, url:'', code:''};
SIM.MANDO=!!CODE;
var PASS=['peerhost','peerport','peerpath','peersecure'];
function peerOpts(){
  var o={debug:0}, h=Q.get('peerhost');
  if(h){ o.host=h; o.port=+(Q.get('peerport')||443); o.path=Q.get('peerpath')||'/'; o.secure=Q.get('peersecure')!=='0'; }
  return o;
}
function now(){ return performance.now(); }
function r3(v){ return Math.round(v*1000)/1000; }

/* =============== LADO ORDENADOR =============== */
var peer=null, conn=null, code='', lastRx=0, rxN=0, seq=-1, errMsg='', retry=0;
function genCode(){ var a=new Uint8Array(6), s=''; (window.crypto||window.msCrypto).getRandomValues(a); for(var i=0;i<6;i++) s+=ALPHA[a[i]%ALPHA.length]; return s; }
function baseUrl(){ var p=location.protocol; return (p==='http:'||p==='https:')?(location.origin+location.pathname):PUB; }
function mkUrl(){ var u=baseUrl()+'?mando='+code; PASS.forEach(function(k){ if(Q.get(k)) u+='&'+k+'='+encodeURIComponent(Q.get(k)); }); return u; }
function zero(){ var o=MOB.out; o.on=false; o.yaw=o.thr=o.roll=o.pitch=0; }
function setState(s){ if(MOB.state!==s){ MOB.state=s; } ui(); }
MOB.active=function(){ return MOB.out.on; };
MOB.linked=function(){ return MOB.state==='on'||MOB.state==='lost'; };

MOB.start=function(){
  if(peer&&!peer.destroyed) { ui(); return; }
  if(typeof Peer==='undefined'){ errMsg='Este navegador no puede crear el enlace (falta WebRTC).'; setState('err'); return; }
  code=genCode(); MOB.code=code; MOB.url=''; errMsg=''; setState('init');
  var p;
  try{ p=new Peer(PEER_ID+code,peerOpts()); }catch(e){ errMsg='No se pudo iniciar el enlace.'; setState('err'); return; }
  peer=p;
  p.on('open',function(){ if(peer!==p) return; retry=0; MOB.url=mkUrl(); setState('wait'); });
  p.on('connection',function(c){ if(peer!==p) return; adopt(c); });
  p.on('disconnected',function(){ if(peer!==p||p.destroyed) return; try{ p.reconnect(); }catch(e){} });
  p.on('error',function(e){
    if(peer!==p) return;
    var t=e&&e.type;
    if(t==='unavailable-id'){ MOB.stop(true); if(retry++<3) MOB.start(); return; }
    if(t==='peer-unavailable') return;
    if(t==='network'||t==='server-error'||t==='socket-error'||t==='socket-closed') errMsg='No se puede contactar con el servidor de enlace. Comprueba la conexión a internet; si la red del centro lo bloquea, este sistema no funcionará allí.';
    else errMsg='Error de enlace ('+(t||'desconocido')+').';
    if(MOB.state!=='on'&&MOB.state!=='lost') setState('err'); else ui();
  });
};
MOB.stop=function(keepErr){
  zero(); var c=conn, p=peer; conn=null; peer=null; MOB.url=''; MOB.rate=0; MOB.rtt=0; rxN=0;
  try{ if(c) c.close(); }catch(e){} try{ if(p) p.destroy(); }catch(e){}
  if(!keepErr) errMsg=''; setState('off');
};
MOB.restart=function(){ MOB.stop(); MOB.start(); };

function adopt(c){
  var ok=false;
  c.on('data',function(m){
    if(!m||typeof m!=='object') return;
    if(m.t==='hi'){
      if(conn&&conn!==c&&conn.open&&conn._k&&conn._k!==m.k){ try{ c.send({t:'busy'}); }catch(e){} setTimeout(function(){ try{ c.close(); }catch(e){} },300); return; }
      if(m.v!==PROTO){ try{ c.send({t:'ver',v:PROTO}); }catch(e){} setTimeout(function(){ try{ c.close(); }catch(e){} },300); return; }
      if(conn&&conn!==c){ var old=conn; conn=null; try{ old.close(); }catch(e){} }
      conn=c; c._k=m.k; ok=true; seq=-1; lastRx=now(); zero(); setState('on');
      try{ c.send({t:'ok'}); }catch(e){}
      return;
    }
    if(!ok||c!==conn) return;
    if(m.t==='i'){
      if(typeof m.s==='number'){ if(m.s<=seq&&seq-m.s<1000) return; seq=m.s; }
      var o=MOB.out; o.yaw=cl(m.y); o.thr=cl(m.th); o.roll=cl(m.r); o.pitch=cl(m.p);
      lastRx=now(); rxN++; if(!o.on||MOB.state==='lost'){ o.on=true; setState('on'); }
    } else if(m.t==='b'){ var h=MOB.hooks[m.k]; if(h){ try{ h(); }catch(e){} } lastRx=now(); }
    else if(m.t==='p'){ if(typeof m.r==='number') MOB.rtt=m.r; lastRx=now(); try{ c.send({t:'q',n:m.n}); }catch(e){} }
  });
  c.on('close',function(){ if(c===conn){ conn=null; zero(); MOB.rate=0; if(peer&&!peer.destroyed) setState('wait'); } });
  c.on('error',function(){ if(c===conn){ conn=null; zero(); MOB.rate=0; if(peer&&!peer.destroyed) setState('wait'); } });
}
function cl(v){ v=+v; return v!==v?0:(v>1?1:(v<-1?-1:v)); }
/* seguridad de enlace: sin datos durante 0,6 s los mandos vuelven a cero, como una pérdida de radio */
setInterval(function(){
  if(MOB.state==='on'&&conn&&now()-lastRx>600){ zero(); setState('lost'); }
  if(MOB.state==='lost'&&!conn) setState('wait');
},100);
setInterval(function(){ MOB.rate=rxN; rxN=0; ui(); },1000);
/* el ordenador informa al móvil de si está en pausa o en el hangar */
setInterval(function(){
  if(!conn||!conn.open||!MOB.hooks.status) return;
  var s; try{ s=MOB.hooks.status(); }catch(e){ return; } s.t='st'; try{ conn.send(s); }catch(e){}
},250);

/* ---------- ventana con el QR (ordenador) ---------- */
var shown='';
function qrSvg(url){
  try{ var qr=qrcode(0,'M'); qr.addData(url); qr.make(); return qr.createSvgTag({cellSize:4,margin:0,scalable:true}); }catch(e){ return ''; }
}
function ui(){
  var d=$('mobDlg'), b=$('bMob'); if(!d||!b) return;
  var st=MOB.state, on=(st==='on'||st==='lost');
  b.textContent=on?'Móvil conectado ✔ (en pruebas)':'Usar móvil como mando (en pruebas)';
  b.classList.toggle('on',on);
  if(d.style.display!=='flex') return;
  var key=MOB.url+'|'+st; if(shown!==key){ shown=key; $('mobQr').innerHTML=(MOB.url&&!on)?qrSvg(MOB.url):''; }
  $('mobQrBox').style.display=(MOB.url&&!on)?'block':'none';
  $('mobCode').textContent=on?'':(MOB.code||'');
  $('mobCodeRow').style.display=(MOB.code&&!on)?'block':'none';
  var u=$('mobUrl'); u.textContent=MOB.url||''; u.style.display=(MOB.url&&!on)?'block':'none';
  var t='', cls='';
  if(st==='init') t='Conectando con el servidor de enlace…';
  else if(st==='wait') t='Esperando al móvil…';
  else if(st==='on') t='✔ Móvil conectado · '+MOB.rate+' mensajes/s'+(MOB.rtt?' · latencia '+Math.round(MOB.rtt)+' ms':'')+'. Cierra esta ventana y pulsa Volar.';
  else if(st==='lost') { t='Sin señal del móvil: los mandos quedan a cero.'; cls='bad'; }
  else if(st==='err') { t='✘ '+errMsg; cls='bad'; }
  var el=$('mobSt'); el.textContent=t; el.className='mst '+cls;
  $('mobStop').style.display=(st==='off')?'none':'inline-block';
  $('mobNew').style.display=(st==='wait'||st==='err'||st==='init')?'inline-block':'none';
}
function openDlg(){ var d=$('mobDlg'); d.style.display='flex'; shown=''; if(MOB.state==='off') MOB.start(); ui(); }
function closeDlg(){ $('mobDlg').style.display='none'; }
MOB.init=function(){
  var b=$('bMob'); if(!b) return;
  b.onclick=openDlg;
  $('mobClose').onclick=closeDlg; $('mobStop').onclick=function(){ MOB.stop(); ui(); }; $('mobNew').onclick=function(){ MOB.restart(); };
  $('mobDlg').addEventListener('pointerdown',function(e){ if(e.target===$('mobDlg')) closeDlg(); });
  ui();
};

/* =============== LADO MÓVIL (mando) =============== */
function mando(){
  document.documentElement.classList.add('mando'); document.title='SANT·SIM — Mando móvil';
  var root=$('mando'); root.style.display='flex';
  var av=document.querySelector('#top img.av'), mav=$('mdAv'); if(av&&mav) mav.src=av.src;
  var tok=''; try{ tok=localStorage.getItem('santsim_mtk')||''; }catch(e){} if(!tok){ tok=genCode()+genCode(); try{ localStorage.setItem('santsim_mtk',tok); }catch(e){} }
  var ax={yaw:0,thr:0,roll:0,pitch:0}, mpeer=null, mconn=null, linked=false, pc={pa:0,hg:0}, sseq=0, lastSent=0, last={y:9,th:9,r:9,p:9}, lastQ=0, rtt=0, retryT=null, msg='', busy=false;
  var $st=$('mdSt'), $pa=$('mdPause'), $hg=$('mdHang');
  function status(t,cls){ $st.textContent=t; $st.className=cls||''; }
  function paint(){
    $pa.textContent=(pc.pa&&!pc.hg)?'Reanudar':'Pausa';
    var dis=!linked||pc.hg; $pa.disabled=dis; $hg.disabled=dis;
    root.classList.toggle('live',linked&&!pc.hg);
    if(linked){ if(pc.hg) status('En el hangar: pulsa Volar en el ordenador','warn'); else status('Conectado'+(rtt?' · '+Math.round(rtt)+' ms':''),'ok'); }
  }
  function send(m){ try{ if(mconn&&mconn.open){ mconn.send(m); return true; } }catch(e){} return false; }
  function connect(){
    clearTimeout(retryT); if(busy) return;
    if(!mpeer||mpeer.destroyed){
      status('Conectando…','');
      mpeer=new Peer(peerOpts());
      mpeer.on('open',function(){ dial(); });
      mpeer.on('disconnected',function(){ try{ mpeer.reconnect(); }catch(e){} });
      mpeer.on('error',function(e){
        var t=e&&e.type; linked=false; paint();
        if(t==='peer-unavailable'){ status('El ordenador no está esperando este código. Vuelve a pulsar «Usar móvil como mando» y escanea el QR nuevo.','bad'); }
        else if(t==='network'||t==='server-error'||t==='socket-error'||t==='socket-closed'){ status('Sin conexión con el servidor de enlace. Reintentando…','bad'); try{ mpeer.destroy(); }catch(x){} mpeer=null; }
        else status('Error de enlace ('+(t||'?')+'). Reintentando…','bad');
        later(2500);
      });
    } else if(mpeer.open) dial(); else if(mpeer.disconnected){ try{ mpeer.reconnect(); }catch(e){} }
  }
  function later(ms){ clearTimeout(retryT); if(!busy) retryT=setTimeout(connect,ms); }
  function dial(){
    if(mconn){ try{ mconn.close(); }catch(e){} mconn=null; }
    status('Buscando el ordenador…','');
    var c=mpeer.connect(PEER_ID+CODE,{serialization:'json',reliable:false}); mconn=c;
    c.on('open',function(){ if(mconn!==c) return; send({t:'hi',v:PROTO,k:tok}); });
    c.on('data',function(m){
      if(!m||mconn!==c) return;
      if(m.t==='ok'){ linked=true; sseq=0; last={y:9,th:9,r:9,p:9}; paint(); wake(); }
      else if(m.t==='busy'){ busy=true; linked=false; status('Ya hay otro móvil conectado a este simulador.','bad'); paint(); }
      else if(m.t==='ver'){ busy=true; status('Versión distinta del simulador en el ordenador y en el móvil. Recarga ambos.','bad'); }
      else if(m.t==='st'){ pc.pa=m.pa?1:0; pc.hg=m.hg?1:0; paint(); }
      else if(m.t==='q'){ rtt=now()-m.n; lastQ=now(); paint(); }
    });
    function gone(){ if(mconn!==c) return; linked=false; mconn=null; paint(); if(!busy){ status('Conexión perdida. Reconectando…','bad'); later(1500); } }
    c.on('close',gone); c.on('error',gone);
  }
  /* envío periódico: 40 Hz si cambia algo, y al menos cada 120 ms como latido */
  setInterval(function(){
    if(!linked) return; var t=now();
    var y=r3(ax.yaw), th=r3(ax.thr), r=r3(ax.roll), p=r3(ax.pitch);
    if(y!==last.y||th!==last.th||r!==last.r||p!==last.p||t-lastSent>120){ last={y:y,th:th,r:r,p:p}; lastSent=t; send({t:'i',s:++sseq,y:y,th:th,r:r,p:p}); }
  },25);
  setInterval(function(){ if(linked){ send({t:'p',n:now(),r:rtt}); if(lastQ&&now()-lastQ>3000){ status('Sin respuesta del ordenador…','bad'); } } },1000);
  function flush(){ if(linked){ var y=r3(ax.yaw), th=r3(ax.thr), r=r3(ax.roll), p=r3(ax.pitch); last={y:y,th:th,r:r,p:p}; lastSent=now(); send({t:'i',s:++sseq,y:y,th:th,r:r,p:p}); } }

  /* joysticks flotantes: el centro es donde apoyas el pulgar */
  function zone(el,kx,ky){
    var base=el.querySelector('.mdbase'), knob=el.querySelector('.mdk'), id=null, cx=0, cy=0, R=60, KR=26;
    function lay(){ R=Math.max(44,Math.min(innerHeight*0.2,innerWidth*0.13)); KR=R*0.45; base.style.width=base.style.height=(2*R)+'px'; knob.style.width=knob.style.height=(2*KR)+'px'; rest(); }
    function put(x,y,dx,dy){ base.style.left=(x-R)+'px'; base.style.top=(y-R)+'px'; knob.style.left=(x+dx-KR)+'px'; knob.style.top=(y+dy-KR)+'px'; }
    function rest(){ var r=el.getBoundingClientRect(); put(r.width/2,r.height*0.62,0,0); }
    function val(e){
      var r=el.getBoundingClientRect(), x=e.clientX-r.left-cx, y=e.clientY-r.top-cy, L=Math.hypot(x,y); if(L>R){ x*=R/L; y*=R/L; }
      put(cx,cy,x,y);
      var nx=x/R, ny=-y/R, dz=0.07; function f(v){ var a=Math.abs(v); if(a<dz) return 0; a=(a-dz)/(1-dz); return v<0?-a:a; }
      ax[kx]=f(nx); ax[ky]=f(ny); flush();
    }
    function end(){ id=null; ax[kx]=0; ax[ky]=0; el.classList.remove('act'); rest(); flush(); }
    el.addEventListener('pointerdown',function(e){ if(id!==null) return; id=e.pointerId; try{ el.setPointerCapture(id); }catch(x){} e.preventDefault(); el.classList.add('act'); var r=el.getBoundingClientRect(); cx=e.clientX-r.left; cy=e.clientY-r.top; first(); val(e); });
    el.addEventListener('pointermove',function(e){ if(e.pointerId===id){ e.preventDefault(); val(e); } });
    el.addEventListener('pointerup',function(e){ if(e.pointerId===id) end(); });
    el.addEventListener('pointercancel',function(e){ if(e.pointerId===id) end(); });
    lay(); window.addEventListener('resize',function(){ if(id===null) lay(); });
    setTimeout(lay,200);
  }
  zone($('mdL'),'yaw','thr'); zone($('mdR'),'roll','pitch');

  /* botones: pausa (toque) y hangar (mantener 0,6 s para no pulsarlo sin querer) */
  $pa.addEventListener('click',function(){ first(); if(linked&&!pc.hg){ send({t:'b',k:'pause'}); if(navigator.vibrate) try{ navigator.vibrate(25); }catch(e){} } });
  var ht=null;
  function hgStart(e){ e.preventDefault(); if($hg.disabled) return; $hg.classList.add('hold'); clearTimeout(ht); ht=setTimeout(function(){ $hg.classList.remove('hold'); send({t:'b',k:'hangar'}); if(navigator.vibrate) try{ navigator.vibrate([30,40,30]); }catch(e){} },600); }
  function hgEnd(){ clearTimeout(ht); $hg.classList.remove('hold'); }
  $hg.addEventListener('pointerdown',hgStart); ['pointerup','pointerleave','pointercancel'].forEach(function(n){ $hg.addEventListener(n,hgEnd); });
  ['contextmenu','gesturestart','dblclick'].forEach(function(n){ root.addEventListener(n,function(e){ e.preventDefault(); }); });
  document.addEventListener('touchmove',function(e){ e.preventDefault(); },{passive:false});

  /* pantalla completa y horizontal (Android), y pantalla siempre encendida */
  var did=false;
  function first(){ if(did) return; did=true; try{ var de=document.documentElement; var rq=de.requestFullscreen||de.webkitRequestFullscreen; if(rq){ var pr=rq.call(de); if(pr&&pr.then) pr.then(function(){ try{ screen.orientation.lock('landscape').catch(function(){}); }catch(e){} }).catch(function(){}); } }catch(e){} wake(); }
  var wl=null; function wake(){ try{ if(navigator.wakeLock&&!wl) navigator.wakeLock.request('screen').then(function(l){ wl=l; l.addEventListener('release',function(){ wl=null; }); }).catch(function(){}); }catch(e){} }
  document.addEventListener('visibilitychange',function(){ if(!document.hidden){ wake(); if(!linked&&!busy) later(300); } else { ax.yaw=ax.thr=ax.roll=ax.pitch=0; flush(); } });
  window.addEventListener('pagehide',function(){ ax.yaw=ax.thr=ax.roll=ax.pitch=0; flush(); });
  paint(); connect();
}
var started=false;
function go(){ if(started) return; started=true; if(SIM.MANDO) mando(); else MOB.init(); }
document.addEventListener('DOMContentLoaded',go);
if(document.readyState!=='loading') go();
})();
