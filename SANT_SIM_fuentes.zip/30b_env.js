/* ===== MODELO: atmósfera, viento, batería, radioenlace, GNSS ===== */
(function(){
var D_ = (typeof SD!=='undefined'?SD:require('./20_data.js'));
var deg = D_.deg, clamp = D_.clamp;

/* RNG reproducible */
SM.rng = function(seed){ var a=seed>>>0; return function(){ a|=0; a=a+0x6D2B79F5|0; var t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; };

/* Atmósfera: elev = cota del lugar (m), qnh (hPa), temp a nivel de la cota (°C), y = altura sobre la cota */
SM.atmo = function(elev,qnh,tempC,y){
  if(D_.PL && D_.PL.id==='mars'){   /* Marte: CO2, qnh = presión (hPa) en la cota 0, escala de altura 11,1 km, R = 188,9 J/kg·K */
    var hm=elev+y, pm=qnh*100*Math.exp(-hm/11100), Tm=tempC+273.15-0.0045*y;
    return {p:pm/100, T:Tm-273.15, rho:pm/(188.92*Tm)};
  }
  var h = Math.max(0,elev+y);
  var p = qnh*100*Math.pow(1-2.25577e-5*h,5.25588);
  var T = tempC+273.15-0.0065*y;
  return {p:p/100, T:T-273.15, rho:p/(287.05*T)};
};
/* Sol en Marte: la hora del reloj del hangar se toma como hora solar LOCAL de Marte en el cráter Jezero (18,4° N);
   declinación fija de +10° (estación tipo primavera/verano boreal). Devuelve azimut (° desde N, horario) y elevación (°). */
SM.marsSun = function(ms){
  var d=new Date(ms), hr=d.getHours()+d.getMinutes()/60+d.getSeconds()/3600, rad=Math.PI/180;
  var ha=(hr-12)*15*rad, la=18.44*rad, decl=10*rad;
  var cz=Math.sin(la)*Math.sin(decl)+Math.cos(la)*Math.cos(decl)*Math.cos(ha), zen=Math.acos(clamp(cz,-1,1)), sz=Math.sin(zen), az;
  if(sz<1e-6) az=180; else { var c2=clamp((Math.sin(la)*Math.cos(zen)-Math.sin(decl))/(Math.cos(la)*sz),-1,1); var a=Math.acos(c2)/rad; az=ha>0?(a+180)%360:(540-a)%360; }
  return {az:az,el:90-zen/rad};
};
/* Altitud de densidad (m) para una densidad dada */
SM.densAlt = function(rho){ return 44330.77*(1-Math.pow(rho/1.225,0.190259)); };


/* Posición del Sol (algoritmo NOAA simplificado). ms = instante UTC; lat/lon en grados (E positivo).
   Devuelve azimut (° desde el norte, sentido horario) y elevación (°). */
SM.sunPos = function(ms,lat,lon){
  if(D_.PL && D_.PL.id==='mars') return SM.marsSun(ms);
  var jd=ms/86400000+2440587.5, T=(jd-2451545)/36525, rad=Math.PI/180;
  var L0=(280.46646+T*(36000.76983+0.0003032*T))%360, M=357.52911+T*(35999.05029-0.0001537*T);
  var e=0.016708634-T*(0.000042037+0.0000001267*T);
  var C=Math.sin(M*rad)*(1.914602-T*(0.004817+0.000014*T))+Math.sin(2*M*rad)*(0.019993-0.000101*T)+Math.sin(3*M*rad)*0.000289;
  var om=125.04-1934.136*T, lam=L0+C-0.00569-0.00478*Math.sin(om*rad);
  var eps0=23+(26+(21.448-T*(46.815+T*(0.00059-T*0.001813)))/60)/60, eps=eps0+0.00256*Math.cos(om*rad);
  var decl=Math.asin(Math.sin(eps*rad)*Math.sin(lam*rad));
  var y=Math.tan(eps*rad/2); y*=y;
  var eq=4/rad*(y*Math.sin(2*L0*rad)-2*e*Math.sin(M*rad)+4*e*y*Math.sin(M*rad)*Math.cos(2*L0*rad)-0.5*y*y*Math.sin(4*L0*rad)-1.25*e*e*Math.sin(2*M*rad));
  var minUTC=((ms%86400000)+86400000)%86400000/60000;
  var tst=((minUTC+eq+4*lon)%1440+1440)%1440, ha=tst/4-180;
  var la=lat*rad, cz=Math.sin(la)*Math.sin(decl)+Math.cos(la)*Math.cos(decl)*Math.cos(ha*rad);
  var zen=Math.acos(clamp(cz,-1,1)), sz=Math.sin(zen), az;
  if(sz<1e-6) az=180; else { var c2=clamp((Math.sin(la)*Math.cos(zen)-Math.sin(decl))/(Math.cos(la)*sz),-1,1); var a=Math.acos(c2)/rad; az=ha>0?(a+180)%360:(540-a)%360; }
  return {az:az,el:90-zen/rad};
};
/* Coordenadas ecuatoriales → vector del mundo (x este, y arriba, z sur) para el instante ms y el lugar lat/lon */
SM.eqVec = function(raDeg,decDeg,ms,lat,lon){
  var rad=Math.PI/180, jd=ms/86400000+2440587.5;
  var lst=(280.46061837+360.98564736629*(jd-2451545)+lon)*rad, ha=lst-raDeg*rad, d=decDeg*rad, f=lat*rad;
  var E=-Math.cos(d)*Math.sin(ha), N=Math.sin(d)*Math.cos(f)-Math.cos(d)*Math.sin(f)*Math.cos(ha), U=Math.sin(d)*Math.sin(f)+Math.cos(d)*Math.cos(f)*Math.cos(ha);
  return {x:E,y:U,z:-N,el:Math.asin(clamp(U,-1,1))/rad};
};
/* Luna (serie reducida, ~1° de error): vector del mundo y elevación. La fase se obtiene luego con el vector al Sol. */
SM.moonPos = function(ms,lat,lon){
  var rad=Math.PI/180, T=(ms/86400000+2440587.5-2451545)/36525, S=function(a){return Math.sin(a*rad);};
  var lam=218.32+481267.881*T+6.29*S(135.0+477198.87*T)-1.27*S(259.3-413335.36*T)+0.66*S(235.7+890534.22*T)+0.21*S(269.9+954397.74*T)-0.19*S(357.5+35999.05*T)-0.11*S(186.5+966404.03*T);
  var bet=5.13*S(93.3+483202.02*T)+0.28*S(228.2+960400.89*T)-0.28*S(318.3+6003.15*T)-0.17*S(217.6-407332.21*T);
  var eps=23.439-0.0130042*T, l=lam*rad, b=bet*rad, e=eps*rad;
  var ra=Math.atan2(Math.sin(l)*Math.cos(e)-Math.tan(b)*Math.sin(e),Math.cos(l)), dec=Math.asin(Math.sin(b)*Math.cos(e)+Math.cos(b)*Math.sin(e)*Math.sin(l));
  return SM.eqVec(ra/rad,dec/rad,ms,lat,lon);
};
/* Fobos: órbita ecuatorial de 7,654 h; visto desde la superficie de Marte (lat. 18,4° N) su ángulo horario decrece 32,4°/h (sale por el oeste).
   La posición inicial es arbitraria (depende del instante ms); el tamaño aparente lo da el sombreador. */
SM.phobosPos = function(ms){
  var rad=Math.PI/180, ha=(((-32.42*ms/3600000)%360)+360)%360*rad, f=18.44*rad;
  var E=-Math.sin(ha), N=-Math.sin(f)*Math.cos(ha), U=Math.cos(f)*Math.cos(ha);
  return {x:E,y:U,z:-N,el:Math.asin(clamp(U,-1,1))/rad};
};
/* Vía Láctea: polo norte galáctico y centro galáctico en el mundo */
SM.galVecs = function(ms,lat,lon){ return {pole:SM.eqVec(192.859,27.128,ms,lat,lon), gc:SM.eqVec(266.405,-28.936,ms,lat,lon)}; };
/* Orto, mediodía solar y ocaso del día (ms) que contiene "ms" en la hora local del navegador */
SM.sunTimes = function(ms,lat,lon){
  var d=new Date(ms), t0=new Date(d.getFullYear(),d.getMonth(),d.getDate(),0,0,0).getTime();
  var rise=null,set=null,noon=t0,best=-99,prev=null;
  for(var m=0;m<=1440;m+=2){ var tt=t0+m*60000, e=SM.sunPos(tt,lat,lon).el;
    if(e>best){ best=e; noon=tt; }
    if(prev!==null){ if(prev<0&&e>=0&&rise===null) rise=tt; if(prev>=0&&e<0) set=tt; }
    prev=e; }
  return {rise:rise,set:set,noon:noon,maxEl:best};
};

/* Escala de Beaufort */
SM.beaufort = function(ms){
  var lim=[0.3,1.6,3.4,5.5,8,10.8,13.9,17.2,20.8,24.5,28.5,32.7];
  for(var i=0;i<lim.length;i++) if(ms<lim[i]) return i; return 12;
};

/* Generador de viento: media (perfil logarítmico/potencial) + turbulencia OU + ráfagas + ladera */
SM.Wind = function(wx, world, seed){
  this.wx=wx; this.world=world; this.r=SM.rng(seed||7);
  this.ou=[0,0,0]; this.gustT=3+this.r()*5; this.gust=null; this.t=0;
  this.alpha = world.rough||0.14;
};
SM.Wind.prototype.mean = function(agl){
  var f = Math.pow(Math.max(agl,2)/10,this.alpha);
  return this.wx.wind*clamp(f,0.35,1.9);
};
SM.Wind.prototype.step = function(dt,x,y,z,agl){
  var wx=this.wx, r=this.r; this.t+=dt;
  var near = this.world.turbNear?this.world.turbNear(x,y,z):1;
  var sig = wx.turb*(0.35*wx.wind+0.4)*near;
  var tau=1.6, k=Math.exp(-dt/tau), s=Math.sqrt(1-k*k);
  for(var i=0;i<3;i++){ var g=(r()+r()+r()+r()-2)*1.73; this.ou[i]=this.ou[i]*k+sig*(i==1?0.6:1)*s*g; }
  /* ráfagas */
  this.gustT-=dt;
  if(this.gustT<=0 && wx.gust>0){ this.gust={a:wx.gust*(0.5+0.5*r()), d:2+2*r(), t:0}; this.gustT=4+10*r(); }
  var ga=0;
  if(this.gust){ this.gust.t+=dt; var u=this.gust.t/this.gust.d; if(u>=1) this.gust=null; else ga=this.gust.a*Math.pow(Math.sin(Math.PI*u),2); }
  var m = this.mean(agl);
  var dirTo = (wx.dir+180)*deg;
  var dx=Math.sin(dirTo), dz=-Math.cos(dirTo);
  var sp = m+ga;
  var vx=dx*sp+this.ou[0], vz=dz*sp+this.ou[2], vy=this.ou[1]*0.6;
  /* efecto orográfico: ascendente en barlovento, descendente en sotavento */
  if(this.world.slope){
    var g2=this.world.slope(x,z), up=(dx*sp*g2.x+dz*sp*g2.z)*Math.exp(-Math.max(agl,0)/70);
    vy+=clamp(up,-9,9);
  }
  var ws=this.world.windScale?this.world.windScale(x,y,z):1; vx*=ws; vy*=ws; vz*=ws;
  this.cur={x:vx,y:vy,z:vz,mean:m*ws,gust:ga*ws,speed:Math.sqrt(vx*vx+vz*vz)};
  return this.cur;
};

/* Batería: tensión en circuito abierto por celda según profundidad de descarga d (0..1) */
SM.vcell = function(chem,d){
  var tab = chem.id==='liion' ? [[0,4.15],[0.1,4.0],[0.3,3.78],[0.5,3.62],[0.8,3.38],[0.95,3.15],[1,2.9],[1.1,2.6]]
                              : [[0,4.20],[0.1,4.05],[0.2,3.93],[0.4,3.82],[0.6,3.75],[0.8,3.65],[0.9,3.55],[1,3.25],[1.1,2.9]];
  return D_.interp(tab,d);
};
SM.capFactor = function(T){ if(D_.PL && D_.PL.id==='mars') return 1;   /* Ingenuity: batería calefactada */
  return clamp(1-0.012*Math.max(0,15-T)-0.003*Math.max(0,T-35),0.4,1.02); };
SM.rintFactor= function(T){ return 1+0.03*Math.max(0,15-T); };

/* Radioenlace -------------------------------------------------- */
SM.fspl = function(dm,fMHz){ return 32.44+20*Math.log10(Math.max(dm,1)/1000)+20*Math.log10(fMHz); };
SM.rangeFree = function(ptDbm,gt,gr,sens,fMHz,extra){
  var Ls = ptDbm+gt+gr-extra-sens;
  return Math.pow(10,(Ls-32.44-20*Math.log10(fMHz))/20)*1000;
};
function jKnife(v){ return v>-0.78 ? 6.9+20*Math.log10(Math.sqrt((v-0.1)*(v-0.1)+1)+v-0.1) : 0; }
/* Pérdida por obstáculos entre a (antena de tierra) y b (dron) */
SM.pathLoss = function(world,a,b,fMHz){
  var dx=b.x-a.x, dy=b.y-a.y, dz=b.z-a.z, d=Math.sqrt(dx*dx+dy*dy+dz*dz);
  if(d<5) return {loss:0,nu:-3,foliage:0,clear:1};
  var lam=300/fMHz, N=Math.min(60,Math.max(16,Math.round(d/25))), nuMax=-9, fol=0, minClear=9;
  for(var i=1;i<N;i++){
    var t=i/N, x=a.x+dx*t, y=a.y+dy*t, z=a.z+dz*t;
    var bt=world.blockTop(x,z,y);
    var d1=d*t, d2=d-d1, F=Math.sqrt(lam*d1*d2/d);
    if(bt.kind==='foliage'){ if(y<bt.top) fol+=Math.min(5,0.25*d/N); continue; }
    var h=bt.top-y;
    var nu=h*Math.sqrt(2*(d1+d2)/(lam*d1*d2));
    if(nu>nuMax) nuMax=nu;
    if(F>0 && -h/F<minClear) minClear=-h/F;
  }
  var L=Math.min(45,Math.max(0,jKnife(nuMax)))+Math.min(25,fol);
  return {loss:L,nu:nuMax,foliage:fol,clear:minClear};
};
SM.rainAtt = function(fMHz,rain,dm){ return Math.pow(fMHz/1000,2.2)*0.0004*Math.pow(Math.max(rain,0),1.1)*dm/1000; };
SM.dbmFromMw = function(mw){ return 10*Math.log10(mw); };

/* Pérdida de ganancia por patrón de antena de tierra según elevación del dron */
SM.antPattern = function(ant,elevDeg){
  if(ant.bw===0){ var c=Math.cos(clamp(elevDeg,0,89)*deg); return 20*Math.log10(Math.max(0.06,c)); }  /* cono de silencio del dipolo */
  var x=elevDeg/(ant.bw/2); return -Math.min(25,12*x*x);
};

/* GNSS: nº de satélites visibles y HDOP según horizonte local */
SM.gnss = function(world,p,rain,jam){
  if(jam||world.noGnss) return {sats:0,hdop:99,err:99,view:0};
  var sum=0, az=8;
  for(var i=0;i<az;i++){
    var a=i*Math.PI*2/az, ex=0;
    for(var r=10;r<=240;r*=1.7){
      var bt=world.blockTop(p.x+Math.sin(a)*r,p.z-Math.cos(a)*r);
      if(bt.kind==='foliage') bt={top:bt.top*0.6};
      var e=Math.atan2(bt.top-p.y,r)/deg; if(e>ex) ex=e;
    }
    sum+=1-clamp(ex/75,0,1);
  }
  var view=sum/az, sats=Math.round(19*view*(rain>8?0.9:1));
  var hdop=0.7+Math.max(0,19-sats)*0.22;
  return {sats:sats,hdop:hdop,view:view};
};
})();
