/* ===== SONIDO (Web Audio, sintetizado: sin archivos) ===== */
var AUD={};
(function(){
var ctx=null, M={}, muted=false, vol=0.7, nextBeep=0, prev={}, nb=null;
try{ muted=localStorage.getItem('santsim_mute')==='1'; }catch(e){}
var clamp=function(v,a,b){return v<a?a:(v>b?b:v);};
function noiseBuf(){ if(nb) return nb; nb=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate); var d=nb.getChannelData(0); for(var i=0;i<d.length;i++) d[i]=Math.random()*2-1; return nb; }
function noiseSrc(){ var s=ctx.createBufferSource(); s.buffer=noiseBuf(); s.loop=true; s.start(); return s; }
function g(v){ var n=ctx.createGain(); n.gain.value=v; return n; }
function bq(t,f,q){ var b=ctx.createBiquadFilter(); b.type=t; b.frequency.value=f; if(q) b.Q.value=q; return b; }
AUD.isMuted=function(){return muted;};
AUD.init=function(){
  if(ctx){ if(ctx.state==='suspended') ctx.resume(); return; }
  var AC=window.AudioContext||window.webkitAudioContext; if(!AC) return;
  try{ ctx=new AC(); }catch(e){ return; }
  M.master=g(muted?0:vol); M.master.connect(ctx.destination);
  /* motores */
  M.lp=bq('lowpass',6000,0.7); M.dist=g(1); M.lp.connect(M.dist); M.dist.connect(M.master);
  M.mLP=bq('lowpass',1800,0.5); M.mG=g(0); M.mLP.connect(M.mG); M.mG.connect(M.lp);
  M.am=g(1); M.am.connect(M.mLP);                                   /* tremolo (palas del helicóptero) */
  M.lfo=ctx.createOscillator(); M.lfo.frequency.value=40; M.lfoD=g(0); M.lfo.connect(M.lfoD); M.lfoD.connect(M.am.gain); M.lfo.start();
  M.osc=[]; [['sawtooth',1,0.5],['sawtooth',1.011,0.4],['sawtooth',0.987,0.4],['square',2.01,0.12],['triangle',0.5,0.3]].forEach(function(c){
    var o=ctx.createOscillator(); o.type=c[0]; o.frequency.value=200; var og=g(c[2]); o.connect(og); og.connect(M.am); o.start(); M.osc.push({o:o,k:c[1],g:og}); });
  M.air=noiseSrc(); M.airF=bq('bandpass',1500,0.6); M.airG=g(0); M.air.connect(M.airF); M.airF.connect(M.airG); M.airG.connect(M.mG);
  /* viento y lluvia (ambiente y viento relativo) */
  M.w=noiseSrc(); M.wF=bq('bandpass',500,0.5); M.wG=g(0); M.w.connect(M.wF); M.wF.connect(M.wG); M.wG.connect(M.master);
  M.r=noiseSrc(); M.rF=bq('highpass',3500,0.5); M.rG=g(0); M.r.connect(M.rF); M.rF.connect(M.rG); M.rG.connect(M.master);
};
AUD.hush=function(){ if(ctx&&M.master) M.master.gain.setTargetAtTime(0,ctx.currentTime,0.03); };
document.addEventListener('visibilitychange',function(){ if(document.hidden) AUD.hush(); });
AUD.setMuted=function(m){ muted=m; try{ localStorage.setItem('santsim_mute',m?'1':'0'); }catch(e){} if(ctx) M.master.gain.setTargetAtTime(m?0:vol,ctx.currentTime,0.05); };
AUD.toggle=function(){ AUD.setMuted(!muted); return muted; };
function tone(f,t0,dur,type,gain,f2){ var o=ctx.createOscillator(), n=g(0); o.type=type||'sine'; o.frequency.setValueAtTime(f,t0); if(f2) o.frequency.exponentialRampToValueAtTime(f2,t0+dur); n.gain.setValueAtTime(0,t0); n.gain.linearRampToValueAtTime(gain,t0+0.008); n.gain.exponentialRampToValueAtTime(0.0008,t0+dur); o.connect(n); n.connect(M.master); o.start(t0); o.stop(t0+dur+0.05); }
function burst(t0,dur,f0,f1,gain,type){ var s=ctx.createBufferSource(); s.buffer=noiseBuf(); var f=bq(type||'lowpass',f0,0.8), n=g(0); f.frequency.setValueAtTime(f0,t0); f.frequency.exponentialRampToValueAtTime(f1,t0+dur); n.gain.setValueAtTime(gain,t0); n.gain.exponentialRampToValueAtTime(0.001,t0+dur); s.connect(f); f.connect(n); n.connect(M.master); s.start(t0,Math.random()); s.stop(t0+dur+0.05); }
AUD.event=function(name){
  if(!ctx||muted) return; var t=ctx.currentTime+0.01;
  if(name==='crash'){ burst(t,1.1,3500,120,1.0); tone(95,t,0.5,'sine',0.9,28); for(var i=0;i<4;i++) tone(300+Math.random()*700,t+0.05+i*0.09+Math.random()*0.05,0.2,'triangle',0.28); burst(t+0.25,0.6,900,100,0.5); }
  else if(name==='ring'){ tone(988,t,0.07,'triangle',0.30); tone(1319,t+0.06,0.40,'triangle',0.30); tone(2637,t+0.06,0.30,'sine',0.12); tone(3951,t+0.06,0.18,'sine',0.05); burst(t,0.08,9000,5000,0.10,'highpass'); }
  else if(name==='ringend'){ [523,659,784,1047,1319].forEach(function(f,i){ tone(f,t+i*0.075,0.30,'triangle',0.28); tone(f*2,t+i*0.075,0.22,'sine',0.08); }); tone(1047,t+0.4,0.6,'triangle',0.22); tone(1319,t+0.4,0.6,'triangle',0.2); tone(1568,t+0.4,0.6,'triangle',0.2); }
  else if(name==='miss'){ tone(260,t,0.18,'sawtooth',0.18,150); }
  else if(name==='land'){ tone(75,t,0.2,'sine',0.5,45); burst(t,0.12,1200,200,0.3); }
  else if(name==='chute'){ burst(t,0.9,400,2500,0.5,'bandpass'); }
  else if(name==='fail'){ tone(420,t,0.7,'sawtooth',0.35,90); burst(t,0.4,2000,300,0.25); }
};
/* f = vuelo; o = {paused, cam, ...} */
AUD.update=function(f,o){
  if(!ctx||!f) return; var t=ctx.currentTime, ac=f.ac;
  /* eventos por cambio de estado */
  if(f.status!==prev.status){ if(f.status==='crashed') AUD.event('crash'); if(f.status==='landed'&&prev.status==='flying'||f.status==='rolling'&&prev.status==='flying') AUD.event('land'); prev.status=f.status; }
  if(f.chuteOpen&&!prev.chute){ AUD.event('chute'); } prev.chute=f.chuteOpen;
  if(f.fail&&!prev.fail){ AUD.event('fail'); } prev.fail=f.fail;
  var silent=o.paused||muted;
  M.master.gain.setTargetAtTime(silent?0:vol,t,0.04);
  if(o.paused) return;
  var running=f.P>12 && f.status!=='crashed' && !f.chuteOpen && (f.status==='flying'||f.status==='rolling'||f.Tcur>0.5) && f.dod<1.06;
  var rev=f.rpm/60, thr=clamp(f.thrPct/100,0,1), heli=ac.kind==='heli', fx=ac.kind==='fixed';
  var fr=heli? clamp(rev*2,50,140) : clamp(rev*(fx?2:2),60,1100);
  var nM=ac.nMotors;
  var vamp=running? (0.05+0.28*Math.pow(thr,1.25))*(0.55+0.12*Math.min(nM,8)) : 0;
  if(heli) vamp*=1.1;
  M.mG.gain.setTargetAtTime(vamp,t,0.05);
  M.osc.forEach(function(s,i){ var k=s.k; if(heli&&i===3) k=(f.rpm>0?3.7:1); s.o.frequency.setTargetAtTime(fr*k*(1+0.003*Math.sin(f.t*3+i)),t,0.05); });
  M.mLP.frequency.setTargetAtTime(fx?900+thr*1800:(heli?700+thr*900:1100+fr*2.5),t,0.1);
  M.lfoD.gain.setTargetAtTime(heli?0.55:(nM>=6?0.06:0.0),t,0.1); M.lfo.frequency.setTargetAtTime(heli?clamp(rev*2,20,120):12,t,0.1);
  M.airG.gain.setTargetAtTime(running?0.15+0.9*thr:0,t,0.1); M.airF.frequency.setTargetAtTime(900+thr*2200,t,0.1);
  /* distancia / perspectiva de cámara */
  var cam=o.cam, att=1, cut=7000;
  if(cam==='vlos'||cam==='top'){ var d=o.dist; att=clamp(1/(1+d/22),0.04,1); cut=clamp(6500/(1+d/55),500,7000); if(cam==='top'){ att*=0.7; } }
  else if(cam==='fpv'){ att=0.75; cut=2600; }
  else { att=0.9; cut=4200; }
  M.dist.gain.setTargetAtTime(att,t,0.08); M.lp.frequency.setTargetAtTime(cut,t,0.08);
  /* viento: ambiente + viento relativo si la cámara va a bordo o cerca */
  var amb=clamp(f.wcur.mean*0.012,0,0.22), rel=0, va=0;
  if(cam==='fpv'||cam==='chase'){ va=fx?f.Va:Math.hypot(f.vel.x-f.wcur.x,f.vel.y-f.wcur.y,f.vel.z-f.wcur.z); rel=clamp(Math.pow(va/22,1.7)*0.4,0,0.5)*(cam==='fpv'?1:0.6); }
  M.wG.gain.setTargetAtTime(Math.min(0.55,amb+rel+(f.wcur.gust*0.008)),t,0.12); M.wF.frequency.setTargetAtTime(260+va*45+f.wcur.mean*30,t,0.15);
  M.rG.gain.setTargetAtTime(clamp(o.rain/40,0,0.28)*(cam==='fpv'?1.2:1),t,0.2);
  /* avisos acústicos */
  if(f.status==='crashed') return;
  if(t>=nextBeep){
    var batt=(1-f.dod)*100, lm=f.sens.ctrl?f.sens.ctrl.margin:99, fly=(f.status==='flying'||f.status==='rolling');
    if(fly&&f.stalled){ tone(1500,t,0.1,'square',0.18); nextBeep=t+0.22; }
    else if(lm<0&&fly){ tone(720,t,0.18,'square',0.2); tone(480,t+0.2,0.18,'square',0.2); nextBeep=t+0.55; }
    else if(batt<15&&fly){ tone(1320,t,0.1,'square',0.2); tone(990,t+0.14,0.1,'square',0.2); nextBeep=t+0.9; }
    else if(fly&&(lm<6||(f.agl&&f.agl()>120))){ tone(1000,t,0.12,'sine',0.2); nextBeep=t+1.2; }
    else if(batt<30&&fly){ tone(880,t,0.14,'sine',0.17); nextBeep=t+3.5; }
    else nextBeep=t+0.3;
  }
};
})();
