/* ===== EMISORA REAL (Gamepad API): radio por USB, cable de simulador o dongle que se vea como "joystick" ===== */
(function(){
var $=function(id){return document.getElementById(id);};
var PAD=SIM.PAD={out:{on:false,yaw:0,thr:0,roll:0,pitch:0,thrAbs:undefined}, hooks:{}};
var FN={thr:'Gas / altura',yaw:'Guiñada (timón)',pitch:'Cabeceo (adelante/atrás)',roll:'Alabeo (izq./dcha.)'};
var AUXN={cam:'Cambiar cámara',rth:'Regreso a casa (RTH)',land:'Aterrizar (suave)',mode:'GPS ↔ ATTI',pause:'Pausa',reset:'Reiniciar vuelo',chute:'Paracaídas',fail:'Fallo de motor'};
var AUXLVL={rth:1,land:1};            /* interruptores: activo = on, inactivo = off */
function ax(a,inv){ return {a:a,inv:inv?1:0,lo:-1,hi:1,c:0}; }
var PRE={
  aetr:{name:'Emisora RC · orden AETR (EdgeTX, OpenTX, Betaflight)',thr:ax(2),yaw:ax(3),pitch:ax(1),roll:ax(0)},
  taer:{name:'Emisora RC · orden TAER (FrSky, Spektrum, FlySky)',thr:ax(0),yaw:ax(3),pitch:ax(2),roll:ax(1)},
  /* mando de consola (ejes 0=izq. horiz., 1=izq. vert., 2=dcha. horiz., 3=dcha. vert.; arriba = negativo, de ahí inv) */
  c1:{name:'Mando de consola · Modo 1',pitch:ax(1,1),yaw:ax(0),thr:ax(3,1),roll:ax(2)},
  c2:{name:'Mando de consola · Modo 2',thr:ax(1,1),yaw:ax(0),pitch:ax(3,1),roll:ax(2)},
  c3:{name:'Mando de consola · Modo 3',pitch:ax(1,1),roll:ax(0),thr:ax(3,1),yaw:ax(2)},
  c4:{name:'Mando de consola · Modo 4',thr:ax(1,1),roll:ax(0),pitch:ax(3,1),yaw:ax(2)}
};
PRE.xbox=PRE.c2;   /* compatibilidad con perfiles guardados */
var cfg={on:true,dz:0.04,expo:0,hold:0.5,padId:'',map:JSON.parse(JSON.stringify({thr:PRE.aetr.thr,yaw:PRE.aetr.yaw,pitch:PRE.aetr.pitch,roll:PRE.aetr.roll})),aux:{}};
try{ var sv=JSON.parse(localStorage.getItem('santsim_pad')||'null'); if(sv&&sv.map) cfg=Object.assign(cfg,sv); }catch(e){}
function save(){ try{ localStorage.setItem('santsim_pad',JSON.stringify(cfg)); }catch(e){} }
cfg.seen=cfg.seen||{};
var cur=null, snap=null, touched=false, learn=null, cal=null, prevAux={}, lastKey='', rawAx=[], rawBt=[];

function list(){ var g=(navigator.getGamepads?navigator.getGamepads():[])||[], r=[]; for(var i=0;i<g.length;i++) if(g[i]&&g[i].connected&&g[i].axes&&g[i].axes.length>=2) r.push(g[i]); return r; }
function pick(l){ if(!l.length) return null; for(var i=0;i<l.length;i++) if(l[i].id===cfg.padId) return l[i]; return l[0]; }

function norm(m,raw,isThr){
  if(raw===undefined||raw===null) return 0;
  var lo=m.lo,hi=m.hi,n;
  if(isThr){ n=(hi-lo)>0.05?(raw-lo)/(hi-lo)*2-1:raw; }
  else { var c=m.c; n=raw>=c?(hi-c>0.05?(raw-c)/(hi-c):raw-c):(c-lo>0.05?(raw-c)/(c-lo):raw-c); }
  n=Math.max(-1,Math.min(1,n)); if(m.inv) n=-n;
  if(isThr) return n;
  return shape(n,cfg.dz);
}
function shape(n,dz){ var a=Math.abs(n); if(a<dz) return 0; a=(a-dz)/(1-dz); var e=cfg.expo; a=(1-e)*a+e*a*a*a; return n<0?-a:a; }
/* gas: el stick (0..1) pasa a orden de ascenso/descenso (−1..1) con el punto de mantener altura en «hold» */
function thrCmd(s){ var h=cfg.hold, a=s<h?-(h-s)/h:(s-h)/(1-h); return shape(a,cfg.dz*1.5); }
function auxState(d,g){ if(!d) return false; if(d.t==='b') return !!(g.buttons[d.i]&&g.buttons[d.i].pressed); var v=g.axes[d.i]; return v!==undefined&&v*d.d>0.5; }

function poll(){
  var l=list(), g=pick(l); cur=g;
  if(!g){ PAD.out.on=false; PAD.out.thrAbs=undefined; snap=null; touched=false; PAD.state=l.length?'':'none'; draw(); return; }
  if(!snap||snap.id!==g.id){ snap={id:g.id,ax:g.axes.slice()}; touched=false;
    if(!cfg.seen[g.id]){   /* primera vez que se ve este dispositivo: perfil probable según su nombre */
      var pre=/spektrum|ws2000|ws1000|horizon|dsm/i.test(g.id)?'taer':(g.mapping==='standard'?'c2':'aetr');
      for(var kk in FN) cfg.map[kk]=JSON.parse(JSON.stringify(PRE[pre][kk])); cfg.seen[g.id]=pre; PAD.autoPre=pre; save(); }
    render(); }
  rawAx=g.axes; rawBt=g.buttons;
  if(g.timestamp!==PAD._ts){ PAD._ts=g.timestamp; var nw=performance.now(); if(PAD._tn){ var dt=nw-PAD._tn; PAD.hz=PAD.hz?PAD.hz*0.9+0.1*(1000/Math.max(dt,1)):1000/Math.max(dt,1); } PAD._tn=nw; }
  var i; if(!touched){ for(i=0;i<g.axes.length;i++) if(Math.abs(g.axes[i]-snap.ax[i])>0.12){ touched=true; break; } if(!touched) for(i=0;i<g.buttons.length;i++) if(g.buttons[i].pressed){ touched=true; break; } }
  /* aprendizaje de ejes / interruptores */
  if(learn){
    if(learn.kind==='axis'){ var bi=-1,bd=0.5; for(i=0;i<g.axes.length;i++){ var dd=Math.abs(g.axes[i]-snap.ax[i]); if(dd>bd){ bd=dd; bi=i; } } if(bi>=0){ cfg.map[learn.key].a=bi; cfg.map[learn.key].lo=-1; cfg.map[learn.key].hi=1; cfg.map[learn.key].c=snap.ax[bi]; learn=null; save(); render(); } }
    else { var found=null; for(i=0;i<g.buttons.length;i++) if(g.buttons[i].pressed){ found={t:'b',i:i}; break; }
      if(!found) for(i=0;i<g.axes.length;i++){ var d2=g.axes[i]-snap.ax[i]; if(Math.abs(d2)>0.6){ found={t:'a',i:i,d:d2>0?1:-1}; break; } }
      if(found){ cfg.aux[learn.key]=found; learn=null; save(); render(); } }
  }
  /* calibración */
  if(cal){ for(i=0;i<g.axes.length;i++){ cal.min[i]=Math.min(cal.min[i]===undefined?9:cal.min[i],g.axes[i]); cal.max[i]=Math.max(cal.max[i]===undefined?-9:cal.max[i],g.axes[i]); } }
  var o=PAD.out, m=cfg.map, key;
  o.on=!!(cfg.on&&touched&&!learn&&!cal);
  if(o.on){
    ['yaw','pitch','roll'].forEach(function(k){ o[k]=norm(m[k],g.axes[m[k].a],false); });
    var tn=norm(m.thr,g.axes[m.thr.a],true), ts=(tn+1)/2; o.thr=thrCmd(ts); o.thrAbs=ts;
    for(key in AUXN){ var st=auxState(cfg.aux[key],g), pv=prevAux[key]; if(pv===undefined){ prevAux[key]=st; continue; }
      if(st!==pv){ prevAux[key]=st; var h=PAD.hooks[key]; if(h&&!SIM.hangarOpen()){ if(AUXLVL[key]) h(st); else if(st) h(); } } }
  } else { o.yaw=o.pitch=o.roll=o.thr=0; o.thrAbs=undefined; for(key in AUXN) prevAux[key]=auxState(cfg.aux[key],g); }
  draw();
}

/* ---------- interfaz ---------- */
var el=null;
function opts(sel,n){ var s=''; for(var i=0;i<n;i++) s+='<option value="'+i+'"'+(i===sel?' selected':'')+'>Eje '+(i+1)+'</option>'; return s; }
function auxTxt(d){ return !d?'<i style="color:var(--ink3,#888)">sin asignar</i>':(d.t==='b'?'Botón '+(d.i+1):'Eje '+(d.i+1)+(d.d>0?' (+)':' (−)')); }
function render(){
  if(!el) return; var g=cur, h='';
  var l=list();
  h+='<div class="card"><h3>Emisora detectada</h3><div class="bd">';
  if(!l.length){
    h+='<div class="note" style="margin-top:0"><b>No se detecta ninguna emisora.</b> Conéctala por USB (en el menú de la radio elige modo <b>«USB Joystick (HID)»</b>), o usa un cable de simulador / dongle y <b>mueve un stick o pulsa un botón</b>: el navegador no la muestra hasta que recibe algo. Con Chrome o Edge, mejor.</div>';
  } else {
    if(PAD.autoPre&&g) h+='<div class="note" style="margin-top:0">Perfil aplicado al detectarla: <b>'+PRE[PAD.autoPre].name+'</b>. Comprueba que los ejes se mueven como esperas y, si no, pulsa otro perfil o «Detectar».</div>';
    h+='<div class="row"><label>Dispositivo</label><select id="padSel">'+l.map(function(p){ return '<option value="'+p.index+'"'+(g&&p.index===g.index?' selected':'')+'>'+p.id.replace(/</g,'')+'</option>'; }).join('')+'</select></div>';
  }
  h+='<details style="margin:6px 0"><summary style="cursor:pointer;font-size:12px;font-weight:600">Cómo conectar una RadioMaster TX16S (EdgeTX)</summary><div class="note"><b>A) Cable USB-C:</b> enciende la radio, conéctala y elige <b>«USB Joystick (HID)»</b>. Los canales salen en orden: CH1→Eje 1, CH2→Eje 2, CH3→Eje 3, CH4→Eje 4… (CH5–CH8 los interruptores). El orden depende de cómo tengas el modelo (AETR, TAER…): si no coincide, pulsa «Detectar».<br><b>B) Dongle Spektrum (WS1000/WS2000):</b> en el modelo activa el módulo interno <b>MULTI → DSM → DSMX</b>; enchufa el dongle con su botón pulsado (LED naranja parpadeando) y pon la radio en modo bind; LED fijo = enlazado. Spektrum envía los canales en orden <b>TAER</b> (gas, alabeo, cabeceo, timón), que es el perfil que se aplica solo.</div></details>';
  h+='<label class="chk"><input type="checkbox" id="padOn"'+(cfg.on?' checked':'')+'><div>Usar la emisora para volar<small>Se activa cuando mueves un mando. El teclado y la pantalla táctil siguen funcionando si no tocas la emisora.</small></div></label>';
  h+='<div class="note" id="padState"></div>';
  if(g){
    h+='<div id="padAx" style="margin-top:8px">'; for(var i=0;i<Math.min(g.axes.length,10);i++){
      var fn=''; for(var k in cfg.map) if(cfg.map[k].a===i) fn+=(fn?' · ':'')+FN[k].split(' ')[0];
      h+='<div style="display:flex;align-items:center;gap:8px;font-size:11px;margin:2px 0"><span style="width:44px;font-family:var(--mono)">Eje '+(i+1)+'</span><span style="flex:1;height:9px;background:#e8ecef;border:1px solid var(--line2);position:relative"><i id="padA'+i+'" style="position:absolute;top:-1px;width:3px;height:9px;background:var(--blue);left:50%"></i></span><span id="padV'+i+'" style="width:42px;text-align:right;font-family:var(--mono)"></span><span style="width:84px;color:var(--ink2)">'+fn+'</span></div>'; }
    h+='</div>';
    h+='<div id="padBt" style="display:flex;flex-wrap:wrap;gap:3px;margin-top:6px">'; for(var b=0;b<Math.min(g.buttons.length,24);b++) h+='<span id="padB'+b+'" style="min-width:24px;text-align:center;font-size:10px;padding:1px 3px;border:1px solid var(--line2);font-family:var(--mono)">'+(b+1)+'</span>'; h+='</div>';
  }
  h+='<div style="margin-top:10px"><b>Emisora RC</b> <span class="note" style="margin:0">(el modo de sticks 1–4 lo define la propia emisora; aquí sólo eliges el orden de canales)</span></div>';
  h+='<div class="pre" style="margin-top:4px;flex-wrap:wrap">'+['aetr','taer'].map(function(k){ return '<button class="btn" data-pre="'+k+'">'+PRE[k].name+'</button>'; }).join('')+'</div>';
  h+='<div style="margin-top:8px"><b>Mando de consola</b> <span class="note" style="margin:0">(elige el modo de sticks; el modo 2 es el habitual: izquierdo = gas y giro, derecho = avance y lateral)</span></div>';
  h+='<div class="pre" style="margin-top:4px;flex-wrap:wrap">'+['c1','c2','c3','c4'].map(function(k){ return '<button class="btn" data-pre="'+k+'">'+PRE[k].name.replace('Mando de consola · ','')+(k==='c2'?' (habitual)':'')+'</button>'; }).join('')+'</div>';
  h+='<div class="row" style="margin-top:8px"><label>Zona muerta</label><div class="val"><input type="range" id="padDz" min="0" max="0.15" step="0.01" value="'+cfg.dz+'"><span id="padDzV">'+Math.round(cfg.dz*100)+' %</span></div></div>';
  h+='<div class="row"><label>Gas: punto de mantener altura</label><div class="val"><input type="range" id="padHold" min="0.15" max="0.5" step="0.05" value="'+cfg.hold+'"><span id="padHoldV">'+Math.round(cfg.hold*100)+' % del recorrido</span></div></div><div class="note" style="margin-top:0">En multirrotor el dron sólo sube cuando el stick de gas pasa de este punto (como el modo AltHold/Loiter de ArduPilot). Con 50 % hay que subir medio recorrido antes de que reaccione; bájalo (p. ej. 25 %) para despegar antes.</div>';
  h+='<div class="row"><label>Expo (suavizar el centro)</label><div class="val"><input type="range" id="padEx" min="0" max="0.7" step="0.05" value="'+cfg.expo+'"><span id="padExV">'+Math.round(cfg.expo*100)+' %</span></div></div>';
  h+='<div class="pre" style="margin-top:8px"><button class="btn'+(cal?' warn':'')+'" id="padCal">'+(cal?'Terminar calibración':'Calibrar recorrido')+'</button></div>';
  h+='<div class="note">'+(cal?'<b>Calibrando:</b> deja los sticks en el centro un instante, luego mueve todos los mandos a todos sus extremos varias veces y pulsa «Terminar».':'Calibra si los sticks no llegan a ±100 % o no centran en 0. Suelta primero los sticks (el gas puede quedar abajo).')+'</div>';
  h+='</div></div>';
  h+='<div class="card"><h3>Asignación de mandos</h3><div class="bd"><table class="tbl" style="width:100%;font-size:12px">';
  h+='<tr><th align=left>Función</th><th>Eje</th><th>Invertir</th><th></th></tr>';
  for(var k2 in FN){ var m=cfg.map[k2]; h+='<tr><td>'+FN[k2]+'</td><td><select data-ax="'+k2+'">'+opts(m.a,Math.max(8,g?g.axes.length:8))+'</select></td><td align=center><input type="checkbox" data-inv="'+k2+'"'+(m.inv?' checked':'')+'></td><td><button class="btn'+(learn&&learn.key===k2?' warn':'')+'" data-learn="axis:'+k2+'">'+(learn&&learn.key===k2?'Mueve el stick…':'Detectar')+'</button></td></tr>'; }
  h+='</table><div class="note">Pulsa «Detectar» y mueve el stick correspondiente. Si va al revés, marca «Invertir». Cabeceo: adelante = avanzar.</div>';
  h+='<h3 style="margin:12px -12px 6px">Interruptores y botones</h3><table class="tbl" style="width:100%;font-size:12px"><tr><th align=left>Función</th><th align=left>Asignado a</th><th></th></tr>';
  for(var a in AUXN) h+='<tr><td>'+AUXN[a]+(AUXLVL[a]?' <small>(interruptor)</small>':'')+'</td><td>'+auxTxt(cfg.aux[a])+'</td><td style="white-space:nowrap"><button class="btn'+(learn&&learn.key===a?' warn':'')+'" data-learn="aux:'+a+'">'+(learn&&learn.key===a?'Acciona…':'Detectar')+'</button> <button class="btn" data-clr="'+a+'">✕</button></td></tr>';
  h+='</table><div class="note">«Detectar» y acciona el interruptor o botón de la emisora. RTH y Aterrizar actúan como interruptor: arriba = activo, abajo = cancelar. En ala fija, el stick de gas fija la potencia directamente; en multirrotor, el centro mantiene la altura.</div>';
  h+='</div></div>';
  if(h!==lastKey){ el.innerHTML=h; lastKey=h; }
}
function draw(){
  var st=$('padState'); if(!el||!st) return; var g=cur;
  var txt=!g?'Sin emisora.':(cfg.on?(PAD.out.on?'<b style="color:var(--green,#1b7a3a)">● Emisora activa</b> — controlas el dron con ella.'+(PAD.hz?' <span style="color:var(--ink2)">('+Math.round(PAD.hz)+' informes/s)</span>':''):(cal?'Calibrando…':(learn?'Esperando mando…':'Emisora detectada. Mueve un stick para activarla.'))):'Emisora desactivada.');
  if(st._t!==txt){ st.innerHTML=txt; st._t=txt; }
  if(!g) return;
  for(var i=0;i<Math.min(g.axes.length,10);i++){ var a=$('padA'+i), v=$('padV'+i); if(!a) break; var x=(g.axes[i]+1)/2*100; a.style.left='calc('+Math.max(0,Math.min(100,x))+'% - 1px)'; v.textContent=Math.round(g.axes[i]*100)+'%'; }
  for(var b=0;b<Math.min(g.buttons.length,24);b++){ var bb=$('padB'+b); if(!bb) break; var on=g.buttons[b].pressed; if(bb._o!==on){ bb._o=on; bb.style.background=on?'var(--blue)':''; bb.style.color=on?'#fff':''; } }
}
PAD.init=function(){
  el=$('padUI'); if(!el) return; render();
  el.addEventListener('change',function(e){ var t=e.target;
    if(t.id==='padOn'){ cfg.on=t.checked; save(); }
    else if(t.id==='padSel'){ var g=(navigator.getGamepads()||[])[+t.value]; if(g){ cfg.padId=g.id; snap=null; save(); render(); } }
    else if(t.dataset.ax){ var m=cfg.map[t.dataset.ax]; m.a=+t.value; m.lo=-1; m.hi=1; m.c=0; save(); lastKey=''; render(); }
    else if(t.dataset.inv){ cfg.map[t.dataset.inv].inv=t.checked?1:0; save(); } });
  el.addEventListener('input',function(e){ var t=e.target; if(t.id==='padDz'){ cfg.dz=+t.value; $('padDzV').textContent=Math.round(cfg.dz*100)+' %'; save(); } if(t.id==='padHold'){ cfg.hold=+t.value; $('padHoldV').textContent=Math.round(cfg.hold*100)+' % del recorrido'; save(); } if(t.id==='padEx'){ cfg.expo=+t.value; $('padExV').textContent=Math.round(cfg.expo*100)+' %'; save(); } });
  el.addEventListener('click',function(e){ var t=e.target.closest('button'); if(!t) return;
    if(t.dataset.pre){ var p=PRE[t.dataset.pre]; for(var k in FN) cfg.map[k]=JSON.parse(JSON.stringify(p[k])); save(); lastKey=''; render(); }
    else if(t.dataset.learn){ var q=t.dataset.learn.split(':'); if(!cur) return; snap={id:cur.id,ax:cur.axes.slice()}; learn=(learn&&learn.key===q[1])?null:{kind:q[0],key:q[1]}; lastKey=''; render(); }
    else if(t.dataset.clr){ delete cfg.aux[t.dataset.clr]; save(); lastKey=''; render(); }
    else if(t.id==='padCal'){ if(!cal){ if(!cur) return; cal={min:[],max:[],c:cur.axes.slice()}; } else { var g=cur; if(g){ for(var kk in cfg.map){ var m=cfg.map[kk], i=m.a; if(cal.min[i]!==undefined&&cal.max[i]-cal.min[i]>0.5){ m.lo=cal.min[i]; m.hi=cal.max[i]; m.c=(kk==='thr')?0:cal.c[i]; } } save(); } cal=null; } lastKey=''; render(); } });
};
PAD.refresh=function(){ lastKey=''; render(); };
PAD.active=function(){ return PAD.out.on; };
window.addEventListener('gamepadconnected',function(){ lastKey=''; render(); });
window.addEventListener('gamepaddisconnected',function(){ lastKey=''; snap=null; render(); });
PAD.init();
setInterval(poll,8);
setInterval(function(){ var n=list().length; if(n!==PAD._n){ PAD._n=n; lastKey=''; render(); } },700);
})();
