/* ===== MARTE (fantasía): bases marcianas, rocas, rover, polvo y remolinos (gráficos) ===== */
/* Se carga tras 47_actors3d.js. Usa THREE y GFX (sólo en tiempo de ejecución). Expone MARS3D. */
var MARS3D={};
(function(){
var PI=Math.PI;
function LM(o){ o=o||{}; if(o.roughness===undefined) o.roughness=0.85; o.metalness=o.metalness||0; if(o.envMapIntensity===undefined) o.envMapIntensity=0.3; return new THREE.MeshStandardMaterial(o); }
function hash(n){ var v=Math.abs(Math.sin(n*12.9898+78.233)*43758.5453); return v-Math.floor(v); }

/* ---------- bases, rocas y riscos: se dibujan a partir de los obstáculos custom:'mars' (cada uno con su "mv") ---------- */
MARS3D.build=function(G,w){
  var list=w.obstacles.filter(function(o){ return o.custom==='mars'; });
  var dummy=new THREE.Object3D(), cc=new THREE.Color();
  var white=LM({color:0xece8e0,roughness:0.5}), grey=LM({color:0xb9bdc1,roughness:0.5,metalness:0.3}), dark=LM({color:0x1b1f26,roughness:0.35,metalness:0.2}),
      glass=new THREE.MeshStandardMaterial({color:0x10202c,roughness:0.15,metalness:0.4,emissive:0x2a5a78,emissiveIntensity:0.0}),
      redM=new THREE.MeshBasicMaterial({color:0xff3a2a,toneMapped:false}), orangeM=LM({color:0xd9632a,roughness:0.6});
  var wins=[];                                         /* ventanas: se iluminan por la noche (GFX.uNight) */
  function mesh(g,m,x,y,z,sh){ var me=new THREE.Mesh(g,m); me.position.set(x,y,z); me.castShadow=sh!==false; me.receiveShadow=true; G.add(me); return me; }
  function win(x,y,z,sx,sy,sz,ry){ var me=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),glass); me.position.set(x,y,z); me.rotation.y=ry||0; G.add(me); wins.push(me); }
  var rocks=[], buttes=[], panels=[];
  list.forEach(function(o){
    var mv=o.mv, r=o.dx, y0=o.y0, col=o.color;
    if(mv==='rock') rocks.push(o); else if(mv==='butte') buttes.push(o); else if(mv==='panel') panels.push(o);
    else if(mv==='dome'){
      var mat=LM({color:col,roughness:0.45});
      var dome=new THREE.Mesh(new THREE.SphereGeometry(r,28,14,0,PI*2,0,PI/2),mat); dome.position.set(o.x,y0,o.z); dome.castShadow=true; dome.receiveShadow=true; G.add(dome);
      mesh(new THREE.CylinderGeometry(r*1.04,r*1.06,0.9,28),grey,o.x,y0+0.45,o.z);
      var nw=Math.max(6,Math.round(r*1.6)); for(var k=0;k<nw;k++){ var a=k/nw*PI*2+0.2; win(o.x+Math.cos(a)*r*0.9,y0+r*0.42,o.z+Math.sin(a)*r*0.9,r*0.14,r*0.12,r*0.05,-a+PI/2); }
      mesh(new THREE.CylinderGeometry(0.12,0.12,r*0.7,6),grey,o.x,y0+r+r*0.3,o.z,false);
      mesh(new THREE.SphereGeometry(0.28,8,6),redM,o.x,y0+r+r*0.66,o.z,false);
    }
    else if(mv==='tubeX'||mv==='tubeZ'){
      var rad=(mv==='tubeX'?o.dz:o.dx)/2, len=mv==='tubeX'?o.dx:o.dz;
      var tg=new THREE.CylinderGeometry(rad,rad,len,20), tm=mesh(tg,LM({color:col,roughness:0.5}),o.x,y0+rad,o.z);
      if(mv==='tubeX') tm.rotation.z=PI/2; else tm.rotation.x=PI/2;
      var nr=Math.max(2,Math.floor(len/4.5));
      for(var i=0;i<=nr;i++){ var u=-len/2+len*i/nr, rg=new THREE.Mesh(new THREE.CylinderGeometry(rad*1.05,rad*1.05,0.28,20),grey);
        if(mv==='tubeX'){ rg.rotation.z=PI/2; rg.position.set(o.x+u,y0+rad,o.z); } else { rg.rotation.x=PI/2; rg.position.set(o.x,y0+rad,o.z+u); } rg.castShadow=true; G.add(rg); }
      var nwn=Math.max(2,Math.floor(len/3.2)); for(var j=0;j<nwn;j++){ var uu=-len/2+len*(j+0.5)/nwn;
        if(mv==='tubeX'){ win(o.x+uu,y0+rad*1.15,o.z+rad*0.93,1.1,0.55,0.12,0); win(o.x+uu,y0+rad*1.15,o.z-rad*0.93,1.1,0.55,0.12,0); }
        else { win(o.x+rad*0.93,y0+rad*1.15,o.z+uu,0.12,0.55,1.1,0); win(o.x-rad*0.93,y0+rad*1.15,o.z+uu,0.12,0.55,1.1,0); } }
    }
    else if(mv==='lock'){
      mesh(new THREE.BoxGeometry(o.dx,o.h,o.dz),LM({color:col,roughness:0.5}),o.x,y0+o.h/2,o.z);
      mesh(new THREE.BoxGeometry(o.dx*0.5,o.h*0.62,0.2),dark,o.x,y0+o.h*0.34,o.z+o.dz/2+0.05,false); mesh(new THREE.SphereGeometry(0.25,8,6),orangeM,o.x,y0+o.h+0.25,o.z,false);
    }
    else if(mv==='tank'){
      mesh(new THREE.CylinderGeometry(r,r,o.h-r,20),LM({color:col,roughness:0.4,metalness:0.4}),o.x,y0+(o.h-r)/2,o.z);
      mesh(new THREE.SphereGeometry(r,20,10,0,PI*2,0,PI/2),LM({color:col,roughness:0.4,metalness:0.4}),o.x,y0+o.h-r,o.z);
      [0.25,0.6].forEach(function(f){ mesh(new THREE.CylinderGeometry(r*1.03,r*1.03,0.35,20),orangeM,o.x,y0+o.h*f,o.z,false); });
    }
    else if(mv==='mast'){
      var nb=6, seg=o.h/nb; for(var b=0;b<nb;b++) mesh(new THREE.CylinderGeometry(r*(1-b*0.07),r*(1-(b-1)*0.07),seg,10),LM({color:(b%2?0xd9632a:0xf1f1ee),roughness:0.5}),o.x,y0+seg*(b+0.5),o.z);
      mesh(new THREE.BoxGeometry(2.4,0.12,0.12),grey,o.x,y0+o.h*0.82,o.z,false); mesh(new THREE.BoxGeometry(0.12,0.12,2.4),grey,o.x,y0+o.h*0.7,o.z,false);
      mesh(new THREE.SphereGeometry(0.4,8,6),redM,o.x,y0+o.h+0.35,o.z,false);
      var dh=mesh(new THREE.SphereGeometry(2.2,16,6,0,PI*2,0,0.55),white,o.x+1.6,y0+o.h*0.9,o.z,true); dh.rotation.set(-0.5,0.4,0.0); dh.material.side=THREE.DoubleSide;
    }
    else if(mv==='dish'){
      mesh(new THREE.CylinderGeometry(0.5,0.65,o.h*0.7,8),grey,o.x,y0+o.h*0.35,o.z);
      var dsh=mesh(new THREE.SphereGeometry(6.5,24,8,0,PI*2,0,0.55),white,o.x,y0+o.h*0.7+0.3,o.z,true); dsh.material=LM({color:0xf0f0ee,roughness:0.4,metalness:0.2}); dsh.material.side=THREE.DoubleSide; dsh.rotation.set(-0.6,0.9,0);
      mesh(new THREE.CylinderGeometry(0.07,0.07,3.2,5),grey,o.x+1.2,y0+o.h*0.7+2.6,o.z-1.6,false);
    }
    else if(mv==='garage'){
      mesh(new THREE.BoxGeometry(o.dx,o.h,o.dz),LM({color:col,roughness:0.6}),o.x,y0+o.h/2,o.z);
      mesh(new THREE.BoxGeometry(o.dx*0.62,o.h*0.7,0.25),dark,o.x,y0+o.h*0.37,o.z+o.dz/2+0.06,false);
      mesh(new THREE.BoxGeometry(o.dx*0.7,0.3,o.dz*0.7),grey,o.x,y0+o.h+0.15,o.z,false);
    }
  });
  /* huerto solar: un solo InstancedMesh */
  if(panels.length){
    var pm=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshStandardMaterial({color:0xffffff,roughness:0.28,metalness:0.55,envMapIntensity:0.9}),panels.length);
    panels.forEach(function(o,i){ dummy.position.set(o.x,o.y0+1.15,o.z); dummy.scale.set(o.dx,0.12,o.dz); dummy.rotation.set(-0.43,0,0); dummy.updateMatrix(); pm.setMatrixAt(i,dummy.matrix); cc.setHex(0x1c2f66); pm.setColorAt(i,cc); });
    pm.instanceMatrix.needsUpdate=true; pm.instanceColor.needsUpdate=true; pm.castShadow=true; pm.receiveShadow=true; G.add(pm);
    var lg=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),grey,panels.length*2);
    panels.forEach(function(o,i){ [-0.3,0.3].forEach(function(s,k){ dummy.position.set(o.x+s*o.dx,o.y0+0.5,o.z); dummy.scale.set(0.18,1.0,0.18); dummy.rotation.set(0,0,0); dummy.updateMatrix(); lg.setMatrixAt(i*2+k,dummy.matrix); }); });
    lg.instanceMatrix.needsUpdate=true; G.add(lg);
  }
  /* rocas: icosaedros deformados */
  function rockGeo(det,amp,seed){ var g=new THREE.IcosahedronGeometry(1,det), p=g.attributes.position; for(var i=0;i<p.count;i++){ var x=p.getX(i),y=p.getY(i),z=p.getZ(i), k=1+amp*(Math.sin(x*3.1+seed)*Math.cos(z*2.7+seed*1.7)+0.6*Math.sin(y*4.3+x*2.0+seed)); p.setXYZ(i,x*k,Math.max(y*k,-0.35),z*k); } g.computeVertexNormals(); return g; }
  var det=(GFX.q&&GFX.q.geo>=2)?2:1;
  if(rocks.length){
    var rm=new THREE.InstancedMesh(rockGeo(det,0.22,1.3),LM({color:0xffffff,roughness:0.95}),rocks.length);
    rocks.forEach(function(o,i){ var h=hash(o.x*0.37+o.z*0.91); dummy.position.set(o.x,o.y0+o.h*0.28,o.z); dummy.scale.set(o.dx*(0.9+0.4*h),o.h*0.9,o.dx*(1.1-0.3*h)); dummy.rotation.set(0,h*6.28,0); dummy.updateMatrix(); rm.setMatrixAt(i,dummy.matrix); cc.setHex(o.color); cc.offsetHSL(0,0,(h-0.5)*0.06); rm.setColorAt(i,cc); });
    rm.instanceMatrix.needsUpdate=true; rm.instanceColor.needsUpdate=true; rm.castShadow=true; rm.receiveShadow=true; G.add(rm);
  }
  if(buttes.length){
    var bg=new THREE.CylinderGeometry(0.72,1.0,1,14,4), bp=bg.attributes.position; for(var q=0;q<bp.count;q++){ var bx=bp.getX(q),by=bp.getY(q),bz=bp.getZ(q), kk=1+0.14*Math.sin(bx*5.0+by*7.0)*Math.cos(bz*4.0)+0.08*Math.sin(by*13.0); bp.setXYZ(q,bx*kk,by,bz*kk); } bg.computeVertexNormals();
    var bm=new THREE.InstancedMesh(bg,LM({color:0xffffff,roughness:0.96}),buttes.length);
    buttes.forEach(function(o,i){ var h=hash(o.x*0.11+o.z*0.23); dummy.position.set(o.x,o.y0+o.h*0.5-1,o.z); dummy.scale.set(o.dx,o.h+1,o.dx*(0.8+0.3*h)); dummy.rotation.set(0,h*6.28,0); dummy.updateMatrix(); bm.setMatrixAt(i,dummy.matrix); cc.setHex(o.color); cc.offsetHSL(0,0,(h-0.5)*0.05); bm.setColorAt(i,cc); });
    bm.instanceMatrix.needsUpdate=true; bm.instanceColor.needsUpdate=true; bm.castShadow=true; bm.receiveShadow=true; G.add(bm);
  }
  MARS3D.wins=wins;
};
/* las ventanas de los módulos se encienden de noche */
MARS3D.night=function(k){ var ws=MARS3D.wins||[]; for(var i=0;i<ws.length;i++){ ws[i].material.emissiveIntensity=k*1.8; } };

/* ---------- rover (tipo Perseverance): chasis marfil, mástil con cámaras, brazo, RTG y 6 ruedas; el frente es −z ---------- */
MARS3D.rover=function(){
  var g=new THREE.Group(), wheels=[];
  var body=LM({color:0xe6e1d6,roughness:0.5,metalness:0.1}), alu=LM({color:0xb8bcc2,roughness:0.35,metalness:0.8}), blk=LM({color:0x1a1d22,roughness:0.5,metalness:0.2}), gold=LM({color:0xd6a63a,roughness:0.3,metalness:0.8});
  function box(w,h,d,m,x,y,z){ var me=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m); me.position.set(x,y,z); me.castShadow=true; me.receiveShadow=true; g.add(me); return me; }
  function tube(a,b,r,m){ var dx=b[0]-a[0],dy=b[1]-a[1],dz=b[2]-a[2], len=Math.sqrt(dx*dx+dy*dy+dz*dz); var me=new THREE.Mesh(new THREE.CylinderGeometry(r,r,len,6),m); me.position.set((a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2); me.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),new THREE.Vector3(dx,dy,dz).normalize()); me.castShadow=true; g.add(me); return me; }
  box(1.7,0.62,2.6,body,0,1.15,0.05); box(1.55,0.12,2.4,gold,0,1.5,0.05); box(1.2,0.3,1.0,blk,0,1.67,0.5);
  box(0.7,0.28,0.55,body,0,1.48,-1.3);                       /* parte delantera */
  tube([0,1.5,-0.45],[0,2.55,-0.45],0.045,alu); box(0.5,0.16,0.18,blk,0,2.6,-0.45); box(0.36,0.1,0.1,alu,0,2.72,-0.45);
  [-0.12,0.12].forEach(function(x){ var e=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.06,10),blk); e.rotation.x=PI/2; e.position.set(x,2.6,-0.55); g.add(e); });
  var rtg=new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.2,0.9,10),LM({color:0x8c9096,roughness:0.4,metalness:0.7})); rtg.rotation.x=PI/2-0.25; rtg.position.set(0,1.18,1.7); rtg.castShadow=true; g.add(rtg);
  for(var f=0;f<4;f++){ var fin=new THREE.Mesh(new THREE.BoxGeometry(0.5,0.02,0.4),alu); fin.position.set(0,1.18,1.62+f*0.1-0.05); fin.rotation.x=-0.25; g.add(fin); }
  tube([0.55,1.35,-1.2],[0.7,1.0,-1.6],0.05,alu); tube([0.7,1.0,-1.6],[0.45,0.85,-2.0],0.045,alu); box(0.22,0.2,0.3,blk,0.4,0.82,-2.1);
  /* suspensión balancín-bogie y ruedas */
  [-1,1].forEach(function(s){
    tube([s*0.85,1.05,-0.1],[s*1.12,0.6,-0.95],0.05,alu); tube([s*1.12,0.6,-0.95],[s*1.12,0.42,-1.15],0.05,alu);
    tube([s*0.85,1.05,0.2],[s*1.12,0.6,0.9],0.05,alu); tube([s*1.12,0.6,0.9],[s*1.12,0.42,1.2],0.05,alu); tube([s*1.12,0.55,0.0],[s*1.12,0.42,0.0],0.05,alu);
    [-1.2,0.0,1.2].forEach(function(z){ var wm=new THREE.Mesh(new THREE.CylinderGeometry(0.4,0.4,0.3,16),alu); wm.rotation.z=PI/2; wm.position.set(s*1.25,0.4,z); wm.castShadow=true; wm.receiveShadow=true;
      for(var k=0;k<10;k++){ var cl=new THREE.Mesh(new THREE.BoxGeometry(0.31,0.05,0.12),blk); var a=k/10*PI*2; cl.position.set(0,Math.cos(a)*0.4,Math.sin(a)*0.4); cl.rotation.x=a; wm.add(cl); }
      g.add(wm); wheels.push(wm); });
  });
  return {g:g,wheels:wheels};
};

/* ---------- polvo: partículas flotantes alrededor de la cámara y remolinos de polvo ---------- */
var DUST=null;
function dustTex(){ var c=document.createElement('canvas'); c.width=c.height=64; var x=c.getContext('2d'), gr=x.createRadialGradient(32,32,0,32,32,32); gr.addColorStop(0,'rgba(255,255,255,0.9)'); gr.addColorStop(0.45,'rgba(255,255,255,0.35)'); gr.addColorStop(1,'rgba(255,255,255,0)'); x.fillStyle=gr; x.fillRect(0,0,64,64); var t=new THREE.CanvasTexture(c); t.colorSpace=THREE.SRGBColorSpace; return t; }
MARS3D.dustInit=function(scene){
  MARS3D.dustClear(scene);
  var tex=dustTex(), NA=420, ND=2, NP=110;
  var ga=new THREE.BufferGeometry(); ga.setAttribute('position',new THREE.BufferAttribute(new Float32Array(NA*3),3));
  var ma=new THREE.PointsMaterial({map:tex,color:0xc98a5e,size:1.6,sizeAttenuation:true,transparent:true,opacity:0.32,depthWrite:false,fog:true});
  var pa=new THREE.Points(ga,ma); pa.frustumCulled=false; scene.add(pa);
  var devils=[];
  for(var d=0;d<ND;d++){ var gd=new THREE.BufferGeometry(); gd.setAttribute('position',new THREE.BufferAttribute(new Float32Array(NP*3),3));
    var md=new THREE.PointsMaterial({map:tex,color:0xb7794f,size:3.4,sizeAttenuation:true,transparent:true,opacity:0.5,depthWrite:false,fog:true}); var pd=new THREE.Points(gd,md); pd.frustumCulled=false; scene.add(pd);
    devils.push({p:pd,x0:(hash(d*3.1)-0.5)*1300,z0:(hash(d*7.7+1)-0.5)*1300,hgt:30+20*hash(d+9),ph:d*2.3}); }
  DUST={pa:pa,ma:ma,NA:NA,NP:NP,devils:devils,scene:scene};
};
MARS3D.dustClear=function(scene){ if(!DUST) return; scene.remove(DUST.pa); DUST.pa.geometry.dispose(); DUST.ma.dispose(); DUST.devils.forEach(function(d){ scene.remove(d.p); d.p.geometry.dispose(); d.p.material.dispose(); }); DUST=null; };
/* cam: posición de la cámara; wx: viento (m/s) y rumbo de procedencia (°); k: luz ambiente 0..1; terrainH(x,z) */
MARS3D.dustUpdate=function(cam,wind,dirDeg,T,k,terrainH,dustAmt){
  if(!DUST) return;
  var a=DUST.pa.geometry.attributes.position.array, N=DUST.NA, R=70, wd=(dirDeg+180)*PI/180, vx=Math.sin(wd), vz=-Math.cos(wd), sp=1.0+wind*0.9;
  for(var i=0;i<N;i++){
    var hx=hash(i*1.7), hy=hash(i*3.3+5), hz=hash(i*5.1+9);
    var x=((hx*2*R+vx*sp*T*(0.6+0.8*hz))%(2*R)+2*R)%(2*R)-R, z=((hz*2*R+vz*sp*T*(0.6+0.8*hx))%(2*R)+2*R)%(2*R)-R, y=hy*28-3+Math.sin(T*0.5+i)*0.6;
    a[i*3]=cam.x+x; a[i*3+1]=cam.y+y; a[i*3+2]=cam.z+z;
  }
  DUST.pa.geometry.attributes.position.needsUpdate=true;
  var dust=0.18+0.55*Math.min(1,dustAmt); DUST.ma.opacity=0.22*dust*1.8*k; DUST.ma.color.setRGB(0.80*Math.max(k,0.18),0.52*Math.max(k,0.18),0.36*Math.max(k,0.18)); DUST.ma.size=1.4+0.8*dustAmt;
  DUST.devils.forEach(function(d,di){
    var cx=((d.x0+vx*sp*0.9*T+700)%1400+1400)%1400-700, cz=((d.z0+vz*sp*0.9*T+700)%1400+1400)%1400-700, near=Math.hypot(cx-cam.x,cz-cam.z)<900; d.p.visible=near; if(!near) return;
    var by=terrainH(cx,cz), pp=d.p.geometry.attributes.position.array, NP=DUST.NP;
    for(var i=0;i<NP;i++){ var u=i/NP, h=Math.pow(u,1.25)*d.hgt, rad=0.8+5.5*Math.pow(u,1.3), ang=hash(i*2.9+di)*6.28+T*(2.6-1.7*u)+d.ph, sw=Math.sin(T*0.7+d.ph+u*3.0)*2.2*u;
      pp[i*3]=cx+Math.cos(ang)*rad+sw; pp[i*3+1]=by+h; pp[i*3+2]=cz+Math.sin(ang)*rad+sw*0.6; }
    d.p.geometry.attributes.position.needsUpdate=true; d.p.material.opacity=0.55*Math.max(k,0.15); d.p.material.color.setRGB(0.72*Math.max(k,0.2),0.46*Math.max(k,0.2),0.31*Math.max(k,0.2));
  });
};
})();
