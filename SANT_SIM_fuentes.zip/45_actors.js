/* ===== ACTORES DINÁMICOS: aves, cometas y personas (lógica, sin gráficos) ===== */
(function(){
var clampf=(typeof SD!=='undefined'?SD:require('./20_data.js')).clamp;
var deg=Math.PI/180;
function mk(seed){ var a=seed>>>0; return function(){ a=(a*1664525+1013904223)>>>0; return a/4294967296; }; }
function tri(u){ u=u-Math.floor(u/2)*2; return u<1?u:2-u; }     /* onda triangular 0..1..0 con periodo 2 */

/* cfg = {air:0..10, people:bool, seed:n}; wx = meteorología (dirección del viento) */
SW.addActors=function(w,cfg,wx){
  var A=w.actors={birds:[],flocks:[],kites:[],people:[],crowds:[],cfg:cfg,lastT:-1};
  if(w.indoor||!cfg){ SW.hookActors(w); return A; }
  var r=mk((cfg.seed||4242)+17), air=Math.round(clampf(cfg.birds||0,0,10)), kn=Math.round(clampf(cfg.kites||0,0,10));
  var hx=w.home.x, hz=w.home.z, hh=w.startHeading||0;
  function terrain(x,z){ return Math.max(0,w.terrainH(x,z)); }
  function okSpot(x,z){
    if(Math.abs(x)>SW.EXT*0.9||Math.abs(z)>SW.EXT*0.9) return false;
    if(w.isWater&&w.isWater(x,z)) return false;
    if(w.blockTop(x,z).kind!=='terrain') return false;
    var s=w.slope(x,z); if(Math.hypot(s.x,s.z)>0.3) return false;
    if(Math.hypot(x-hx,z-hz)<14) return false;
    if(w.showRunway){ var q=w.showRunway; if(Math.abs(x-q.x)<q.wid/2+4&&Math.abs(z-q.z)<q.len/2+4) return false; }
    if(w.zones){ for(var i=0;i<w.zones.length;i++){ var zz=w.zones[i]; if(zz.type==='crowd'&&Math.hypot(x-zz.x,z-zz.z)<zz.r+2) return false; } }
    return true;
  }
  function spot(minD,maxD,a0,spread){
    for(var k=0;k<60;k++){
      var a=(a0===undefined? r()*6.2832 : a0+(r()-0.5)*spread), d=minD+r()*(maxD-minD);
      var x=hx+Math.sin(a)*d, z=hz-Math.cos(a)*d;
      if(okSpot(x,z)) return {x:x,z:z,a:a,d:d};
    }
    return null;
  }
  /* ---------- aves: bandadas de gaviotas ---------- */
  if(air>0){
    var nf=Math.ceil(air/2);
    for(var f=0;f<nf;f++){
      var c=spot(40,220, f===0? hh*deg : undefined, f===0?1.0:6.2832) || {x:hx+80,z:hz-80,a:0};
      var fl={cx:c.x,cz:c.z,R:30+r()*55,alt:10+r()*40,sp:7.5+r()*3,dir:r()<0.5?-1:1,th0:r()*6.2832,wob:2+r()*4,wph:r()*6.28,n:0};
      var nb=Math.min(9,4+Math.floor(air/2)+Math.floor(r()*3)); fl.n=nb;
      for(var b=0;b<nb;b++){
        A.birds.push({fl:fl,ox:(r()-0.5)*14,oz:(r()-0.5)*12,oy:(r()-0.5)*5,ph:r()*6.28,x:0,y:0,z:0,hd:0,r:0.6,label:'una gaviota'});
      }
      A.flocks.push(fl);
    }
  }
  if(kn>0){
    /* ---------- cometas ---------- */
    var nk=kn, wTo=((wx&&wx.dir||270)+180)*deg;   /* hacia dónde sopla el viento */
    for(var k=0;k<nk;k++){
      var c2=spot(50,230);
      if(!c2) continue;
      var L=55+r()*60, el0=(48+r()*14)*deg;
      A.kites.push({ax:c2.x,az:c2.z,ay:terrain(c2.x,c2.z),L:L,el:el0,wTo:wTo+(r()-0.5)*0.4,ph:r()*6.28,col:Math.floor(r()*5),x:0,y:0,z:0,r:0.8,label:'una cometa'});
    }
  }
  /* ---------- personas ---------- */
  if(cfg.people){
    var palCount=6;
    function person(x,z,kind,extra){ var p={x:x,z:z,x0:x,z0:z,y:terrain(x,z),kind:kind,col:Math.floor(r()*palCount),ph:r()*6.28,hd:r()*6.28,label:'una persona',crowd:-1,moving:false}; if(extra) for(var q in extra) p[q]=extra[q]; A.people.push(p); return p; }
    /* aglomeraciones: una cerca de la zona de despegue y otras repartidas */
    var nc=(w.id==='montana')?2:3;
    for(var ci=0;ci<nc;ci++){
      var cs=ci===0? spot(85,150, hh*deg+ (r()<0.5?0.9:-0.9), 0.6) : spot(120,300);
      if(!cs) continue;
      var n=11+Math.floor(r()*11), rad=4.5+r()*4;
      var crowd={x:cs.x,z:cs.z,r:rad,n:n,idx:A.crowds.length}; A.crowds.push(crowd);
      for(var i=0;i<n;i++){
        var aa=r()*6.2832, dd=Math.sqrt(r())*rad; var px=cs.x+Math.cos(aa)*dd, pz=cs.z+Math.sin(aa)*dd;
        person(px,pz,'crowd',{crowd:crowd.idx,wr:0.5+r()*0.9,ws:0.25+r()*0.3,hd:r()*6.28});
      }
    }
    /* aisladas: quietas y caminando */
    var ns=10;
    for(var s=0;s<ns;s++){
      var sp=spot(30,260); if(!sp) continue;
      if(s%3===0){ person(sp.x,sp.z,'stand'); }
      else {
        var ang=r()*6.2832, len=18+r()*45, bx=sp.x+Math.sin(ang)*len, bz=sp.z-Math.cos(ang)*len;
        if(!okSpot(bx,bz)){ bx=sp.x-Math.sin(ang)*len; bz=sp.z+Math.cos(ang)*len; if(!okSpot(bx,bz)){ person(sp.x,sp.z,'stand'); continue; } }
        person(sp.x,sp.z,'walk',{bx:bx,bz:bz,len:len,spd:1.0+r()*0.6,u0:r()*2,moving:true});
      }
    }
  }
  SW.hookActors(w);
  return A;
};

/* ---------- movimiento analítico (determinista: sirve para pausa y reinicio) ---------- */
function upd(A,w){
  return function(t,force){
    if(!force && t-A.lastT<0.03 && t>=A.lastT) return; A.lastT=t;
    var i, b, p, f;
    for(i=0;i<A.birds.length;i++){
      b=A.birds[i]; f=b.fl;
      var th=f.th0+f.dir*(f.sp/f.R)*t, c=Math.cos(th), s=Math.sin(th);
      var tx=-s*f.dir, tz=c*f.dir;                          /* tangente (x,z) del círculo (cx+R cos, cz+R sin) */
      var nx=c, nz=s;                                       /* normal hacia fuera */
      b.x=f.cx+f.R*c + tx*b.ox*0.6 + nx*b.oz;
      b.z=f.cz+f.R*s + tz*b.ox*0.6 + nz*b.oz;
      b.y=Math.max(0,w.terrainH(b.x,b.z))+f.alt+b.oy+f.wob*Math.sin(t*0.5+f.wph+b.ph*0.2);
      b.hd=Math.atan2(tx,-tz);                              /* brújula: 0 = norte (-z) */
    }
    for(i=0;i<A.kites.length;i++){
      var k=A.kites[i];
      var az=k.wTo+0.32*Math.sin(t*0.37+k.ph), el=k.el+0.07*Math.sin(t*0.83+k.ph*1.7);
      var hz=k.L*Math.cos(el);
      k.x=k.ax+Math.sin(az)*hz; k.z=k.az-Math.cos(az)*hz; k.y=k.ay+k.L*Math.sin(el)+0.8;
      k.az2=az; k.bank=0.25*Math.sin(t*1.3+k.ph);
    }
    for(i=0;i<A.people.length;i++){
      p=A.people[i];
      if(p.kind==='walk'){
        var u=tri(p.u0+t*p.spd/p.len), dx=p.bx-p.x0, dz=p.bz-p.z0;
        p.x=p.x0+dx*u; p.z=p.z0+dz*u; var sg=tri(p.u0+t*p.spd/p.len+0.001)>=u?1:-1; p.hd=Math.atan2(dx*sg,-dz*sg);
      } else if(p.kind==='crowd'){
        p.x=p.x0+Math.sin(t*p.ws+p.ph)*p.wr; p.z=p.z0+Math.cos(t*p.ws*1.13+p.ph*1.7)*p.wr;
      }
      p.y=Math.max(0,w.terrainH(p.x,p.z));
    }
  };
}

/* ---------- consultas y colisiones ---------- */
SW.hookActors=function(w){
  var A=w.actors; if(!A) return;
  A.update=upd(A,w);
  var ou=w.update; w.update=function(t){ ou(t); A.update(t); };
  var oc=w.collide;
  w.collide=function(x,y,z,r){
    var h=oc(x,y,z,r); if(h) return h;
    var i, d2, rr;
    for(i=0;i<A.birds.length;i++){ var b=A.birds[i]; rr=b.r+r; d2=(x-b.x)*(x-b.x)+(y-b.y)*(y-b.y)+(z-b.z)*(z-b.z); if(d2<rr*rr) return b; }
    for(i=0;i<A.kites.length;i++){
      var k=A.kites[i]; rr=k.r+r; d2=(x-k.x)*(x-k.x)+(y-k.y)*(y-k.y)+(z-k.z)*(z-k.z); if(d2<rr*rr) return k;
      /* hilo: distancia al segmento ancla–cometa */
      var sx=k.x-k.ax, sy=k.y-k.ay, sz=k.z-k.az, L2=sx*sx+sy*sy+sz*sz, t=((x-k.ax)*sx+(y-k.ay)*sy+(z-k.az)*sz)/L2; t=t<0?0:(t>1?1:t);
      var qx=k.ax+sx*t-x, qy=k.ay+sy*t-y, qz=k.az+sz*t-z; if(qx*qx+qy*qy+qz*qz<(0.12+r*0.6)*(0.12+r*0.6)) return {label:'el hilo de una cometa'};
    }
    for(i=0;i<A.people.length;i++){ var p=A.people[i]; var dx=x-p.x, dz=z-p.z; rr=0.35+r; if(dx*dx+dz*dz<rr*rr && y<p.y+1.85 && y>p.y-0.3) return p; }
    return null;
  };
  var on=w.nearestObstacle;
  w.nearestObstacle=function(x,y,z,yaw){
    var res=on(x,y,z,yaw), i, d;
    function cand(o,r,dy0){ var dx=x-o.x, dz=z-o.z, dy=(dy0===undefined)?(y-o.y):dy0; d=Math.sqrt(dx*dx+dy*dy+dz*dz)-r; if(d<res.dist){ res.dist=Math.max(0,d); res.label=o.label; } }
    for(i=0;i<A.birds.length;i++) cand(A.birds[i],0.4);
    for(i=0;i<A.kites.length;i++) cand(A.kites[i],0.7);
    for(i=0;i<A.people.length;i++){ var p=A.people[i]; var dy=Math.max(0,y-(p.y+1.8),p.y-y); cand(p,0.3,dy); }
    return res;
  };
  /* resumen para alertas y normativa */
  w.actorInfo=function(x,y,z){
    var o={air:99,airLabel:'',pers:99,crowdEdge:99,overCrowd:false,overPerson:false,nPers30:0}, i, d, dh;
    for(i=0;i<A.birds.length;i++){ var b=A.birds[i]; d=Math.sqrt((x-b.x)*(x-b.x)+(y-b.y)*(y-b.y)+(z-b.z)*(z-b.z)); if(d<o.air){ o.air=d; o.airLabel=b.label; } }
    for(i=0;i<A.kites.length;i++){ var k=A.kites[i]; d=Math.sqrt((x-k.x)*(x-k.x)+(y-k.y)*(y-k.y)+(z-k.z)*(z-k.z)); if(d<o.air){ o.air=d; o.airLabel=k.label; }
      var sx=k.x-k.ax, sy=k.y-k.ay, sz=k.z-k.az, L2=sx*sx+sy*sy+sz*sz, t=((x-k.ax)*sx+(y-k.ay)*sy+(z-k.az)*sz)/L2; t=t<0?0:(t>1?1:t);
      var qx=k.ax+sx*t-x, qy=k.ay+sy*t-y, qz=k.az+sz*t-z; d=Math.sqrt(qx*qx+qy*qy+qz*qz); if(d<o.air){ o.air=d; o.airLabel='el hilo de una cometa'; } }
    for(i=0;i<A.people.length;i++){ var p=A.people[i]; dh=Math.hypot(x-p.x,z-p.z); if(dh<o.pers) o.pers=dh; if(dh<30) o.nPers30++; if(dh<3 && y>p.y) o.overPerson=true; }
    for(i=0;i<A.crowds.length;i++){ var c=A.crowds[i]; dh=Math.hypot(x-c.x,z-c.z)-c.r; if(dh<o.crowdEdge) o.crowdEdge=dh; if(dh<5) o.overCrowd=true; }
    return o;
  };
  A.update(0,true);
};
})();
