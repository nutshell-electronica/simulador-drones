/* ===== ACTORES DINÁMICOS: aves, cometas y personas (lógica, sin gráficos) ===== */
(function(){
var clampf=(typeof SD!=='undefined'?SD:require('./20_data.js')).clamp;
var deg=Math.PI/180;
function mk(seed){ var a=seed>>>0; return function(){ a=(a*1664525+1013904223)>>>0; return a/4294967296; }; }
function tri(u){ u=u-Math.floor(u/2)*2; return u<1?u:2-u; }     /* onda triangular 0..1..0 con periodo 2 */

/* cfg = {air:0..10, people:bool, seed:n}; wx = meteorología (dirección del viento) */
SW.addActors=function(w,cfg,wx){
  var A=w.actors={birds:[],flocks:[],kites:[],people:[],crowds:[],lines:[],wires:[],towers:[],cars:[],cfg:cfg,lastT:-1};
  if(w.indoor||!cfg){ SW.hookActors(w); return A; }
  var r=mk((cfg.seed||4242)+17), air=Math.round(clampf(cfg.birds||0,0,10)), kn=Math.round(clampf(cfg.kites||0,0,10));
  var hx=w.home.x, hz=w.home.z, hh=w.startHeading||0;
  function terrain(x,z){ return Math.max(0,w.terrainH(x,z)); }
  function okSpot(x,z){
    if(Math.abs(x)>SW.EXT*0.9||Math.abs(z)>SW.EXT*0.9) return false;
    if(w.isWater&&w.isWater(x,z)) return false;
    if(w.blockTop(x,z).kind!=='terrain') return false;
    var s=w.slope(x,z); if(Math.hypot(s.x,s.z)>0.3) return false;
    if(Math.hypot(x-hx,z-hz)<14) return false;
    if(w.showRunway){ var q=w.showRunway; if(Math.abs(x-q.x)<q.wid/2+4&&Math.abs(z-q.z)<q.len/2+4) return false; }
    if(w.zones){ for(var i=0;i<w.zones.length;i++){ var zz=w.zones[i]; if(zz.type==='crowd'&&Math.hypot(x-zz.x,z-zz.z)<zz.r+2) return false; } }
    return true;
  }
  function spot(minD,maxD,a0,spread){
    for(var k=0;k<60;k++){
      var a=(a0===undefined? r()*6.2832 : a0+(r()-0.5)*spread), d=minD+r()*(maxD-minD);
      var x=hx+Math.sin(a)*d, z=hz-Math.cos(a)*d;
      if(okSpot(x,z)) return {x:x,z:z,a:a,d:d};
    }
    return null;
  }
  /* ---------- aves: bandadas de gaviotas ---------- */
  if(air>0){
    var nf=Math.ceil(air/2);
    for(var f=0;f<nf;f++){
      var c=spot(40,220, f===0? hh*deg : undefined, f===0?1.0:6.2832) || {x:hx+80,z:hz-80,a:0};
      var fl={cx:c.x,cz:c.z,R:30+r()*55,alt:10+r()*40,sp:7.5+r()*3,dir:r()<0.5?-1:1,th0:r()*6.2832,wob:2+r()*4,wph:r()*6.28,n:0};
      var nb=Math.min(9,4+Math.floor(air/2)+Math.floor(r()*3)); fl.n=nb;
      for(var b=0;b<nb;b++){
        A.birds.push({fl:fl,ox:(r()-0.5)*14,oz:(r()-0.5)*12,oy:(r()-0.5)*5,ph:r()*6.28,x:0,y:0,z:0,hd:0,r:0.6,label:'una gaviota'});
      }
      A.flocks.push(fl);
    }
  }
  if(kn>0){
    /* ---------- cometas ---------- */
    var nk=kn, wTo=((wx&&wx.dir||270)+180)*deg;   /* hacia dónde sopla el viento */
    for(var k=0;k<nk;k++){
      var c2=spot(50,230);
      if(!c2) continue;
      var L=55+r()*60, el0=(48+r()*14)*deg;
      A.kites.push({ax:c2.x,az:c2.z,ay:terrain(c2.x,c2.z),L:L,el:el0,wTo:wTo+(r()-0.5)*0.4,ph:r()*6.28,col:Math.floor(r()*5),x:0,y:0,z:0,r:0.8,label:'una cometa'});
    }
  }
  /* ---------- personas ---------- */
  if(cfg.people){
    var palCount=6;
    function person(x,z,kind,extra){ var p={x:x,z:z,x0:x,z0:z,y:terrain(x,z),kind:kind,col:Math.floor(r()*palCount),ph:r()*6.28,hd:r()*6.28,label:'una persona',crowd:-1,moving:false}; if(extra) for(var q in extra) p[q]=extra[q]; A.people.push(p); return p; }
    /* aglomeraciones: una cerca de la zona de despegue y otras repartidas */
    var nc=(w.id==='montana')?2:3;
    for(var ci=0;ci<nc;ci++){
      var cs=ci===0? spot(85,150, hh*deg+ (r()<0.5?0.9:-0.9), 0.6) : spot(120,300);
      if(!cs) continue;
      var n=11+Math.floor(r()*11), rad=4.5+r()*4;
      var crowd={x:cs.x,z:cs.z,r:rad,n:n,idx:A.crowds.length}; A.crowds.push(crowd);
      for(var i=0;i<n;i++){
        var aa=r()*6.2832, dd=Math.sqrt(r())*rad; var px=cs.x+Math.cos(aa)*dd, pz=cs.z+Math.sin(aa)*dd;
        person(px,pz,'crowd',{crowd:crowd.idx,wr:0.5+r()*0.9,ws:0.25+r()*0.3,hd:r()*6.28});
      }
    }
    /* aisladas: quietas y caminando */
    var ns=10;
    for(var s=0;s<ns;s++){
      var sp=spot(30,260); if(!sp) continue;
      if(s%3===0){ person(sp.x,sp.z,'stand'); }
      else {
        var ang=r()*6.2832, len=18+r()*45, bx=sp.x+Math.sin(ang)*len, bz=sp.z-Math.cos(ang)*len;
        if(!okSpot(bx,bz)){ bx=sp.x-Math.sin(ang)*len; bz=sp.z+Math.cos(ang)*len; if(!okSpot(bx,bz)){ person(sp.x,sp.z,'stand'); continue; } }
        person(sp.x,sp.z,'walk',{bx:bx,bz:bz,len:len,spd:1.0+r()*0.6,u0:r()*2,moving:true});
      }
    }
  }
  /* ---------- tendidos eléctricos y torres de telefonía móvil (estáticos, con colisión) ---------- */
  var ln=Math.round(clampf(cfg.lines||0,0,10));
  if(ln>0){
    var urban=(w.ground==='urban'||w.id==='muelle'||w.id==='bloques'||w.id==='fortaleza');
    function farOk(x,z,d){ return okSpot(x,z) && Math.hypot(x-hx,z-hz)>d; }
    for(var li=0;li<ln;li++){
      var tower = urban || (li%3===2);
      if(!tower){
        for(var tr=0;tr<40;tr++){
          var st=spot(80,260); if(!st) break;
          var ang=r()*6.2832, np=4+Math.floor(r()*3), sp=58+r()*22, H=17+r()*11, pts=[], ok=true;
          for(var pi=0;pi<np;pi++){ var px=st.x+Math.sin(ang)*sp*pi, pz=st.z-Math.cos(ang)*sp*pi; if(!farOk(px,pz,50)){ ok=false; break; } pts.push({x:px,z:pz}); }
          if(!ok) continue;
          /* los vanos no deben cruzar la pista ni la casa: muestreo cada 6 m */
          for(var pi=1;pi<np&&ok;pi++){ for(var q=1;q<10;q++){ var u=q/10, mx=pts[pi-1].x+(pts[pi].x-pts[pi-1].x)*u, mz=pts[pi-1].z+(pts[pi].z-pts[pi-1].z)*u; if(!farOk(mx,mz,40)){ ok=false; break; } } }
          if(!ok) continue;
          var line={pylons:[],ang:ang,H:H,sag:2.0+r()*1.4};
          pts.forEach(function(p){ var o=w.addObs('cyl',p.x,p.z,1.7,0,H,'una torre del tendido eléctrico',0x7a8085,{solid:true,custom:'pylon',ang:ang}); line.pylons.push(o); });
          var lx=Math.cos(ang), lz=Math.sin(ang);          /* unidad lateral (perpendicular al tendido) */
          [[-3.0,H-2.4],[0,H-2.4],[3.0,H-2.4],[0,H+0.6]].forEach(function(c){
            for(var sI=0;sI<np-1;sI++){ var pa=line.pylons[sI], pb=line.pylons[sI+1], seg=[], bx0=1e9,bx1=-1e9,bz0=1e9,bz1=-1e9,by0=1e9,by1=-1e9;
              for(var q=0;q<=8;q++){ var u=q/8, x=pa.x+(pb.x-pa.x)*u+lx*c[0], z=pa.z+(pb.z-pa.z)*u+lz*c[0], y=pa.y0+c[1]+(pb.y0-pa.y0)*u-line.sag*4*u*(1-u); seg.push({x:x,y:y,z:z});
                if(x<bx0)bx0=x; if(x>bx1)bx1=x; if(z<bz0)bz0=z; if(z>bz1)bz1=z; if(y<by0)by0=y; if(y>by1)by1=y; }
              A.wires.push({pts:seg,bb:[bx0-2,bx1+2,by0-2,by1+2,bz0-2,bz1+2],label:'un cable del tendido eléctrico',line:line}); } });
          A.lines.push(line); break;
        }
      } else {
        var ts=null; for(var tt=0;tt<30&&!ts;tt++){ var c3=spot(60,280); if(c3&&Math.hypot(c3.x-hx,c3.z-hz)>45) ts=c3; }
        if(!ts) continue;
        var TH=24+r()*16;
        var ob=w.addObs('cyl',ts.x,ts.z,1.6,0,TH,'una torre de telefonía móvil',0x8a9096,{solid:true,custom:'tower'});
        A.towers.push(ob);
      }
    }
  }
  /* ---------- vehículos en movimiento ---------- */
  var cn=Math.round(clampf(cfg.cars||0,0,10));
  if(cn>0){
    var roads=(w.ground==='urban'), LBL={car:'un coche',van:'una furgoneta',bus:'un autobús',truck:'un camión',tractor:'un tractor'};
    var DIM={car:[4.4,1.8,1.5],van:[5.2,2.0,2.3],bus:[11,2.5,3.2],truck:[8.6,2.5,3.6],tractor:[4.2,2.2,2.8]};
    function roadOk(x,z){ return okSpot(x,z) && Math.hypot(x-hx,z-hz)>24 && !nearWire(x,z); }
    function nearWire(x,z){ for(var i=0;i<A.towers.length;i++){ if(Math.hypot(x-A.towers[i].x,z-A.towers[i].z)<4) return true; } return false; }
    for(var tries=0;tries<220&&A.cars.length<cn;tries++){
      var s0=spot(40,320); if(!s0) break;
      var ang2=roads? (r()<0.5?0:Math.PI/2) : r()*6.2832, dx=Math.sin(ang2), dz=-Math.cos(ang2);
      var fw=0; while(fw<240 && roadOk(s0.x+dx*(fw+8),s0.z+dz*(fw+8))) fw+=8;
      var bw=0; while(bw<240 && roadOk(s0.x-dx*(bw+8),s0.z-dz*(bw+8))) bw+=8;
      if(fw+bw<70) continue;
      var ax=s0.x-dx*bw, az=s0.z-dz*bw, bx=s0.x+dx*fw, bz=s0.z+dz*fw, len=fw+bw;
      var kinds=roads?['car','car','car','van','bus']:['car','van','truck','tractor','car'];
      var kind=kinds[Math.floor(r()*kinds.length)], d=DIM[kind];
      var spd={car:9+r()*5,van:8+r()*4,bus:7+r()*2,truck:7+r()*3,tractor:2.5+r()*1.5}[kind];
      if(!roads) spd*=0.75;
      A.cars.push({kind:kind,ax:ax,az:az,bx:bx,bz:bz,len:len,spd:spd,u0:r()*2,L:d[0],W:d[1],H:d[2],col:Math.floor(r()*6),x:ax,z:az,y:0,hd:ang2,dist:0,label:LBL[kind],r:Math.max(d[0],d[1])/2});
    }
  }
  SW.hookActors(w);
  return A;
};

/* ---------- movimiento analítico (determinista: sirve para pausa y reinicio) ---------- */
function upd(A,w){
  return function(t,force){
    if(!force && t-A.lastT<0.03 && t>=A.lastT) return; A.lastT=t;
    var i, b, p, f;
    for(i=0;i<A.birds.length;i++){
      b=A.birds[i]; f=b.fl;
      var th=f.th0+f.dir*(f.sp/f.R)*t, c=Math.cos(th), s=Math.sin(th);
      var tx=-s*f.dir, tz=c*f.dir;                          /* tangente (x,z) del círculo (cx+R cos, cz+R sin) */
      var nx=c, nz=s;                                       /* normal hacia fuera */
      b.x=f.cx+f.R*c + tx*b.ox*0.6 + nx*b.oz;
      b.z=f.cz+f.R*s + tz*b.ox*0.6 + nz*b.oz;
      b.y=Math.max(0,w.terrainH(b.x,b.z))+f.alt+b.oy+f.wob*Math.sin(t*0.5+f.wph+b.ph*0.2);
      b.hd=Math.atan2(tx,-tz);                              /* brújula: 0 = norte (-z) */
    }
    for(i=0;i<A.kites.length;i++){
      var k=A.kites[i];
      var az=k.wTo+0.32*Math.sin(t*0.37+k.ph), el=k.el+0.07*Math.sin(t*0.83+k.ph*1.7);
      var hz=k.L*Math.cos(el);
      k.x=k.ax+Math.sin(az)*hz; k.z=k.az-Math.cos(az)*hz; k.y=k.ay+k.L*Math.sin(el)+0.8;
      k.az2=az; k.bank=0.25*Math.sin(t*1.3+k.ph);
    }
    for(i=0;i<A.cars.length;i++){
      var c=A.cars[i], uc=c.u0+t*c.spd/c.len, u=tri(uc), fwd=(uc-Math.floor(uc/2)*2)<1?1:-1, ddx=c.bx-c.ax, ddz=c.bz-c.az;
      /* frena en los extremos: suavizado del tramo final (0,3 s) */
      c.x=c.ax+ddx*u; c.z=c.az+ddz*u; c.hd=Math.atan2(ddx*fwd,-ddz*fwd); c.dist=uc*c.len; c.y=Math.max(0,w.terrainH(c.x,c.z));
    }
    for(i=0;i<A.people.length;i++){
      p=A.people[i];
      if(p.kind==='walk'){
        var u=tri(p.u0+t*p.spd/p.len), dx=p.bx-p.x0, dz=p.bz-p.z0;
        p.x=p.x0+dx*u; p.z=p.z0+dz*u; var sg=tri(p.u0+t*p.spd/p.len+0.001)>=u?1:-1; p.hd=Math.atan2(dx*sg,-dz*sg);
      } else if(p.kind==='crowd'){
        p.x=p.x0+Math.sin(t*p.ws+p.ph)*p.wr; p.z=p.z0+Math.cos(t*p.ws*1.13+p.ph*1.7)*p.wr;
      }
      p.y=Math.max(0,w.terrainH(p.x,p.z));
    }
  };
}

/* ---------- consultas y colisiones ---------- */
function carHit(c,x,y,z,r){ var dx=x-c.x, dz=z-c.z, fx=Math.sin(c.hd), fz=-Math.cos(c.hd); var lx=dx*fx+dz*fz, ly=dx*Math.cos(c.hd)+dz*Math.sin(c.hd);
  return Math.abs(lx)<c.L/2+r && Math.abs(ly)<c.W/2+r && y<c.y+c.H+r && y>c.y-0.2; }
function segDist(a,b,x,y,z){ var sx=b.x-a.x, sy=b.y-a.y, sz=b.z-a.z, L2=sx*sx+sy*sy+sz*sz||1e-9, t=((x-a.x)*sx+(y-a.y)*sy+(z-a.z)*sz)/L2; t=t<0?0:(t>1?1:t);
  var qx=a.x+sx*t-x, qy=a.y+sy*t-y, qz=a.z+sz*t-z; return Math.sqrt(qx*qx+qy*qy+qz*qz); }
function wireDist(A,x,y,z){ var best={d:1e9,label:''}, i, k, W=A.wires;
  for(i=0;i<W.length;i++){ var b=W[i].bb; if(x<b[0]-best.d||x>b[1]+best.d||y<b[2]-best.d||y>b[3]+best.d||z<b[4]-best.d||z>b[5]+best.d) continue;
    var P=W[i].pts; for(k=0;k<P.length-1;k++){ var d=segDist(P[k],P[k+1],x,y,z); if(d<best.d){ best.d=d; best.label=W[i].label; } } }
  return best; }
SW.hookActors=function(w){
  var A=w.actors; if(!A) return;
  A.update=upd(A,w);
  var ou=w.update; w.update=function(t){ ou(t); A.update(t); };
  var oc=w.collide;
  w.collide=function(x,y,z,r){
    var h=oc(x,y,z,r); if(h) return h;
    var i, d2, rr;
    for(i=0;i<A.birds.length;i++){ var b=A.birds[i]; rr=b.r+r; d2=(x-b.x)*(x-b.x)+(y-b.y)*(y-b.y)+(z-b.z)*(z-b.z); if(d2<rr*rr) return b; }
    for(i=0;i<A.kites.length;i++){
      var k=A.kites[i]; rr=k.r+r; d2=(x-k.x)*(x-k.x)+(y-k.y)*(y-k.y)+(z-k.z)*(z-k.z); if(d2<rr*rr) return k;
      /* hilo: distancia al segmento ancla–cometa */
      var sx=k.x-k.ax, sy=k.y-k.ay, sz=k.z-k.az, L2=sx*sx+sy*sy+sz*sz, t=((x-k.ax)*sx+(y-k.ay)*sy+(z-k.az)*sz)/L2; t=t<0?0:(t>1?1:t);
      var qx=k.ax+sx*t-x, qy=k.ay+sy*t-y, qz=k.az+sz*t-z; if(qx*qx+qy*qy+qz*qz<(0.12+r*0.6)*(0.12+r*0.6)) return {label:'el hilo de una cometa'};
    }
    for(i=0;i<A.people.length;i++){ var p=A.people[i]; var dx=x-p.x, dz=z-p.z; rr=0.35+r; if(dx*dx+dz*dz<rr*rr && y<p.y+1.85 && y>p.y-0.3) return p; }
    for(i=0;i<A.cars.length;i++){ var c=A.cars[i]; if(carHit(c,x,y,z,r)) return c; }
    if(A.wires.length){ var wr=wireDist(A,x,y,z); if(wr.d<0.12+r*0.6) return {label:wr.label}; }
    return null;
  };
  var on=w.nearestObstacle;
  w.nearestObstacle=function(x,y,z,yaw){
    var res=on(x,y,z,yaw), i, d;
    function cand(o,r,dy0){ var dx=x-o.x, dz=z-o.z, dy=(dy0===undefined)?(y-o.y):dy0; d=Math.sqrt(dx*dx+dy*dy+dz*dz)-r; if(d<res.dist){ res.dist=Math.max(0,d); res.label=o.label; } }
    for(i=0;i<A.birds.length;i++) cand(A.birds[i],0.4);
    for(i=0;i<A.kites.length;i++) cand(A.kites[i],0.7);
    for(i=0;i<A.people.length;i++){ var p=A.people[i]; var dy=Math.max(0,y-(p.y+1.8),p.y-y); cand(p,0.3,dy); }
    for(i=0;i<A.cars.length;i++){ var c=A.cars[i]; var dyc=Math.max(0,y-(c.y+c.H),c.y-y); cand(c,c.r*0.8,dyc); }
    if(A.wires.length){ var wr=wireDist(A,x,y,z); if(wr.d<res.dist){ res.dist=Math.max(0,wr.d); res.label=wr.label; } }
    return res;
  };
  /* resumen para alertas y normativa */
  w.actorInfo=function(x,y,z){
    var o={air:99,airLabel:'',pers:99,crowdEdge:99,overCrowd:false,overPerson:false,nPers30:0,car:99,overCar:false,carLabel:''}, i, d, dh;
    for(i=0;i<A.birds.length;i++){ var b=A.birds[i]; d=Math.sqrt((x-b.x)*(x-b.x)+(y-b.y)*(y-b.y)+(z-b.z)*(z-b.z)); if(d<o.air){ o.air=d; o.airLabel=b.label; } }
    for(i=0;i<A.kites.length;i++){ var k=A.kites[i]; d=Math.sqrt((x-k.x)*(x-k.x)+(y-k.y)*(y-k.y)+(z-k.z)*(z-k.z)); if(d<o.air){ o.air=d; o.airLabel=k.label; }
      var sx=k.x-k.ax, sy=k.y-k.ay, sz=k.z-k.az, L2=sx*sx+sy*sy+sz*sz, t=((x-k.ax)*sx+(y-k.ay)*sy+(z-k.az)*sz)/L2; t=t<0?0:(t>1?1:t);
      var qx=k.ax+sx*t-x, qy=k.ay+sy*t-y, qz=k.az+sz*t-z; d=Math.sqrt(qx*qx+qy*qy+qz*qz); if(d<o.air){ o.air=d; o.airLabel='el hilo de una cometa'; } }
    if(A.wires.length){ var wr=wireDist(A,x,y,z); if(wr.d<o.air){ o.air=wr.d; o.airLabel=wr.label; } }
    for(i=0;i<A.cars.length;i++){ var c=A.cars[i]; var dyc=Math.max(0,y-(c.y+c.H),c.y-y); d=Math.max(0,Math.sqrt((x-c.x)*(x-c.x)+(z-c.z)*(z-c.z)+dyc*dyc)-c.r*0.8); if(d<o.air&&dyc<12){ o.air=d; o.airLabel=c.label; } }
    for(i=0;i<A.cars.length;i++){ var c=A.cars[i]; dh=Math.max(0,Math.hypot(x-c.x,z-c.z)-c.r*0.8); if(dh<o.car){ o.car=dh; o.carLabel=c.label; } if(dh<2.5&&y>c.y+c.H) o.overCar=true; }
    for(i=0;i<A.people.length;i++){ var p=A.people[i]; dh=Math.hypot(x-p.x,z-p.z); if(dh<o.pers) o.pers=dh; if(dh<30) o.nPers30++; if(dh<3 && y>p.y) o.overPerson=true; }
    for(i=0;i<A.crowds.length;i++){ var c=A.crowds[i]; dh=Math.hypot(x-c.x,z-c.z)-c.r; if(dh<o.crowdEdge) o.crowdEdge=dh; if(dh<5) o.overCrowd=true; }
    return o;
  };
  A.update(0,true);
};
})();
