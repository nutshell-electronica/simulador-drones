/* ===== INTERFAZ (A): estado y hangar de configuración ===== */
var SIM={};
(function(){
var $=function(id){return document.getElementById(id);};
var clamp=SD.clamp;
function opt(v,t,sel){ var o=document.createElement('option'); o.value=v; o.textContent=t; if(sel)o.selected=true; return o; }
function fill(sel,items,cur){ sel.innerHTML=''; items.forEach(function(it){ sel.appendChild(opt(it[0],it[1],String(it[0])===String(cur))); }); }

var ST=SIM.ST={
  cfg:Object.assign({type:'quad'},SD.STD.quad),
  wxId:'brisa', wx:Object.assign({},SD.WX.brisa), tod:'dia', elevOv:null,
  scn:'campo', jam:false, rfNoise:0, trail:true,
  lat:36.7770, lon:-4.3930, dtMode:'now', dtDate:'', dtTime:'', birds:0, kites:0, people:false, apText:'', apOn:false,
  rf:{cl:'elrs24',cp:100,ca:'omni',vl:'ana58',vp:25,va:'omni',fl:'rth',fb:'rth',alt:30,obs:false}
};
try{ var sv=JSON.parse(localStorage.getItem('santsim_v1')||'null'); if(sv&&sv.cfg&&sv.rf){ Object.assign(ST,sv); ST.wx=Object.assign({},SD.WX.brisa,sv.wx); } }catch(e){}
SIM.save=function(){ try{ localStorage.setItem('santsim_v1',JSON.stringify(ST)); }catch(e){} };

/* ---------- hora, posición y Sol ---------- */
function p2(n){ return (n<10?'0':'')+n; }
SIM.dateStr=function(ms){ var d=new Date(ms); return d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate()); };
SIM.timeStr=function(ms){ var d=new Date(ms); return p2(d.getHours())+':'+p2(d.getMinutes()); };
SIM.flightMs=function(){   /* instante de despegue: reloj del sistema o fecha/hora elegidas */
  if(ST.dtMode!=='custom'||!ST.dtDate||!ST.dtTime) return Date.now();
  var a=ST.dtDate.split('-'), b=ST.dtTime.split(':'); var t=new Date(+a[0],+a[1]-1,+a[2],+b[0],+b[1],0).getTime();
  return isNaN(t)?Date.now():t;
};
SIM.sunAt=function(ms){ return SM.sunPos(ms,ST.lat,ST.lon); };
SIM.todFromSun=function(el){ return el>8?'dia':(el>-4?'atardecer':'noche'); };
SIM.syncTod=function(){ var ms=SIM.flightMs(); ST.tod=SIM.todFromSun(SIM.sunAt(ms).el); return ST.tod; };
SIM.compass=function(az){ var n=['N','NE','E','SE','S','SO','O','NO']; return n[Math.round(az/45)%8]; };

/* ---------- raster del mapa (terreno + obstáculos + zonas) ---------- */
SIM.mapRaster=function(w,N,ext){
  var c=document.createElement('canvas'); c.width=c.height=N; var g=c.getContext('2d'), im=g.createImageData(N,N), d=im.data;
  var step=2*ext/N;
  for(var j=0;j<N;j++)for(var i=0;i<N;i++){
    var x=-ext+(i+0.5)*step, z=-ext+(j+0.5)*step, h=w.land(x,z), col=w.pal(x,z,h);
    var hx=w.land(x+step,z)-w.land(x-step,z), hz=w.land(x,z+step)-w.land(x,z-step);
    var sh=clamp(1+(-hx*0.6-hz*0.8)/(step*1.2+1)*0.8,0.55,1.35);
    var r=col[0]*sh, gg=col[1]*sh, b=col[2]*sh;
    if(w.sea&&h<0.05){ r=0.55;gg=0.75;b=0.88; }
    var k=(j*N+i)*4; d[k]=clamp(r*255*1.05+30*0.0,0,255); d[k+1]=clamp(gg*255*1.05,0,255); d[k+2]=clamp(b*255*1.05,0,255); d[k+3]=255;
  }
  g.putImageData(im,0,0);
  var px=function(v){return (v+ext)/step;};
  if(w.showRunway){ var r=w.showRunway; g.fillStyle='#555'; g.fillRect(px(r.x-r.wid/2),px(r.z-r.len/2),r.wid/step,r.len/step); }
  w.obstacles.forEach(function(o){
    if(o.label==='el techo') return;
    if(o.kind==='tree'){ g.fillStyle='rgba(30,90,45,0.6)'; g.fillRect(px(o.x)-1,px(o.z)-1,Math.max(1.5,o.dx*2/step),Math.max(1.5,o.dx*2/step)); }
    else if(o.kind==='box'){ g.fillStyle='#8b94a0'; g.fillRect(px(o.x-o.dx/2),px(o.z-o.dz/2),Math.max(1.5,o.dx/step),Math.max(1.5,o.dz/step)); }
    else { g.fillStyle='#c0392b'; g.beginPath(); g.arc(px(o.x),px(o.z),Math.max(1.5,o.dx/step*1.5),0,6.3); g.fill(); }
  });
  w.zones.forEach(function(z){ g.strokeStyle='#d9342b'; g.fillStyle='rgba(217,52,43,0.12)'; g.lineWidth=1.5; g.beginPath(); g.arc(px(z.x),px(z.z),z.r/step,0,6.3); g.fill(); g.stroke(); });
  return {canvas:c,ext:ext,step:step};
};
var SCN_EXT={campo:700,ciudad:900,barrio:700,bosque:1300,montana:1600,costa:1300,nave:60,aeropuerto:3000,muelle:1100,guadalhorce:1100};
SIM.SCN_EXT=SCN_EXT;

/* ---------- construcción del hangar ---------- */
var V=null;  /* última validación */
function fillFrames(){
  var fr=SD.FRAMES.filter(function(f){return f.type===ST.cfg.type;});
  fill($('cFrame'),fr.map(function(f){return [f.id,f.name];}),ST.cfg.frame);
  if(!fr.some(function(f){return f.id===ST.cfg.frame;})) ST.cfg.frame=fr[0].id;
}
function fillProps(){
  var kind=D(ST.cfg.type).kind;
  $('rProp').style.display=kind==='heli'?'none':'';
  var list=kind==='fixed'?SD.PROPS_FW:SD.PROPS_MULTI;
  fill($('cProp'),list.map(function(p){return [p,p.replace('x',' × ')+'"'];}),ST.cfg.prop);
  if(list.indexOf(ST.cfg.prop)<0 && kind!=='heli') ST.cfg.prop=list[0];
}
function D(id){return SD.byId(SD.TYPES,id);}
function commList(){ return SD.COMM||[]; }
function buildComm(){
  var s=$('cComm'); if(!s) return; s.innerHTML='<option value="">Configuración libre (eliges los componentes)</option>';
  var mk=''; var g=null;
  commList().forEach(function(c){ if(c.maker!==mk){ g=document.createElement('optgroup'); g.label=c.maker; s.appendChild(g); mk=c.maker; } var o=document.createElement('option'); o.value=c.id; o.textContent=c.name+' · '+Math.round(c.mass*1000)+' g'; g.appendChild(o); });
}
function syncComm(){
  var c=ST.cfg, cm=c.comm?SD.byId(SD.COMM,c.comm):null; if(c.comm&&!cm){ delete c.comm; }
  $('cComm').value=cm?cm.id:'';
  ['cFrame','cMotor','cProp','cEsc','cChem','cCap'].forEach(function(id){ var e=$(id), o=e.querySelector('option[data-cm]');
    if(cm){ if(!o){ o=document.createElement('option'); o.dataset.cm=1; e.insertBefore(o,e.firstChild); } o.value='__cm'; o.textContent=id==='cCap'?cm.cap+' mAh (de la ficha)':'Incluido en el modelo'; e.value='__cm'; }
    else if(o) o.remove(); });
  ['cType','cFrame','cMotor','cProp','cEsc','cChem','cCells','cCap'].forEach(function(id){ $(id).disabled=!!cm; });
  document.querySelectorAll('#accList input').forEach(function(i){ var b=cm&&(cm.builtin.indexOf(i.dataset.a)>=0||!cm.allowAcc); i.disabled=!!b; i.parentNode.style.opacity=b?0.55:1; });
  $('cPay').disabled=!!cm&&!cm.allowPay;
  $('commHint').innerHTML=cm?'<b>Ficha fija del fabricante.</b> '+(cm.allowAcc?'Este modelo admite cambiar la carga útil (cámaras, sensores, lastre).':'Los componentes no son modificables.')+(cm.note?'<br>'+cm.note:''):'Elige un modelo comercial para cargar sus características publicadas, o deja la configuración libre para diseñar tu propia aeronave.';
  var card=$('commCard'); if(!cm){ card.style.display='none'; return; } card.style.display='';
  var h='<table class="tbl" style="width:100%;font-size:12px">'+cm.pub.map(function(r){ return '<tr><td style="color:var(--ink2);width:42%">'+r[0]+'</td><td>'+r[1]+'</td></tr>'; }).join('')+'</table>';
  h+='<div class="note"><b>Equivalente del simulador</b> (no son datos del fabricante): '+cm.est.join(' · ')+'. La masa, la batería, la autonomía y las velocidades máximas se han ajustado a la ficha.</div>';
  h+='<div class="note">Fuentes: '+cm.src.map(function(s){ return '<a href="'+s.u+'" target="_blank" rel="noopener">'+s.t+'</a>'; }).join(' · ')+'</div>';
  $('commBody').innerHTML=h;
}
SIM.syncComm=syncComm;
function buildStatic(){
  fill($('cType'),SD.TYPES.map(function(t){return [t.id,t.name];}),ST.cfg.type);
  fill($('cMotor'),SD.MOTORS.map(function(m){return [m.id,m.name+' · '+Math.round(m.m*1000)+' g · '+m.imax+' A'];}),ST.cfg.motor);
  fill($('cEsc'),SD.ESC.map(function(e){return [e,e+' A'];}),ST.cfg.esc);
  fill($('cChem'),SD.CHEM.map(function(c){return [c.id,c.name];}),ST.cfg.chem);
  var cells=[]; for(var i=1;i<=12;i++) cells.push([i,i+'S · '+(i*3.7).toFixed(1)+' V']); fill($('cCells'),cells,ST.cfg.cells);
  fill($('cCap'),SD.CAPS.map(function(c){return [c,c+' mAh'];}),ST.cfg.cap);
  var al=$('accList'); al.innerHTML='';
  SD.ACC.forEach(function(a){
    var l=document.createElement('label'); l.className='chk';
    l.innerHTML='<input type="checkbox" data-a="'+a.id+'"><div>'+a.name+' <span style="color:var(--ink2);font-family:var(--mono);font-size:11px">('+Math.round(a.m*1000)+' g · '+a.w+' W)</span><small>'+a.desc+'</small></div>';
    al.appendChild(l);
  });
  $('cPay').value=ST.cfg.pay;
  fillFrames(); fillProps(); buildComm();
  /* meteo */
  var wp=$('wxPre'); wp.innerHTML='';
  Object.keys(SD.WX).forEach(function(k){ var b=document.createElement('button'); b.className='btn'; b.dataset.k=k; b.textContent=SD.WX[k].name; wp.appendChild(b); });
  var tp=$('todPre'); tp.innerHTML=''; [['now','Ahora (reloj)'],['am','Mañana 9:00'],['noon','Mediodía solar'],['pm','Tarde'],['dusk','Puesta de Sol'],['night','Noche']].forEach(function(t){ var b=document.createElement('button'); b.className='btn'; b.dataset.t=t[0]; b.textContent=t[1]; tp.appendChild(b); });
  var sl=$('wxSl'); sl.innerHTML='';
  var defs=[['wind','Viento medio (m/s)',0,25,0.5],['dir','Procedencia (°)',0,359,5],['gust','Ráfagas (+ m/s)',0,15,0.5],['turb','Turbulencia (0–1)',0,1,0.05],['temp','Temperatura (°C)',-20,45,1],['qnh','Presión QNH (hPa)',970,1040,1],['vis','Visibilidad (km)',0.1,30,0.1],['rain','Lluvia (mm/h)',0,30,1],['elev','Cota del lugar (m)',0,3000,10]];
  defs.forEach(function(d){
    var r=document.createElement('div'); r.className='row';
    r.innerHTML='<label>'+d[1]+'</label><div class="val"><input type="range" data-w="'+d[0]+'" min="'+d[2]+'" max="'+d[3]+'" step="'+d[4]+'"><span></span></div>';
    sl.appendChild(r);
  });
  var info=document.createElement('div'); info.className='note'; info.id='wxInfo'; sl.appendChild(info);
  /* escenarios */
  var sc=$('scnList'); sc.innerHTML='';
  SW.LIST.forEach(function(m){
    var d=document.createElement('div'); d.className='sc'; d.dataset.id=m.id;
    d.innerHTML='<canvas width="300" height="110"></canvas><div class="t"><em>'+m.tag+'</em><b>'+m.name+'</b><p>'+m.desc+'</p></div>';
    sc.appendChild(d);
  });
  /* radio */
  fill($('rCl'),SD.CTRL_LINKS.map(function(l){return [l.id,l.name+' ('+l.f+' MHz)'];}),ST.rf.cl);
  fill($('rVl'),SD.VID_LINKS.map(function(l){return [l.id,l.name];}),ST.rf.vl);
  fill($('rCa'),SD.GANT.map(function(a){return [a.id,a.name];}),ST.rf.ca);
  fill($('rVa'),SD.GANT.map(function(a){return [a.id,a.name];}),ST.rf.va);
}
function syncTime(){
  var ms=SIM.flightMs(), cust=ST.dtMode==='custom';
  $('dtDate').value=SIM.dateStr(ms); $('dtTime').value=SIM.timeStr(ms); $('dtLat').value=ST.lat; $('dtLon').value=ST.lon;
  document.querySelectorAll('#todPre .btn').forEach(function(b){ b.classList.toggle('on',b.dataset.t==='now'&&!cust); });
  var sp=SIM.sunAt(ms), tm=SM.sunTimes(ms,ST.lat,ST.lon), tod=SIM.syncTod();
  var f=function(t){ return t?SIM.timeStr(t):'—'; }, off=-new Date(ms).getTimezoneOffset()/60;
  $('dtInfo').innerHTML='Sol: azimut <b>'+sp.az.toFixed(0)+'° ('+SIM.compass(sp.az)+')</b> · elevación <b>'+sp.el.toFixed(0)+'°</b>'+(sp.el<0?' (bajo el horizonte)':'')+' · orto '+f(tm.rise)+' · puesta '+f(tm.set)+' (hora local UTC'+(off>=0?'+':'')+off+') · iluminación: <b>'+({dia:'día',atardecer:'crepúsculo / sol bajo',noche:'noche'}[tod])+'</b>'+(tod==='noche'?' · exige luz verde intermitente':'')+(sp.el>0&&sp.el<25?' · <span style="color:var(--amber)">Sol bajo: cuidado al volar de cara al Sol</span>':'');
}
SIM.syncTime=syncTime;
function syncCtrls(){
  var c=ST.cfg;
  if(c.comm&&!SD.byId(SD.COMM,c.comm)) delete c.comm;
  $('cType').value=c.type; fillFrames(); $('cFrame').value=c.frame; fillProps(); if(c.prop) $('cProp').value=c.prop;
  $('cMotor').value=c.motor; $('cEsc').value=c.esc; $('cChem').value=c.chem; $('cCells').value=c.cells; $('cCap').value=c.cap; $('cPay').value=c.pay;
  document.querySelectorAll('#accList input').forEach(function(i){ i.checked=c.acc.indexOf(i.dataset.a)>=0; });
  $('cPayV').textContent=c.pay+' g';
  syncComm();
  /* meteo */
  document.querySelectorAll('#wxPre .btn').forEach(function(b){ b.classList.toggle('on',b.dataset.k===ST.wxId); });
  syncTime();
  $('oBirds').value=ST.birds; $('oBirdsV').textContent=ST.birds?ST.birds+' / 10':'sin aves'; $('oKites').value=ST.kites; $('oKitesV').textContent=ST.kites?ST.kites+' / 10':'sin cometas'; $('oPeople').checked=ST.people;
  var indoor=(ST.scn==='nave'); $('oBirds').disabled=indoor; $('oKites').disabled=indoor; $('oPeople').disabled=indoor; $('actNote').style.display=indoor?'block':'none';
  var elev=ST.elevOv!==null?ST.elevOv:SW_ELEV(ST.scn);
  document.querySelectorAll('#wxSl input').forEach(function(i){ var k=i.dataset.w, v=(k==='elev')?elev:ST.wx[k]; i.value=v; var s=i.parentNode.querySelector('span'); s.textContent=(k==='vis'?(+v).toFixed(1):v)+''; });
  document.querySelectorAll('.sc').forEach(function(d){ d.classList.toggle('on',d.dataset.id===ST.scn); });
  $('oJam').checked=ST.jam; $('oNoise').value=ST.rfNoise; $('oNoiseV').textContent='+'+ST.rfNoise+' dB'; $('oTrail').checked=ST.trail;
  var r=ST.rf;
  $('rCl').value=r.cl; $('rVl').value=r.vl; $('rCa').value=r.ca; $('rVa').value=r.va; $('rFl').value=r.fl; $('rFb').value=r.fb; $('rAlt').value=r.alt; $('rAltV').textContent=r.alt+' m'; $('rObs').checked=r.obs;
  fillPw('rCp',SD.byId(SD.CTRL_LINKS,r.cl),r.cp); fillPw('rVp',SD.byId(SD.VID_LINKS,r.vl),r.vp);
}
var ELEVS={campo:50,ciudad:30,barrio:40,bosque:400,montana:1800,costa:5,nave:50,aeropuerto:8};
function SW_ELEV(id){return ELEVS[id]||0;}
SIM.elev=function(){ return ST.elevOv!==null?ST.elevOv:SW_ELEV(ST.scn); };
function fillPw(id,L,cur){ var s=$(id); fill(s,L.powers.map(function(p){return [p,p+' mW'+(p>L.lim?'  ⚠':'')];}),cur); if(L.powers.indexOf(+cur)<0){ s.value=L.powers[1]||L.powers[0]; } }

function legalNote(L,pw,el){
  var dbm=SM.dbmFromMw(pw);
  var ok=pw<=L.lim;
  el.className='legal '+(ok?'ok':'bad');
  el.innerHTML=(ok?'✔ ':'✘ ')+pw+' mW ('+dbm.toFixed(1)+' dBm) '+(ok?'dentro':'<b>por encima</b>')+' del límite orientativo de '+L.lim+' mW en la UE.'+(ok?'':' Volar así sería una infracción de radio.');
}
var warnedRF=false;

/* ---------- validación y estadísticas ---------- */
SIM.validate=function(){
  V=SM.validate(ST.cfg); var I=V.info, ac=V.ac;
  var kind=ac.kind;
  var st=$('stats');
  function cell(l,v,cls){ return '<div class="'+(cls||'')+'"><label>'+l+'</label><b>'+v+'</b></div>'; }
  var h='';
  h+=cell('Masa total',(I.mass*1000).toFixed(0)+' g');
  h+=cell('Peso',I.weight.toFixed(1)+' N');
  if(kind==='fixed'){
    h+=cell('Empuje estático',I.Tmax.toFixed(1)+' N', I.twr<0.3?'bad':'');
    h+=cell('Vel. pérdida Vs',I.Vs.toFixed(1)+' m/s',I.Vs>14?'mid':'');
    h+=cell('Vel. crucero',(I.cruiseV*1.25).toFixed(0)+' m/s');
    h+=cell('Planeo L/D',I.LD.toFixed(1));
    h+=cell('Carga alar',I.wingLoad.toFixed(2)+' kg/m²');
    h+=cell('Autonomía crucero','≈ '+I.cruiseMin.toFixed(0)+' min');
  } else {
    h+=cell('Empuje máx.',I.Tmax.toFixed(1)+' N');
    h+=cell('Empuje / peso',I.twr.toFixed(2),I.twr<1.25?'bad':(I.twr<2?'mid':''));
    h+=cell('Gas en estacionario',(I.hoverThr*100).toFixed(0)+' %',I.hoverThr>0.8?'mid':'');
    h+=cell('Potencia estacionario',I.hoverW.toFixed(0)+' W');
    h+=cell('Autonomía estac.','≈ '+I.hoverMin.toFixed(1)+' min',I.hoverMin<5?'mid':'');
    h+=cell('Corriente máx.',I.Itot.toFixed(0)+' A',I.Itot>I.capA?'mid':'');
  }
  h+=cell('Batería',I.battWh.toFixed(0)+' Wh · '+(I.battMass*1000).toFixed(0)+' g');
  h+=cell('Descarga máx. batería',I.capA.toFixed(0)+' A');
  h+=cell('Categoría UE',I.cat.split(' · ')[0]);
  h+=cell('Registro operador',I.needReg?'Obligatorio':'No exigido');
  st.innerHTML=h;
  var vl=$('valList'); vl.innerHTML='';
  V.errors.forEach(function(e){ var li=document.createElement('li'); li.className='e'; li.innerHTML='<b>✘ Configuración no válida.</b> '+e; vl.appendChild(li); });
  V.warns.forEach(function(e){ var li=document.createElement('li'); li.className='w'; li.innerHTML='<b>⚠</b> '+e; vl.appendChild(li); });
  if(!V.errors.length && !V.warns.length){ var li=document.createElement('li'); li.className='o'; li.innerHTML='✔ La configuración es coherente: motores, ESC, batería y peso están equilibrados.'; vl.appendChild(li); }
  else if(!V.errors.length){ var li2=document.createElement('li'); li2.className='o'; li2.innerHTML='✔ Puede volar (revisa los avisos).'; vl.appendChild(li2); }
  var fs=$('flySt');
  if(V.errors.length){ fs.className='st bad'; fs.textContent='✘ Esta configuración no tiene sentido físico: corrígela para poder volar ('+V.errors.length+' error'+(V.errors.length>1?'es':'')+').'; $('bFly').disabled=true; }
  else { fs.className='st ok'; fs.textContent='✔ Lista para volar · '+(ac.cm?ac.cm.maker+' '+ac.cm.name:ac.type.name)+' · '+(I.mass*1000).toFixed(0)+' g · '+I.cat; $('bFly').disabled=false; }
  /* legalidad radio */
  var cl=SD.byId(SD.CTRL_LINKS,ST.rf.cl), vl2=SD.byId(SD.VID_LINKS,ST.rf.vl);
  legalNote(cl,ST.rf.cp,$('legC')); legalNote(vl2,ST.rf.vp,$('legV'));
  var ws=SM.beaufort(ST.wx.wind);
  var wi=$('wxInfo'); if(wi){ var fr=ac.frame; var rho=SM.atmo(SIM.elev(),ST.wx.qnh,ST.wx.temp,0).rho;
    wi.innerHTML='Beaufort <b>'+ws+'</b> · densidad del aire <b>'+rho.toFixed(3)+' kg/m³</b> (altitud de densidad ≈ '+Math.round(SM.densAlt(rho)+0)+' m) · máx. viento recomendado para este dron: <b>'+fr.maxWind+' m/s</b>'+(ST.wx.wind+ST.wx.gust>fr.maxWind?' <span style="color:var(--red)">· ⚠ rachas por encima</span>':'')+(ST.wx.temp<=2&&(ST.wx.rain>0||ST.wx.vis<2)?' <span style="color:var(--red)">· ⚠ riesgo de engelamiento</span>':''); }
  return V;
};

/* ---------- eventos del hangar ---------- */
function wire(){
  function chg(fn){ return function(e){ fn(e); syncAfter(); }; }
  function syncAfter(){ SIM.validate(); SIM.save(); }
  $('cComm').onchange=function(){ var id=this.value;
    if(id){ var cm=SD.byId(SD.COMM,id); ST.cfg=Object.assign({},SD.commCfg(cm)); }
    else { var t=ST.cfg.type; ST.cfg={type:t}; Object.assign(ST.cfg,JSON.parse(JSON.stringify(SD.STD[t]))); }
    syncCtrls(); syncAfter(); };
  $('cType').onchange=function(){ delete ST.cfg.comm; ST.cfg.type=this.value; var s=SD.STD[ST.cfg.type]; Object.assign(ST.cfg,JSON.parse(JSON.stringify(s))); syncCtrls(); syncAfter(); };
  $('cFrame').onchange=chg(function(){ ST.cfg.frame=$('cFrame').value; });
  $('cMotor').onchange=chg(function(){ ST.cfg.motor=$('cMotor').value; });
  $('cProp').onchange=chg(function(){ ST.cfg.prop=$('cProp').value; });
  $('cEsc').onchange=chg(function(){ ST.cfg.esc=+$('cEsc').value; });
  $('cChem').onchange=chg(function(){ ST.cfg.chem=$('cChem').value; });
  $('cCells').onchange=chg(function(){ ST.cfg.cells=+$('cCells').value; });
  $('cCap').onchange=chg(function(){ ST.cfg.cap=+$('cCap').value; });
  $('cPay').oninput=chg(function(){ ST.cfg.pay=+$('cPay').value; $('cPayV').textContent=ST.cfg.pay+' g'; });
  $('bStd').onclick=function(){ if(ST.cfg.comm) return; var f=ST.cfg.frame; Object.assign(ST.cfg,JSON.parse(JSON.stringify(SD.STD[ST.cfg.type]))); syncCtrls(); syncAfter(); };
  function interior(acc){ ST.cfg=Object.assign({type:'quad'},JSON.parse(JSON.stringify(SD.STD.quad))); ST.cfg.acc=acc; ST.scn='nave'; ST.elevOv=null; ST.wxId='calma'; ST.wx=Object.assign({},SD.WX.calma); syncCtrls(); syncAfter(); }
  $('bInt1').onclick=function(){ interior(['camfpv','lr-f','lr-b','lr-l','lr-r','lr-u','lr-d','flow','rid']); };
  $('bInt2').onclick=function(){ interior(['camfpv','lidar','lr-u','lr-d','flow','rid']); };
  $('accList').onchange=chg(function(e){ var a=e.target.dataset.a, i=ST.cfg.acc.indexOf(a); if(e.target.checked&&i<0) ST.cfg.acc.push(a); if(!e.target.checked&&i>=0) ST.cfg.acc.splice(i,1); });
  $('wxPre').onclick=function(e){ var k=e.target.dataset&&e.target.dataset.k; if(!k) return; ST.wxId=k; ST.wx=Object.assign({},SD.WX[k]); syncCtrls(); syncAfter(); };
  function setCustom(ms){ ST.dtMode='custom'; ST.dtDate=SIM.dateStr(ms); ST.dtTime=SIM.timeStr(ms); }
  $('todPre').onclick=function(e){ var t=e.target.dataset&&e.target.dataset.t; if(!t) return;
    if(t==='now'){ ST.dtMode='now'; }
    else { var base=SIM.flightMs(), tm=SM.sunTimes(base,ST.lat,ST.lon), d=new Date(base), ms;
      if(t==='am') ms=new Date(d.getFullYear(),d.getMonth(),d.getDate(),9,0).getTime();
      else if(t==='noon') ms=tm.noon; else if(t==='pm') ms=(tm.set||tm.noon+6*3600000)-100*60000;
      else if(t==='dusk') ms=(tm.set||tm.noon+6*3600000)-10*60000; else ms=(tm.set||tm.noon+6*3600000)+100*60000;
      setCustom(ms); }
    syncCtrls(); syncAfter(); };
  function dtInput(){ var d=$('dtDate').value, t=$('dtTime').value; if(d&&t){ ST.dtMode='custom'; ST.dtDate=d; ST.dtTime=t; } syncTime(); SIM.validate(); SIM.save(); }
  $('dtDate').onchange=dtInput; $('dtTime').onchange=dtInput;
  function llInput(){ var la=parseFloat($('dtLat').value), lo=parseFloat($('dtLon').value); if(!isNaN(la)) ST.lat=Math.max(-66,Math.min(66,la)); if(!isNaN(lo)) ST.lon=Math.max(-180,Math.min(180,lo)); syncTime(); SIM.validate(); SIM.save(); }
  $('dtLat').onchange=llInput; $('dtLon').onchange=llInput;
  $('bLoc').onclick=function(){ ST.lat=36.7770; ST.lon=-4.3930; syncTime(); SIM.validate(); SIM.save(); };
  $('oBirds').oninput=function(){ ST.birds=+$('oBirds').value; $('oBirdsV').textContent=ST.birds?ST.birds+' / 10':'sin aves'; SIM.save(); };
  $('oKites').oninput=function(){ ST.kites=+$('oKites').value; $('oKitesV').textContent=ST.kites?ST.kites+' / 10':'sin cometas'; SIM.save(); };
  $('oPeople').onchange=function(){ ST.people=$('oPeople').checked; SIM.save(); };
  $('wxSl').oninput=function(e){ var k=e.target.dataset.w; if(!k) return; var v=parseFloat(e.target.value); if(k==='elev') ST.elevOv=v; else ST.wx[k]=v; ST.wxId='custom'; e.target.parentNode.querySelector('span').textContent=(k==='vis'?v.toFixed(1):v); document.querySelectorAll('#wxPre .btn').forEach(function(b){b.classList.remove('on');}); SIM.validate(); SIM.save(); };
  $('scnList').onclick=function(e){ var d=e.target.closest('.sc'); if(!d) return; ST.scn=d.dataset.id; ST.elevOv=null; var m=SW.LIST.filter(function(x){return x.id===ST.scn;})[0]; var DEF=[36.7770,-4.3930], pre=SW.LIST.filter(function(x){return x.lat;}).map(function(x){return [x.lat,x.lon];}); pre.push(DEF); if(pre.some(function(p){return Math.abs(p[0]-ST.lat)<1e-6&&Math.abs(p[1]-ST.lon)<1e-6;})){ var t=m.lat?[m.lat,m.lon]:DEF; ST.lat=t[0]; ST.lon=t[1]; syncTime(); }
    if(ST.wxId!=='custom'||true){ ST.wxId=m.wx; ST.wx=Object.assign({},SD.WX[m.wx]); } syncCtrls(); syncAfter(); };
  $('oJam').onchange=chg(function(){ ST.jam=$('oJam').checked; });
  $('oNoise').oninput=chg(function(){ ST.rfNoise=+$('oNoise').value; $('oNoiseV').textContent='+'+ST.rfNoise+' dB'; });
  $('oTrail').onchange=chg(function(){ ST.trail=$('oTrail').checked; });
  $('rCl').onchange=chg(function(){ ST.rf.cl=$('rCl').value; var L=SD.byId(SD.CTRL_LINKS,ST.rf.cl); fillPw('rCp',L,ST.rf.cp); ST.rf.cp=+$('rCp').value; });
  $('rCp').onchange=chg(function(){ ST.rf.cp=+$('rCp').value; });
  $('rVl').onchange=chg(function(){ ST.rf.vl=$('rVl').value; var L=SD.byId(SD.VID_LINKS,ST.rf.vl); fillPw('rVp',L,ST.rf.vp); ST.rf.vp=+$('rVp').value; });
  $('rVp').onchange=chg(function(){ ST.rf.vp=+$('rVp').value; });
  $('rCa').onchange=chg(function(){ ST.rf.ca=$('rCa').value; });
  $('rVa').onchange=chg(function(){ ST.rf.va=$('rVa').value; });
  $('rFl').onchange=chg(function(){ ST.rf.fl=$('rFl').value; });
  $('rFb').onchange=chg(function(){ ST.rf.fb=$('rFb').value; });
  $('rAlt').oninput=chg(function(){ ST.rf.alt=+$('rAlt').value; $('rAltV').textContent=ST.rf.alt+' m'; });
  $('rObs').onchange=chg(function(){ ST.rf.obs=$('rObs').checked; });
  $('tabs').onclick=function(e){ var t=e.target.closest('.tab'); if(!t) return; document.querySelectorAll('.tab').forEach(function(x){x.classList.toggle('on',x===t);}); document.querySelectorAll('.pg').forEach(function(p,i){p.classList.toggle('on',i==t.dataset.p);}); };
}
SIM.refreshAll=function(){ syncCtrls(); SIM.validate(); SIM.save(); };
SIM.initHangar=function(){
  buildStatic(); syncCtrls(); wire(); SIM.validate(); if(SIM.apInit) SIM.apInit();
  /* miniaturas de escenarios */
  setTimeout(function(){
    document.querySelectorAll('.sc').forEach(function(d){
      var id=d.dataset.id, w=SW.make(id), r=SIM.mapRaster(w,150,SCN_EXT[id]), cv=d.querySelector('canvas'), g=cv.getContext('2d');
      g.imageSmoothingEnabled=true; var ar=cv.width/cv.height; var sh=r.canvas.height/ar; g.drawImage(r.canvas,0,(r.canvas.height-sh)/2,r.canvas.width,sh,0,0,cv.width,cv.height);
      var hx=(w.home.x+r.ext)/r.step/r.canvas.width*cv.width, hy=((w.home.z+r.ext)/r.step-(r.canvas.height-sh)/2)/sh*cv.height;
      g.fillStyle='#f5c842'; g.strokeStyle='#14283a'; g.lineWidth=1.5; g.beginPath(); g.arc(hx,hy,5,0,6.3); g.fill(); g.stroke();
    });
  },50);
};
})();
