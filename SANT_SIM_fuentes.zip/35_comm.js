/* ===== AERONAVES COMERCIALES: ficha del fabricante + equivalente físico calibrado ===== */
/* Cada modelo guarda (a) los datos PUBLICADOS por el fabricante (pub) y (b) los parámetros que el simulador necesita y el
   fabricante no publica (hélice, motor, ...): se calculan para que masa, batería, autonomía y velocidad máxima coincidan con la ficha. */
(function(){
var deg=Math.PI/180, G=SD.G, RHO=1.225;
SD.COMM=[];
function dimsOf(s){ return SD.propDims(s); }

/* r = datos de partida; devuelve el modelo ya calibrado */
function make(r){
  var Vn=r.cells*r.vc, nm=r.type==='quad'?4:1;
  var cm={id:r.id,maker:r.maker,name:r.name,type:r.type,mass:r.mass,cells:r.cells,cap:r.cap,esc:r.esc||60,prop:r.prop,
    builtin:r.builtin||[],allowAcc:!!r.allowAcc,allowPay:!!r.allowPay,eu:r.eu,pub:r.pub,est:r.est||[],src:r.src||[],note:r.note||'',
    ap:r.ap||null,avW:r.avW||1.5,pK:1};
  var battMass=r.battMass, Wh=r.Wh;
  cm.chem={id:'c-'+r.id,name:r.chemName,vc:r.vc,wh:Wh/battMass,c:r.cr||8,hi:false};
  cm.cap=Math.round(Wh/Vn*1000);                     /* mAh equivalentes a la tensión nominal usada */
  var pd=dimsOf(r.prop), ct=SM.propCoef(pd.Din,pd.P).ct;
  if(r.type==='quad'){
    var W=r.mass*G, Teach=r.twr*W/nm, n=Math.sqrt(Teach/(ct*RHO*Math.pow(pd.D,4))), kv=n*60/(0.72*Vn*1.05);
    var tilt=r.tilt, vm=r.vmax, cdA=0.84*r.mass*G*Math.tan(r.tiltV*deg)/(0.5*RHO*vm*vm);
    cm.motor={id:'m-'+r.id,name:'Motor equivalente · '+Math.round(kv)+' KV',kv:kv,m:r.motorMass,imax:999,maxS:r.cells+2};
    cm.frame={id:'f-'+r.id,type:'quad',name:r.name,m:0.01,dim:r.dim,maxProp:pd.Din+0.5,maxPay:r.allowAcc?r.maxPay:0,cdA:cdA,maxWind:r.wind,tilt:tilt,yawRate:r.yaw};
    cm.spec={vmax:r.vmax,vUp:r.vUp,vDn:r.vDn,ceiling:r.ceiling};
  } else {
    var fw=r.fw; var Tstat=r.tstat*r.mass*G;
    var nmx=r.vpTarget/(0.0254*pd.P*0.85), kvf=nmx*60/(0.72*Vn*1.05);   /* rpm tales que la hélice da la velocidad máxima publicada con margen */
    cm.motor={id:'m-'+r.id,name:'Motor equivalente · '+Math.round(kvf)+' KV',kv:kvf,m:r.motorMass,imax:999,maxS:r.cells+2};
    cm.frame={id:'f-'+r.id,type:'fw-long',name:r.name,m:0.01,dim:fw.b,b:fw.b,S:fw.S,CL0:fw.CL0,CLa:fw.CLa,CD0:fw.CD0,e:fw.e,aMax:fw.aMax,maxProp:pd.Din+0.5,maxPay:0,cdA:0,maxWind:r.wind,vne:fw.vne};
    cm.spec={vmax:fw.vne,ceiling:r.ceiling};
  }
  SD.COMM.push(cm);
  /* calibración de potencia: la autonomía en estacionario (o crucero) del simulador = la publicada */
  var cfg=SD.commCfg(cm), ac=SM.build(cfg), pa=ac.avW+ac.accW;
  if(r.type==='quad'){
    var Th=ac.W/ac.nMotors, hp=SM.rotorPower(ac,Th,RHO).P, Ptgt=Wh*60/r.tHover;
    cm.pK=Math.max(0.2,(Ptgt-pa)*(ac.effM*ac.effE)/(ac.nMotors*hp));
  } else { cm.pK=r.pK||1; }
  cm.tHover=r.tHover;
  return cm;
}

/* cfg estándar de un modelo comercial (la entrada de SM.build) */
SD.commCfg=function(cm,old){
  return {type:cm.type,comm:cm.id,frame:cm.frame.id,motor:cm.motor.id,prop:cm.prop,esc:cm.esc,chem:cm.chem.id,cells:cm.cells,cap:cm.cap,
          acc:cm.builtin.slice(),pay:0};
};

/* ---------------- datos (ficha del fabricante) ---------------- */
var SRC_DJI=function(u,t){ return {t:t,u:u}; };

make({id:'tello',maker:'Ryze / DJI',name:'Tello',type:'quad',mass:0.080,dim:0.10,
  cells:1,vc:3.8,Wh:4.18,battMass:0.026,chemName:'LiPo 1S 1100 mAh',cr:10,
  prop:'3x3',twr:1.9,tilt:35,tiltV:30,vmax:8,vUp:2.5,vDn:2,yaw:100,wind:4,ceiling:30,tHover:13,
  motorMass:0.006,builtin:['camhd'],esc:6,eu:'C0 · subcategoría A1',avW:1.0,
  ap:{fenceOn:true,fenceAltMax:30,fenceRadius:100,fenceAct:'rth'},
  pub:[['Masa','80 g (87 g con protectores)'],['Dimensiones','98 × 92,5 × 41 mm'],['Autonomía máx.','13 min'],['Velocidad máx.','28,8 km/h (8 m/s)'],['Alcance máx.','100 m'],['Altura máx.','30 m'],['Batería','LiPo 3,8 V · 1100 mAh · 4,18 Wh'],['Hélices','2 palas, Ø 76 mm (DJI 3044P)'],['Cámara','5 MP · vídeo 720p']],
  est:['Hélice y motor equivalentes','Velocidad ascenso/descenso','Velocidad de guiñada','Viento máximo (no publicado)'],
  src:[{t:'Ficha del fabricante recogida en Wikipedia: Ryze Tello',u:'https://en.wikipedia.org/wiki/Ryze_Tello'}],
  note:'Geovalla de fábrica de 30 m de altura y 100 m de distancia (límites publicados), que aquí provoca un regreso a casa.'});

make({id:'dji-mini4pro',maker:'DJI',name:'Mini 4 Pro',type:'quad',mass:0.249,dim:0.30,
  cells:2,vc:3.66,Wh:18.96,battMass:0.0779,chemName:'Li-ion 2S 2590 mAh',cr:12,
  prop:'5x3',twr:2.2,tilt:35,tiltV:35,vmax:16,vUp:5,vDn:5,yaw:120,wind:10.7,ceiling:4000,tHover:30,
  motorMass:0.012,builtin:['camhd','obs'],esc:20,eu:'C0 · subcategoría A1',avW:2.0,
  pub:[['Masa al despegue','< 249 g'],['Dimensiones plegado','148 × 94 × 64 mm'],['Dimensiones desplegado','298 × 373 × 101 mm'],['Velocidad ascenso / descenso máx.','5 m/s (modo S y N) · 3 m/s (modo C)'],['Velocidad horizontal máx.','16 m/s (S) · 12 m/s (N y C)'],['Resistencia al viento','10,7 m/s'],['Autonomía máx. / en estacionario','34 min / 30 min'],['Altitud máx. de despegue','4000 m'],['Ángulo de cabeceo máx.','35°'],['Batería','Li-ion · 2590 mAh · 7,32 V · 18,96 Wh · 77,9 g'],['Alcance de vídeo (CE)','10 km (sin obstáculos ni interferencias)'],['Clase UE','C0'],['Cámara','CMOS 1/1,3″ · 48 MP'],['Temperatura de uso','−10 a 40 °C']],
  est:['Hélice y motor equivalentes','Velocidad de guiñada'],
  src:[{t:'DJI · Mini 4 Pro · Especificaciones',u:'https://www.dji.com/mini-4-pro/specs'}]});

make({id:'dji-mini5pro',maker:'DJI',name:'Mini 5 Pro',type:'quad',mass:0.2499,dim:0.31,
  cells:2,vc:3.5,Wh:19.52,battMass:0.0712,chemName:'Li-ion 2S 2788 mAh',cr:12,
  prop:'5x3',twr:2.3,tilt:38,tiltV:38,vmax:18,vUp:10,vDn:6,yaw:120,wind:12,ceiling:6000,tHover:31.8,
  motorMass:0.012,builtin:['camhd','obs'],esc:20,eu:'C0 · subcategoría A1',avW:2.0,
  pub:[['Masa al despegue','249,9 g (± 4 g)'],['Dimensiones plegado','157 × 95 × 68 mm'],['Dimensiones desplegado','304 × 380 × 91 mm'],['Velocidad ascenso máx.','10 m/s (S) · 6 m/s (N) · 3 m/s (C)'],['Velocidad descenso máx.','6 m/s (S y N) · 3 m/s (C)'],['Velocidad horizontal máx.','18 m/s (modo S)'],['Resistencia al viento','12 m/s'],['Autonomía máx. / típica','36 min / 21 min'],['Altitud máx. de despegue','6000 m'],['Ángulo de cabeceo máx.','38°'],['Batería','Li-ion · 2788 mAh · 7 V · 19,52 Wh · 71,2 g'],['Alcance de vídeo (CE)','10 km'],['Clase UE','C0'],['Cámara','CMOS 1″ · 50 MP · 24 mm · f/1,8'],['Sensores','Visión binocular omnidireccional + LiDAR frontal']],
  est:['Hélice y motor equivalentes','Velocidad de guiñada','Autonomía en estacionario (no publicada: se estima en el 88 % de la autonomía máx., como en el Mini 4 Pro)'],
  src:[{t:'DJI · Mini 5 Pro · Especificaciones (región Grecia)',u:'https://www.dji.com/gr/mini-5-pro/specs'}]});

make({id:'dji-air3s',maker:'DJI',name:'Air 3S',type:'quad',mass:0.724,dim:0.40,
  cells:4,vc:3.65,Wh:62.5,battMass:0.247,chemName:'Li-ion 4S 4276 mAh',cr:8,
  prop:'7x4',twr:2.0,tilt:36,tiltV:36,vmax:19,vUp:10,vDn:10,yaw:100,wind:12,ceiling:6000,tHover:41,
  motorMass:0.03,builtin:['camhd','obs','rid'],esc:30,eu:'C1 · subcategoría A1',avW:3.0,
  pub:[['Masa al despegue','724 g'],['Dimensiones plegado','214,19 × 100,63 × 89,17 mm'],['Dimensiones desplegado','266,11 × 325,47 × 106 mm'],['Velocidad ascenso / descenso máx.','10 m/s'],['Velocidad horizontal máx.','21 m/s (19 m/s en la UE)'],['Resistencia al viento','12 m/s'],['Autonomía máx. / en estacionario','45 min / 41 min'],['Altitud máx. de despegue','6000 m'],['Ángulo de cabeceo máx.','36°'],['Batería','Li-ion 4S · 4276 mAh · 14,6 V · 62,5 Wh · 247 g'],['Alcance de vídeo (CE)','10 km'],['Clase UE','C1'],['Cámaras','CMOS 1″ 50 MP (24 mm) + CMOS 1/1,3″ 48 MP (70 mm)'],['Sensores','Visión omnidireccional + LiDAR frontal + infrarrojo inferior']],
  est:['Hélice y motor equivalentes','Velocidad de guiñada','Límite de 19 m/s (región UE) en lugar de 21 m/s'],
  src:[{t:'DJI · Air 3S · Especificaciones',u:'https://www.dji.com/air-3s/specs'}]});

make({id:'dji-mavic4pro',maker:'DJI',name:'Mavic 4 Pro',type:'quad',mass:1.063,dim:0.42,
  cells:4,vc:3.58,Wh:95.3,battMass:0.332,chemName:'Li-ion 4S 6654 mAh',cr:8,
  prop:'9x4',twr:2.0,tilt:35,tiltV:35,vmax:25,vUp:10,vDn:10,yaw:100,wind:12,ceiling:6000,tHover:45,
  motorMass:0.045,builtin:['camhd','obs','rid'],esc:30,eu:'C2 · subcategoría A2',avW:3.5,
  pub:[['Masa al despegue','≈ 1063 g'],['Dimensiones plegado','257,6 × 124,8 × 106,6 mm'],['Dimensiones desplegado','328,7 × 390,5 × 135,2 mm'],['Velocidad ascenso / descenso máx.','10 m/s (modo S) · 6 m/s (N y C)'],['Velocidad horizontal máx.','25 m/s (modo S, sin viento)'],['Resistencia al viento','12 m/s'],['Autonomía máx. / en estacionario','51 min / 45 min'],['Altitud máx. de despegue','6000 m'],['Ángulo de cabeceo máx.','35°'],['Batería','Li-ion 4S · 6654 mAh · 14,32 V · 95,3 Wh · 332 g'],['Alcance de vídeo (CE)','15 km'],['Clase UE','C2'],['Cámaras','4/3″ 100 MP (Hasselblad) + 1/1,3″ 48 MP + 1/1,5″ 50 MP'],['Sensores','Visión omnidireccional + LiDAR frontal + infrarrojo inferior']],
  est:['Hélice y motor equivalentes','Velocidad de guiñada'],
  src:[{t:'DJI Mavic 4 Pro · especificaciones (copia de la ficha de DJI en PDF de un distribuidor)',u:'https://www.cliftoncameras.co.uk/uploads/specifications/DJI%20Mavic%204%20Pro%20Specification.pdf'}]});

make({id:'dji-avata2',maker:'DJI',name:'Avata 2 (FPV)',type:'quad',mass:0.377,dim:0.21,
  cells:4,vc:3.69,Wh:31.7,battMass:0.145,chemName:'Li-ion 4S 2150 mAh',cr:15,
  prop:'3.5x3',twr:3.3,tilt:60,tiltV:42,vmax:19,vUp:9,vDn:9,yaw:300,wind:10.7,ceiling:5000,tHover:21,
  motorMass:0.02,builtin:['camfpv','rid'],esc:30,eu:'C1 · subcategoría A1',avW:2.5,
  pub:[['Masa al despegue','≈ 377 g'],['Dimensiones','185 × 212 × 64 mm'],['Velocidad ascenso / descenso máx.','6 m/s (Normal) · 9 m/s (Sport)'],['Velocidad horizontal máx.','8 m/s (Normal) · 16 m/s (Sport) · 27 m/s (Manual; 19 m/s en la UE)'],['Resistencia al viento','10,7 m/s (nivel 5)'],['Autonomía máx. / en estacionario','≈ 23 min / ≈ 21 min'],['Altitud máx. de despegue','5000 m'],['Batería','Li-ion · 2150 mAh · 14,76 V · 31,7 Wh · 145 g'],['Alcance de vídeo (CE)','10 km'],['Clase UE','C1'],['Cámara','CMOS 1/1,3″ · 12 MP'],['Temperatura de uso','−10 a 40 °C']],
  est:['Hélice y motor equivalentes','Ángulo de inclinación en modo Manual (no publicado)','Velocidad de guiñada','Velocidad máxima: 19 m/s del modo Manual UE'],
  src:[{t:'DJI · Avata 2 · Especificaciones',u:'https://www.dji.com/avata-2/specs'}],
  note:'Se vuela con el modo «ATTI» (Q) para el comportamiento manual de los FPV.'});

make({id:'dji-m350',maker:'DJI Enterprise',name:'Matrice 350 RTK',type:'quad',mass:6.47,dim:0.90,
  cells:12,vc:3.73,Wh:526.4,battMass:2.70,chemName:'Li-ion 2 × TB65 (12S) 2 × 5880 mAh',cr:6,
  prop:'21x10',twr:2.3,tilt:30,tiltV:30,vmax:23,vUp:6,vDn:5,yaw:100,wind:12,ceiling:5000,tHover:55,
  motorMass:0.19,builtin:['rtk','obs','rid'],allowAcc:true,allowPay:true,maxPay:2.7,esc:80,eu:'Sin marcado de clase · categoría específica',avW:12,
  pub:[['Masa sin baterías (con gimbal)','≈ 3,77 kg'],['Masa con 2 baterías TB65','≈ 6,47 kg'],['Masa máx. al despegue','9,2 kg'],['Dimensiones desplegado (sin hélices)','810 × 670 × 430 mm'],['Distancia diagonal','895 mm'],['Carga útil máx. (1 gimbal)','960 g'],['Velocidad ascenso máx.','6 m/s'],['Velocidad descenso máx.','5 m/s'],['Velocidad horizontal máx.','23 m/s'],['Resistencia al viento','12 m/s'],['Autonomía máx. (sin carga, ≈ 8 m/s)','55 min'],['Altitud máx.','5000 m (hélices 2110s) · 7000 m (2112)'],['Ángulo de cabeceo máx.','30° (25° en modo N con visión frontal)'],['Velocidad angular máx.','cabeceo 300°/s · guiñada 100°/s'],['Baterías','2 × TB65 · 5880 mAh · 44,76 V · 263,2 Wh · 1,35 kg c/u'],['Protección','IP55'],['Alcance de vídeo (CE)','8 km'],['Temperatura de uso','−20 a 50 °C']],
  est:['Hélice y motor equivalentes','Autonomía en estacionario igualada a la autonomía máx. publicada'],
  src:[{t:'DJI Enterprise · Matrice 350 RTK · Especificaciones',u:'https://enterprise.dji.com/matrice-350-rtk/specs'}],
  note:'Admite cambiar la carga útil: elige cámaras, LiDAR o lastre. La autonomía baja al subir la masa.'});

make({id:'ebee-x',maker:'AgEagle (senseFly)',name:'eBee X',type:'fw-long',mass:1.6,dim:1.16,
  cells:4,vc:3.65,Wh:80,battMass:0.45,chemName:'Li-ion 4S (batería de autonomía, estimada)',cr:5,
  prop:'9x8',vpTarget:40,vmax:30,wind:12.8,ceiling:4500,tHover:90,
  motorMass:0.07,builtin:['camhd','rid'],esc:40,eu:'Categoría específica',avW:4,
  fw:{b:1.16,S:0.20,CL0:0.40,CLa:5.0,CD0:0.024,e:0.88,aMax:13,vne:35},pK:0.77,
  pub:[['Masa máx. al despegue','1,6 kg'],['Envergadura','116 cm'],['Autonomía máx.','90 min (batería de autonomía + cámara S.O.D.A.)'],['Velocidad de crucero','11–30 m/s (40–110 km/h)'],['Resistencia al viento','hasta 12,8 m/s (46 km/h)'],['Alcance del radioenlace','3 km nominal (hasta 8 km)'],['Aterrizaje','automático lineal, precisión 5 m en cono de 35°'],['Temperatura de uso','−15 a 40 °C']],
  est:['Superficie alar y polar aerodinámica (no publicadas)','Capacidad de la batería (no publicada: ≈ 80 Wh)','Hélice y motor equivalentes','Potencia calibrada para ≈ 90 min en crucero'],
  src:[{t:'AgEagle · eBee X · folleto 2026',u:'https://www.thefuture3d.com/spec-sheets/ageagle/AgEagle_eBee_X__Brochure_2026_EN.pdf'}],
  note:'Ala fija: se despega lanzándolo con gas a fondo y se aterriza con B (toma asistida).'});

SD.COMM_LIST=SD.COMM;
})();
if(typeof module!=='undefined') module.exports=SD;
